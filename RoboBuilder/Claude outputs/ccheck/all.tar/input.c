﻿#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <windows.h>
#include <windowsx.h>  // GET_X_LPARAM/GET_Y_LPARAM: SIGNED mouse coords (negative when a captured drag leaves the window)
#include <commctrl.h>
#include <math.h>

#include "app.h"
#include "input.h"
#include "geometry.h"
#include "config.h"

#include "robot.h"
#include "graphics.h"
#include "renderer.h"
#include "save.h"
#include "app_init.h"

// ---------------- ARC AUTO-ADJUST ----------------
// Re-validates an arc pair's EXISTING angles against a circle's new
// size/position, nudging an angle only as far as needed to keep its
// fillet solve from exceeding maxRadius -- geometry.h's
// clampToSafeAngleRange is a no-op when the current angle is already
// safe, so an arc that's still comfortably valid after the resize/move
// is left completely untouched, and one that isn't gets pulled back in
// by the minimum amount rather than reset to some fixed default. Same
// outer-bound margin (ARC_ANGLE_MARGIN_DEG and friends) the drag code
// already computes maxDelta with -- this just applies it to the angle
// that's already there instead of one freshly read off the mouse.
static void adjustHeadButtArcs(AppState* app)
{
    PointF headLocal = { app->robotScene.robot.headX, app->robotScene.robot.y };
    PointF buttLocal = { app->robotScene.robot.buttX, app->robotScene.robot.y };

    SafeAngleRange range = filletSafeAngleRange(headLocal, app->robotScene.robot.headRadius, buttLocal, app->robotScene.robot.buttRadius, MAX_ARC_R);

    app->robotScene.robot.seamArc1Angle = clampToSafeAngleRange(app->robotScene.robot.seamArc1Angle, range, ARC_ANGLE_MARGIN_DEG);
    app->robotScene.robot.seamArc2Angle = clampToSafeAngleRange(app->robotScene.robot.seamArc2Angle, range, ARC_ANGLE_MARGIN_DEG);
}

static void adjustThighArcs(AppState* app)
{
    SafeAngleRange range1 = filletSafeAngleRange(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, MAX_SEMNI_THIGH_ARC_R);
    SafeAngleRange range2 = filletSafeAngleRangeConcave(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, MAX_THIGH_ARC2_CONCAVE_R);

    app->robotScene.robot.thighArc1Angle = clampToSafeAngleRange(app->robotScene.robot.thighArc1Angle, range1, THIGH_ARC_ANGLE_MARGIN_DEG);
    app->robotScene.robot.thighArc2Angle = clampToSafeAngleRange(app->robotScene.robot.thighArc2Angle, range2, THIGH_ARC_ANGLE_MARGIN_DEG);
}

static void adjustShinArcs(AppState* app)
{
    SafeAngleRange range1 = filletSafeAngleRange(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, app->robotScene.robot.footCircle, app->robotScene.robot.footRadius, MAX_SHIN_ARC_R);
    SafeAngleRange range2 = filletSafeAngleRangeConcave(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, app->robotScene.robot.footCircle, app->robotScene.robot.footRadius, MAX_SHIN_ARC2_CONCAVE_R);

    app->robotScene.robot.shinArc1Angle = clampToSafeAngleRange(app->robotScene.robot.shinArc1Angle, range1, SHIN_ARC_ANGLE_MARGIN_DEG);
    app->robotScene.robot.shinArc2Angle = clampToSafeAngleRange(app->robotScene.robot.shinArc2Angle, range2, SHIN_ARC_ANGLE_MARGIN_DEG);
}

// Same re-validation as adjustShinArcs, just for Rocky's own kneeCircle/
// footCircle pair -- needed since the knee handle's plain-scroll gesture
// (see WM_MOUSEWHEEL's ROBOT_KIND_ROCKY branch) can change kneeRadius,
// which feeds the shin arcs' fillet solve the same way it does for Semni.
static void adjustRockyShinArcs(AppState* app)
{
    SafeAngleRange range1 = filletSafeAngleRange(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius, app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius, MAX_SHIN_ARC_R);
    SafeAngleRange range2 = filletSafeAngleRangeConcave(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius, app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius, MAX_SHIN_ARC2_CONCAVE_R);

    app->robotScene.rocky.shinArc1Angle = clampToSafeAngleRange(app->robotScene.rocky.shinArc1Angle, range1, SHIN_ARC_ANGLE_MARGIN_DEG);
    app->robotScene.rocky.shinArc2Angle = clampToSafeAngleRange(app->robotScene.rocky.shinArc2Angle, range2, SHIN_ARC_ANGLE_MARGIN_DEG);
}

// Same re-validation as adjustThighArcs/adjustShinArcs, for Stilo's own
// hip1->feet1 chain -- Stilo now has no knee/shin/foot sub-stage any more
// (see app.h's Stilo comment), just the pair of thigh arcs directly between
// the hip and feet circles, needing its own copy since it's a separate
// struct/set of AppState fields.
static void adjustStiloThigh1Arcs(AppState* app)
{
    SafeAngleRange range1 = filletSafeAngleRange(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius, app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius, MAX_SEMNI_THIGH_ARC_R);
    SafeAngleRange range2 = filletSafeAngleRangeConcave(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius, app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius, MAX_THIGH_ARC2_CONCAVE_R);

    app->robotScene.stilo.thigh1Arc1Angle = clampToSafeAngleRange(app->robotScene.stilo.thigh1Arc1Angle, range1, THIGH_ARC_ANGLE_MARGIN_DEG);
    app->robotScene.stilo.thigh1Arc2Angle = clampToSafeAngleRange(app->robotScene.stilo.thigh1Arc2Angle, range2, THIGH_ARC_ANGLE_MARGIN_DEG);
}

// Same re-validation as adjustStiloThigh1Arcs above, for Stilo's SECOND leg
// (see app.h's Stilo comment) -- its own independent hip2->feet2 chain, so
// it needs its own copy of these checks against its own hip2/feet2/thigh2
// fields.
static void adjustStiloThigh2Arcs(AppState* app)
{
    SafeAngleRange range1 = filletSafeAngleRange(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius, app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius, MAX_SEMNI_THIGH_ARC_R);
    SafeAngleRange range2 = filletSafeAngleRangeConcave(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius, app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius, MAX_THIGH_ARC2_CONCAVE_R);

    app->robotScene.stilo.thigh2Arc1Angle = clampToSafeAngleRange(app->robotScene.stilo.thigh2Arc1Angle, range1, THIGH_ARC_ANGLE_MARGIN_DEG);
    app->robotScene.stilo.thigh2Arc2Angle = clampToSafeAngleRange(app->robotScene.stilo.thigh2Arc2Angle, range2, THIGH_ARC_ANGLE_MARGIN_DEG);
}

// Axis-aligned bounding box (in whichever robot's own RAW local, pre-
// rotation/pre-joint-angle fields -- same convention save.c's
// save*AsEquations functions already use) enclosing whichever robot kind
// is currently active, for updateRobotSizeLabel below (and renderer.c's
// drawRobotSizeBox, which draws this same box directly into the GL scene
// while the Robot Size slider is being dragged -- see its own comment).
//
// BODY ONLY, deliberately, not the whole robot including its leg(s) --
// requested directly: Semni/Stilo's box is just their head circle, butt
// circle, and the two seam arcs connecting them (the torso), same
// approximate-as-a-circle-or-exact-trimmed-arc approach as before, just
// with every hip/knee/foot/thigh/shin/feet term dropped. Rocky has no
// head/butt/seam torso at all -- its "body" is just its rectangle, so
// that's the whole box for it (see its own case below for why the
// rectangle's width/height are swapped there too, also requested
// directly). Since this reads the raw local fields, it reflects each
// robot's DESIGNED pose, not a mid-drag bend from kneeAngle/hipAngle --
// consistent with the rest of this file's "raw fields, not the live
// rotated pose" convention.
//
// Deliberately NOT static -- renderer.h declares this too, so
// renderRobotScene/renderApp can draw the exact same box input.c's own
// label is built from, rather than risk the two drifting apart.
void robotBoundingBoxLocal(AppState* app, float* minX, float* maxX, float* minY, float* maxY)
{
    *minX = *minY = 1e9f;
    *maxX = *maxY = -1e9f;

#define ROBOT_BB_INCLUDE(cx, cy, rad) \
    do { \
        float _bbX = (cx); \
        float _bbY = (cy); \
        float _bbR = (rad); \
        if (_bbX - _bbR < *minX) *minX = _bbX - _bbR; \
        if (_bbX + _bbR > *maxX) *maxX = _bbX + _bbR; \
        if (_bbY - _bbR < *minY) *minY = _bbY - _bbR; \
        if (_bbY + _bbR > *maxY) *maxY = _bbY + _bbR; \
    } while (0)

    // Same idea as ROBOT_BB_INCLUDE above, but for a seam fillet ARC
    // instead of a bare circle: walks the exact trimmed curve
    // renderer.c's computeArcPoints returns (the same circumcircle +
    // sweep it renders through drawArc) and includes every sampled point.
    // Using the fillet's FULL circle here instead -- the same
    // "approximate as a full circle" shortcut ROBOT_BB_INCLUDE itself is
    // for the head/butt circles above -- would badly OVERSHOOT: an arc's
    // underlying circle can be far bigger than the sliver of it that's
    // actually visible (MAX_ARC_R alone is 6.0 world units, config.h,
    // several times the whole robot), so only the genuinely trimmed curve
    // gives a tight box.
#define ROBOT_BB_INCLUDE_ARC(p0, p1, p2) \
    do { \
        PointF _arcPts[ARC_SAMPLE_COUNT]; \
        int _arcCount = computeArcPoints((p0), (p1), (p2), _arcPts); \
        for (int _i = 0; _i < _arcCount; _i++) \
            ROBOT_BB_INCLUDE(_arcPts[_i].x, _arcPts[_i].y, 0.0f); \
    } while (0)

    switch (app->robotScene.activeKind)
    {
        case ROBOT_KIND_SEMNI:
        {
            Semni* s = &app->robotScene.robot;
            ROBOT_BB_INCLUDE(s->headX, s->y, s->headRadius);
            ROBOT_BB_INCLUDE(s->buttX, s->y, s->buttRadius);

            // The 2 seam arcs connecting head/butt can bulge past them --
            // same local-frame p0/p1/p2 construction drawSemniBody
            // (renderer.c) uses for the actual curve, just without its
            // final rotatePoint step, since this function deliberately
            // stays in the same pre-rotation local frame the 2 circles
            // above are already in.
            {
                PointF headLocal = { s->headX, s->y };
                PointF buttLocal = { s->buttX, s->y };
                PointF bodyMidLocal = { (headLocal.x + buttLocal.x) * 0.5f, (headLocal.y + buttLocal.y) * 0.5f };

                Fillet seamArc1Fillet = filletFromAttachAngle(headLocal, s->headRadius, buttLocal, s->buttRadius, s->seamArc1Angle, MIN_ARC_R, MAX_ARC_R);
                ROBOT_BB_INCLUDE_ARC(
                    circleEdge(headLocal, s->headRadius, s->seamArc1Angle),
                    circleTowardPoint(seamArc1Fillet.center, seamArc1Fillet.radius, bodyMidLocal),
                    internalTangentPoint(seamArc1Fillet.center, seamArc1Fillet.radius, buttLocal, s->buttRadius));

                Fillet seamArc2Fillet = filletFromAttachAngle(headLocal, s->headRadius, buttLocal, s->buttRadius, s->seamArc2Angle, MIN_ARC_R, MAX_ARC_R);
                ROBOT_BB_INCLUDE_ARC(
                    circleEdge(headLocal, s->headRadius, s->seamArc2Angle),
                    circleTowardPoint(seamArc2Fillet.center, seamArc2Fillet.radius, bodyMidLocal),
                    internalTangentPoint(seamArc2Fillet.center, seamArc2Fillet.radius, buttLocal, s->buttRadius));
            }
            break;
        }

        case ROBOT_KIND_ROCKY:
        {
            // Rocky's "body" is just its rectangle -- no head/butt/seam
            // torso the way Semni/Stilo have, so that's the whole box.
            // X/Y extents match drawRockyBodyRect (renderer.c) exactly
            // (bodyHalfWidth as X extent, bodyHalfHeight as Y extent) --
            // the earlier version of this case swapped them here, but that
            // was moved to the "Size: W x H mm" label/UI text instead (see
            // updateRobotSizeLabel and drawRobotSizeBox), so the actual
            // drawn box goes back to matching the real rectangle exactly.
            Rocky* r = &app->robotScene.rocky;
            ROBOT_BB_INCLUDE(r->bodyX - r->bodyHalfWidth, r->bodyY - r->bodyHalfHeight, 0.0f);
            ROBOT_BB_INCLUDE(r->bodyX + r->bodyHalfWidth, r->bodyY + r->bodyHalfHeight, 0.0f);
            break;
        }

        case ROBOT_KIND_STILO:
        {
            Stilo* st = &app->robotScene.stilo;
            ROBOT_BB_INCLUDE(st->headX, st->y, st->headRadius);
            ROBOT_BB_INCLUDE(st->buttX, st->y, st->buttRadius);

            // Seam arcs (head-butt, shared torso) -- same construction as
            // Semni's above, see drawStiloBody (renderer.c). Both legs
            // (hip1/feet1/thigh1, hip2/feet2/thigh2) are deliberately
            // excluded, same "body only" scope as Semni's case above.
            {
                PointF headLocal = { st->headX, st->y };
                PointF buttLocal = { st->buttX, st->y };
                PointF bodyMidLocal = { (headLocal.x + buttLocal.x) * 0.5f, (headLocal.y + buttLocal.y) * 0.5f };

                Fillet seamArc1Fillet = filletFromAttachAngle(headLocal, st->headRadius, buttLocal, st->buttRadius, st->seamArc1Angle, MIN_ARC_R, MAX_ARC_R);
                ROBOT_BB_INCLUDE_ARC(
                    circleEdge(headLocal, st->headRadius, st->seamArc1Angle),
                    circleTowardPoint(seamArc1Fillet.center, seamArc1Fillet.radius, bodyMidLocal),
                    internalTangentPoint(seamArc1Fillet.center, seamArc1Fillet.radius, buttLocal, st->buttRadius));

                Fillet seamArc2Fillet = filletFromAttachAngle(headLocal, st->headRadius, buttLocal, st->buttRadius, st->seamArc2Angle, MIN_ARC_R, MAX_ARC_R);
                ROBOT_BB_INCLUDE_ARC(
                    circleEdge(headLocal, st->headRadius, st->seamArc2Angle),
                    circleTowardPoint(seamArc2Fillet.center, seamArc2Fillet.radius, bodyMidLocal),
                    internalTangentPoint(seamArc2Fillet.center, seamArc2Fillet.radius, buttLocal, st->buttRadius));
            }
            break;
        }

        default:
            break;
    }

#undef ROBOT_BB_INCLUDE_ARC

#undef ROBOT_BB_INCLUDE
}

// Refreshes the "Size: W x H mm" control-panel label (app.h's
// hRobotSizeLabel) from robotBoundingBoxLocal's bounding box, converted to
// millimeters via config.h's MM_PER_WORLD_UNIT and scaled by the current
// "Robot Size" slider (graphicsGetRobotScale) -- dragging that slider is
// meant to read as actually resizing the robot's real-world footprint, not
// just how it's being viewed, so this number has to move with it instead
// of staying pinned to the fixed designed size. Rounded to the nearest
// whole mm and hand-split into an integer for wsprintf, same reason
// WM_HSCROLL's own Scale label splits its float by hand just below --
// wsprintf has no floating-point conversion at all.
static void updateRobotSizeLabel(AppState* app)
{
    if (!app->ui.hRobotSizeLabel)
        return;

    float minX, maxX, minY, maxY;
    robotBoundingBoxLocal(app, &minX, &maxX, &minY, &maxY);

    if (maxX < minX || maxY < minY)
    {
        SetWindowText(app->ui.hRobotSizeLabel, L"Size: - mm");
        return;
    }

    float robotScale = graphicsGetRobotScale();
    int widthMM = (int)((maxX - minX) * MM_PER_WORLD_UNIT * robotScale + 0.5f);
    int heightMM = (int)((maxY - minY) * MM_PER_WORLD_UNIT * robotScale + 0.5f);

    // Rocky specifically prints these swapped (height where width would
    // normally go, width where height would normally go) -- requested
    // directly, so the label's numbers read the way Rocky's own
    // bodyHalfWidth/bodyHalfHeight fields are actually meant to be
    // interpreted for this readout, without changing the drawn box itself
    // (robotBoundingBoxLocal's ROBOT_KIND_ROCKY case) or the rectangle's
    // own real on-screen rendering (drawRockyBodyRect, renderer.c), both
    // of which are left matching bodyHalfWidth/bodyHalfHeight exactly.
    int displayWidthMM = widthMM;
    int displayHeightMM = heightMM;
    if (app->robotScene.activeKind == ROBOT_KIND_ROCKY)
    {
        displayWidthMM = heightMM;
        displayHeightMM = widthMM;
    }

    wchar_t buf[64];
    wsprintf(buf, L"Size: %d x %d mm", displayWidthMM, displayHeightMM);
    SetWindowText(app->ui.hRobotSizeLabel, buf);
}

// Formats a non-negative float as "%.2f" into "out" (must hold at least 16
// wchar_ts) -- same hand-split-for-wsprintf pattern as updateRobotSizeLabel's
// mm rounding and WM_HSCROLL's own Scale label ("wsprintf has no floating-
// point conversion at all"). Only ever called with a non-negative weight
// value (bodyWeight/legWeight/actualWeight) -- doesn't handle negatives.
// Parses the Weight box's text. Accepts '.' or ',' as the decimal
// separator (a German-locale habit, "1,5"), and returns FALSE -- leaving
// the robot's current weight untouched -- for empty or non-numeric text,
// instead of wcstod's silent 0.0 (which is how a half-typed or cleared box
// used to zero a robot's weight).
static BOOL parseWeightText(const wchar_t* text, float* out)
{
    wchar_t buf[64];
    int n = 0;
    for (const wchar_t* p = text; *p && n < 63; p++)
        buf[n++] = (*p == L',') ? L'.' : *p;
    buf[n] = 0;

    wchar_t* end = NULL;
    double v = wcstod(buf, &end);
    if (end == buf) return FALSE;          // nothing numeric at all
    while (*end == L' ' || *end == L'\t') end++;
    if (*end != 0) return FALSE;           // trailing junk
    if (v < 0.0) return FALSE;
    *out = (float)v;
    return TRUE;
}

static void formatNonNegativeFloat2dp(float value, wchar_t* out)
{
    int whole = (int)value;
    int hundredths = (int)((value - (float)whole) * 100.0f + 0.5f);
    if (hundredths >= 100)
    {
        hundredths -= 100;
        whole += 1;
    }
    wsprintf(out, L"%d.%02d", whole, hundredths);
}

// The active robot kind's actualWeight (the Weight box's backing value).
static float* activeKindActualWeightPtr(AppState* app)
{
    switch (app->robotScene.activeKind)
    {
        case ROBOT_KIND_ROCKY: return &app->robotScene.rocky.actualWeight;
        case ROBOT_KIND_STILO: return &app->robotScene.stilo.actualWeight;
        case ROBOT_KIND_SEMNI:
        default:               return &app->robotScene.robot.actualWeight;
    }
}

// Rewrites the Weight box from the active kind's weight, always in the same
// "1.00" two-decimal format (it used to start as "1.0" and only switch to
// "1.00" after a robot switch). Typing is only ever read back on focus loss
// (commitWeightEdit), never on EN_CHANGE, so writing the text here can't be
// mistaken for user input.
static void refreshWeightEdit(AppState* app)
{
    if (!app->ui.hActualWeightEdit) return;
    wchar_t buf[32];
    formatNonNegativeFloat2dp(*activeKindActualWeightPtr(app), buf);
    SetWindowText(app->ui.hActualWeightEdit, buf);
}

// Confirms whatever is typed in the Weight box: a valid number becomes the
// active kind's weight; anything else (empty, half-typed, letters) is
// discarded. Either way the box is then reformatted from the stored value,
// so it always shows what's actually in effect. Called when the box loses
// focus (Enter, or clicking anything else -- see weightEditSubclassProc and
// the ID_ACTUAL_WEIGHT_EDIT EN_KILLFOCUS handler) and by File > Save.
void commitWeightEdit(AppState* app)
{
    if (!app->ui.hActualWeightEdit) return;
    wchar_t buf[64];
    GetWindowText(app->ui.hActualWeightEdit, buf, 64);
    float value;
    if (parseWeightText(buf, &value))
        *activeKindActualWeightPtr(app) = value;
    refreshWeightEdit(app);
}

// Moves hWeightRatioSlider (and refreshes hWeightRatioLabel) to match
// whatever bodyWeight/legWeight currently are -- called from every place
// that changes them without going through the slider's own WM_HSCROLL
// handler (the on-canvas mass-center drag, ID_ROBOT_SELECTOR's
// CBN_SELCHANGE) so the slider is never the odd one out. TBM_SETPOS
// doesn't raise WM_HSCROLL, so this can't recursively
// re-trigger the slider's own handler. Guards the same <=1e-6f
// "meaningless ratio" case computeRockyMassCenterWorld/
// computeSemniMassCenterWorld/computeStiloMassCenterWorld already guard
// with an even 50/50 split, so the slider doesn't snap to either extreme
// just because both weights happen to be ~0.
static void syncWeightRatioSlider(AppState* app, float bodyWeight, float legWeight)
{
    float total = bodyWeight + legWeight;
    int bodyPct;
    if (total <= 1e-6f)
    {
        bodyPct = 50;
    }
    else
    {
        bodyPct = (int)(bodyWeight / total * 100.0f + 0.5f);
        if (bodyPct < 0) bodyPct = 0;
        if (bodyPct > 100) bodyPct = 100;
    }

    SendMessage(app->ui.hWeightRatioSlider, TBM_SETPOS, TRUE, bodyPct);

    wchar_t ratioBuf[32];
    wsprintf(ratioBuf, L"Body/Leg Ratio: %d / %d", bodyPct, 100 - bodyPct);
    SetWindowText(app->ui.hWeightRatioLabel, ratioBuf);
}

// World-space midpoint of one of Rocky's 4 rectangle edges -- same
// bodyX/bodyY +/- bodyHalfWidth/bodyHalfHeight construction, then
// rotatePoint by the body's own angle, that renderer.c's drawRocky uses
// to actually draw each edge's handle (leftMid/rightMid/bottomMid/
// topMid). Exists so rockyMassCenterWins (below) has a real world-space
// point to compare distances against when the mass-center dot's range
// happens to pass near an edge, not just near Body/Knee/Foot/Shin.
static PointF rockyEdgeMidWorld(Rocky r, int edge, PointF center)
{
    PointF local;
    switch (edge)
    {
        case ROCKY_EDGE_LEFT:   local = (PointF){ r.bodyX - r.bodyHalfWidth, r.bodyY }; break;
        case ROCKY_EDGE_RIGHT:  local = (PointF){ r.bodyX + r.bodyHalfWidth, r.bodyY }; break;
        case ROCKY_EDGE_BOTTOM: local = (PointF){ r.bodyX, r.bodyY - r.bodyHalfHeight }; break;
        case ROCKY_EDGE_TOP:    local = (PointF){ r.bodyX, r.bodyY + r.bodyHalfHeight }; break;
        default:                local = center; break;
    }
    return rotatePoint(local, center, r.angle);
}

static float rockyDistSq(PointF a, PointF b)
{
    float dx = a.x - b.x, dy = a.y - b.y;
    return dx * dx + dy * dy;
}

// Whether the Body/Leg Weight mass-center dot should win a hit-test tie
// against whichever OTHER Rocky handle the mouse is ALSO currently within
// range of. The dot's own reachable range (rect-centroid<->leg-centroid,
// computeRockyMassCenterEndpointsWorld) can drift close to the knee, foot,
// a shin arc handle, or an edge midpoint depending on the current Body/Leg
// Weight split and leg pose -- not just the Body handle's documented
// exact-coincidence case (legWeight ~ 0). Unconditionally giving the dot
// priority over everything (the previous behavior) meant it could quietly
// steal clicks/hovers meant for whatever other handle it happened to be
// sitting near, which is exactly the "doesn't work well near another
// handle" symptom. This instead picks whichever candidate the mouse is
// actually closer to, with an exact tie (the documented Body-coincidence
// case) still going to the mass-center dot, same as before.
static BOOL rockyMassCenterWins(PointF mouse, PointF massCenter, PointF rockyCenter,
                                 int rockyEdgeHit, Rocky rocky,
                                 PointF kneeWorld, PointF footWorld,
                                 PointF shin1World, PointF shin2World)
{
    PointF otherPoint = rockyCenter;
    BOOL haveOther = TRUE;

    if (isNear(mouse, rockyCenter, HIP_HANDLE_RADIUS))
        otherPoint = rockyCenter;
    else if (rockyEdgeHit != ROCKY_EDGE_NONE)
        otherPoint = rockyEdgeMidWorld(rocky, rockyEdgeHit, rockyCenter);
    else if (isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS))
        otherPoint = kneeWorld;
    else if (isNear(mouse, footWorld, FOOT_HANDLE_RADIUS))
        otherPoint = footWorld;
    else if (isNear(mouse, shin1World, ROCKY_SHIN_HANDLE_RADIUS))
        otherPoint = shin1World;
    else if (isNear(mouse, shin2World, ROCKY_SHIN_HANDLE_RADIUS))
        otherPoint = shin2World;
    else
        haveOther = FALSE;

    if (!haveOther)
        return TRUE; // nothing else in range -- mass center wins by default

    return rockyDistSq(mouse, massCenter) <= rockyDistSq(mouse, otherPoint); // tie -> mass center
}

// Whether a rectangle-edge hit (Width/Height resize) should actually win
// against Knee/Foot/Shin1/Shin2 when the mouse is ALSO within range of one
// of those. hitTestRockyEdge deliberately extends a bit past each edge's
// own span (its own "slack" margin) so a drag started slightly past the
// edge's true endpoint still grabs it -- but that same slack means the
// edge's hit region reaches into a CORNER, where the knee (or foot/shin)
// handle can legitimately be sitting too (reported: a knee parked right in
// a corner became impossible to grab at all, since the edge unconditionally
// won every time). Same "whichever the mouse is actually closer to wins"
// principle as rockyMassCenterWins above, just for this other pairing.
static BOOL rockyEdgeWins(PointF mouse, PointF edgeMid, PointF kneeWorld, PointF footWorld, PointF shin1World, PointF shin2World)
{
    float edgeDistSq = rockyDistSq(mouse, edgeMid);

    if (isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS) && rockyDistSq(mouse, kneeWorld) < edgeDistSq)
        return FALSE;
    if (isNear(mouse, footWorld, FOOT_HANDLE_RADIUS) && rockyDistSq(mouse, footWorld) < edgeDistSq)
        return FALSE;
    if (isNear(mouse, shin1World, ROCKY_SHIN_HANDLE_RADIUS) && rockyDistSq(mouse, shin1World) < edgeDistSq)
        return FALSE;
    if (isNear(mouse, shin2World, ROCKY_SHIN_HANDLE_RADIUS) && rockyDistSq(mouse, shin2World) < edgeDistSq)
        return FALSE;

    return TRUE;
}

// Hit-tests Rocky's 4 rectangle edges (left/right/top/bottom) against a
// point already given in the rectangle's OWN local frame (i.e. already
// run through inverseRotate around getRockyCenter -- see WM_LBUTTONDOWN/
// WM_MOUSEMOVE below), so this never has to know about rotation itself.
// A point counts as "on" an edge if it's within ROCKY_EDGE_HIT_TOLERANCE
// of that edge's line AND within a small slack margin of the edge's own
// span (so a corner doesn't ambiguously hit both edges that meet there --
// it just picks whichever is checked first, left/right before top/
// bottom). Returns ROCKY_EDGE_NONE if the point isn't near any edge.
static int hitTestRockyEdge(Rocky r, PointF localPoint)
{
    float left   = r.bodyX - r.bodyHalfWidth;
    float right  = r.bodyX + r.bodyHalfWidth;
    float bottom = r.bodyY - r.bodyHalfHeight;
    float top    = r.bodyY + r.bodyHalfHeight;

    float slackX = r.bodyHalfWidth * 0.15f + ROCKY_EDGE_HIT_TOLERANCE;
    float slackY = r.bodyHalfHeight * 0.15f + ROCKY_EDGE_HIT_TOLERANCE;

    BOOL withinY = (localPoint.y > bottom - slackY) && (localPoint.y < top + slackY);
    BOOL withinX = (localPoint.x > left - slackX) && (localPoint.x < right + slackX);

    if (withinY && fabsf(localPoint.x - left) < ROCKY_EDGE_HIT_TOLERANCE)
        return ROCKY_EDGE_LEFT;
    if (withinY && fabsf(localPoint.x - right) < ROCKY_EDGE_HIT_TOLERANCE)
        return ROCKY_EDGE_RIGHT;
    if (withinX && fabsf(localPoint.y - bottom) < ROCKY_EDGE_HIT_TOLERANCE)
        return ROCKY_EDGE_BOTTOM;
    if (withinX && fabsf(localPoint.y - top) < ROCKY_EDGE_HIT_TOLERANCE)
        return ROCKY_EDGE_TOP;

    return ROCKY_EDGE_NONE;
}

// Distance from a world-space point to a world-space line segment -- same
// math as canvas.c's own distPointToSegment (that one's static to its own
// file, so not shared; kept as a small local duplicate rather than
// threading it through geometry.h for one caller). Used by the View
// Segments fillet hover hit-test below to pick against the ACTUAL trimmed
// arc polyline (computeSemniArcPoints) instead of the full circle it was
// cut from.
static float distPointFToSegment(PointF p, PointF a, PointF b)
{
    float dx = b.x - a.x;
    float dy = b.y - a.y;
    float len2 = dx * dx + dy * dy;

    if (len2 < 1e-9f)
    {
        float ddx = p.x - a.x, ddy = p.y - a.y;
        return sqrtf(ddx * ddx + ddy * ddy);
    }

    float t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2;
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;

    float projX = a.x + t * dx;
    float projY = a.y + t * dy;
    float ddx = p.x - projX, ddy = p.y - projY;
    return sqrtf(ddx * ddx + ddy * ddy);
}

// NEW: middle-mouse drag-pan state, mirroring canvas.c's ArcSpline
// panning/panLastX/panLastY -- gives the Semni robot editor the same
// pan gesture instead of only supporting zoom.
static BOOL semniPanning = FALSE;
static int  semniPanLastX = 0, semniPanLastY = 0;

// ---------------- SEMNI CONTROL PANEL LOOK & FEEL ----------------
// The Semni buttons used to be plain WS_CHILD controls floating directly
// over the OpenGL viewport with the default tiny system font and no
// backdrop, which read as unfinished next to the ArcSpline panel's own
// solid-backed floating panel (ui.c's SemniUIPanel). This gives the
// robot editor the same treatment: a solid backdrop behind the cluster
// and a consistent "Segoe UI" font (already the app's chosen typeface --
// see canvas.c's GL text font) instead of the stock GUI font.
static HFONT g_semniUIFont = NULL;
static HFONT g_semniUITitleFont = NULL;
static BOOL  g_semniPanelClassRegistered = FALSE;

static void ensureSemniUIFonts(void)
{
    if (g_semniUIFont) return;

    g_semniUIFont = CreateFont(
        -15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

    g_semniUITitleFont = CreateFont(
        -15, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
}

// Registers the flat, solid-backed "backdrop" window class used for both
// hControlPanel (behind the button cluster) and hHoverPanel (behind the
// bottom-left hover label). COLOR_BTNFACE matches the ArcSpline panel's
// own background (ui.c's createUIWindow) so both editor modes share the
// same panel color. WS_EX_STATICEDGE (applied at CreateWindowEx time,
// not here) gives it a thin flat frame instead of the dated sunken-3D
// look of WS_EX_CLIENTEDGE.
// The robot panel's background: a click on empty panel space moves focus to
// the main window, so it also confirms a value being typed in the Weight
// box (EN_KILLFOCUS -> commitWeightEdit), same as clicking the canvas.
static LRESULT CALLBACK semniPanelWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (msg == WM_LBUTTONDOWN)
        SetFocus(GetParent(hwnd));
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

static void ensureSemniPanelClassRegistered(void)
{
    if (g_semniPanelClassRegistered) return;

    WNDCLASS wc = {0};
    wc.lpfnWndProc = semniPanelWndProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = L"SemniControlPanel";
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClass(&wc);

    g_semniPanelClassRegistered = TRUE;
}

// Subclass for hActualWeightEdit ONLY -- a plain WS_CHILD EDIT
// control (this isn't a dialog, so there's no IDOK default-button/Enter
// handling to piggyback on) otherwise just beeps on Enter and leaves focus
// sitting in the box, silently swallowing every keyboard shortcut this
// editor relies on (arrow-key nudges, Shift+drag hints, etc -- see this
// file's own WM_KEYDOWN case) until the user manually clicks back onto the
// canvas. Catching VK_RETURN here and returning focus to the main window
// (dwRefData, set to app->hwndMain at SetWindowSubclass time below) makes
// Enter behave the way it does after every OTHER control on this panel
// (see e.g. ID_MIRROR_LEG_BUTTON's own SetFocus(app->hwndMain) right after
// its InvalidateRect) instead of being the one control that doesn't give
// focus back.
static LRESULT CALLBACK weightEditSubclassProc(HWND hEdit, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
{
    if (msg == WM_KEYDOWN && wParam == VK_ESCAPE)
    {
        // Esc cancels the edit: drop the typed text, then leave the box.
        // commitWeightEdit on the focus loss re-reads the (restored) text.
        refreshWeightEdit(&app);
        SetFocus((HWND)dwRefData);
        return 0;
    }

    if (msg == WM_CHAR && (wParam == VK_RETURN || wParam == VK_ESCAPE))
        return 0;   // no beep for the Enter/Esc handled on WM_KEYDOWN

    if (msg == WM_KEYDOWN && wParam == VK_RETURN)
    {
        // Enter confirms: moving focus away fires EN_KILLFOCUS, which
        // commits the value (commitWeightEdit).
        SetFocus((HWND)dwRefData);
        return 0;   // swallow it -- DefSubclassProc's default handling for an
                    // unclaimed Enter in a single-line edit is just a beep
    }

    if (msg == WM_NCDESTROY)
    {
        // Matches every other subclass's own cleanup convention -- remove
        // self right before the control is actually destroyed so a stale
        // subclass callback can never fire against a dead HWND (this app
        // only ever destroys these two controls by destroying the whole
        // main window, but this is the correct pattern regardless of when
        // that happens to occur).
        RemoveWindowSubclass(hEdit, weightEditSubclassProc, uIdSubclass);
    }

    return DefSubclassProc(hEdit, msg, wParam, lParam);
}

// TRUE while the mouse is over (or dragging) any editable robot handle in
// the Robot editor -- joint circles, fillet-arc handles, Rocky's body/edges,
// mass-center dots, for all three robot kinds. Drives the hand cursor
// (WM_SETCURSOR below) so it's obvious something can be grabbed.
static BOOL robotHandleHoveredOrDragged(const AppState* app)
{
    return app->draggingSeamArc1 ||
           app->draggingSeamArc2 ||
           app->draggingInner ||
           app->draggingKnee ||
           app->draggingThigh1 ||
           app->draggingThigh2 ||
           app->draggingFoot ||
           app->draggingShin1 ||
           app->draggingShin2 ||
           app->hoverRockyBody ||
           app->draggingRockyBody ||
           app->hoverRockyEdge ||
           app->draggingRockyEdge ||
           app->hoverRockyKnee ||
           app->draggingRockyKnee ||
           app->hoverRockyFoot ||
           app->draggingRockyFoot ||
           app->hoverRockyMassCenter ||
           app->draggingRockyMassCenter ||
           app->hoverSemniMassCenter ||
           app->draggingSemniMassCenter ||
           app->hoverStiloMassCenter ||
           app->draggingStiloMassCenter ||
           app->draggingRockyShin1 ||
           app->draggingRockyShin2 ||
           app->hoverRockyShin1 ||
           app->hoverRockyShin2 ||
           app->hoverHip ||
           app->hoverKnee ||
           app->hoverFoot ||
           app->hoverButt ||
           app->hoverHead ||
           app->hoverSeamArc1 ||
           app->hoverSeamArc2 ||
           app->hoverThigh1 ||
           app->hoverThigh2 ||
           app->hoverShin1 ||
           app->hoverShin2 ||
           app->draggingStiloSeamArc1 ||
           app->draggingStiloSeamArc2 ||
           app->draggingStiloHip1 ||
           app->draggingStiloFeet1 ||
           app->draggingStiloThigh1Arc1 ||
           app->draggingStiloThigh1Arc2 ||
           app->hoverStiloHip1 ||
           app->hoverStiloFeet1 ||
           app->hoverStiloButt ||
           app->hoverStiloHead ||
           app->hoverStiloSeamArc1 ||
           app->hoverStiloSeamArc2 ||
           app->hoverStiloThigh1Arc1 ||
           app->hoverStiloThigh1Arc2 ||
           app->draggingStiloHip2 ||
           app->draggingStiloFeet2 ||
           app->draggingStiloThigh2Arc1 ||
           app->draggingStiloThigh2Arc2 ||
           app->hoverStiloHip2 ||
           app->hoverStiloFeet2 ||
           app->hoverStiloThigh2Arc1 ||
           app->hoverStiloThigh2Arc2;
}

LRESULT handleInput(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, AppState* app)
{
    switch (msg)
    {
        case WM_CAPTURECHANGED:
            // Mouse capture taken away mid-pan (Alt+Tab, a dialog...): stop
            // panning, otherwise the view keeps following the mouse with no
            // button held.
            if ((HWND)lParam != hwnd) semniPanning = FALSE;
            break;

        case WM_SETCURSOR:
        {
            // Hand cursor over a grabbable robot handle (and while dragging
            // one). Middle-button panning keeps its own hand cursor too.
            if (LOWORD(lParam) == HTCLIENT && ((HWND)wParam == hwnd)
                && (semniPanning || robotHandleHoveredOrDragged(app)))
            {
                SetCursor(LoadCursor(NULL, IDC_HAND));
                return TRUE;
            }
            break;
        }

        case WM_MBUTTONDOWN:
        {
            semniPanning = TRUE;
            semniPanLastX = GET_X_LPARAM(lParam);
            semniPanLastY = GET_Y_LPARAM(lParam);
            SetCapture(hwnd);

            // Same hand-cursor treatment as canvas.c's own ArcSpline
            // panning (WM_MBUTTONDOWN there) -- this window never handles
            // WM_SETCURSOR at all (its class cursor is just the plain
            // IDC_ARROW set at RegisterClass time, see
            // ensureSemniPanelClassRegistered), so without an explicit
            // SetCursor call here the cursor never changed for a middle-
            // mouse pan in the Design Robot screen at all, unlike the
            // Environment/Simulation canvas. Set directly rather than
            // relying on WM_SETCURSOR, for the same reason noted there.
            SetCursor(LoadCursor(NULL, IDC_HAND));
            return 0;
        }

        case WM_MBUTTONUP:
        {
            semniPanning = FALSE;
            ReleaseCapture();
            return 0;
        }
        case WM_LBUTTONDOWN:
        {
            // Clicking the canvas confirms a value being typed in the
            // Weight box (focus leaves it -> EN_KILLFOCUS -> commitWeightEdit).
            if (GetFocus() != hwnd)
                SetFocus(hwnd);

            int mx = GET_X_LPARAM(lParam);
            int my = GET_Y_LPARAM(lParam);

            // Capture the mouse for the whole drag, same as WM_MBUTTONDOWN's
            // panning just above. Without this, releasing the button
            // anywhere other than this window -- most easily this panel's
            // own Remove Leg/Remove Body checkboxes, sitting right next to
            // the canvas -- never delivers a WM_LBUTTONUP here at all, so
            // whichever dragging* flag this click sets below (just above
            // WM_LBUTTONUP's own reset list) never gets cleared. The result
            // is a handle stuck "dragging" with no button held: every later
            // WM_MOUSEMOVE keeps assigning its position from the cursor, so
            // it visibly tracks the mouse (faster/slower exactly matching
            // cursor speed) until some OTHER path happens to zero the flag
            // (e.g. entering Simulation, see canvas.c's ID_MODE_SIMULATION
            // handler). SetCapture guarantees the matching WM_LBUTTONUP
            // below always reaches this window instead, so that can no
            // longer happen.
            SetCapture(hwnd);

            screenToGL(hwnd, mx, my, &app->mouseGL.x, &app->mouseGL.y);

            app->draggingSeamArc1 = 0;
            app->draggingSeamArc2 = 0;
            app->draggingInner = 0;
            app->draggingKnee = 0;
            app->draggingThigh1 = 0;
            app->draggingThigh2 = 0;
            app->draggingFoot = 0;
            app->draggingShin1 = 0;
            app->draggingShin2 = 0;
            app->draggingRockyBody = 0;
            app->draggingRockyEdge = ROCKY_EDGE_NONE;
            app->draggingRockyKnee = 0;
            app->draggingRockyFoot = 0;
            app->draggingRockyMassCenter = 0;
            app->draggingSemniMassCenter = 0;
            app->draggingStiloMassCenter = 0;
            app->draggingRockyShin1 = 0;
            app->draggingRockyShin2 = 0;
            app->draggingStiloSeamArc1 = 0;
            app->draggingStiloSeamArc2 = 0;
            app->draggingStiloHip1 = 0;
            app->draggingStiloFeet1 = 0;
            app->draggingStiloThigh1Arc1 = 0;
            app->draggingStiloThigh1Arc2 = 0;
            app->draggingStiloHip2 = 0;
            app->draggingStiloFeet2 = 0;
            app->draggingStiloThigh2Arc1 = 0;
            app->draggingStiloThigh2Arc2 = 0;

            // Rocky's rectangular torso has one hip-like handle (see
            // app.h's hoverRockyBody/draggingRockyBody): hover to
            // highlight, drag to move the whole robot, plain scroll (see
            // WM_MOUSEWHEEL) to resize. It also has 4 edge midpoints
            // (hoverRockyEdge/draggingRockyEdge, see ROCKY_EDGE_* in
            // app.h) -- hover/drag one of those to stretch just that
            // dimension instead of moving or uniformly scaling. It has one
            // knee handle (hoverRockyKnee/draggingRockyKnee) where the leg
            // attaches to the rectangle -- drag it freely anywhere inside
            // the rectangle (clamped so the knee circle never pokes
            // outside the body, see WM_MOUSEMOVE), plain scroll to resize
            // kneeRadius, Shift+scroll to bend kneeAngle. And it has one
            // foot handle (hoverRockyFoot/draggingRockyFoot) at the far
            // end of the shin -- drag it along the knee->foot axis
            // (constrainToAxis, same as Semni's own foot handle) to
            // change the leg's length. Stilo (below) now has Semni's FULL
            // set of joint handles instead.
            if (app->robotScene.activeKind == ROBOT_KIND_ROCKY)
            {
                PointF rockyCenter = getRockyCenter(app->robotScene.rocky);
                PointF kneeWorld = rotatePoint(app->robotScene.rocky.kneeCircle, rockyCenter, app->robotScene.rocky.angle);
                PointF footWorld = jointToWorld(app->robotScene.rocky.footCircle, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle, rockyCenter, app->robotScene.rocky.angle);

                // Body/Leg Weight mass-center dot's CURRENT position (see
                // renderer.c's computeRockyMassCenterWorld, which is what
                // actually draws it) -- needed here for its own hit-test
                // below, ahead of every other handle's (see that check's
                // own comment for why it has to go first).
                PointF rockyMassCenterWorld = computeRockyMassCenterWorld(app->robotScene.rocky);

                // Shin connector-arc handle positions -- same
                // circleAtAxisMid construction as renderer.c's drawRocky
                // (where these handles are actually drawn), so the hit-test
                // always lines up with what's on screen.
                PointF rockyShinAxisMidLocal = { (app->robotScene.rocky.kneeCircle.x + app->robotScene.rocky.footCircle.x) * 0.5f,
                                                  (app->robotScene.rocky.kneeCircle.y + app->robotScene.rocky.footCircle.y) * 0.5f };

                Fillet rockyShin1Fillet = filletFromAttachAngle(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius,
                                                                 app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius,
                                                                 app->robotScene.rocky.shinArc1Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC_R);
                PointF rockyShin1NearLocal = circleTowardPoint(rockyShin1Fillet.center, rockyShin1Fillet.radius, rockyShinAxisMidLocal);
                PointF rockyShin1MidLocal = circleAtAxisMid(rockyShin1Fillet.center, rockyShin1Fillet.radius, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle, rockyShin1NearLocal);

                Fillet rockyShin2Fillet = filletFromAttachAngleConcave(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius,
                                                                        app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius,
                                                                        app->robotScene.rocky.shinArc2Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC2_CONCAVE_R);
                PointF rockyShin2NearLocal = circleTowardPoint(rockyShin2Fillet.center, rockyShin2Fillet.radius, rockyShinAxisMidLocal);
                PointF rockyShin2MidLocal = circleAtAxisMid(rockyShin2Fillet.center, rockyShin2Fillet.radius, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle, rockyShin2NearLocal);

                PointF rockyShin1World = jointToWorld(rockyShin1MidLocal, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle, rockyCenter, app->robotScene.rocky.angle);
                PointF rockyShin2World = jointToWorld(rockyShin2MidLocal, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle, rockyCenter, app->robotScene.rocky.angle);

                // shin-local frame: undo the whole-body angle first (same
                // as the "localMouse" WM_MOUSEMOVE computes and reuses for
                // this exact purpose), then kneeAngle on top of that --
                // Rocky only has these 2 nested rotations (no separate hip
                // stage the way Semni's own legLocalMouseDown/
                // shinLocalMouseDown chain has to undo 3), but skipping
                // the body-angle step here would only happen to work while
                // rocky.angle is 0 and silently break as soon as the whole
                // body is rotated. Needed so the drag-start perpendicular-
                // offset capture reads the mouse in the same frame
                // WM_MOUSEMOVE's own update math (rockyShinLocalMouse) uses.
                PointF rockyBodyLocalMouseDown = inverseRotate(app->mouseGL, rockyCenter, app->robotScene.rocky.angle);
                PointF rockyShinLocalMouseDown = inverseRotate(rockyBodyLocalMouseDown, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle);

                // Computed once up front (rather than only in the fallback
                // branch, as before) so the 4 rectangle-edge midpoints can
                // be checked right after the move-handle -- see this
                // chain's own comment below for the full priority ordering.
                int rockyEdgeHitDown = hitTestRockyEdge(app->robotScene.rocky, rockyBodyLocalMouseDown);

                // Mass-center dot -- checked first, but only actually wins
                // when rockyMassCenterWins agrees it's the CLOSER of the
                // two (see that function's own comment): the dot's own
                // reachable range runs along the rect-centroid<->leg-
                // centroid segment (renderer.c's
                // computeRockyMassCenterEndpointsWorld), and the rect-
                // centroid END of that segment is exactly rockyCenter
                // itself (the body handle's own position -- see
                // getRockyCenter's comment) -- so whenever legWeight is at
                // or near 0, this dot and the body handle sit right on top
                // of each other, and the tie there deliberately still
                // goes to the dot. But that same reachable range can also
                // drift close to the knee, foot, a shin arc handle, or an
                // edge midpoint depending on pose -- unconditionally
                // giving the dot priority in ALL of those cases too (the
                // previous behavior) meant it could steal clicks meant
                // for whichever handle it merely happened to be sitting
                // near, so rockyMassCenterWins settles every other case by
                // actual distance instead.
                if ((LOWORD(wParam) & MK_SHIFT) &&
                    isNear(app->mouseGL, rockyMassCenterWorld, MASS_CENTER_HANDLE_RADIUS) &&
                    rockyMassCenterWins(app->mouseGL, rockyMassCenterWorld, rockyCenter, rockyEdgeHitDown,
                                         app->robotScene.rocky, kneeWorld, footWorld, rockyShin1World, rockyShin2World))
                {
                    app->draggingRockyMassCenter = 1;

                    // total held fixed for the whole drag -- see app.h's
                    // own comment on rockyMassCenterDragTotal for why
                    // (Rob.txt's export writes bodyWeight out as a literal
                    // mass, not just a ratio). Floors at 1.0 in the
                    // (unusual) case both weights are already ~0, so the
                    // drag has a well-defined nonzero total to redistribute
                    // -- same "avoid dividing into a degenerate zero" spirit
                    // as computeRockyMassCenterWorld's own totalWeight
                    // guard.
                    float total = app->robotScene.rocky.bodyWeight + app->robotScene.rocky.legWeight;
                    app->rockyMassCenterDragTotal = (total > 1e-6f) ? total : 1.0f;
                }
                else if (!app->robotScene.rocky.bodyHidden && isNear(app->mouseGL, rockyCenter, HIP_HANDLE_RADIUS))
                {
                    app->draggingRockyBody = 1;

                    // capture the leg's fixed offset from the body right
                    // now, so the drag can carry it along as one rigid
                    // piece -- same pattern as Semni's own
                    // hipDragKneeOffset/hipDragFootOffset
                    app->rockyDragKneeOffset.x = app->robotScene.rocky.kneeCircle.x - app->robotScene.rocky.bodyX;
                    app->rockyDragKneeOffset.y = app->robotScene.rocky.kneeCircle.y - app->robotScene.rocky.bodyY;

                    app->rockyDragFootOffset.x = app->robotScene.rocky.footCircle.x - app->robotScene.rocky.bodyX;
                    app->rockyDragFootOffset.y = app->robotScene.rocky.footCircle.y - app->robotScene.rocky.bodyY;
                }
                // The 4 rectangle-edge midpoints (body Width/Height resize)
                // now take priority right after the move-handle, ahead of
                // knee/foot/shin -- see rockyEdgeHitDown's own comment
                // above for why this no longer has to be a last-resort
                // fallback check. But only actually wins when
                // rockyEdgeWins agrees it's the CLOSER of the two (see
                // that function's own comment) -- hitTestRockyEdge's own
                // corner slack otherwise let an edge unconditionally beat
                // a knee/foot/shin handle parked right in that corner,
                // making it impossible to grab.
                else if (!app->robotScene.rocky.bodyHidden && rockyEdgeHitDown != ROCKY_EDGE_NONE &&
                         rockyEdgeWins(app->mouseGL, rockyEdgeMidWorld(app->robotScene.rocky, rockyEdgeHitDown, rockyCenter),
                                       kneeWorld, footWorld, rockyShin1World, rockyShin2World))
                {
                    app->draggingRockyEdge = rockyEdgeHitDown;
                }
                else if (!app->robotScene.rocky.legHidden && isNear(app->mouseGL, kneeWorld, KNEE_HANDLE_RADIUS))
                {
                    app->draggingRockyKnee = 1;

                    // capture the shin's fixed offset from the knee right
                    // now, so dragging the knee around inside the
                    // rectangle carries the foot/shin along as one rigid
                    // piece -- same pattern as Semni's own
                    // kneeDragFootOffset
                    app->rockyKneeDragFootOffset.x = app->robotScene.rocky.footCircle.x - app->robotScene.rocky.kneeCircle.x;
                    app->rockyKneeDragFootOffset.y = app->robotScene.rocky.footCircle.y - app->robotScene.rocky.kneeCircle.y;
                }
                else if (!app->robotScene.rocky.legHidden && isNear(app->mouseGL, footWorld, FOOT_HANDLE_RADIUS))
                {
                    // no offset capture needed -- nothing hangs off the
                    // foot, same as Semni's own draggingFoot
                    app->draggingRockyFoot = 1;
                }
                else if (!app->robotScene.rocky.legHidden && isNear(app->mouseGL, rockyShin1World, ROCKY_SHIN_HANDLE_RADIUS))
                {
                    app->draggingRockyShin1 = 1;

                    // remember where the drag started (mouse's
                    // perpendicular-to-axis offset, relative to the knee->
                    // foot axis + the current angle), same idea as Semni's
                    // own shinArcDragStartPerp/shinArcDragStartAngle
                    app->rockyShinArcDragStartPerp = perpOffsetOnAxis(rockyShinLocalMouseDown, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle);
                    app->rockyShinArcDragStartAngle = app->robotScene.rocky.shinArc1Angle;
                }
                else if (!app->robotScene.rocky.legHidden && isNear(app->mouseGL, rockyShin2World, ROCKY_SHIN_HANDLE_RADIUS))
                {
                    app->draggingRockyShin2 = 1;

                    app->rockyShinArcDragStartPerp = perpOffsetOnAxis(rockyShinLocalMouseDown, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle);
                    app->rockyShinArcDragStartAngle = app->robotScene.rocky.shinArc2Angle;
                }
                break;
            }

            // Stilo now has just two joints per leg (hip + feet, no
            // knee/shin/foot sub-stage any more -- see app.h's Stilo
            // comment) -- same hit-test construction as the ROBOT_KIND_SEMNI
            // block below, just reading/writing app->robotScene.stilo and
            // the Stilo-specific draggingStilo*/stilo* fields (see app.h)
            // instead of Semni's own, since a different struct is being
            // edited.
            if (app->robotScene.activeKind == ROBOT_KIND_STILO)
            {
                PointF stiloCenter = getStiloCenter(app->robotScene.stilo);
                PointF stiloMouse = app->mouseGL;

                PointF stiloHeadLocal = { app->robotScene.stilo.headX, app->robotScene.stilo.y };
                PointF stiloButtLocal = { app->robotScene.stilo.buttX, app->robotScene.stilo.y };
                PointF stiloBodyMidLocal = { (stiloHeadLocal.x + stiloButtLocal.x) * 0.5f, (stiloHeadLocal.y + stiloButtLocal.y) * 0.5f };

                Fillet stiloSeamArc1Fillet = filletFromAttachAngle(stiloHeadLocal, app->robotScene.stilo.headRadius, stiloButtLocal, app->robotScene.stilo.buttRadius, app->robotScene.stilo.seamArc1Angle, MIN_ARC_R, MAX_ARC_R);
                Fillet stiloSeamArc2Fillet = filletFromAttachAngle(stiloHeadLocal, app->robotScene.stilo.headRadius, stiloButtLocal, app->robotScene.stilo.buttRadius, app->robotScene.stilo.seamArc2Angle, MIN_ARC_R, MAX_ARC_R);

                PointF stiloSeamArc1NearLocal = circleTowardPoint(stiloSeamArc1Fillet.center, stiloSeamArc1Fillet.radius, stiloBodyMidLocal);
                PointF stiloSeamArc2NearLocal = circleTowardPoint(stiloSeamArc2Fillet.center, stiloSeamArc2Fillet.radius, stiloBodyMidLocal);

                PointF stiloSeamArc1MidLocal = circleAtX(stiloSeamArc1Fillet.center, stiloSeamArc1Fillet.radius, stiloBodyMidLocal.x, stiloSeamArc1NearLocal);
                PointF stiloSeamArc2MidLocal = circleAtX(stiloSeamArc2Fillet.center, stiloSeamArc2Fillet.radius, stiloBodyMidLocal.x, stiloSeamArc2NearLocal);

                PointF stiloSeamArc1HandleWorld = rotatePoint(stiloSeamArc1MidLocal, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloSeamArc2HandleWorld = rotatePoint(stiloSeamArc2MidLocal, stiloCenter, app->robotScene.stilo.angle);

                PointF stiloHip1World = rotatePoint(app->robotScene.stilo.hip1Circle, stiloCenter, app->robotScene.stilo.angle);

                PointF stiloHip1Pivot = app->robotScene.stilo.hip1Circle;
                float stiloHip1Angle = app->robotScene.stilo.hip1Angle;

                PointF stiloFeet1World = jointToWorld(app->robotScene.stilo.feet1Circle, stiloHip1Pivot, stiloHip1Angle, stiloCenter, app->robotScene.stilo.angle);

                PointF stiloThigh1AxisMidLocal = { (app->robotScene.stilo.hip1Circle.x + app->robotScene.stilo.feet1Circle.x) * 0.5f,
                                                    (app->robotScene.stilo.hip1Circle.y + app->robotScene.stilo.feet1Circle.y) * 0.5f };

                Fillet stiloThigh1Arc1Fillet = filletFromAttachAngle(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius,
                                                                      app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius,
                                                                      app->robotScene.stilo.thigh1Arc1Angle, MIN_THIGH_ARC_R, MAX_SEMNI_THIGH_ARC_R);
                PointF stiloThigh1Arc1NearLocal = circleTowardPoint(stiloThigh1Arc1Fillet.center, stiloThigh1Arc1Fillet.radius, stiloThigh1AxisMidLocal);
                PointF stiloThigh1Arc1MidLocal = circleAtAxisMid(stiloThigh1Arc1Fillet.center, stiloThigh1Arc1Fillet.radius, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle, stiloThigh1Arc1NearLocal);

                Fillet stiloThigh1Arc2Fillet = filletFromAttachAngleConcave(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius,
                                                                             app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius,
                                                                             app->robotScene.stilo.thigh1Arc2Angle, MIN_THIGH_ARC_R, MAX_THIGH_ARC2_CONCAVE_R);
                PointF stiloThigh1Arc2NearLocal = circleTowardPoint(stiloThigh1Arc2Fillet.center, stiloThigh1Arc2Fillet.radius, stiloThigh1AxisMidLocal);
                PointF stiloThigh1Arc2MidLocal = circleAtAxisMid(stiloThigh1Arc2Fillet.center, stiloThigh1Arc2Fillet.radius, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle, stiloThigh1Arc2NearLocal);

                PointF stiloThigh1Arc1World = jointToWorld(stiloThigh1Arc1MidLocal, stiloHip1Pivot, stiloHip1Angle, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloThigh1Arc2World = jointToWorld(stiloThigh1Arc2MidLocal, stiloHip1Pivot, stiloHip1Angle, stiloCenter, app->robotScene.stilo.angle);

                PointF stiloLeg1LocalMouseDown = inverseRotate(inverseRotate(stiloMouse, stiloCenter, app->robotScene.stilo.angle), stiloHip1Pivot, stiloHip1Angle);

                // ---- leg 2 hit-test -- same construction as leg 1 above,
                // just reading app->robotScene.stilo's hip2/feet2/thigh2
                // fields (see app.h's Stilo comment). No seam arc handles
                // here -- those are torso-level, shared with leg 1, already
                // hit-tested above.
                PointF stiloHip2Pivot = app->robotScene.stilo.hip2Circle;
                float stiloHip2Angle = app->robotScene.stilo.hip2Angle;

                PointF stiloHip2World = rotatePoint(stiloHip2Pivot, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloFeet2World = jointToWorld(app->robotScene.stilo.feet2Circle, stiloHip2Pivot, stiloHip2Angle, stiloCenter, app->robotScene.stilo.angle);

                PointF stiloThigh2AxisMidLocal = { (app->robotScene.stilo.hip2Circle.x + app->robotScene.stilo.feet2Circle.x) * 0.5f,
                                                    (app->robotScene.stilo.hip2Circle.y + app->robotScene.stilo.feet2Circle.y) * 0.5f };

                Fillet stiloThigh2Arc1Fillet = filletFromAttachAngle(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius,
                                                                      app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius,
                                                                      app->robotScene.stilo.thigh2Arc1Angle, MIN_THIGH_ARC_R, MAX_SEMNI_THIGH_ARC_R);
                PointF stiloThigh2Arc1NearLocal = circleTowardPoint(stiloThigh2Arc1Fillet.center, stiloThigh2Arc1Fillet.radius, stiloThigh2AxisMidLocal);
                PointF stiloThigh2Arc1MidLocal = circleAtAxisMid(stiloThigh2Arc1Fillet.center, stiloThigh2Arc1Fillet.radius, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle, stiloThigh2Arc1NearLocal);

                Fillet stiloThigh2Arc2Fillet = filletFromAttachAngleConcave(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius,
                                                                             app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius,
                                                                             app->robotScene.stilo.thigh2Arc2Angle, MIN_THIGH_ARC_R, MAX_THIGH_ARC2_CONCAVE_R);
                PointF stiloThigh2Arc2NearLocal = circleTowardPoint(stiloThigh2Arc2Fillet.center, stiloThigh2Arc2Fillet.radius, stiloThigh2AxisMidLocal);
                PointF stiloThigh2Arc2MidLocal = circleAtAxisMid(stiloThigh2Arc2Fillet.center, stiloThigh2Arc2Fillet.radius, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle, stiloThigh2Arc2NearLocal);

                PointF stiloThigh2Arc1World = jointToWorld(stiloThigh2Arc1MidLocal, stiloHip2Pivot, stiloHip2Angle, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloThigh2Arc2World = jointToWorld(stiloThigh2Arc2MidLocal, stiloHip2Pivot, stiloHip2Angle, stiloCenter, app->robotScene.stilo.angle);

                PointF stiloLeg2LocalMouseDown = inverseRotate(inverseRotate(stiloMouse, stiloCenter, app->robotScene.stilo.angle), stiloHip2Pivot, stiloHip2Angle);

                // Body/Leg Weight mass-center dot -- same idea as Semni's
                // own version above, just against Stilo's bodyWeight/
                // legWeight and computeStiloMassCenterWorld (which blends
                // the body centroid against a single COMBINED centroid of
                // both legs -- see app.h's own comment on Stilo's
                // legWeight). Same "no closest-wins tie-break needed"
                // reasoning as Semni's version.
                PointF stiloMassCenterWorld = computeStiloMassCenterWorld(app->robotScene.stilo);

                if ((LOWORD(wParam) & MK_SHIFT) && isNear(stiloMouse, stiloMassCenterWorld, MASS_CENTER_HANDLE_RADIUS))
                {
                    app->draggingStiloMassCenter = 1;

                    float stiloTotal = app->robotScene.stilo.bodyWeight + app->robotScene.stilo.legWeight;
                    app->stiloMassCenterDragTotal = (stiloTotal > 1e-6f) ? stiloTotal : 1.0f;
                }
                else if (isNear(stiloMouse, stiloSeamArc1HandleWorld, ARC_HANDLE_RADIUS))
                {
                    app->draggingStiloSeamArc1 = 1;
                    app->stiloArcDragStartMouseY = inverseRotate(stiloMouse, stiloCenter, app->robotScene.stilo.angle).y;
                    app->stiloArcDragStartAngle = app->robotScene.stilo.seamArc1Angle;
                }
                else if (isNear(stiloMouse, stiloSeamArc2HandleWorld, ARC_HANDLE_RADIUS))
                {
                    app->draggingStiloSeamArc2 = 1;
                    app->stiloArcDragStartMouseY = inverseRotate(stiloMouse, stiloCenter, app->robotScene.stilo.angle).y;
                    app->stiloArcDragStartAngle = app->robotScene.stilo.seamArc2Angle;
                }
                else if (isNear(stiloMouse, stiloHip1World, HIP_HANDLE_RADIUS))
                {
                    app->draggingStiloHip1 = 1;

                    PointF stiloHip1 = app->robotScene.stilo.hip1Circle;

                    app->stiloHip1DragFeetOffset.x = app->robotScene.stilo.feet1Circle.x - stiloHip1.x;
                    app->stiloHip1DragFeetOffset.y = app->robotScene.stilo.feet1Circle.y - stiloHip1.y;
                }
                else if (isNear(stiloMouse, stiloFeet1World, KNEE_HANDLE_RADIUS))
                {
                    app->draggingStiloFeet1 = 1;
                }
                else if (isNear(stiloMouse, stiloThigh1Arc1World, THIGH_HANDLE_RADIUS))
                {
                    app->draggingStiloThigh1Arc1 = 1;
                    app->stiloThigh1ArcDragStartPerp = perpOffsetOnAxis(stiloLeg1LocalMouseDown, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle);
                    app->stiloThigh1ArcDragStartAngle = app->robotScene.stilo.thigh1Arc1Angle;
                }
                else if (isNear(stiloMouse, stiloThigh1Arc2World, THIGH_HANDLE_RADIUS))
                {
                    app->draggingStiloThigh1Arc2 = 1;
                    app->stiloThigh1ArcDragStartPerp = perpOffsetOnAxis(stiloLeg1LocalMouseDown, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle);
                    app->stiloThigh1ArcDragStartAngle = app->robotScene.stilo.thigh1Arc2Angle;
                }
                else if (isNear(stiloMouse, stiloHip2World, HIP_HANDLE_RADIUS))
                {
                    app->draggingStiloHip2 = 1;

                    PointF stiloHip2 = app->robotScene.stilo.hip2Circle;

                    app->stiloHip2DragFeetOffset.x = app->robotScene.stilo.feet2Circle.x - stiloHip2.x;
                    app->stiloHip2DragFeetOffset.y = app->robotScene.stilo.feet2Circle.y - stiloHip2.y;
                }
                else if (isNear(stiloMouse, stiloFeet2World, KNEE_HANDLE_RADIUS))
                {
                    app->draggingStiloFeet2 = 1;
                }
                else if (isNear(stiloMouse, stiloThigh2Arc1World, THIGH_HANDLE_RADIUS))
                {
                    app->draggingStiloThigh2Arc1 = 1;
                    app->stiloThigh2ArcDragStartPerp = perpOffsetOnAxis(stiloLeg2LocalMouseDown, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle);
                    app->stiloThigh2ArcDragStartAngle = app->robotScene.stilo.thigh2Arc1Angle;
                }
                else if (isNear(stiloMouse, stiloThigh2Arc2World, THIGH_HANDLE_RADIUS))
                {
                    app->draggingStiloThigh2Arc2 = 1;
                    app->stiloThigh2ArcDragStartPerp = perpOffsetOnAxis(stiloLeg2LocalMouseDown, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle);
                    app->stiloThigh2ArcDragStartAngle = app->robotScene.stilo.thigh2Arc2Angle;
                }

                break;
            }

            // Per-joint hand-dragging beyond Rocky's one body handle and
            // Stilo's full handle set above only exists for Semni here --
            // this guard just stops the code below (which assumes
            // app->robotScene.robot) from running for either of them.
            if (app->robotScene.activeKind != ROBOT_KIND_SEMNI)
                break;

            PointF center = getCenter(app->robotScene.robot);

            PointF mouse = app->mouseGL;

            // seam attach handles: pinned to the exact midpoint between
            // head and butt on X, with Y solved from the arc's actual
            // fillet circle at that exact X (circleAtX) -- same
            // construction as drawSemniHandles, so the hit-test matches
            // exactly where the handle is actually drawn
            PointF headLocal = { app->robotScene.robot.headX, app->robotScene.robot.y };
            PointF buttLocal = { app->robotScene.robot.buttX, app->robotScene.robot.y };
            PointF bodyMidLocal = { (headLocal.x + buttLocal.x) * 0.5f, (headLocal.y + buttLocal.y) * 0.5f };

            Fillet seamArc1Fillet = filletFromAttachAngle(headLocal, app->robotScene.robot.headRadius, buttLocal, app->robotScene.robot.buttRadius, app->robotScene.robot.seamArc1Angle, MIN_ARC_R, MAX_ARC_R);
            Fillet seamArc2Fillet = filletFromAttachAngle(headLocal, app->robotScene.robot.headRadius, buttLocal, app->robotScene.robot.buttRadius, app->robotScene.robot.seamArc2Angle, MIN_ARC_R, MAX_ARC_R);

            PointF seamArc1NearLocal = circleTowardPoint(seamArc1Fillet.center, seamArc1Fillet.radius, bodyMidLocal);
            PointF seamArc2NearLocal = circleTowardPoint(seamArc2Fillet.center, seamArc2Fillet.radius, bodyMidLocal);

            PointF seamArc1MidLocal = circleAtX(seamArc1Fillet.center, seamArc1Fillet.radius, bodyMidLocal.x, seamArc1NearLocal);
            PointF seamArc2MidLocal = circleAtX(seamArc2Fillet.center, seamArc2Fillet.radius, bodyMidLocal.x, seamArc2NearLocal);

            PointF seamArc1HandleWorld = rotatePoint(seamArc1MidLocal, center, app->robotScene.robot.angle);
            PointF seamArc2HandleWorld = rotatePoint(seamArc2MidLocal, center, app->robotScene.robot.angle);

            PointF innerWorld = rotatePoint(app->robotScene.robot.innerCircle, center, app->robotScene.robot.angle);

            // the leg chain (knee, thigh handles, foot, shin handles) lives
            // in a frame that's additionally rotated by hipAngle around
            // innerCircle, independent of the whole-body angle
            PointF hipPivot = app->robotScene.robot.innerCircle;
            float hipAngle = app->robotScene.robot.hipAngle;

            PointF kneeWorld = jointToWorld(app->robotScene.robot.kneeCircle, hipPivot, hipAngle, center, app->robotScene.robot.angle);

            // thigh arc handles: same tangent-fillet + circleAtAxisMid
            // construction used in renderer.c's drawThighHandles, so the
            // hit-test matches exactly where the handle is actually drawn
            PointF thighAxisMidLocal = { (app->robotScene.robot.innerCircle.x + app->robotScene.robot.kneeCircle.x) * 0.5f,
                                         (app->robotScene.robot.innerCircle.y + app->robotScene.robot.kneeCircle.y) * 0.5f };

            Fillet thigh1Fillet = filletFromAttachAngle(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius,
                                                         app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                         app->robotScene.robot.thighArc1Angle, MIN_THIGH_ARC_R, MAX_SEMNI_THIGH_ARC_R);
            PointF thigh1NearLocal = circleTowardPoint(thigh1Fillet.center, thigh1Fillet.radius, thighAxisMidLocal);
            PointF thigh1MidLocal = circleAtAxisMid(thigh1Fillet.center, thigh1Fillet.radius, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle, thigh1NearLocal);

            // thighArc2Angle uses the concave construction (bulges inward
            // instead of outward) -- see app.h's comment. circleTowardPoint
            // + circleAtAxisMid work unchanged for it (purely geometric,
            // don't care whether the fillet is internally or externally
            // tangent), only the fillet solve itself differs.
            Fillet thigh2Fillet = filletFromAttachAngleConcave(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius,
                                                                app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                                app->robotScene.robot.thighArc2Angle, MIN_THIGH_ARC_R, MAX_THIGH_ARC2_CONCAVE_R);
            PointF thigh2NearLocal = circleTowardPoint(thigh2Fillet.center, thigh2Fillet.radius, thighAxisMidLocal);
            PointF thigh2MidLocal = circleAtAxisMid(thigh2Fillet.center, thigh2Fillet.radius, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle, thigh2NearLocal);

            PointF thigh1World = jointToWorld(thigh1MidLocal, hipPivot, hipAngle, center, app->robotScene.robot.angle);
            PointF thigh2World = jointToWorld(thigh2MidLocal, hipPivot, hipAngle, center, app->robotScene.robot.angle);

            // same leg-local frame the drag math in WM_MOUSEMOVE uses --
            // computed once here so both thigh handles' click-capture can
            // read the mouse's perpendicular-to-axis position at the
            // moment the drag starts
            PointF legLocalMouseDown = inverseRotate(inverseRotate(mouse, center, app->robotScene.robot.angle), hipPivot, hipAngle);

            // the shin (foot, shin handles) hangs off the knee, which
            // itself hangs off the hip -- two nested joint rotations
            // before it lands in world space
            PointF kneePivot = app->robotScene.robot.kneeCircle;
            float kneeAngle = app->robotScene.robot.kneeAngle;

            PointF footWorld = nestedJointToWorld(app->robotScene.robot.footCircle, kneePivot, kneeAngle, hipPivot, hipAngle, center, app->robotScene.robot.angle);

            // shin arc handles: same tangent-fillet + circleAtAxisMid
            // construction used for the thigh handles above (and in
            // renderer.c's drawShinHandles), just between kneeCircle and
            // footCircle instead of innerCircle and kneeCircle, so the
            // hit-test matches exactly where the handle is actually drawn
            PointF shinAxisMidLocal = { (app->robotScene.robot.kneeCircle.x + app->robotScene.robot.footCircle.x) * 0.5f,
                                        (app->robotScene.robot.kneeCircle.y + app->robotScene.robot.footCircle.y) * 0.5f };

            Fillet shin1Fillet = filletFromAttachAngle(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                        app->robotScene.robot.footCircle, app->robotScene.robot.footRadius,
                                                        app->robotScene.robot.shinArc1Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC_R);
            PointF shin1NearLocal = circleTowardPoint(shin1Fillet.center, shin1Fillet.radius, shinAxisMidLocal);
            PointF shin1MidLocal = circleAtAxisMid(shin1Fillet.center, shin1Fillet.radius, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle, shin1NearLocal);

            // shinArc2Angle uses the concave construction (bulges inward
            // instead of outward -- see app.h's comment), same as
            // thighArc2Angle
            Fillet shin2Fillet = filletFromAttachAngleConcave(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                               app->robotScene.robot.footCircle, app->robotScene.robot.footRadius,
                                                               app->robotScene.robot.shinArc2Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC2_CONCAVE_R);
            PointF shin2NearLocal = circleTowardPoint(shin2Fillet.center, shin2Fillet.radius, shinAxisMidLocal);
            PointF shin2MidLocal = circleAtAxisMid(shin2Fillet.center, shin2Fillet.radius, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle, shin2NearLocal);

            PointF shin1World = nestedJointToWorld(shin1MidLocal, kneePivot, kneeAngle, hipPivot, hipAngle, center, app->robotScene.robot.angle);
            PointF shin2World = nestedJointToWorld(shin2MidLocal, kneePivot, kneeAngle, hipPivot, hipAngle, center, app->robotScene.robot.angle);

            // same leg-local frame the drag math in WM_MOUSEMOVE uses --
            // computed once here so both shin handles' click-capture can
            // read the mouse's perpendicular-to-axis position (relative to
            // the knee->foot axis) at the moment the drag starts
            PointF shinLocalMouseDown = inverseRotate(legLocalMouseDown, kneePivot, kneeAngle);

            // Body/Leg Weight mass-center dot -- same idea as Rocky's own
            // (see that block's comment further up), just against Semni's
            // bodyWeight/legWeight and computeSemniMassCenterWorld. Checked
            // first, gated on Shift like Rocky's own version, but WITHOUT
            // Rocky's closest-wins tie-break: Semni's body/leg centroids
            // don't algebraically coincide with any single existing handle
            // the way Rocky's rect-centroid-equals-body-handle case does,
            // so a plain Shift+proximity check is enough here.
            PointF semniMassCenterWorld = computeSemniMassCenterWorld(app->robotScene.robot);

            if ((LOWORD(wParam) & MK_SHIFT) && isNear(mouse, semniMassCenterWorld, MASS_CENTER_HANDLE_RADIUS))
            {
                app->draggingSemniMassCenter = 1;

                float semniTotal = app->robotScene.robot.bodyWeight + app->robotScene.robot.legWeight;
                app->semniMassCenterDragTotal = (semniTotal > 1e-6f) ? semniTotal : 1.0f;
            }
            else if (isNear(mouse, seamArc1HandleWorld, ARC_HANDLE_RADIUS))
            {
                app->draggingSeamArc1 = 1;
                app->activeHandle = 1;

                // remember where the drag started (mouse Y + current
                // angle) so WM_MOUSEMOVE can nudge the angle incrementally
                // from here instead of solving an absolute position
                app->arcDragStartMouseY = inverseRotate(mouse, center, app->robotScene.robot.angle).y;
                app->arcDragStartAngle = app->robotScene.robot.seamArc1Angle;
            }
            else if (isNear(mouse, seamArc2HandleWorld, ARC_HANDLE_RADIUS))
            {
                app->draggingSeamArc2 = 1;
                app->activeHandle = 2;

                app->arcDragStartMouseY = inverseRotate(mouse, center, app->robotScene.robot.angle).y;
                app->arcDragStartAngle = app->robotScene.robot.seamArc2Angle;
            }
            else if (isNear(mouse, innerWorld, HIP_HANDLE_RADIUS))
            {
                app->draggingInner = 1;
                app->activeHandle = 3;

                // remember the whole leg's offset from the hip right now,
                // so dragging the hip can carry it along as one rigid
                // piece instead of leaving it behind
                PointF hip = app->robotScene.robot.innerCircle;

                app->hipDragKneeOffset.x = app->robotScene.robot.kneeCircle.x - hip.x;
                app->hipDragKneeOffset.y = app->robotScene.robot.kneeCircle.y - hip.y;

                // thighArc1Angle/thighArc2Angle/shinArc1Angle/shinArc2Angle
                // need no offset -- they're already relative to their own
                // joint (hip or knee), unaffected by moving innerCircle
                // itself

                app->hipDragFootOffset.x = app->robotScene.robot.footCircle.x - hip.x;
                app->hipDragFootOffset.y = app->robotScene.robot.footCircle.y - hip.y;
            }
            else if (isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS))
            {
                app->draggingKnee = 1;
                app->activeHandle = 4;

                // remember the shin's offset from the knee right now, so
                // it can be pinned to this exact shape/length for the
                // whole drag instead of drifting frame by frame
                PointF knee = app->robotScene.robot.kneeCircle;

                app->kneeDragFootOffset.x = app->robotScene.robot.footCircle.x - knee.x;
                app->kneeDragFootOffset.y = app->robotScene.robot.footCircle.y - knee.y;

                // shinArc1Angle/shinArc2Angle need no offset -- they're
                // already knee-frame-relative angles, unaffected by moving
                // kneeCircle itself
            }
            // Foot's priority moved up to right after Knee (was after both
            // thigh handles) -- see this file's own comment above this
            // whole chain for the full Head/Butt/Seam/Hip/Knee/Feet/
            // Thigh/Shin ordering this now follows.
            else if (isNear(mouse, footWorld, FOOT_HANDLE_RADIUS))
            {
                app->draggingFoot = 1;
                app->activeHandle = 5;
            }
            else if (isNear(mouse, thigh1World, THIGH_HANDLE_RADIUS))
            {
                app->draggingThigh1 = 1;
                app->activeHandle = 6;

                // remember where the drag started (mouse's perpendicular-
                // to-axis offset + current angle) so WM_MOUSEMOVE can nudge
                // the angle incrementally from here, same idea as
                // arcDragStartMouseY/arcDragStartAngle for the seam arcs
                app->thighArcDragStartPerp = perpOffsetOnAxis(legLocalMouseDown, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle);
                app->thighArcDragStartAngle = app->robotScene.robot.thighArc1Angle;
            }
            else if (isNear(mouse, thigh2World, THIGH_HANDLE_RADIUS))
            {
                app->draggingThigh2 = 1;
                app->activeHandle = 7;

                app->thighArcDragStartPerp = perpOffsetOnAxis(legLocalMouseDown, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle);
                app->thighArcDragStartAngle = app->robotScene.robot.thighArc2Angle;
            }
            else if (isNear(mouse, shin1World, SHIN_HANDLE_RADIUS))
            {
                app->draggingShin1 = 1;
                app->activeHandle = 8;

                // remember where the drag started (mouse's perpendicular-
                // to-axis offset, relative to the knee->foot axis + the
                // current angle), same idea as thighArcDragStartPerp/Angle
                app->shinArcDragStartPerp = perpOffsetOnAxis(shinLocalMouseDown, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle);
                app->shinArcDragStartAngle = app->robotScene.robot.shinArc1Angle;
            }
            else if (isNear(mouse, shin2World, SHIN_HANDLE_RADIUS))
            {
                app->draggingShin2 = 1;
                app->activeHandle = 9;

                app->shinArcDragStartPerp = perpOffsetOnAxis(shinLocalMouseDown, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle);
                app->shinArcDragStartAngle = app->robotScene.robot.shinArc2Angle;
            }
        }
        break;

        case WM_LBUTTONUP:
        {
            ReleaseCapture();

            app->draggingSeamArc1 = 0;
            app->draggingSeamArc2 = 0;
            app->draggingInner = 0;
            app->draggingKnee = 0;
            app->draggingThigh1 = 0;
            app->draggingThigh2 = 0;
            app->draggingFoot = 0;
            app->draggingShin1 = 0;
            app->draggingShin2 = 0;
            app->draggingRockyBody = 0;
            app->draggingRockyEdge = ROCKY_EDGE_NONE;
            app->draggingRockyKnee = 0;
            app->draggingRockyFoot = 0;
            app->draggingRockyMassCenter = 0;
            app->draggingSemniMassCenter = 0;
            app->draggingStiloMassCenter = 0;
            app->draggingRockyShin1 = 0;
            app->draggingRockyShin2 = 0;
            app->draggingStiloSeamArc1 = 0;
            app->draggingStiloSeamArc2 = 0;
            app->draggingStiloHip1 = 0;
            app->draggingStiloFeet1 = 0;
            app->draggingStiloThigh1Arc1 = 0;
            app->draggingStiloThigh1Arc2 = 0;
            app->draggingStiloHip2 = 0;
            app->draggingStiloFeet2 = 0;
            app->draggingStiloThigh2Arc1 = 0;
            app->draggingStiloThigh2Arc2 = 0;
            app->activeHandle = 0;

            // Whatever handle was just released, the pose may have
            // changed -- refresh the mm size readout. See
            // updateRobotSizeLabel's own comment for why this only
            // updates on release rather than live during the drag.
            updateRobotSizeLabel(app);
        }
        break;

        case WM_MOUSEMOVE:
        {
            int mx = GET_X_LPARAM(lParam);
            int my = GET_Y_LPARAM(lParam);

            if (semniPanning)
            {
                // Same reasoning as WM_MBUTTONDOWN's own SetCursor call
                // just above -- re-assert the hand cursor on every move
                // for the rest of the drag, matching canvas.c's own
                // ArcSpline panning (WM_MOUSEMOVE there).
                SetCursor(LoadCursor(NULL, IDC_HAND));

                int dx = mx - semniPanLastX;
                int dy = my - semniPanLastY;

                graphicsPan(dx, dy);

                semniPanLastX = mx;
                semniPanLastY = my;

                InvalidateRect(hwnd, NULL, FALSE);
                return 0;
            }

            screenToGL(hwnd, mx, my, &app->mouseGL.x, &app->mouseGL.y);

            // Rocky's body handle: hover highlight + drag-to-move, same
            // "capture the leg's offset once, re-apply every move" pattern
            // as Semni's own hip drag (see WM_LBUTTONDOWN's draggingInner
            // handling) -- just simpler, since Rocky's handle IS its own
            // rotation pivot (getRockyCenter), so there's no separate
            // fixed torso frame the way Semni's head/butt-defined center
            // is for its hip.
            if (app->robotScene.activeKind == ROBOT_KIND_ROCKY)
            {
                PointF rockyCenter = getRockyCenter(app->robotScene.rocky);

                // Same local frame hitTestRockyEdge expects -- computed
                // once here so it can feed both the hover check below and
                // the resize-drag branch further down.
                PointF localMouse = inverseRotate(app->mouseGL, rockyCenter, app->robotScene.rocky.angle);

                PointF kneeWorld = rotatePoint(app->robotScene.rocky.kneeCircle, rockyCenter, app->robotScene.rocky.angle);
                PointF footWorld = jointToWorld(app->robotScene.rocky.footCircle, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle, rockyCenter, app->robotScene.rocky.angle);

                // Body/Leg Weight mass-center dot's CURRENT position -- see
                // rockyMassCenterWins's own comment for why it no longer
                // unconditionally wins the priority chain below.
                PointF rockyMassCenterWorld = computeRockyMassCenterWorld(app->robotScene.rocky);

                // Shin connector-arc handle positions -- moved up ahead of
                // the priority decision below (used to be computed after
                // it) so rockyMassCenterWins has real shin handle points
                // to compare distances against too, not just Body/Edge/
                // Knee/Foot. Same circleAtAxisMid construction as
                // renderer.c's drawRocky and this same WM_MOUSEMOVE's own
                // WM_LBUTTONDOWN hit-test. No stored hoverRockyShin1/2
                // flag, same as Semni's own shin handles -- just a direct
                // isNear check for the label, further below.
                PointF rockyShinAxisMidLocal = { (app->robotScene.rocky.kneeCircle.x + app->robotScene.rocky.footCircle.x) * 0.5f,
                                                  (app->robotScene.rocky.kneeCircle.y + app->robotScene.rocky.footCircle.y) * 0.5f };

                Fillet rockyShin1Fillet = filletFromAttachAngle(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius,
                                                                 app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius,
                                                                 app->robotScene.rocky.shinArc1Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC_R);
                PointF rockyShin1NearLocal = circleTowardPoint(rockyShin1Fillet.center, rockyShin1Fillet.radius, rockyShinAxisMidLocal);
                PointF rockyShin1MidLocal = circleAtAxisMid(rockyShin1Fillet.center, rockyShin1Fillet.radius, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle, rockyShin1NearLocal);

                Fillet rockyShin2Fillet = filletFromAttachAngleConcave(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius,
                                                                        app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius,
                                                                        app->robotScene.rocky.shinArc2Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC2_CONCAVE_R);
                PointF rockyShin2NearLocal = circleTowardPoint(rockyShin2Fillet.center, rockyShin2Fillet.radius, rockyShinAxisMidLocal);
                PointF rockyShin2MidLocal = circleAtAxisMid(rockyShin2Fillet.center, rockyShin2Fillet.radius, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle, rockyShin2NearLocal);

                PointF rockyShin1World = jointToWorld(rockyShin1MidLocal, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle, rockyCenter, app->robotScene.rocky.angle);
                PointF rockyShin2World = jointToWorld(rockyShin2MidLocal, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle, rockyCenter, app->robotScene.rocky.angle);

                // Priority order: Mass Center, Body, the 4 rectangle-edge
                // segments (Width/Height resize), Knee, Foot -- edges win
                // over Knee/Foot instead of only being checked as a
                // last-resort, mirroring WM_LBUTTONDOWN's own
                // rockyEdgeHitDown ordering. Mass Center only actually
                // wins its own hit-test when Shift is held (see
                // WM_LBUTTONDOWN's own matching Shift check -- dragging
                // the dot is Shift-locked so it doesn't move by accident
                // during ordinary Body-handle drags, given how close the
                // two can sit) AND rockyMassCenterWins agrees it's the
                // CLOSER of the two (see that function's own comment) --
                // computed against whichever of Body/Edge/Knee/Foot/
                // Shin1/Shin2 the mouse is also currently near, rather
                // than unconditionally, so it no longer steals hover from
                // a handle it merely happens to be sitting near. Gating
                // the hover on Shift too (not just the drag) keeps the
                // highlighted handle always matching whatever a click
                // would actually grab.
                int rockyEdgeHitNow = hitTestRockyEdge(app->robotScene.rocky, localMouse);
                BOOL rockyMassHitNow = (LOWORD(wParam) & MK_SHIFT) &&
                    isNear(app->mouseGL, rockyMassCenterWorld, MASS_CENTER_HANDLE_RADIUS);
                BOOL rockyMassWinsNow = rockyMassHitNow &&
                    rockyMassCenterWins(app->mouseGL, rockyMassCenterWorld, rockyCenter, rockyEdgeHitNow,
                                         app->robotScene.rocky, kneeWorld, footWorld, rockyShin1World, rockyShin2World);

                // Same rockyEdgeWins tie-break WM_LBUTTONDOWN now uses --
                // keeps the hover highlight matching whatever a click
                // would actually grab, including a knee/foot/shin handle
                // sitting in a corner an edge's own hit-test slack also
                // reaches into.
                BOOL rockyEdgeWinsNow = (rockyEdgeHitNow != ROCKY_EDGE_NONE) &&
                    rockyEdgeWins(app->mouseGL, rockyEdgeMidWorld(app->robotScene.rocky, rockyEdgeHitNow, rockyCenter),
                                  kneeWorld, footWorld, rockyShin1World, rockyShin2World);

                // Testing-only toggles (ID_ROCKY_TOGGLE_LEG_BUTTON/
                // ID_ROCKY_TOGGLE_BODY_BUTTON) -- AND'd into each
                // assignment below (rather than restructuring the whole
                // priority cascade above) so a hidden part's condition
                // simply reads false and the cascade falls through to
                // whatever's next in priority exactly like the part was
                // never there, same treatment as the mirrored
                // WM_LBUTTONDOWN cascade above.
                BOOL rockyLegHidden = app->robotScene.rocky.legHidden;
                BOOL rockyBodyHidden = app->robotScene.rocky.bodyHidden;

                app->hoverRockyMassCenter = rockyMassWinsNow;
                app->hoverRockyBody = !rockyBodyHidden && !app->hoverRockyMassCenter && isNear(app->mouseGL, rockyCenter, HIP_HANDLE_RADIUS);
                app->hoverRockyEdge = (rockyBodyHidden || app->hoverRockyMassCenter || app->hoverRockyBody || !rockyEdgeWinsNow) ? ROCKY_EDGE_NONE : rockyEdgeHitNow;
                app->hoverRockyKnee = !rockyLegHidden && !app->hoverRockyMassCenter && !app->hoverRockyBody && app->hoverRockyEdge == ROCKY_EDGE_NONE && isNear(app->mouseGL, kneeWorld, KNEE_HANDLE_RADIUS);
                app->hoverRockyFoot = !rockyLegHidden && !app->hoverRockyMassCenter && !app->hoverRockyBody && app->hoverRockyEdge == ROCKY_EDGE_NONE && !app->hoverRockyKnee && isNear(app->mouseGL, footWorld, FOOT_HANDLE_RADIUS);

                // Requested directly: hovering a shin arc handle (not just
                // dragging it) should also turn it yellow -- same treatment
                // Semni's own hoverSeamArc1/hoverThigh1/etc. give their own
                // arc handles.
                BOOL hoverRockyShin1Now = !rockyLegHidden && isNear(app->mouseGL, rockyShin1World, ROCKY_SHIN_HANDLE_RADIUS);
                BOOL hoverRockyShin2Now = !rockyLegHidden && isNear(app->mouseGL, rockyShin2World, ROCKY_SHIN_HANDLE_RADIUS);
                app->hoverRockyShin1 = hoverRockyShin1Now;
                app->hoverRockyShin2 = hoverRockyShin2Now;

                const wchar_t* rockyHoverLabel = L"";
                if (app->hoverRockyMassCenter)
                    rockyHoverLabel = L"Weight Balance";
                else if (app->hoverRockyBody)
                    rockyHoverLabel = L"Body";
                else if (app->hoverRockyEdge == ROCKY_EDGE_LEFT)
                    rockyHoverLabel = L"Body Width 2";
                else if (app->hoverRockyEdge == ROCKY_EDGE_RIGHT)
                    rockyHoverLabel = L"Body Width 1";
                else if (app->hoverRockyEdge == ROCKY_EDGE_TOP)
                    rockyHoverLabel = L"Body Height 1";
                else if (app->hoverRockyEdge == ROCKY_EDGE_BOTTOM)
                    rockyHoverLabel = L"Body Height 2";
                else if (app->hoverRockyKnee)
                    rockyHoverLabel = L"Knee";
                else if (app->hoverRockyFoot)
                    rockyHoverLabel = L"Foot";
                else if (hoverRockyShin1Now)
                    rockyHoverLabel = L"Shin Arc 1";
                else if (hoverRockyShin2Now)
                    rockyHoverLabel = L"Shin Arc 2";
                SetWindowText(app->ui.hHoverLabel, rockyHoverLabel);

                // View Segments hover -- same idea as Semni's own version
                // further down (computeRockyArcPoints' trimmed fillet
                // curve for the 2 shin arcs, computeRockyBodyCircles'
                // real circles for knee/foot, computeRockyRectSegments'
                // straight edges for the rectangular body), against
                // Rocky's own 2-fillet/2-body-circle/4-rect-edge set
                // (renderer.c/h's NUM_ROCKY_CIRCLE_SEGMENTS/
                // NUM_ROCKY_BODY_CIRCLES/NUM_ROCKY_RECT_SEGMENTS). Placed
                // here, inside this block and BEFORE the drag handling
                // below, rather than after this whole if (activeKind ==
                // ROCKY) block -- everything past this block's own closing
                // break (a little further down) is unreachable whenever
                // Rocky is active, since that break always fires first.
                if (app->showCircleSegments)
                {
                    PointF rockyArcPoints[NUM_ROCKY_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
                    int rockyArcCounts[NUM_ROCKY_CIRCLE_SEGMENTS];
                    computeRockyArcPoints(app->robotScene.rocky, rockyArcPoints, rockyArcCounts);

                    CircleSegment rockyBodySegs[NUM_ROCKY_BODY_CIRCLES];
                    computeRockyBodyCircles(app->robotScene.rocky, rockyBodySegs);

                    RockyEdgeSegment rockyRectSegs[NUM_ROCKY_RECT_SEGMENTS];
                    computeRockyRectSegments(app->robotScene.rocky, rockyRectSegs);

                    float rockyEffectiveZoom = graphicsGetZoom() * graphicsGetRobotScale();
                    float rockyTolerance = 0.05f / rockyEffectiveZoom;

                    int bestFillet = -1;
                    int bestBody = -1;
                    int bestRect = -1;
                    float bestDist = rockyTolerance;

                    for (int i = 0; i < NUM_ROCKY_CIRCLE_SEGMENTS; i++)
                    {
                        for (int k = 0; k < rockyArcCounts[i] - 1; k++)
                        {
                            float d = distPointFToSegment(app->mouseGL, rockyArcPoints[i][k], rockyArcPoints[i][k + 1]);
                            if (d < bestDist)
                            {
                                bestDist = d;
                                bestFillet = i;
                                bestBody = -1;
                                bestRect = -1;
                            }
                        }
                    }

                    for (int i = 0; i < NUM_ROCKY_BODY_CIRCLES; i++)
                    {
                        float dx = app->mouseGL.x - rockyBodySegs[i].center.x;
                        float dy = app->mouseGL.y - rockyBodySegs[i].center.y;
                        float distToCenter = sqrtf(dx * dx + dy * dy);
                        float distToEdge = fabsf(distToCenter - rockyBodySegs[i].radius);

                        if (distToEdge < bestDist)
                        {
                            bestDist = distToEdge;
                            bestBody = i;
                            bestFillet = -1;
                            bestRect = -1;
                        }
                    }

                    for (int i = 0; i < NUM_ROCKY_RECT_SEGMENTS; i++)
                    {
                        float d = distPointFToSegment(app->mouseGL, rockyRectSegs[i].start, rockyRectSegs[i].end);
                        if (d < bestDist)
                        {
                            bestDist = d;
                            bestRect = i;
                            bestFillet = -1;
                            bestBody = -1;
                        }
                    }

                    app->hoveredCircleSegment = bestFillet;
                    app->hoveredBodyCircle = bestBody;
                    app->hoveredRectSegment = bestRect;
                }
                else
                {
                    app->hoveredCircleSegment = -1;
                    app->hoveredBodyCircle = -1;
                    app->hoveredRectSegment = -1;
                }

                if (app->draggingRockyBody)
                {
                    // The body handle IS the whole-body rotation pivot
                    // itself (getRockyCenter just returns bodyX/bodyY
                    // directly) -- unlike every other Rocky handle, which
                    // lives in the rectangle's LOCAL, un-rotated frame and
                    // needs localMouse (the mouse rotated by -angle around
                    // this same pivot) to compare against local bounds,
                    // moving the pivot ITSELF needs the RAW world mouse
                    // position, not a rotated proxy of it -- localMouse
                    // and the real cursor position only coincide when
                    // rocky.angle happens to be exactly 0, so using it
                    // here (as this used to) made the whole body (and the
                    // knee/foot rigidly carried along with it) jump to a
                    // rotated-looking location the instant the robot had
                    // been rotated at all. Knee/foot still use their own
                    // captured offset from the body (set at drag-start),
                    // just added to the raw mouse now instead -- valid
                    // because that offset is a pure rigid translation (the
                    // whole group's angle doesn't change during a body
                    // drag), so no rotation math belongs in any of the
                    // three anymore.
                    app->robotScene.rocky.bodyX = app->mouseGL.x;
                    app->robotScene.rocky.bodyY = app->mouseGL.y;

                    app->robotScene.rocky.kneeCircle.x = app->mouseGL.x + app->rockyDragKneeOffset.x;
                    app->robotScene.rocky.kneeCircle.y = app->mouseGL.y + app->rockyDragKneeOffset.y;

                    app->robotScene.rocky.footCircle.x = app->mouseGL.x + app->rockyDragFootOffset.x;
                    app->robotScene.rocky.footCircle.y = app->mouseGL.y + app->rockyDragFootOffset.y;
                }
                else if (app->draggingRockyKnee)
                {
                    // Detached by explicit request -- the knee handle
                    // just follows the mouse directly, with no clamp
                    // keeping its pivot point inside the rectangle
                    // (previously it was clamped straight to the body's
                    // own bounds). The whole leg can now be dragged out
                    // and posed anywhere, not just somewhere within the
                    // torso -- there's no other invariant relying on the
                    // knee staying inside the body (Rocky's own default
                    // poses already place the foot outside it, see
                    // app_init.c's initRockyStandingPosition/
                    // initRockyHomePosition).
                    PointF newKnee = localMouse;
                    app->robotScene.rocky.kneeCircle = newKnee;

                    // re-anchor the shin to the offset captured when the
                    // drag started, so its length/shape can't drift over a
                    // long drag -- only the knee's own position is
                    // changing here
                    app->robotScene.rocky.footCircle.x = newKnee.x + app->rockyKneeDragFootOffset.x;
                    app->robotScene.rocky.footCircle.y = newKnee.y + app->rockyKneeDragFootOffset.y;
                }
                else if (app->draggingRockyFoot)
                {
                    // shin-local frame: undo kneeAngle around kneeCircle,
                    // same as Semni's own shinLocalMouse -- constrainToAxis
                    // then keeps the foot sliding along the knee->foot
                    // axis so only the leg's length changes, not its
                    // bend/direction (that's kneeAngle's job).
                    PointF shinLocalMouse = inverseRotate(localMouse, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle);

                    app->robotScene.rocky.footCircle = constrainToAxis(
                        app->robotScene.rocky.kneeCircle,
                        app->robotScene.rocky.footCircle,
                        shinLocalMouse,
                        MIN_LIMB_LENGTH);

                    // knee<->foot distance just changed, so the shin arcs'
                    // fillet solve did too -- re-validate their existing
                    // angles against it, same as Semni's own adjustShinArcs
                    adjustRockyShinArcs(app);
                }
                else if (app->draggingRockyMassCenter)
                {
                    // Doesn't move a geometric field at all (see app.h's
                    // own comment on hoverRockyMassCenter/
                    // draggingRockyMassCenter) -- re-derives bodyWeight/
                    // legWeight instead, by projecting the mouse onto the
                    // rect-centroid<->leg-centroid segment (the only
                    // positions reachable by a non-negative weight ratio)
                    // and reading off how far along it the projection
                    // landed.
                    PointF rectCentroidWorld, legCentroidWorld;
                    computeRockyMassCenterEndpointsWorld(app->robotScene.rocky, &rectCentroidWorld, &legCentroidWorld);

                    float segX = legCentroidWorld.x - rectCentroidWorld.x;
                    float segY = legCentroidWorld.y - rectCentroidWorld.y;
                    float segLenSq = segX * segX + segY * segY;

                    // t=0 -> rect centroid (bodyWeight-only), t=1 -> leg
                    // centroid (legWeight-only) -- clamped to [0,1] since
                    // neither weight can go negative to extrapolate past
                    // either end. segLenSq near 0 means the two centroids
                    // themselves are (nearly) coincident -- nothing
                    // meaningful to project onto, so the ratio is just left
                    // wherever it already was (skip the update entirely
                    // rather than divide by ~0).
                    if (segLenSq > 1e-9f)
                    {
                        float t = ((app->mouseGL.x - rectCentroidWorld.x) * segX + (app->mouseGL.y - rectCentroidWorld.y) * segY) / segLenSq;
                        if (t < 0.0f) t = 0.0f;
                        if (t > 1.0f) t = 1.0f;

                        // total held fixed at whatever it was when the drag
                        // started (app->rockyMassCenterDragTotal, captured
                        // in WM_LBUTTONDOWN) -- only the split between the
                        // two changes.
                        float total = app->rockyMassCenterDragTotal;
                        app->robotScene.rocky.bodyWeight = (1.0f - t) * total;
                        app->robotScene.rocky.legWeight = t * total;

                        // Keep hWeightRatioSlider showing the same split
                        // the drag just derived -- TBM_SETPOS doesn't raise
                        // WM_HSCROLL, so this can't recursively re-trigger
                        // its own handler and fight with the drag.
                        syncWeightRatioSlider(app, app->robotScene.rocky.bodyWeight, app->robotScene.rocky.legWeight);
                    }
                }
                else if (app->draggingRockyShin1)
                {
                    // Same incremental, perpendicular-offset drag math as
                    // Semni's own draggingShin1 (see this file's
                    // ROBOT_KIND_SEMNI block) -- reads the mouse's
                    // perpendicular movement relative to the knee->foot
                    // axis (in the shin-local frame, kneeAngle undone) and
                    // nudges shinArc1Angle from wherever the drag started,
                    // clamped to the convex fillet's own safe range so it
                    // can't flatten into a line or flip to the other side.
                    PointF rockyShinLocalMouse = inverseRotate(localMouse, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle);

                    SafeAngleRange range = filletSafeAngleRange(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius,
                                                                 app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius,
                                                                 MAX_SHIN_ARC_R);
                    float maxDelta = range.halfWidthDeg - SHIN_ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < SHIN_ARC_SIDE_MARGIN_DEG) maxDelta = SHIN_ARC_SIDE_MARGIN_DEG;

                    // NEW: same mirror-aware side derivation as Semni's
                    // draggingThigh1/draggingShin1 (see their comments in
                    // the ROBOT_KIND_SEMNI block above). mirrorRockyLeg
                    // (robot.c) reflects shinArc1Angle via mirrorArcAngle's
                    // "180 - angle" trick -- a genuine mirror reflection,
                    // which reverses orientation even though kneeCircle/
                    // footCircle (and so range.centerDeg) don't move: the
                    // side of centerDeg that was "correct" before mirroring
                    // ends up on the OPPOSITE side after. The hardcoded
                    // "always negative" clamp used to snap the arc back to
                    // the wrong side the instant a drag started on a
                    // mirrored leg -- re-deriving the side from
                    // rockyShinArcDragStartAngle (the actual current angle)
                    // fixes that the same way it did for Semni.
                    float startDelta = app->rockyShinArcDragStartAngle - range.centerDeg;
                    while (startDelta > 180.0f) startDelta -= 360.0f;
                    while (startDelta < -180.0f) startDelta += 360.0f;
                    BOOL positiveSide = (startDelta >= 0.0f);

                    float perpNow = perpOffsetOnAxis(rockyShinLocalMouse, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle);
                    float raw = app->rockyShinArcDragStartAngle + (perpNow - app->rockyShinArcDragStartPerp) * SHIN_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (positiveSide)
                    {
                        if (delta < SHIN_ARC_SIDE_MARGIN_DEG) delta = SHIN_ARC_SIDE_MARGIN_DEG;
                        if (delta > maxDelta) delta = maxDelta;
                    }
                    else
                    {
                        if (delta > -SHIN_ARC_SIDE_MARGIN_DEG) delta = -SHIN_ARC_SIDE_MARGIN_DEG;
                        if (delta < -maxDelta) delta = -maxDelta;
                    }

                    app->robotScene.rocky.shinArc1Angle = range.centerDeg + delta;
                }
                else if (app->draggingRockyShin2)
                {
                    // Concave counterpart, same as Semni's own
                    // draggingShin2 -- its own disjoint safe range
                    // (filletSafeAngleRangeConcave), no one-sided lock
                    // needed since it doesn't share shinArc1Angle's
                    // degenerate center.
                    PointF rockyShinLocalMouse = inverseRotate(localMouse, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle);

                    SafeAngleRange range = filletSafeAngleRangeConcave(app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeRadius,
                                                                        app->robotScene.rocky.footCircle, app->robotScene.rocky.footRadius,
                                                                        MAX_SHIN_ARC2_CONCAVE_R);
                    float maxDelta = range.halfWidthDeg - SHIN_ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < 0.0f) maxDelta = 0.0f;

                    float perpNow = perpOffsetOnAxis(rockyShinLocalMouse, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.footCircle);
                    float raw = app->rockyShinArcDragStartAngle + (perpNow - app->rockyShinArcDragStartPerp) * SHIN_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (delta > maxDelta) delta = maxDelta;
                    if (delta < -maxDelta) delta = -maxDelta;

                    app->robotScene.rocky.shinArc2Angle = range.centerDeg + delta;
                }
                else if (app->draggingRockyEdge == ROCKY_EDGE_LEFT || app->draggingRockyEdge == ROCKY_EDGE_RIGHT)
                {
                    // Dragging a side edge stretches the half-width only --
                    // the opposite edge (and the whole rectangle's center/
                    // leg) stays put, same as dragging a window border.
                    float newHalfWidth = fabsf(localMouse.x - app->robotScene.rocky.bodyX);
                    if (newHalfWidth < MIN_ROCKY_BODY_HALF) newHalfWidth = MIN_ROCKY_BODY_HALF;
                    if (newHalfWidth > MAX_ROCKY_BODY_HALF) newHalfWidth = MAX_ROCKY_BODY_HALF;
                    app->robotScene.rocky.bodyHalfWidth = newHalfWidth;

                    // The knee (and the foot/shin hanging off it) used to
                    // get pulled back inside a shrinking rectangle here --
                    // removed along with the knee's own drag clamp above,
                    // since the knee isn't bound to the body at all
                    // anymore (detached by explicit request).
                }
                else if (app->draggingRockyEdge == ROCKY_EDGE_TOP || app->draggingRockyEdge == ROCKY_EDGE_BOTTOM)
                {
                    float newHalfHeight = fabsf(localMouse.y - app->robotScene.rocky.bodyY);
                    if (newHalfHeight < MIN_ROCKY_BODY_HALF) newHalfHeight = MIN_ROCKY_BODY_HALF;
                    if (newHalfHeight > MAX_ROCKY_BODY_HALF) newHalfHeight = MAX_ROCKY_BODY_HALF;
                    app->robotScene.rocky.bodyHalfHeight = newHalfHeight;

                    // same reasoning as the width edges above -- no
                    // longer needed, see that comment
                }
                break;
            }

            // Stilo now has just two joints per leg (hip + feet) worth of
            // hover/drag feedback -- same construction as the
            // ROBOT_KIND_SEMNI block below, operating on
            // app->robotScene.stilo and the Stilo-specific hoverStilo*/
            // draggingStilo*/stilo* fields instead of Semni's own. View
            // Segments hover (hoveredCircleSegment/hoveredBodyCircle) is
            // computed a little further down, after stiloMouse/
            // stiloCenter/stiloAngle exist -- see that block's own comment.
            if (app->robotScene.activeKind == ROBOT_KIND_STILO)
            {
                PointF stiloMouse = app->mouseGL;

                PointF stiloCenter = getStiloCenter(app->robotScene.stilo);
                float stiloAngle = app->robotScene.stilo.angle;

                PointF stiloHip1World  = rotatePoint(app->robotScene.stilo.hip1Circle, stiloCenter, stiloAngle);
                PointF stiloFeet1World = jointToWorld(app->robotScene.stilo.feet1Circle, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Angle, stiloCenter, stiloAngle);
                PointF stiloHeadWorld  = rotatePoint((PointF){app->robotScene.stilo.headX, app->robotScene.stilo.y}, stiloCenter, stiloAngle);
                PointF stiloButtWorld  = rotatePoint((PointF){app->robotScene.stilo.buttX, app->robotScene.stilo.y}, stiloCenter, stiloAngle);

                app->hoverStiloHip1  = isNear(stiloMouse, stiloHip1World, HIP_HANDLE_RADIUS);
                app->hoverStiloFeet1 = isNear(stiloMouse, stiloFeet1World, KNEE_HANDLE_RADIUS);
                app->hoverStiloHead = isNear(stiloMouse, stiloHeadWorld, HEAD_BUTT_HANDLE_RADIUS);
                app->hoverStiloButt = isNear(stiloMouse, stiloButtWorld, HEAD_BUTT_HANDLE_RADIUS);

                // leg 2's own hip/feet hover -- same construction as leg 1's
                // above, against app->robotScene.stilo's hip2/feet2 fields.
                // No leg-2 equivalent of hoverStiloHead/hoverStiloButt --
                // those are torso-level, shared with leg 1.
                PointF stiloHip2World  = rotatePoint(app->robotScene.stilo.hip2Circle, stiloCenter, stiloAngle);
                PointF stiloFeet2World = jointToWorld(app->robotScene.stilo.feet2Circle, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Angle, stiloCenter, stiloAngle);

                app->hoverStiloHip2  = isNear(stiloMouse, stiloHip2World, HIP_HANDLE_RADIUS);
                app->hoverStiloFeet2 = isNear(stiloMouse, stiloFeet2World, KNEE_HANDLE_RADIUS);

                // Body/Leg Weight mass-center dot -- same Shift-gated
                // proximity hover as Semni's own hoverSemniMassCenter (see
                // that check's comment on why no closest-wins tie-break is
                // needed here, unlike Rocky's version).
                app->hoverStiloMassCenter = (LOWORD(wParam) & MK_SHIFT) &&
                    isNear(stiloMouse, computeStiloMassCenterWorld(app->robotScene.stilo), MASS_CENTER_HANDLE_RADIUS);

                // hover label -- same construction/priority order as
                // Semni's own hover label block below
                {
                    PointF stiloHeadLocalHover = { app->robotScene.stilo.headX, app->robotScene.stilo.y };
                    PointF stiloButtLocalHover = { app->robotScene.stilo.buttX, app->robotScene.stilo.y };
                    PointF stiloBodyMidLocalHover = { (stiloHeadLocalHover.x + stiloButtLocalHover.x) * 0.5f, (stiloHeadLocalHover.y + stiloButtLocalHover.y) * 0.5f };

                    Fillet stiloSeamArc1FilletHover = filletFromAttachAngle(stiloHeadLocalHover, app->robotScene.stilo.headRadius, stiloButtLocalHover, app->robotScene.stilo.buttRadius, app->robotScene.stilo.seamArc1Angle, MIN_ARC_R, MAX_ARC_R);
                    Fillet stiloSeamArc2FilletHover = filletFromAttachAngle(stiloHeadLocalHover, app->robotScene.stilo.headRadius, stiloButtLocalHover, app->robotScene.stilo.buttRadius, app->robotScene.stilo.seamArc2Angle, MIN_ARC_R, MAX_ARC_R);

                    PointF stiloSeamArc1NearLocalHover = circleTowardPoint(stiloSeamArc1FilletHover.center, stiloSeamArc1FilletHover.radius, stiloBodyMidLocalHover);
                    PointF stiloSeamArc2NearLocalHover = circleTowardPoint(stiloSeamArc2FilletHover.center, stiloSeamArc2FilletHover.radius, stiloBodyMidLocalHover);

                    PointF stiloSeamArc1MidLocalHover = circleAtX(stiloSeamArc1FilletHover.center, stiloSeamArc1FilletHover.radius, stiloBodyMidLocalHover.x, stiloSeamArc1NearLocalHover);
                    PointF stiloSeamArc2MidLocalHover = circleAtX(stiloSeamArc2FilletHover.center, stiloSeamArc2FilletHover.radius, stiloBodyMidLocalHover.x, stiloSeamArc2NearLocalHover);

                    PointF stiloSeamArc1HandleWorldHover = rotatePoint(stiloSeamArc1MidLocalHover, stiloCenter, stiloAngle);
                    PointF stiloSeamArc2HandleWorldHover = rotatePoint(stiloSeamArc2MidLocalHover, stiloCenter, stiloAngle);

                    PointF stiloThigh1AxisMidLocalHover = { (app->robotScene.stilo.hip1Circle.x + app->robotScene.stilo.feet1Circle.x) * 0.5f,
                                                             (app->robotScene.stilo.hip1Circle.y + app->robotScene.stilo.feet1Circle.y) * 0.5f };

                    Fillet stiloThigh1Arc1FilletHover = filletFromAttachAngle(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius, app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius, app->robotScene.stilo.thigh1Arc1Angle, MIN_THIGH_ARC_R, MAX_SEMNI_THIGH_ARC_R);
                    PointF stiloThigh1Arc1NearLocalHover = circleTowardPoint(stiloThigh1Arc1FilletHover.center, stiloThigh1Arc1FilletHover.radius, stiloThigh1AxisMidLocalHover);
                    PointF stiloThigh1Arc1MidLocalHover = circleAtAxisMid(stiloThigh1Arc1FilletHover.center, stiloThigh1Arc1FilletHover.radius, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle, stiloThigh1Arc1NearLocalHover);

                    Fillet stiloThigh1Arc2FilletHover = filletFromAttachAngleConcave(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius, app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius, app->robotScene.stilo.thigh1Arc2Angle, MIN_THIGH_ARC_R, MAX_THIGH_ARC2_CONCAVE_R);
                    PointF stiloThigh1Arc2NearLocalHover = circleTowardPoint(stiloThigh1Arc2FilletHover.center, stiloThigh1Arc2FilletHover.radius, stiloThigh1AxisMidLocalHover);
                    PointF stiloThigh1Arc2MidLocalHover = circleAtAxisMid(stiloThigh1Arc2FilletHover.center, stiloThigh1Arc2FilletHover.radius, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle, stiloThigh1Arc2NearLocalHover);

                    PointF stiloThigh1Arc1WorldHover = jointToWorld(stiloThigh1Arc1MidLocalHover, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Angle, stiloCenter, stiloAngle);
                    PointF stiloThigh1Arc2WorldHover = jointToWorld(stiloThigh1Arc2MidLocalHover, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Angle, stiloCenter, stiloAngle);

                    // leg 2's own thigh arc hover -- same construction as
                    // leg 1's above, against the hip2/feet2/thigh2 fields
                    PointF stiloThigh2AxisMidLocalHover = { (app->robotScene.stilo.hip2Circle.x + app->robotScene.stilo.feet2Circle.x) * 0.5f,
                                                             (app->robotScene.stilo.hip2Circle.y + app->robotScene.stilo.feet2Circle.y) * 0.5f };

                    Fillet stiloThigh2Arc1FilletHover = filletFromAttachAngle(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius, app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius, app->robotScene.stilo.thigh2Arc1Angle, MIN_THIGH_ARC_R, MAX_SEMNI_THIGH_ARC_R);
                    PointF stiloThigh2Arc1NearLocalHover = circleTowardPoint(stiloThigh2Arc1FilletHover.center, stiloThigh2Arc1FilletHover.radius, stiloThigh2AxisMidLocalHover);
                    PointF stiloThigh2Arc1MidLocalHover = circleAtAxisMid(stiloThigh2Arc1FilletHover.center, stiloThigh2Arc1FilletHover.radius, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle, stiloThigh2Arc1NearLocalHover);

                    Fillet stiloThigh2Arc2FilletHover = filletFromAttachAngleConcave(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius, app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius, app->robotScene.stilo.thigh2Arc2Angle, MIN_THIGH_ARC_R, MAX_THIGH_ARC2_CONCAVE_R);
                    PointF stiloThigh2Arc2NearLocalHover = circleTowardPoint(stiloThigh2Arc2FilletHover.center, stiloThigh2Arc2FilletHover.radius, stiloThigh2AxisMidLocalHover);
                    PointF stiloThigh2Arc2MidLocalHover = circleAtAxisMid(stiloThigh2Arc2FilletHover.center, stiloThigh2Arc2FilletHover.radius, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle, stiloThigh2Arc2NearLocalHover);

                    PointF stiloThigh2Arc1WorldHover = jointToWorld(stiloThigh2Arc1MidLocalHover, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Angle, stiloCenter, stiloAngle);
                    PointF stiloThigh2Arc2WorldHover = jointToWorld(stiloThigh2Arc2MidLocalHover, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Angle, stiloCenter, stiloAngle);

                    // Requested directly: hovering one of these arc handles
                    // (not just dragging it) should also turn it yellow --
                    // same treatment as Semni's own hoverSeamArc1/hoverThigh1/
                    // etc. above, reusing the exact positions the label
                    // chain below already needs.
                    BOOL hoverStiloSeamArc1Now = isNear(stiloMouse, stiloSeamArc1HandleWorldHover, ARC_HANDLE_RADIUS);
                    BOOL hoverStiloSeamArc2Now = isNear(stiloMouse, stiloSeamArc2HandleWorldHover, ARC_HANDLE_RADIUS);
                    BOOL hoverStiloThigh1Arc1Now = isNear(stiloMouse, stiloThigh1Arc1WorldHover, THIGH_HANDLE_RADIUS);
                    BOOL hoverStiloThigh1Arc2Now = isNear(stiloMouse, stiloThigh1Arc2WorldHover, THIGH_HANDLE_RADIUS);
                    BOOL hoverStiloThigh2Arc1Now = isNear(stiloMouse, stiloThigh2Arc1WorldHover, THIGH_HANDLE_RADIUS);
                    BOOL hoverStiloThigh2Arc2Now = isNear(stiloMouse, stiloThigh2Arc2WorldHover, THIGH_HANDLE_RADIUS);

                    app->hoverStiloSeamArc1 = hoverStiloSeamArc1Now;
                    app->hoverStiloSeamArc2 = hoverStiloSeamArc2Now;
                    app->hoverStiloThigh1Arc1 = hoverStiloThigh1Arc1Now;
                    app->hoverStiloThigh1Arc2 = hoverStiloThigh1Arc2Now;
                    app->hoverStiloThigh2Arc1 = hoverStiloThigh2Arc1Now;
                    app->hoverStiloThigh2Arc2 = hoverStiloThigh2Arc2Now;

                    const wchar_t* stiloHoverLabel = L"";

                    // Priority order: Head, Butt, Seam Arc 1, Seam Arc 2,
                    // then leg 1 (Hip 1, Feet 1, Thigh 1 Arc 1, Thigh 1 Arc
                    // 2), then leg 2 (same) -- mirrors the WM_LBUTTONDOWN
                    // hit-test chain further up this file (which already
                    // checks Hip before Feet before the thigh arcs, per
                    // leg). Head/Butt lead the list even though they aren't
                    // draggable (no draggingStiloHead/draggingStiloButt --
                    // same as Semni's own head/butt), and their displayed
                    // names are intentionally swapped vs. the flag name --
                    // see Semni's identical hoverHead/hoverButt swap above
                    // for why (avoids re-interpreting seamArc1Angle/
                    // seamArc2Angle around a different physical circle).
                    if (app->hoverStiloMassCenter)
                        stiloHoverLabel = L"Weight Balance";
                    else if (app->hoverStiloButt)
                        stiloHoverLabel = L"Head";
                    else if (app->hoverStiloHead)
                        stiloHoverLabel = L"Butt";
                    else if (hoverStiloSeamArc1Now)
                        stiloHoverLabel = L"Seam Arc 1";
                    else if (hoverStiloSeamArc2Now)
                        stiloHoverLabel = L"Seam Arc 2";
                    else if (app->hoverStiloHip1)
                        stiloHoverLabel = L"Hip 1";
                    else if (app->hoverStiloFeet1)
                        stiloHoverLabel = L"Feet 1";
                    else if (hoverStiloThigh1Arc1Now)
                        stiloHoverLabel = L"Thigh 1 Arc 1";
                    else if (hoverStiloThigh1Arc2Now)
                        stiloHoverLabel = L"Thigh 1 Arc 2";
                    else if (app->hoverStiloHip2)
                        stiloHoverLabel = L"Hip 2";
                    else if (app->hoverStiloFeet2)
                        stiloHoverLabel = L"Feet 2";
                    else if (hoverStiloThigh2Arc1Now)
                        stiloHoverLabel = L"Thigh 2 Arc 1";
                    else if (hoverStiloThigh2Arc2Now)
                        stiloHoverLabel = L"Thigh 2 Arc 2";

                    SetWindowText(app->ui.hHoverLabel, stiloHoverLabel);
                }

                // View Segments hover -- same idea as Semni's own version
                // further down (computeStiloArcPoints' trimmed fillet
                // curve for the 6 fillets, computeStiloBodyCircles' real
                // circles for the 6 body circles), just against Stilo's
                // own set (renderer.c/h's NUM_STILO_CIRCLE_SEGMENTS/
                // NUM_STILO_BODY_CIRCLES). Placed here, inside this block
                // and BEFORE the early "not dragging" break just below --
                // everything past this whole if (activeKind == STILO)
                // block's own closing break (a little further down) is
                // unreachable whenever Stilo is active, since one of these
                // two breaks always fires first.
                if (app->showCircleSegments)
                {
                    PointF stiloArcPoints[NUM_STILO_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
                    int stiloArcCounts[NUM_STILO_CIRCLE_SEGMENTS];
                    computeStiloArcPoints(app->robotScene.stilo, stiloArcPoints, stiloArcCounts);

                    CircleSegment stiloBodySegs[NUM_STILO_BODY_CIRCLES];
                    computeStiloBodyCircles(app->robotScene.stilo, stiloBodySegs);

                    float stiloEffectiveZoom = graphicsGetZoom() * graphicsGetRobotScale();
                    float stiloTolerance = 0.05f / stiloEffectiveZoom;

                    int bestFillet = -1;
                    int bestBody = -1;
                    float bestDist = stiloTolerance;

                    for (int i = 0; i < NUM_STILO_CIRCLE_SEGMENTS; i++)
                    {
                        for (int k = 0; k < stiloArcCounts[i] - 1; k++)
                        {
                            float d = distPointFToSegment(stiloMouse, stiloArcPoints[i][k], stiloArcPoints[i][k + 1]);
                            if (d < bestDist)
                            {
                                bestDist = d;
                                bestFillet = i;
                                bestBody = -1;
                            }
                        }
                    }

                    for (int i = 0; i < NUM_STILO_BODY_CIRCLES; i++)
                    {
                        float dx = stiloMouse.x - stiloBodySegs[i].center.x;
                        float dy = stiloMouse.y - stiloBodySegs[i].center.y;
                        float distToCenter = sqrtf(dx * dx + dy * dy);
                        float distToEdge = fabsf(distToCenter - stiloBodySegs[i].radius);

                        if (distToEdge < bestDist)
                        {
                            bestDist = distToEdge;
                            bestBody = i;
                            bestFillet = -1;
                        }
                    }

                    app->hoveredCircleSegment = bestFillet;
                    app->hoveredBodyCircle = bestBody;
                    // Rocky-only (see app.h's own comment) -- reset here too
                    // so a stale Rocky value can't linger onto Stilo's own
                    // View Segments overlay after a kind switch.
                    app->hoveredRectSegment = -1;
                }
                else
                {
                    app->hoveredCircleSegment = -1;
                    app->hoveredBodyCircle = -1;
                    app->hoveredRectSegment = -1;
                }

                if (!app->draggingStiloSeamArc1 && !app->draggingStiloSeamArc2 &&
                    !app->draggingStiloHip1 && !app->draggingStiloFeet1 &&
                    !app->draggingStiloThigh1Arc1 && !app->draggingStiloThigh1Arc2 &&
                    !app->draggingStiloHip2 && !app->draggingStiloFeet2 &&
                    !app->draggingStiloThigh2Arc1 && !app->draggingStiloThigh2Arc2 &&
                    !app->draggingStiloMassCenter)
                    break;

                PointF stiloLocalMouse = inverseRotate(stiloMouse, stiloCenter, stiloAngle);

                PointF stiloHeadLocal = { app->robotScene.stilo.headX, app->robotScene.stilo.y };
                PointF stiloButtLocal = { app->robotScene.stilo.buttX, app->robotScene.stilo.y };

                // Body/Leg Weight mass-center dot -- same idea as Semni's
                // own draggingSemniMassCenter drag math above, just against
                // Stilo's bodyWeight/legWeight and
                // computeStiloMassCenterEndpointsWorld's body/combined-leg
                // endpoints (see app.h's own comment on Stilo's legWeight
                // covering both legs together).
                if (app->draggingStiloMassCenter)
                {
                    PointF stiloBodyCentroidWorld, stiloLegCentroidWorld;
                    computeStiloMassCenterEndpointsWorld(app->robotScene.stilo, &stiloBodyCentroidWorld, &stiloLegCentroidWorld);

                    float stiloSegX = stiloLegCentroidWorld.x - stiloBodyCentroidWorld.x;
                    float stiloSegY = stiloLegCentroidWorld.y - stiloBodyCentroidWorld.y;
                    float stiloSegLenSq = stiloSegX * stiloSegX + stiloSegY * stiloSegY;

                    if (stiloSegLenSq > 1e-9f)
                    {
                        float stiloT = ((stiloMouse.x - stiloBodyCentroidWorld.x) * stiloSegX + (stiloMouse.y - stiloBodyCentroidWorld.y) * stiloSegY) / stiloSegLenSq;
                        if (stiloT < 0.0f) stiloT = 0.0f;
                        if (stiloT > 1.0f) stiloT = 1.0f;

                        float stiloTotal = app->stiloMassCenterDragTotal;
                        app->robotScene.stilo.bodyWeight = (1.0f - stiloT) * stiloTotal;
                        app->robotScene.stilo.legWeight = stiloT * stiloTotal;

                        syncWeightRatioSlider(app, app->robotScene.stilo.bodyWeight, app->robotScene.stilo.legWeight);
                    }
                }

                if (app->draggingStiloSeamArc1)
                {
                    SafeAngleRange range = filletSafeAngleRange(stiloHeadLocal, app->robotScene.stilo.headRadius, stiloButtLocal, app->robotScene.stilo.buttRadius, MAX_ARC_R);
                    float maxDelta = range.halfWidthDeg - ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < ARC_SIDE_MARGIN_DEG) maxDelta = ARC_SIDE_MARGIN_DEG;

                    float deltaY = stiloLocalMouse.y - app->stiloArcDragStartMouseY;
                    float raw = app->stiloArcDragStartAngle + deltaY * ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (delta > -ARC_SIDE_MARGIN_DEG) delta = -ARC_SIDE_MARGIN_DEG;
                    if (delta < -maxDelta) delta = -maxDelta;

                    app->robotScene.stilo.seamArc1Angle = range.centerDeg + delta;
                    app->robotScene.stilo.seamArc2Angle = range.centerDeg - delta;
                }

                if (app->draggingStiloSeamArc2)
                {
                    SafeAngleRange range = filletSafeAngleRange(stiloHeadLocal, app->robotScene.stilo.headRadius, stiloButtLocal, app->robotScene.stilo.buttRadius, MAX_ARC_R);
                    float maxDelta = range.halfWidthDeg - ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < ARC_SIDE_MARGIN_DEG) maxDelta = ARC_SIDE_MARGIN_DEG;

                    float deltaY = stiloLocalMouse.y - app->stiloArcDragStartMouseY;
                    float raw = app->stiloArcDragStartAngle + deltaY * ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (delta < ARC_SIDE_MARGIN_DEG) delta = ARC_SIDE_MARGIN_DEG;
                    if (delta > maxDelta) delta = maxDelta;

                    app->robotScene.stilo.seamArc2Angle = range.centerDeg + delta;
                    app->robotScene.stilo.seamArc1Angle = range.centerDeg - delta;
                }

                if (app->draggingStiloHip1)
                {
                    PointF newHip1 = stiloLocalMouse;

                    app->robotScene.stilo.feet1Circle.x = newHip1.x + app->stiloHip1DragFeetOffset.x;
                    app->robotScene.stilo.feet1Circle.y = newHip1.y + app->stiloHip1DragFeetOffset.y;

                    app->robotScene.stilo.hip1Circle = newHip1;

                    adjustStiloThigh1Arcs(app);
                }

                PointF stiloLeg1LocalMouse = inverseRotate(stiloLocalMouse, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Angle);

                if (app->draggingStiloFeet1)
                {
                    app->robotScene.stilo.feet1Circle = constrainToAxis(
                        app->robotScene.stilo.hip1Circle,
                        app->robotScene.stilo.feet1Circle,
                        stiloLeg1LocalMouse,
                        MIN_LIMB_LENGTH);

                    adjustStiloThigh1Arcs(app);
                }

                if (app->draggingStiloThigh1Arc1)
                {
                    SafeAngleRange range = filletSafeAngleRange(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius,
                                                                 app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius,
                                                                 MAX_SEMNI_THIGH_ARC_R);
                    float maxDelta = range.halfWidthDeg - THIGH_ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < THIGH_ARC_SIDE_MARGIN_DEG) maxDelta = THIGH_ARC_SIDE_MARGIN_DEG;

                    // NEW: mirror-aware side derivation, same fix as
                    // Semni's draggingThigh1/draggingShin1 and Rocky's
                    // draggingRockyShin1 (see their comments) -- mirrorStiloLeg
                    // reflects hip1Circle/feet1Circle/thigh1Arc1Angle through
                    // a true screen-space mirror, which reverses orientation,
                    // so the hardcoded "always negative" side lock this used
                    // to have was wrong on a mirrored leg 1. Re-derive which
                    // side is currently correct from stiloThigh1ArcDragStartAngle
                    // (the actual angle at drag start) instead of assuming.
                    float startDelta = app->stiloThigh1ArcDragStartAngle - range.centerDeg;
                    while (startDelta > 180.0f) startDelta -= 360.0f;
                    while (startDelta < -180.0f) startDelta += 360.0f;
                    BOOL positiveSide = (startDelta >= 0.0f);

                    float perpNow = perpOffsetOnAxis(stiloLeg1LocalMouse, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle);
                    float raw = app->stiloThigh1ArcDragStartAngle + (perpNow - app->stiloThigh1ArcDragStartPerp) * THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (positiveSide)
                    {
                        if (delta < THIGH_ARC_SIDE_MARGIN_DEG) delta = THIGH_ARC_SIDE_MARGIN_DEG;
                        if (delta > maxDelta) delta = maxDelta;
                    }
                    else
                    {
                        if (delta > -THIGH_ARC_SIDE_MARGIN_DEG) delta = -THIGH_ARC_SIDE_MARGIN_DEG;
                        if (delta < -maxDelta) delta = -maxDelta;
                    }

                    app->robotScene.stilo.thigh1Arc1Angle = range.centerDeg + delta;
                }

                if (app->draggingStiloThigh1Arc2)
                {
                    SafeAngleRange range = filletSafeAngleRangeConcave(app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Radius,
                                                                        app->robotScene.stilo.feet1Circle, app->robotScene.stilo.feet1Radius,
                                                                        MAX_THIGH_ARC2_CONCAVE_R);
                    float maxDelta = range.halfWidthDeg - THIGH_ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < 0.0f) maxDelta = 0.0f;

                    float perpNow = perpOffsetOnAxis(stiloLeg1LocalMouse, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.feet1Circle);
                    float raw = app->stiloThigh1ArcDragStartAngle + (perpNow - app->stiloThigh1ArcDragStartPerp) * THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (delta > maxDelta) delta = maxDelta;
                    if (delta < -maxDelta) delta = -maxDelta;

                    app->robotScene.stilo.thigh1Arc2Angle = range.centerDeg + delta;
                }

                // ---- leg 2 drag updates -- same construction as leg 1's
                // above, against the hip2/feet2/thigh2 fields. No seam-arc
                // dragging here -- that's torso-level, shared with leg 1,
                // already handled above.
                if (app->draggingStiloHip2)
                {
                    PointF newHip2 = stiloLocalMouse;

                    app->robotScene.stilo.feet2Circle.x = newHip2.x + app->stiloHip2DragFeetOffset.x;
                    app->robotScene.stilo.feet2Circle.y = newHip2.y + app->stiloHip2DragFeetOffset.y;

                    app->robotScene.stilo.hip2Circle = newHip2;

                    adjustStiloThigh2Arcs(app);
                }

                PointF stiloLeg2LocalMouse = inverseRotate(stiloLocalMouse, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Angle);

                if (app->draggingStiloFeet2)
                {
                    app->robotScene.stilo.feet2Circle = constrainToAxis(
                        app->robotScene.stilo.hip2Circle,
                        app->robotScene.stilo.feet2Circle,
                        stiloLeg2LocalMouse,
                        MIN_LIMB_LENGTH);

                    adjustStiloThigh2Arcs(app);
                }

                if (app->draggingStiloThigh2Arc1)
                {
                    SafeAngleRange range = filletSafeAngleRange(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius,
                                                                 app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius,
                                                                 MAX_SEMNI_THIGH_ARC_R);
                    float maxDelta = range.halfWidthDeg - THIGH_ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < THIGH_ARC_SIDE_MARGIN_DEG) maxDelta = THIGH_ARC_SIDE_MARGIN_DEG;

                    // NEW: same mirror-aware side derivation as leg 1's
                    // draggingStiloThigh1Arc1 above (see its comment) --
                    // mirrorStiloLeg2 reflects leg 2 the same way
                    // mirrorStiloLeg reflects leg 1.
                    float startDelta = app->stiloThigh2ArcDragStartAngle - range.centerDeg;
                    while (startDelta > 180.0f) startDelta -= 360.0f;
                    while (startDelta < -180.0f) startDelta += 360.0f;
                    BOOL positiveSide = (startDelta >= 0.0f);

                    float perpNow = perpOffsetOnAxis(stiloLeg2LocalMouse, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle);
                    float raw = app->stiloThigh2ArcDragStartAngle + (perpNow - app->stiloThigh2ArcDragStartPerp) * THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (positiveSide)
                    {
                        if (delta < THIGH_ARC_SIDE_MARGIN_DEG) delta = THIGH_ARC_SIDE_MARGIN_DEG;
                        if (delta > maxDelta) delta = maxDelta;
                    }
                    else
                    {
                        if (delta > -THIGH_ARC_SIDE_MARGIN_DEG) delta = -THIGH_ARC_SIDE_MARGIN_DEG;
                        if (delta < -maxDelta) delta = -maxDelta;
                    }

                    app->robotScene.stilo.thigh2Arc1Angle = range.centerDeg + delta;
                }

                if (app->draggingStiloThigh2Arc2)
                {
                    SafeAngleRange range = filletSafeAngleRangeConcave(app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Radius,
                                                                        app->robotScene.stilo.feet2Circle, app->robotScene.stilo.feet2Radius,
                                                                        MAX_THIGH_ARC2_CONCAVE_R);
                    float maxDelta = range.halfWidthDeg - THIGH_ARC_ANGLE_MARGIN_DEG;
                    if (maxDelta < 0.0f) maxDelta = 0.0f;

                    float perpNow = perpOffsetOnAxis(stiloLeg2LocalMouse, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.feet2Circle);
                    float raw = app->stiloThigh2ArcDragStartAngle + (perpNow - app->stiloThigh2ArcDragStartPerp) * THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                    float delta = raw - range.centerDeg;
                    while (delta > 180.0f) delta -= 360.0f;
                    while (delta < -180.0f) delta += 360.0f;

                    if (delta > maxDelta) delta = maxDelta;
                    if (delta < -maxDelta) delta = -maxDelta;

                    app->robotScene.stilo.thigh2Arc2Angle = range.centerDeg + delta;
                }

                break;
            }

            // Per-joint hover/drag feedback (hoverHip/hoverKnee/etc, the
            // bottom-left hover label) beyond Rocky's one body handle and
            // Stilo's full set above only exists for Semni here -- see
            // WM_LBUTTONDOWN's matching guard. View Segments hover DOES run
            // for all three kinds now (see computeRocky*/computeStilo* in
            // renderer.c/h, mirroring the original Semni-only versions),
            // but NOT here -- Rocky's and Stilo's own hit-tests live INSIDE
            // their own if (activeKind == ROBOT_KIND_ROCKY/STILO) blocks
            // above (right after each one's hover-label SetWindowText call,
            // before its drag handling), not here after them, since both of
            // those blocks always `break` before control would ever reach
            // this point -- placing it here the first time around silently
            // made it dead code for both kinds.
            if (app->robotScene.activeKind != ROBOT_KIND_SEMNI)
            {
                break;
            }

            PointF mouse = app->mouseGL;

            PointF center = getCenter(app->robotScene.robot);
            float angle = app->robotScene.robot.angle;

            // hover state for the joint circle handles is tracked here,
            // continuously, regardless of whether anything is being
            // dragged -- that's what lets them highlight yellow just
            // from the mouse passing near them
            PointF innerWorld = rotatePoint(app->robotScene.robot.innerCircle, center, angle);
            PointF kneeWorld  = jointToWorld(app->robotScene.robot.kneeCircle, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, angle);
            PointF footWorld = nestedJointToWorld(app->robotScene.robot.footCircle, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeAngle, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, angle);
            PointF headWorld  = rotatePoint((PointF){app->robotScene.robot.headX, app->robotScene.robot.y}, center, angle);
            PointF buttWorld  = rotatePoint((PointF){app->robotScene.robot.buttX, app->robotScene.robot.y}, center, angle);

            app->hoverHip   = isNear(mouse, innerWorld, HIP_HANDLE_RADIUS);
            app->hoverKnee  = isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS);
            app->hoverFoot = isNear(mouse, footWorld, FOOT_HANDLE_RADIUS);
            app->hoverHead  = isNear(mouse, headWorld, HEAD_BUTT_HANDLE_RADIUS);
            app->hoverButt  = isNear(mouse, buttWorld, HEAD_BUTT_HANDLE_RADIUS);

            // Body/Leg Weight mass-center dot -- same Shift-gated
            // proximity hover as WM_LBUTTONDOWN's own check (see that
            // block's comment on why no closest-wins tie-break is needed
            // here, unlike Rocky's version).
            app->hoverSemniMassCenter = (LOWORD(wParam) & MK_SHIFT) &&
                isNear(mouse, computeSemniMassCenterWorld(app->robotScene.robot), MASS_CENTER_HANDLE_RADIUS);

            // View Segments hover: which SINGLE thing -- out of both the
            // 6 fillet ARCS (computeSemniArcPoints' actual trimmed curve,
            // NOT the full circle each one was cut from) and the 5
            // always-visible body circles (computeSemniBodyCircles, real
            // full circles) -- is nearest the mouse, within a small pick
            // tolerance. Same idea as the ArcSpline canvas's
            // findHoveredSegment, gated the same way canvas.c gates its own
            // hover detection on canvas.showSegments.
            //
            // Fillets specifically pick against the TRIMMED arc polyline,
            // not the full circle's edge (|distToCenter - radius|) the way
            // this used to -- a fillet's full circle is often much bigger
            // than the visible arc actually drawn (drawSemniCircleSegments'
            // own "ghost circle" makes the untrimmed rest of it visible too
            // while View Segments is on, but only as a faint dashed
            // reference, not something meant to be hoverable in its own
            // right). Same reasoning robotBoundingBoxLocal's
            // ROBOT_BB_INCLUDE_ARC already uses this exact function for.
            // Body circles are real, fully-drawn circles with no such
            // ghost/trimmed distinction, so their own hit-test is
            // unchanged.
            //
            // The two candidate sets are searched against ONE shared
            // bestDist rather than independently, so exactly one thing
            // (fillet OR body, never both) ends up highlighted even where
            // a fillet and a body circle happen to sit close together --
            // whichever loop finds a closer match resets the other kind's
            // result back to -1.
            if (app->showCircleSegments)
            {
                PointF filletArcPoints[NUM_ROBOT_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
                int filletArcCounts[NUM_ROBOT_CIRCLE_SEGMENTS];
                computeSemniArcPoints(app->robotScene.robot, filletArcPoints, filletArcCounts);

                CircleSegment bodySegs[NUM_ROBOT_BODY_CIRCLES];
                computeSemniBodyCircles(app->robotScene.robot, bodySegs);

                // World-unit pick radius that corresponds to a constant
                // on-screen size, same reasoning as ArcSpline's "tolerance
                // = 0.05 * canvas.zoom" -- except Semni's zoom convention
                // is inverted (see graphicsGetZoom's comment: bigger means
                // zoomed IN here, unlike canvas.zoom), so this divides
                // instead of multiplies, and also folds in the robot size
                // slider (graphicsGetRobotScale) since that scales the
                // view the same way zoom does.
                float effectiveZoom = graphicsGetZoom() * graphicsGetRobotScale();
                float tolerance = 0.05f / effectiveZoom;

                int bestFillet = -1;
                int bestBody = -1;
                float bestDist = tolerance;

                for (int i = 0; i < NUM_ROBOT_CIRCLE_SEGMENTS; i++)
                {
                    for (int k = 0; k < filletArcCounts[i] - 1; k++)
                    {
                        float d = distPointFToSegment(mouse, filletArcPoints[i][k], filletArcPoints[i][k + 1]);
                        if (d < bestDist)
                        {
                            bestDist = d;
                            bestFillet = i;
                            bestBody = -1;
                        }
                    }
                }

                for (int i = 0; i < NUM_ROBOT_BODY_CIRCLES; i++)
                {
                    float dx = mouse.x - bodySegs[i].center.x;
                    float dy = mouse.y - bodySegs[i].center.y;
                    float distToCenter = sqrtf(dx * dx + dy * dy);
                    float distToEdge = fabsf(distToCenter - bodySegs[i].radius);

                    if (distToEdge < bestDist)
                    {
                        bestDist = distToEdge;
                        bestBody = i;
                        bestFillet = -1;
                    }
                }

                app->hoveredCircleSegment = bestFillet;
                app->hoveredBodyCircle = bestBody;
                // Rocky-only (see app.h's own comment) -- reset here too so
                // a stale Rocky value can't linger onto Semni's own View
                // Segments overlay after a kind switch.
                app->hoveredRectSegment = -1;
            }
            else
            {
                app->hoveredCircleSegment = -1;
                app->hoveredBodyCircle = -1;
                app->hoveredRectSegment = -1;
            }

            // bottom-left hover label: also needs the bulge/seam handle
            // positions (seam arc 1, seam arc 2, both thigh arcs, both
            // shin arcs), which the code below only computes while a drag
            // is active -- so they're worked out fresh here too, same
            // fillet + circleAtX/circleAtAxisMid construction
            // WM_LBUTTONDOWN's hit-test and renderer.c's drawSemniHandles/
            // drawThighHandles/drawShinHandles use, so this always lines
            // up with where each handle is actually drawn. Kept in its
            // own "Hover"-suffixed locals so it can't collide with the
            // (differently-scoped) drag-only versions of the same
            // computation further down.
            {
                PointF headLocalHover = { app->robotScene.robot.headX, app->robotScene.robot.y };
                PointF buttLocalHover = { app->robotScene.robot.buttX, app->robotScene.robot.y };
                PointF bodyMidLocalHover = { (headLocalHover.x + buttLocalHover.x) * 0.5f, (headLocalHover.y + buttLocalHover.y) * 0.5f };

                Fillet seamArc1FilletHover = filletFromAttachAngle(headLocalHover, app->robotScene.robot.headRadius, buttLocalHover, app->robotScene.robot.buttRadius, app->robotScene.robot.seamArc1Angle, MIN_ARC_R, MAX_ARC_R);
                Fillet seamArc2FilletHover = filletFromAttachAngle(headLocalHover, app->robotScene.robot.headRadius, buttLocalHover, app->robotScene.robot.buttRadius, app->robotScene.robot.seamArc2Angle, MIN_ARC_R, MAX_ARC_R);

                PointF seamArc1NearLocalHover = circleTowardPoint(seamArc1FilletHover.center, seamArc1FilletHover.radius, bodyMidLocalHover);
                PointF seamArc2NearLocalHover = circleTowardPoint(seamArc2FilletHover.center, seamArc2FilletHover.radius, bodyMidLocalHover);

                PointF seamArc1MidLocalHover = circleAtX(seamArc1FilletHover.center, seamArc1FilletHover.radius, bodyMidLocalHover.x, seamArc1NearLocalHover);
                PointF seamArc2MidLocalHover = circleAtX(seamArc2FilletHover.center, seamArc2FilletHover.radius, bodyMidLocalHover.x, seamArc2NearLocalHover);

                PointF seamArc1HandleWorldHover = rotatePoint(seamArc1MidLocalHover, center, angle);
                PointF seamArc2HandleWorldHover = rotatePoint(seamArc2MidLocalHover, center, angle);

                PointF thighAxisMidLocalHover = { (app->robotScene.robot.innerCircle.x + app->robotScene.robot.kneeCircle.x) * 0.5f,
                                                  (app->robotScene.robot.innerCircle.y + app->robotScene.robot.kneeCircle.y) * 0.5f };

                Fillet thigh1FilletHover = filletFromAttachAngle(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, app->robotScene.robot.thighArc1Angle, MIN_THIGH_ARC_R, MAX_SEMNI_THIGH_ARC_R);
                PointF thigh1NearLocalHover = circleTowardPoint(thigh1FilletHover.center, thigh1FilletHover.radius, thighAxisMidLocalHover);
                PointF thigh1MidLocalHover = circleAtAxisMid(thigh1FilletHover.center, thigh1FilletHover.radius, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle, thigh1NearLocalHover);

                Fillet thigh2FilletHover = filletFromAttachAngleConcave(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, app->robotScene.robot.thighArc2Angle, MIN_THIGH_ARC_R, MAX_THIGH_ARC2_CONCAVE_R);
                PointF thigh2NearLocalHover = circleTowardPoint(thigh2FilletHover.center, thigh2FilletHover.radius, thighAxisMidLocalHover);
                PointF thigh2MidLocalHover = circleAtAxisMid(thigh2FilletHover.center, thigh2FilletHover.radius, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle, thigh2NearLocalHover);

                PointF thigh1WorldHover = jointToWorld(thigh1MidLocalHover, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, angle);
                PointF thigh2WorldHover = jointToWorld(thigh2MidLocalHover, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, angle);

                PointF shinAxisMidLocalHover = { (app->robotScene.robot.kneeCircle.x + app->robotScene.robot.footCircle.x) * 0.5f,
                                                 (app->robotScene.robot.kneeCircle.y + app->robotScene.robot.footCircle.y) * 0.5f };

                Fillet shin1FilletHover = filletFromAttachAngle(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, app->robotScene.robot.footCircle, app->robotScene.robot.footRadius, app->robotScene.robot.shinArc1Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC_R);
                PointF shin1NearLocalHover = circleTowardPoint(shin1FilletHover.center, shin1FilletHover.radius, shinAxisMidLocalHover);
                PointF shin1MidLocalHover = circleAtAxisMid(shin1FilletHover.center, shin1FilletHover.radius, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle, shin1NearLocalHover);

                Fillet shin2FilletHover = filletFromAttachAngleConcave(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius, app->robotScene.robot.footCircle, app->robotScene.robot.footRadius, app->robotScene.robot.shinArc2Angle, MIN_SHIN_ARC_R, MAX_SHIN_ARC2_CONCAVE_R);
                PointF shin2NearLocalHover = circleTowardPoint(shin2FilletHover.center, shin2FilletHover.radius, shinAxisMidLocalHover);
                PointF shin2MidLocalHover = circleAtAxisMid(shin2FilletHover.center, shin2FilletHover.radius, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle, shin2NearLocalHover);

                PointF shin1WorldHover = nestedJointToWorld(shin1MidLocalHover, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeAngle, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, angle);
                PointF shin2WorldHover = nestedJointToWorld(shin2MidLocalHover, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeAngle, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, angle);

                // Requested directly: hovering one of these arc handles (not
                // just dragging it) should also turn it yellow -- computed
                // here, continuously, same as hoverHip/hoverKnee/etc. above,
                // reusing the exact handle positions the label chain below
                // already needs.
                BOOL hoverSeamArc1Now = isNear(mouse, seamArc1HandleWorldHover, ARC_HANDLE_RADIUS);
                BOOL hoverSeamArc2Now = isNear(mouse, seamArc2HandleWorldHover, ARC_HANDLE_RADIUS);
                BOOL hoverThigh1Now = isNear(mouse, thigh1WorldHover, THIGH_HANDLE_RADIUS);
                BOOL hoverThigh2Now = isNear(mouse, thigh2WorldHover, THIGH_HANDLE_RADIUS);
                BOOL hoverShin1Now = isNear(mouse, shin1WorldHover, SHIN_HANDLE_RADIUS);
                BOOL hoverShin2Now = isNear(mouse, shin2WorldHover, SHIN_HANDLE_RADIUS);

                app->hoverSeamArc1 = hoverSeamArc1Now;
                app->hoverSeamArc2 = hoverSeamArc2Now;
                app->hoverThigh1 = hoverThigh1Now;
                app->hoverThigh2 = hoverThigh2Now;
                app->hoverShin1 = hoverShin1Now;
                app->hoverShin2 = hoverShin2Now;

                // Priority order: Head, Butt, Seam Arc 1, Seam Arc 2, Hip,
                // Knee, Foot, Thigh Arc 1, Thigh Arc 2, Shin Arc 1, Shin Arc
                // 2 -- mirrors WM_LBUTTONDOWN's hit-test order for
                // everything that's actually draggable (seamArc1, seamArc2,
                // hip, knee, foot, thigh1, thigh2, shin1, shin2); Head/Butt
                // are hover-only (there's no draggingHead/draggingButt --
                // clicking them falls through to whatever's underneath), so
                // they can't be "mirrored" in the click chain, but they
                // still lead this list since head/butt should win over
                // every other handle when the mouse is near more than one.
                const wchar_t* hoverLabel = L"";

                // label text intentionally swapped vs. the flag name --
                // requested swap of "head"/"butt" as displayed NAMES only.
                // Doing it here (display-only) instead of swapping the
                // underlying headX/buttX/headRadius/buttRadius field
                // values (which was tried and reverted) avoids corrupting
                // seamArc1Angle/seamArc2Angle: those are stored as angles
                // measured specifically around the head circle
                // (filletFromAttachAngle/circleEdge take headLocal as
                // their asymmetric "c1" argument), so swapping which
                // physical circle headX/headRadius point to would silently
                // re-interpret those tuned angles around a different
                // circle entirely -- not just relabel them, which is what
                // caused the seam handle drag to look broken/inverted.
                if (app->hoverSemniMassCenter)
                    hoverLabel = L"Weight Balance";
                else if (app->hoverButt)
                    hoverLabel = L"Head";
                else if (app->hoverHead)
                    hoverLabel = L"Butt";
                else if (hoverSeamArc1Now)
                    hoverLabel = L"Seam Arc 1";
                else if (hoverSeamArc2Now)
                    hoverLabel = L"Seam Arc 2";
                else if (app->hoverHip)
                    hoverLabel = L"Hip";
                else if (app->hoverKnee)
                    hoverLabel = L"Knee";
                else if (app->hoverFoot)
                    hoverLabel = L"Foot";
                else if (hoverThigh1Now)
                    hoverLabel = L"Thigh Arc 1";
                else if (hoverThigh2Now)
                    hoverLabel = L"Thigh Arc 2";
                else if (hoverShin1Now)
                    hoverLabel = L"Shin Arc 1";
                else if (hoverShin2Now)
                    hoverLabel = L"Shin Arc 2";

                SetWindowText(app->ui.hHoverLabel, hoverLabel);
            }

            if (!app->draggingSeamArc1 && !app->draggingSeamArc2 &&
                !app->draggingInner &&
                !app->draggingKnee && !app->draggingThigh1 && !app->draggingThigh2 &&
                !app->draggingFoot && !app->draggingShin1 && !app->draggingShin2)
                break;

            PointF localMouse = inverseRotate(mouse, center, angle);

            PointF headLocal = { app->robotScene.robot.headX, app->robotScene.robot.y };
            PointF buttLocal = { app->robotScene.robot.buttX, app->robotScene.robot.y };

            // the seam handle now sits at the arc's visible middle/bulge
            // point rather than the head-circle tangent point, so the
            // attach angle can no longer be read directly off the mouse's
            // polar angle around the head circle -- the handle isn't ON
            // that circle anymore. Instead it drags along ONE axis only
            // (vertical mouse movement), incrementally: angle = (angle
            // when the drag started) + (Y moved since then) * a
            // sensitivity constant -- see ARC_DRAG_SENSITIVITY_DEG_PER_UNIT
            // in config.h for why. Clamped on TWO sides: the far side (via
            // filletSafeAngleRange) stops it from flattening into a line,
            // and the near side keeps it away from centerDeg itself -- a
            // second, different degenerate point where the arc's bulge
            // collapses flat against the head-butt axis and flips to the
            // opposite side. Each handle is locked to its own side of
            // centerDeg (seam arc 1 stays negative-delta, seam arc 2 stays
            // positive-delta) so they can never cross into each other's
            // territory.
            //
            // The two arcs are kept symmetrical: dragging either handle
            // also updates the OTHER arc's angle to centerDeg - delta --
            // i.e. the same distance from centerDeg, mirrored to the
            // opposite side. Since both arcs share the exact same
            // centerDeg/safe range (it only depends on headLocal/buttLocal/
            // radii, not on which handle is being dragged), the mirrored
            // delta is automatically valid for the other arc too -- no
            // extra clamping needed.
            // Body/Leg Weight mass-center dot -- same idea as Rocky's own
            // draggingRockyMassCenter drag math (see that block's
            // comment), just against Semni's bodyWeight/legWeight and
            // computeSemniMassCenterEndpointsWorld's body/leg endpoints.
            if (app->draggingSemniMassCenter)
            {
                PointF semniBodyCentroidWorld, semniLegCentroidWorld;
                computeSemniMassCenterEndpointsWorld(app->robotScene.robot, &semniBodyCentroidWorld, &semniLegCentroidWorld);

                float semniSegX = semniLegCentroidWorld.x - semniBodyCentroidWorld.x;
                float semniSegY = semniLegCentroidWorld.y - semniBodyCentroidWorld.y;
                float semniSegLenSq = semniSegX * semniSegX + semniSegY * semniSegY;

                if (semniSegLenSq > 1e-9f)
                {
                    float semniT = ((mouse.x - semniBodyCentroidWorld.x) * semniSegX + (mouse.y - semniBodyCentroidWorld.y) * semniSegY) / semniSegLenSq;
                    if (semniT < 0.0f) semniT = 0.0f;
                    if (semniT > 1.0f) semniT = 1.0f;

                    float semniTotal = app->semniMassCenterDragTotal;
                    app->robotScene.robot.bodyWeight = (1.0f - semniT) * semniTotal;
                    app->robotScene.robot.legWeight = semniT * semniTotal;

                    syncWeightRatioSlider(app, app->robotScene.robot.bodyWeight, app->robotScene.robot.legWeight);
                }
            }

            if (app->draggingSeamArc1)
            {
                SafeAngleRange range = filletSafeAngleRange(headLocal, app->robotScene.robot.headRadius, buttLocal, app->robotScene.robot.buttRadius, MAX_ARC_R);
                float maxDelta = range.halfWidthDeg - ARC_ANGLE_MARGIN_DEG;
                if (maxDelta < ARC_SIDE_MARGIN_DEG) maxDelta = ARC_SIDE_MARGIN_DEG;

                float deltaY = localMouse.y - app->arcDragStartMouseY;
                float raw = app->arcDragStartAngle + deltaY * ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                float delta = raw - range.centerDeg;
                while (delta > 180.0f) delta -= 360.0f;
                while (delta < -180.0f) delta += 360.0f;

                if (delta > -ARC_SIDE_MARGIN_DEG) delta = -ARC_SIDE_MARGIN_DEG;
                if (delta < -maxDelta) delta = -maxDelta;

                app->robotScene.robot.seamArc1Angle = range.centerDeg + delta;
                app->robotScene.robot.seamArc2Angle = range.centerDeg - delta;
            }

            if (app->draggingSeamArc2)
            {
                SafeAngleRange range = filletSafeAngleRange(headLocal, app->robotScene.robot.headRadius, buttLocal, app->robotScene.robot.buttRadius, MAX_ARC_R);
                float maxDelta = range.halfWidthDeg - ARC_ANGLE_MARGIN_DEG;
                if (maxDelta < ARC_SIDE_MARGIN_DEG) maxDelta = ARC_SIDE_MARGIN_DEG;

                float deltaY = localMouse.y - app->arcDragStartMouseY;
                float raw = app->arcDragStartAngle + deltaY * ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                float delta = raw - range.centerDeg;
                while (delta > 180.0f) delta -= 360.0f;
                while (delta < -180.0f) delta += 360.0f;

                // mirror image of seam arc 1's clamp -- locked to the
                // opposite (positive-delta) side of centerDeg
                if (delta < ARC_SIDE_MARGIN_DEG) delta = ARC_SIDE_MARGIN_DEG;
                if (delta > maxDelta) delta = maxDelta;

                app->robotScene.robot.seamArc2Angle = range.centerDeg + delta;
                app->robotScene.robot.seamArc1Angle = range.centerDeg - delta;
            }

            // dragging the hip carries the whole leg along as one rigid
            // piece -- each descendant point is re-applied fresh from its
            // offset (captured when the drag started) relative to the new
            // hip position, same "captured offset" pattern used below for
            // the knee drag, so the leg's shape/pose never drifts or gets
            // left behind
            if (app->draggingInner)
            {
                PointF newInner = localMouse;

                app->robotScene.robot.kneeCircle.x = newInner.x + app->hipDragKneeOffset.x;
                app->robotScene.robot.kneeCircle.y = newInner.y + app->hipDragKneeOffset.y;

                // thighArc1Angle/thighArc2Angle don't move with the hip --
                // they're already relative to it

                app->robotScene.robot.footCircle.x = newInner.x + app->hipDragFootOffset.x;
                app->robotScene.robot.footCircle.y = newInner.y + app->hipDragFootOffset.y;

                // shinArc1Angle/shinArc2Angle don't move with the hip
                // either -- already relative to kneeCircle, which itself
                // just got carried along via hipDragKneeOffset above

                app->robotScene.robot.innerCircle = newInner;

                // dragging the hip carries the whole leg as a rigid
                // translation, so the thigh/shin arcs' underlying
                // distances never actually change and this ends up a
                // no-op -- called anyway for the same reason as the
                // length-changing drags below (consistency: moving any
                // circle re-validates its arcs), and it's cheap since
                // clampToSafeAngleRange leaves an already-safe angle alone
                adjustThighArcs(app);
                adjustShinArcs(app);
            }

            // the leg chain sits in a frame additionally rotated by hipAngle
            // around innerCircle, so undo that rotation too before storing
            // the raw local coordinates for knee/thigh/foot/shin
            PointF legLocalMouse = inverseRotate(localMouse, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle);

            // dragging the knee circle only changes the thigh's length --
            // it's constrained to slide along the hip->knee axis instead
            // of moving freely, so bending the leg is left to hipAngle
            if (app->draggingKnee)
            {
                PointF newKnee = constrainToAxis(
                    app->robotScene.robot.innerCircle,
                    app->robotScene.robot.kneeCircle,
                    legLocalMouse,
                    MIN_LIMB_LENGTH);

                app->robotScene.robot.kneeCircle = newKnee;

                // re-anchor the shin to the offsets captured when the
                // drag started (not nudged incrementally frame by frame)
                // so its length and shape can't drift over a long drag --
                // only the thigh is getting longer or shorter here
                app->robotScene.robot.footCircle.x = newKnee.x + app->kneeDragFootOffset.x;
                app->robotScene.robot.footCircle.y = newKnee.y + app->kneeDragFootOffset.y;

                // shinArc1Angle/shinArc2Angle don't need re-anchoring
                // either -- already relative to kneeCircle, which just
                // moved to newKnee above

                // the hip<->knee distance just changed, so the thigh arcs'
                // fillet solve did too -- re-validate their existing
                // angles against it. The shin arcs are left alone
                // (knee<->foot distance is preserved by the re-anchor
                // above), matching the thigh-only blue highlight this
                // drag already gets
                adjustThighArcs(app);
            }

            // thigh arcs: same tangent-restricted, angle-driven drag as
            // the head/butt seams above (seamArc1Angle/seamArc2Angle), but
            // reading the mouse's perpendicular-to-axis movement
            // (perpOffsetOnAxis) instead of raw Y, since the hip->knee
            // axis isn't fixed horizontal like the head-butt axis -- it
            // rotates with hipAngle and the user can pose the leg any
            // direction. thighArc1Angle (convex) stays locked to the
            // negative-delta side of ITS centerDeg, same "stay off the
            // degenerate center" safety seam arc 1/2 uses. thighArc2Angle
            // (concave) drags against a totally different, disjoint safe
            // range (see its own block below) so it doesn't need that
            // same one-sided lock. Dragging one never mirrors the other --
            // the thigh's two sides aren't meant to bulge symmetrically.
            // Nothing needs to "recenter" on a hip/knee move the way the
            // old free-point handles did: the angle is already fully
            // relative to innerCircle/kneeCircle, so the fillet solve
            // just adapts automatically every frame.
            if (app->draggingThigh1)
            {
                SafeAngleRange range = filletSafeAngleRange(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius,
                                                             app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                             MAX_SEMNI_THIGH_ARC_R);
                float maxDelta = range.halfWidthDeg - THIGH_ARC_ANGLE_MARGIN_DEG;
                if (maxDelta < THIGH_ARC_SIDE_MARGIN_DEG) maxDelta = THIGH_ARC_SIDE_MARGIN_DEG;

                // NEW: which side of centerDeg counts as "the good side"
                // used to just be hardcoded to negative -- true for a
                // never-mirrored leg, but mirrorHipLeg (robot.c) reflects
                // the leg through a true screen-space mirror, which
                // reverses orientation/handedness: whichever side of
                // centerDeg was physically valid before mirroring ends up
                // on the OPPOSITE side afterward. Semni doesn't keep a
                // persistent "is this leg mirrored" flag to branch on, so
                // instead this re-derives the correct side fresh every
                // drag from thighArcDragStartAngle itself (the actual
                // current angle, captured in WM_LBUTTONDOWN, which is
                // already sitting on whichever side is currently correct)
                // rather than assuming it's always negative. Without this,
                // starting a drag right after mirroring immediately
                // clamped to the hardcoded (now wrong) side and snapped
                // the arc to it -- the reported "jumps when mirrored" bug.
                float startDelta = app->thighArcDragStartAngle - range.centerDeg;
                while (startDelta > 180.0f) startDelta -= 360.0f;
                while (startDelta < -180.0f) startDelta += 360.0f;
                BOOL positiveSide = (startDelta >= 0.0f);

                float perpNow = perpOffsetOnAxis(legLocalMouse, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle);
                float raw = app->thighArcDragStartAngle + (perpNow - app->thighArcDragStartPerp) * THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                float delta = raw - range.centerDeg;
                while (delta > 180.0f) delta -= 360.0f;
                while (delta < -180.0f) delta += 360.0f;

                if (positiveSide)
                {
                    if (delta < THIGH_ARC_SIDE_MARGIN_DEG) delta = THIGH_ARC_SIDE_MARGIN_DEG;
                    if (delta > maxDelta) delta = maxDelta;
                }
                else
                {
                    if (delta > -THIGH_ARC_SIDE_MARGIN_DEG) delta = -THIGH_ARC_SIDE_MARGIN_DEG;
                    if (delta < -maxDelta) delta = -maxDelta;
                }

                app->robotScene.robot.thighArc1Angle = range.centerDeg + delta;
            }

            // thighArc2Angle drags the same incremental, perpendicular-
            // offset way as thighArc1Angle, but against its own concave
            // safe range (filletSafeAngleRangeConcave) -- which is
            // centered on the opposite side of innerCircle, facing
            // kneeCircle. No side-lock needed here: thighArc1Angle's
            // range and this one no longer share a degenerate center to
            // stay apart from, so this just clamps symmetrically to
            // whichever side of ITS OWN center the drag reaches.
            if (app->draggingThigh2)
            {
                SafeAngleRange range = filletSafeAngleRangeConcave(app->robotScene.robot.innerCircle, app->robotScene.robot.innerRadius,
                                                                    app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                                    MAX_THIGH_ARC2_CONCAVE_R);
                float maxDelta = range.halfWidthDeg - THIGH_ARC_ANGLE_MARGIN_DEG;
                if (maxDelta < 0.0f) maxDelta = 0.0f;

                float perpNow = perpOffsetOnAxis(legLocalMouse, app->robotScene.robot.innerCircle, app->robotScene.robot.kneeCircle);
                float raw = app->thighArcDragStartAngle + (perpNow - app->thighArcDragStartPerp) * THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                float delta = raw - range.centerDeg;
                while (delta > 180.0f) delta -= 360.0f;
                while (delta < -180.0f) delta += 360.0f;

                if (delta > maxDelta) delta = maxDelta;
                if (delta < -maxDelta) delta = -maxDelta;

                app->robotScene.robot.thighArc2Angle = range.centerDeg + delta;
            }

            // the shin sits in a frame additionally rotated by kneeAngle
            // around kneeCircle, so undo that rotation too before storing
            // the raw local coordinates for foot/shin
            PointF shinLocalMouse = inverseRotate(legLocalMouse, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeAngle);

            // same idea for the foot circle: constrained to the
            // knee->foot axis so dragging it only changes the shin's
            // length, not its direction
            if (app->draggingFoot)
            {
                app->robotScene.robot.footCircle = constrainToAxis(
                    app->robotScene.robot.kneeCircle,
                    app->robotScene.robot.footCircle,
                    shinLocalMouse,
                    MIN_LIMB_LENGTH);

                // knee<->foot distance just changed, so the shin arcs'
                // fillet solve did too -- re-validate their existing
                // angles against it
                adjustShinArcs(app);
            }

            // shin arcs: same tangent-restricted, angle-driven drag as the
            // thigh arcs above, just reading the mouse's perpendicular-to-
            // axis movement relative to the knee->foot axis instead of
            // hip->knee (shinLocalMouse already has kneeAngle undone, same
            // way legLocalMouse has hipAngle undone for the thigh).
            // shinArc1Angle (convex) stays locked to the negative-delta
            // side of ITS centerDeg, same "stay off the degenerate center"
            // safety seam arc 1/2 and thighArc1Angle use. shinArc2Angle
            // (concave) drags against a totally different, disjoint safe
            // range (see its own block below) so it doesn't need that
            // same one-sided lock. Dragging one never mirrors the other.
            // Nothing needs recentering on a knee/foot move -- the angle
            // is already fully relative to kneeCircle/footCircle, so the
            // fillet solve just adapts automatically every frame.
            if (app->draggingShin1)
            {
                SafeAngleRange range = filletSafeAngleRange(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                             app->robotScene.robot.footCircle, app->robotScene.robot.footRadius,
                                                             MAX_SHIN_ARC_R);
                float maxDelta = range.halfWidthDeg - SHIN_ARC_ANGLE_MARGIN_DEG;
                if (maxDelta < SHIN_ARC_SIDE_MARGIN_DEG) maxDelta = SHIN_ARC_SIDE_MARGIN_DEG;

                // NEW: same mirror-aware side derivation as thighArc1's
                // drag block above (see its comment) -- mirrorHipLeg
                // reverses orientation, so the hardcoded "always negative"
                // side lock this used to have was wrong for a mirrored
                // leg. Re-derive which side is currently correct from
                // shinArcDragStartAngle (the actual angle at drag start)
                // instead of assuming.
                float startDelta = app->shinArcDragStartAngle - range.centerDeg;
                while (startDelta > 180.0f) startDelta -= 360.0f;
                while (startDelta < -180.0f) startDelta += 360.0f;
                BOOL positiveSide = (startDelta >= 0.0f);

                float perpNow = perpOffsetOnAxis(shinLocalMouse, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle);
                float raw = app->shinArcDragStartAngle + (perpNow - app->shinArcDragStartPerp) * SHIN_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                float delta = raw - range.centerDeg;
                while (delta > 180.0f) delta -= 360.0f;
                while (delta < -180.0f) delta += 360.0f;

                if (positiveSide)
                {
                    if (delta < SHIN_ARC_SIDE_MARGIN_DEG) delta = SHIN_ARC_SIDE_MARGIN_DEG;
                    if (delta > maxDelta) delta = maxDelta;
                }
                else
                {
                    if (delta > -SHIN_ARC_SIDE_MARGIN_DEG) delta = -SHIN_ARC_SIDE_MARGIN_DEG;
                    if (delta < -maxDelta) delta = -maxDelta;
                }

                app->robotScene.robot.shinArc1Angle = range.centerDeg + delta;
            }

            // shinArc2Angle drags the same incremental, perpendicular-
            // offset way as shinArc1Angle, but against its own concave
            // safe range (filletSafeAngleRangeConcave) -- centered on the
            // opposite side of kneeCircle, facing footCircle. No
            // side-lock needed: shinArc1Angle's range and this one don't
            // share a degenerate center, so this just clamps symmetrically
            // to whichever side of ITS OWN center the drag reaches.
            if (app->draggingShin2)
            {
                SafeAngleRange range = filletSafeAngleRangeConcave(app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeRadius,
                                                                    app->robotScene.robot.footCircle, app->robotScene.robot.footRadius,
                                                                    MAX_SHIN_ARC2_CONCAVE_R);
                float maxDelta = range.halfWidthDeg - SHIN_ARC_ANGLE_MARGIN_DEG;
                if (maxDelta < 0.0f) maxDelta = 0.0f;

                float perpNow = perpOffsetOnAxis(shinLocalMouse, app->robotScene.robot.kneeCircle, app->robotScene.robot.footCircle);
                float raw = app->shinArcDragStartAngle + (perpNow - app->shinArcDragStartPerp) * SHIN_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT;

                float delta = raw - range.centerDeg;
                while (delta > 180.0f) delta -= 360.0f;
                while (delta < -180.0f) delta += 360.0f;

                if (delta > maxDelta) delta = maxDelta;
                if (delta < -maxDelta) delta = -maxDelta;

                app->robotScene.robot.shinArc2Angle = range.centerDeg + delta;
            }
        }
        break;

        case WM_MOUSEWHEEL:
        {
            // wheel delta comes in the high word of wParam, positive = away from user
            short wheelDelta = (short)HIWORD(wParam);

            // wheel messages give screen coords, not client coords
            POINT pt;
            pt.x = (short)LOWORD(lParam);
            pt.y = (short)HIWORD(lParam);
            ScreenToClient(hwnd, &pt);

            float gx, gy;
            screenToGL(hwnd, pt.x, pt.y, &gx, &gy);

            PointF mouse = { gx, gy };

            // Rocky's body handle: plain scroll while hovering it resizes
            // the rectangle (both half-width and half-height together),
            // same "hover the joint circle handle, scroll to resize"
            // interaction as Semni's own hip circle (see the innerRadius
            // branch further below) -- no Shift-gated rotate here, since
            // Rocky's whole-body angle has no dedicated scroll gesture yet
            // (only the keyboard Left/Right, see WM_KEYDOWN).
            if (app->robotScene.activeKind == ROBOT_KIND_ROCKY)
            {
                PointF rockyCenter = getRockyCenter(app->robotScene.rocky);
                PointF kneeWorld = rotatePoint(app->robotScene.rocky.kneeCircle, rockyCenter, app->robotScene.rocky.angle);
                PointF footWorld = jointToWorld(app->robotScene.rocky.footCircle, app->robotScene.rocky.kneeCircle, app->robotScene.rocky.kneeAngle, rockyCenter, app->robotScene.rocky.angle);

                // wheel messages pack the modifier keys into the low word
                // of wParam, same as WM_MOUSEMOVE -- see Semni's own
                // shiftHeld read further below
                int shiftHeld = (LOWORD(wParam) & MK_SHIFT) != 0;

                if (!app->robotScene.rocky.bodyHidden && isNear(mouse, rockyCenter, HIP_HANDLE_RADIUS))
                {
                    float sizeStep = 0.02f;
                    if (wheelDelta > 0)
                    {
                        app->robotScene.rocky.bodyHalfWidth += sizeStep;
                        app->robotScene.rocky.bodyHalfHeight += sizeStep;
                    }
                    else
                    {
                        app->robotScene.rocky.bodyHalfWidth -= sizeStep;
                        app->robotScene.rocky.bodyHalfHeight -= sizeStep;
                    }

                    if (app->robotScene.rocky.bodyHalfWidth < MIN_ROCKY_BODY_HALF)
                        app->robotScene.rocky.bodyHalfWidth = MIN_ROCKY_BODY_HALF;
                    if (app->robotScene.rocky.bodyHalfWidth > MAX_ROCKY_BODY_HALF)
                        app->robotScene.rocky.bodyHalfWidth = MAX_ROCKY_BODY_HALF;

                    if (app->robotScene.rocky.bodyHalfHeight < MIN_ROCKY_BODY_HALF)
                        app->robotScene.rocky.bodyHalfHeight = MIN_ROCKY_BODY_HALF;
                    if (app->robotScene.rocky.bodyHalfHeight > MAX_ROCKY_BODY_HALF)
                        app->robotScene.rocky.bodyHalfHeight = MAX_ROCKY_BODY_HALF;

                    // The knee (and the foot/shin hanging off it) used
                    // to get pulled back inside a shrinking rectangle
                    // here -- removed along with the knee's own drag
                    // clamp (WM_MOUSEMOVE's draggingRockyKnee branch),
                    // since the knee isn't bound to the body at all
                    // anymore (detached by explicit request).
                }
                else if (!app->robotScene.rocky.legHidden && isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS) && shiftHeld)
                {
                    // rotate the knee joint -- bends the foot/shin around
                    // kneeCircle, leaving the rectangle and the knee's own
                    // position untouched. Gated behind Shift for the same
                    // reason as Semni's own knee/hip rotate: a plain
                    // scroll while hovering the handle falls through to
                    // the ordinary view-zoom below instead of bending the
                    // leg by accident.
                    float step = 2.0f;
                    if (wheelDelta > 0)
                        app->robotScene.rocky.kneeAngle += step;
                    else
                        app->robotScene.rocky.kneeAngle -= step;
                }
                else if (!app->robotScene.rocky.legHidden && isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS))
                {
                    // plain scroll (no Shift) resizes the knee circle
                    // itself instead of bending -- same idea as the body
                    // handle above and Semni's own knee handle
                    float radiusStep = 0.01f;
                    if (wheelDelta > 0)
                        app->robotScene.rocky.kneeRadius += radiusStep;
                    else
                        app->robotScene.rocky.kneeRadius -= radiusStep;

                    if (app->robotScene.rocky.kneeRadius < MIN_R)
                        app->robotScene.rocky.kneeRadius = MIN_R;
                    if (app->robotScene.rocky.kneeRadius > MAX_R)
                        app->robotScene.rocky.kneeRadius = MAX_R;

                    // knee radius feeds the shin arcs' fillet solve --
                    // re-validate their existing angles against the new size
                    adjustRockyShinArcs(app);
                }
                else if (!app->robotScene.rocky.legHidden && isNear(mouse, footWorld, FOOT_HANDLE_RADIUS))
                {
                    // plain scroll on the foot handle resizes it -- no
                    // Shift-gated rotate branch needed, same reasoning as
                    // Semni's own foot handle: it's the last joint in the
                    // chain, so there's nothing further down to bend
                    float radiusStep = 0.01f;
                    if (wheelDelta > 0)
                        app->robotScene.rocky.footRadius += radiusStep;
                    else
                        app->robotScene.rocky.footRadius -= radiusStep;

                    if (app->robotScene.rocky.footRadius < MIN_R)
                        app->robotScene.rocky.footRadius = MIN_R;
                    if (app->robotScene.rocky.footRadius > MAX_R)
                        app->robotScene.rocky.footRadius = MAX_R;

                    // foot radius feeds the shin arcs' fillet solve too --
                    // re-validate their existing angles against the new size
                    adjustRockyShinArcs(app);
                }
                else
                {
                    float factor = (wheelDelta > 0) ? ZOOM_STEP : (1.0f / ZOOM_STEP);
                    graphicsZoom(factor);
                }
                break;
            }

            // Stilo now has just a hip + feet handle per leg's worth of
            // scroll-to-rotate/resize (no knee/foot/shin sub-stage any
            // more -- see app.h's Stilo comment) -- same construction as
            // the ROBOT_KIND_SEMNI block below, operating on
            // app->robotScene.stilo instead of Semni's own.
            if (app->robotScene.activeKind == ROBOT_KIND_STILO)
            {
                PointF stiloCenter = getStiloCenter(app->robotScene.stilo);
                PointF stiloHip1World  = rotatePoint(app->robotScene.stilo.hip1Circle, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloFeet1World = jointToWorld(app->robotScene.stilo.feet1Circle, app->robotScene.stilo.hip1Circle, app->robotScene.stilo.hip1Angle, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloHeadWorld = rotatePoint((PointF){app->robotScene.stilo.headX, app->robotScene.stilo.y}, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloButtWorld = rotatePoint((PointF){app->robotScene.stilo.buttX, app->robotScene.stilo.y}, stiloCenter, app->robotScene.stilo.angle);

                // leg 2's own hip/feet -- same construction as leg 1's
                // above, against the hip2/feet2 fields. No leg-2 equivalent
                // of stiloHeadWorld/stiloButtWorld -- those are torso-level,
                // shared with leg 1.
                PointF stiloHip2World  = rotatePoint(app->robotScene.stilo.hip2Circle, stiloCenter, app->robotScene.stilo.angle);
                PointF stiloFeet2World = jointToWorld(app->robotScene.stilo.feet2Circle, app->robotScene.stilo.hip2Circle, app->robotScene.stilo.hip2Angle, stiloCenter, app->robotScene.stilo.angle);

                float stiloStep = 2.0f;
                float stiloRadiusStep = 0.01f;

                int stiloShiftHeld = (LOWORD(wParam) & MK_SHIFT) != 0;

                if (isNear(mouse, stiloHip1World, HIP_HANDLE_RADIUS) && stiloShiftHeld)
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.hip1Angle += stiloStep;
                    else
                        app->robotScene.stilo.hip1Angle -= stiloStep;
                }
                else if (isNear(mouse, stiloHip1World, HIP_HANDLE_RADIUS))
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.hip1Radius += stiloRadiusStep;
                    else
                        app->robotScene.stilo.hip1Radius -= stiloRadiusStep;

                    if (app->robotScene.stilo.hip1Radius < MIN_R)
                        app->robotScene.stilo.hip1Radius = MIN_R;
                    if (app->robotScene.stilo.hip1Radius > MAX_R)
                        app->robotScene.stilo.hip1Radius = MAX_R;

                    adjustStiloThigh1Arcs(app);
                }
                else if (isNear(mouse, stiloFeet1World, KNEE_HANDLE_RADIUS))
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.feet1Radius += stiloRadiusStep;
                    else
                        app->robotScene.stilo.feet1Radius -= stiloRadiusStep;

                    if (app->robotScene.stilo.feet1Radius < MIN_R)
                        app->robotScene.stilo.feet1Radius = MIN_R;
                    if (app->robotScene.stilo.feet1Radius > MAX_R)
                        app->robotScene.stilo.feet1Radius = MAX_R;

                    adjustStiloThigh1Arcs(app);
                }
                else if (isNear(mouse, stiloHeadWorld, HEAD_BUTT_HANDLE_RADIUS))
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.headRadius += stiloRadiusStep;
                    else
                        app->robotScene.stilo.headRadius -= stiloRadiusStep;

                    if (app->robotScene.stilo.headRadius < MIN_R)
                        app->robotScene.stilo.headRadius = MIN_R;
                    if (app->robotScene.stilo.headRadius > MAX_R)
                        app->robotScene.stilo.headRadius = MAX_R;
                }
                else if (isNear(mouse, stiloButtWorld, HEAD_BUTT_HANDLE_RADIUS))
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.buttRadius += stiloRadiusStep;
                    else
                        app->robotScene.stilo.buttRadius -= stiloRadiusStep;

                    if (app->robotScene.stilo.buttRadius < MIN_R)
                        app->robotScene.stilo.buttRadius = MIN_R;
                    if (app->robotScene.stilo.buttRadius > MAX_R)
                        app->robotScene.stilo.buttRadius = MAX_R;
                }
                else if (isNear(mouse, stiloHip2World, HIP_HANDLE_RADIUS) && stiloShiftHeld)
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.hip2Angle += stiloStep;
                    else
                        app->robotScene.stilo.hip2Angle -= stiloStep;
                }
                else if (isNear(mouse, stiloHip2World, HIP_HANDLE_RADIUS))
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.hip2Radius += stiloRadiusStep;
                    else
                        app->robotScene.stilo.hip2Radius -= stiloRadiusStep;

                    if (app->robotScene.stilo.hip2Radius < MIN_R)
                        app->robotScene.stilo.hip2Radius = MIN_R;
                    if (app->robotScene.stilo.hip2Radius > MAX_R)
                        app->robotScene.stilo.hip2Radius = MAX_R;

                    adjustStiloThigh2Arcs(app);
                }
                else if (isNear(mouse, stiloFeet2World, KNEE_HANDLE_RADIUS))
                {
                    if (wheelDelta > 0)
                        app->robotScene.stilo.feet2Radius += stiloRadiusStep;
                    else
                        app->robotScene.stilo.feet2Radius -= stiloRadiusStep;

                    if (app->robotScene.stilo.feet2Radius < MIN_R)
                        app->robotScene.stilo.feet2Radius = MIN_R;
                    if (app->robotScene.stilo.feet2Radius > MAX_R)
                        app->robotScene.stilo.feet2Radius = MAX_R;

                    adjustStiloThigh2Arcs(app);
                }
                else
                {
                    float factor = (wheelDelta > 0) ? ZOOM_STEP : (1.0f / ZOOM_STEP);
                    graphicsZoom(factor);
                }
                break;
            }

            // Per-joint scroll-to-rotate/resize beyond Rocky's one body
            // handle and Stilo's full set above only exists for Semni here
            // -- see WM_LBUTTONDOWN's matching guard.
            if (app->robotScene.activeKind != ROBOT_KIND_SEMNI)
            {
                float factor = (wheelDelta > 0) ? ZOOM_STEP : (1.0f / ZOOM_STEP);
                graphicsZoom(factor);
                break;
            }

            PointF center = getCenter(app->robotScene.robot);
            PointF innerWorld = rotatePoint(app->robotScene.robot.innerCircle, center, app->robotScene.robot.angle);
            PointF kneeWorld = jointToWorld(app->robotScene.robot.kneeCircle, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, app->robotScene.robot.angle);
            PointF footWorld = nestedJointToWorld(app->robotScene.robot.footCircle, app->robotScene.robot.kneeCircle, app->robotScene.robot.kneeAngle, app->robotScene.robot.innerCircle, app->robotScene.robot.hipAngle, center, app->robotScene.robot.angle);
            PointF headWorld = rotatePoint((PointF){app->robotScene.robot.headX, app->robotScene.robot.y}, center, app->robotScene.robot.angle);
            PointF buttWorld = rotatePoint((PointF){app->robotScene.robot.buttX, app->robotScene.robot.y}, center, app->robotScene.robot.angle);

            float step = 2.0f;
            float radiusStep = 0.01f;

            // WM_MOUSEWHEEL packs the modifier keys held during the scroll
            // into the low word of wParam (MK_SHIFT/MK_CONTROL/etc.), same
            // as WM_MOUSEMOVE -- so no GetAsyncKeyState polling needed
            int shiftHeld = (LOWORD(wParam) & MK_SHIFT) != 0;

            if (isNear(mouse, innerWorld, HIP_HANDLE_RADIUS) && shiftHeld)
            {
                // rotate just the hip joint (and everything hanging off of
                // it -- knee, foot, thigh/shin handles), not the whole
                // robot body. Gated behind Shift so a plain scroll while
                // hovering the (small, easy-to-clip) hip handle falls
                // through to the ordinary view-zoom behavior below instead
                // of rotating the hip by accident.
                if (wheelDelta > 0)
                    app->robotScene.robot.hipAngle += step;
                else
                    app->robotScene.robot.hipAngle -= step;
            }
            else if (isNear(mouse, innerWorld, HIP_HANDLE_RADIUS))
            {
                // plain scroll (no Shift) on the hip handle resizes the hip
                // circle itself instead of rotating -- same idea as the
                // head/butt handles below, just reachable without a
                // modifier since resizing the hip doesn't cascade into the
                // rest of the leg the way rotating it does
                if (wheelDelta > 0)
                    app->robotScene.robot.innerRadius += radiusStep;
                else
                    app->robotScene.robot.innerRadius -= radiusStep;

                if (app->robotScene.robot.innerRadius < MIN_R)
                    app->robotScene.robot.innerRadius = MIN_R;
                if (app->robotScene.robot.innerRadius > MAX_R)
                    app->robotScene.robot.innerRadius = MAX_R;

                // hip radius feeds the thigh arcs' fillet solve --
                // re-validate their existing angles against the new size
                adjustThighArcs(app);
            }
            else if (isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS) && shiftHeld)
            {
                // rotate just the knee joint (and the shin/foot hanging
                // off of it), leaving the hip and the rest of the body
                // untouched. Gated behind Shift for the same reason as the
                // hip above -- a plain scroll while hovering the knee
                // handle falls through to the ordinary view-zoom instead.
                if (wheelDelta > 0)
                    app->robotScene.robot.kneeAngle += step;
                else
                    app->robotScene.robot.kneeAngle -= step;
            }
            else if (isNear(mouse, kneeWorld, KNEE_HANDLE_RADIUS))
            {
                // plain scroll (no Shift) on the knee handle resizes the
                // knee circle itself instead of rotating -- same idea as
                // the hip handle above
                if (wheelDelta > 0)
                    app->robotScene.robot.kneeRadius += radiusStep;
                else
                    app->robotScene.robot.kneeRadius -= radiusStep;

                if (app->robotScene.robot.kneeRadius < MIN_R)
                    app->robotScene.robot.kneeRadius = MIN_R;
                if (app->robotScene.robot.kneeRadius > MAX_R)
                    app->robotScene.robot.kneeRadius = MAX_R;

                // knee radius feeds both the thigh arcs' fillet solve (hip
                // <-> knee) and the shin arcs' (knee <-> foot), so both
                // pairs get re-validated
                adjustThighArcs(app);
                adjustShinArcs(app);
            }
            else if (isNear(mouse, footWorld, FOOT_HANDLE_RADIUS))
            {
                // plain scroll on the foot/foot handle resizes it -- no
                // Shift-gated rotate branch needed here, unlike the hip and
                // knee above: the foot is the last joint in the chain, so
                // there's nothing further down for a rotation to carry
                // along, and it can just always resize on scroll like the
                // head/butt handles below
                if (wheelDelta > 0)
                    app->robotScene.robot.footRadius += radiusStep;
                else
                    app->robotScene.robot.footRadius -= radiusStep;

                if (app->robotScene.robot.footRadius < MIN_R)
                    app->robotScene.robot.footRadius = MIN_R;
                if (app->robotScene.robot.footRadius > MAX_R)
                    app->robotScene.robot.footRadius = MAX_R;

                // foot radius feeds the shin arcs' fillet solve --
                // re-validate their existing angles against the new size
                adjustShinArcs(app);
            }
            else if (isNear(mouse, headWorld, HEAD_BUTT_HANDLE_RADIUS))
            {
                // scroll on the head circle's own handle to resize it,
                // same range as the head radius slider
                if (wheelDelta > 0)
                    app->robotScene.robot.headRadius += radiusStep;
                else
                    app->robotScene.robot.headRadius -= radiusStep;

                if (app->robotScene.robot.headRadius < MIN_R)
                    app->robotScene.robot.headRadius = MIN_R;
                if (app->robotScene.robot.headRadius > MAX_R)
                    app->robotScene.robot.headRadius = MAX_R;

                // head radius feeds the seam arc 1/2 fillet solve --
                // re-validate their existing angles
                adjustHeadButtArcs(app);
            }
            else if (isNear(mouse, buttWorld, HEAD_BUTT_HANDLE_RADIUS))
            {
                // same idea for the butt circle's handle
                if (wheelDelta > 0)
                    app->robotScene.robot.buttRadius += radiusStep;
                else
                    app->robotScene.robot.buttRadius -= radiusStep;

                if (app->robotScene.robot.buttRadius < MIN_R)
                    app->robotScene.robot.buttRadius = MIN_R;
                if (app->robotScene.robot.buttRadius > MAX_R)
                    app->robotScene.robot.buttRadius = MAX_R;

                // butt radius feeds the same seam arc 1/2 fillet solve
                adjustHeadButtArcs(app);
            }
            else
            {
                // not over any handle -- treat the wheel as a view zoom
                // instead. Always centered on the robot's own rotation
                // pivot (not the cursor) -- see graphicsZoom's comment for
                // why: a cursor-centered version could drift the view off
                // the robot entirely, since it's drawn as thin outlines
                // rather than filled shapes.
                float factor = (wheelDelta > 0) ? ZOOM_STEP : (1.0f / ZOOM_STEP);
                graphicsZoom(factor);
            }
        }

        // A view-only zoom (the "else" branch just above) doesn't change
        // the robot's actual size, but every OTHER branch in this handler
        // does (a radius nudge) -- cheaper to just always refresh than to
        // thread a "did this actually change geometry" flag out of every
        // branch above.
        updateRobotSizeLabel(app);
        break;

        case WM_HSCROLL:
        {
            // Only message this trackbar sends -- fires on every drag step,
            // arrow-key nudge, and click-on-the-track, not just release, so
            // the robot resizes live as the slider moves.
            if ((HWND)lParam == app->ui.hScaleSlider)
            {
                int pos = (int)SendMessage(app->ui.hScaleSlider, TBM_GETPOS, 0, 0);

                // Scale around whichever robot kind is active's own
                // center, not the world origin -- see
                // graphicsSetRobotScale's comment for why (the robot's
                // center is rarely anywhere near the origin, so without
                // this it visibly drifts across the screen as it resizes
                // instead of growing/shrinking in place).
                PointF scaleCenter;
                switch (app->robotScene.activeKind)
                {
                    case ROBOT_KIND_ROCKY:
                        scaleCenter = getRockyCenter(app->robotScene.rocky);
                        break;

                    case ROBOT_KIND_STILO:
                        scaleCenter = getStiloCenter(app->robotScene.stilo);
                        break;

                    case ROBOT_KIND_SEMNI:
                    default:
                        scaleCenter = getCenter(app->robotScene.robot);
                        break;
                }
                graphicsSetRobotScale(pos / 100.0f, scaleCenter.x, scaleCenter.y);

                // (Re)start the real-world-size bounding box overlay's
                // hold+fade window -- see renderer.c's drawRobotSizeBox and
                // config.h's ROBOT_SIZE_BOX_HOLD_MS/FADE_MS. Stamped fresh
                // on every scroll step (not just the first), so the box
                // stays fully visible for as long as the user keeps
                // dragging, and only starts fading once they actually stop.
                app->robotSizeBoxStartTick = GetTickCount();

                // Live value in the label instead of a static "Scale" --
                // matches the ArcSpline panel's "Thickness: N px" label
                // (ui.c). wsprintf has no float conversion, so the
                // pos (50-200) is split into whole/hundredths by hand
                // (e.g. pos=75 -> "0.75", pos=200 -> "2.00").
                wchar_t scaleBuf[32];
                wsprintf(scaleBuf, L"Scale: %d.%02d", pos / 100, pos % 100);
                SetWindowText(app->ui.hScaleLabel, scaleBuf);

                // "Size: W x H mm" now moves WITH this slider (see
                // updateRobotSizeLabel's own comment) instead of staying
                // pinned to the fixed designed size, so it has to refresh
                // live on every step here too, not just on kind-switch/
                // handle-release.
                updateRobotSizeLabel(app);

                // Hand keyboard focus back to the main window after every
                // slider step (mouse-drag or the trackbar's own native
                // arrow-key nav) -- a focused trackbar otherwise keeps
                // Left/Right for itself (nudging its own position) instead
                // of passing them through to WM_KEYDOWN's whole-body
                // rotate below, so without this, adjusting Robot Size and
                // then immediately pressing Left/Right to rotate the robot
                // would just move the slider again instead. Safe to call
                // on every WM_HSCROLL tick, including mid-drag -- an
                // active trackbar drag is driven by mouse CAPTURE, not
                // keyboard focus, so this doesn't interrupt it.
                SetFocus(hwnd);

                InvalidateRect(hwnd, NULL, FALSE);
            }

            // Body<->Leg ratio slider -- see ID_WEIGHT_RATIO_SLIDER's own
            // comment. pos is 0-100, read directly as the body share
            // percentage; the leg share is just 100-pos. Written straight
            // into bodyWeight/legWeight as 0..1 fractions summing to
            // exactly 1.0 -- fine since only their RATIO to each other is
            // ever used (see every computeXMassCenterWorld's <=1e-6f
            // guard comment), so the actual magnitude resetting on every
            // slider move changes nothing downstream.
            else if ((HWND)lParam == app->ui.hWeightRatioSlider)
            {
                int pos = (int)SendMessage(app->ui.hWeightRatioSlider, TBM_GETPOS, 0, 0);
                float bodyShare = pos / 100.0f;
                float legShare = 1.0f - bodyShare;

                switch (app->robotScene.activeKind)
                {
                    case ROBOT_KIND_ROCKY:
                        app->robotScene.rocky.bodyWeight = bodyShare;
                        app->robotScene.rocky.legWeight = legShare;
                        break;
                    case ROBOT_KIND_STILO:
                        app->robotScene.stilo.bodyWeight = bodyShare;
                        app->robotScene.stilo.legWeight = legShare;
                        break;
                    case ROBOT_KIND_SEMNI:
                    default:
                        app->robotScene.robot.bodyWeight = bodyShare;
                        app->robotScene.robot.legWeight = legShare;
                        break;
                }

                wchar_t ratioBuf[32];
                wsprintf(ratioBuf, L"Body/Leg Ratio: %d / %d", pos, 100 - pos);
                SetWindowText(app->ui.hWeightRatioLabel, ratioBuf);

                // Same keyboard-focus handoff as hScaleSlider above, same
                // reasoning.
                SetFocus(hwnd);

                InvalidateRect(hwnd, NULL, FALSE);
            }
        }
        break;

        case WM_KEYDOWN:
        {
            // Rocky's mass-center handle hover (hoverRockyMassCenter,
            // gating both the yellow highlight and whether a click would
            // actually grab it) is only ever recomputed inside
            // WM_MOUSEMOVE, keyed off (LOWORD(wParam) & MK_SHIFT) -- so if
            // the cursor is already sitting still on top of the handle
            // when Shift goes down, nothing re-evaluates it until the
            // mouse physically moves a pixel, which read as "I have to
            // wiggle the cursor for it to turn yellow". Fix: synthesize a
            // WM_MOUSEMOVE at the CURRENT cursor position (with the
            // CURRENT Shift/mouse-button state folded into wParam, same
            // MK_SHIFT/MK_LBUTTON bits Windows itself would set) so the
            // exact same hover logic re-runs immediately on the down-
            // stroke, with no visible mouse movement required. Harmless
            // for every other robot kind/mode -- it's just a no-op
            // WM_MOUSEMOVE at the same spot the cursor was already at.
            if (wParam == VK_SHIFT)
            {
                POINT shiftCursor;
                GetCursorPos(&shiftCursor);
                ScreenToClient(hwnd, &shiftCursor);

                WPARAM shiftMods = MK_SHIFT;
                if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) shiftMods |= MK_LBUTTON;
                if (GetAsyncKeyState(VK_CONTROL) & 0x8000) shiftMods |= MK_CONTROL;

                SendMessage(hwnd, WM_MOUSEMOVE, shiftMods,
                            MAKELPARAM((short)shiftCursor.x, (short)shiftCursor.y));
            }

            // Ctrl+Numpad0: reset the view (zoom to 100%, pan back to
            // center) -- same shortcut/convention as the ArcSpline canvas's
            // own Ctrl+Numpad0 (see canvas.c's WM_KEYDOWN) and Simulation's
            // (sim_camera.h's simCameraReset). Deliberately VK_NUMPAD0, not
            // the top-row '0' (see canvas.c's WM_KEYDOWN for why those are
            // different VK codes). Also deliberately leaves
            // graphicsSetRobotScale's "size" slider alone -- that's the
            // robot's own configured size, not a camera position, so this
            // shouldn't undo it.
            if (wParam == VK_NUMPAD0 && (GetAsyncKeyState(VK_CONTROL) & 0x8000))
            {
                graphicsResetView();
                InvalidateRect(hwnd, NULL, FALSE);
                break;
            }

            // Whole-body rotate (Left/Right) and move (Up/Down) act on
            // whichever robot is currently active (see app.h's RobotKind).
            // Rocky still relies on this for its whole-body pose (it has
            // no whole-body drag handle of its own); Stilo now ALSO has
            // Semni's full per-joint dragging (see WM_LBUTTONDOWN/
            // WM_MOUSEMOVE/WM_MOUSEWHEEL), but keeps this same whole-body
            // nudge too, same as Semni does below.
            switch (app->robotScene.activeKind)
            {
                case ROBOT_KIND_ROCKY:
                {
                    if (wParam == VK_LEFT)
                        app->robotScene.rocky.angle += 2.0f;

                    if (wParam == VK_RIGHT)
                        app->robotScene.rocky.angle -= 2.0f;

                    if (wParam == VK_UP || wParam == VK_DOWN)
                    {
                        int ctrlHeld = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
                        float step = ctrlHeld ? 0.01f : 0.05f;
                        if (wParam == VK_DOWN) step = -step;

                        // Move the whole robot (rectangle + leg) together
                        app->robotScene.rocky.bodyY += step;
                        app->robotScene.rocky.kneeCircle.y += step;
                        app->robotScene.rocky.footCircle.y += step;
                    }
                    break;
                }

                case ROBOT_KIND_STILO:
                {
                    if (wParam == VK_LEFT)
                        app->robotScene.stilo.angle += 2.0f;

                    if (wParam == VK_RIGHT)
                        app->robotScene.stilo.angle -= 2.0f;

                    if (wParam == VK_UP || wParam == VK_DOWN)
                    {
                        int ctrlHeld = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
                        float step = ctrlHeld ? 0.01f : 0.05f;
                        if (wParam == VK_DOWN) step = -step;

                        app->robotScene.stilo.y += step;
                        app->robotScene.stilo.hip1Circle.y += step;
                        app->robotScene.stilo.feet1Circle.y += step;

                        // leg 2 hangs off the same shared torso Y above --
                        // carry it along the same whole-body nudge, same
                        // "y/hip1Circle.y/feet1Circle.y" pattern as leg 1
                        // just above
                        app->robotScene.stilo.hip2Circle.y += step;
                        app->robotScene.stilo.feet2Circle.y += step;
                    }
                    break;
                }

                case ROBOT_KIND_SEMNI:
                default:
                {
                    if (wParam == VK_LEFT)
                        app->robotScene.robot.angle += 2.0f;

                    if (wParam == VK_RIGHT)
                        app->robotScene.robot.angle -= 2.0f;

                    if (wParam == VK_UP)
                    {
                        // Check if Ctrl is held for finer movement
                        int ctrlHeld = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
                        float step = ctrlHeld ? 0.01f : 0.05f;

                        // Move entire robot including body and legs
                        app->robotScene.robot.y += step;
                        app->robotScene.robot.innerCircle.y += step;
                        app->robotScene.robot.kneeCircle.y += step;
                        app->robotScene.robot.footCircle.y += step;
                    }

                    if (wParam == VK_DOWN)
                    {
                        // Check if Ctrl is held for finer movement
                        int ctrlHeld = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
                        float step = ctrlHeld ? 0.01f : 0.05f;

                        // Move entire robot including body and legs
                        app->robotScene.robot.y -= step;
                        app->robotScene.robot.innerCircle.y -= step;
                        app->robotScene.robot.kneeCircle.y -= step;
                        app->robotScene.robot.footCircle.y -= step;
                    }
                    break;
                }
            }
        }
        break;

        case WM_KEYUP:
        {
            // Mirror image of WM_KEYDOWN's own VK_SHIFT handling just
            // above -- releasing Shift while the cursor is sitting still
            // over the handle needs the same synthetic WM_MOUSEMOVE to
            // immediately drop the hover/highlight back out (Mass Center
            // hover requires MK_SHIFT to be set at all, so a stale "still
            // yellow after letting go of Shift" would be the mirror-image
            // bug of the one this pair fixes).
            if (wParam == VK_SHIFT)
            {
                POINT shiftCursor;
                GetCursorPos(&shiftCursor);
                ScreenToClient(hwnd, &shiftCursor);

                WPARAM shiftMods = 0;
                if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) shiftMods |= MK_LBUTTON;
                if (GetAsyncKeyState(VK_CONTROL) & 0x8000) shiftMods |= MK_CONTROL;

                SendMessage(hwnd, WM_MOUSEMOVE, shiftMods,
                            MAKELPARAM((short)shiftCursor.x, (short)shiftCursor.y));
            }
        }
        break;

        case WM_SIZE:
        {
            int w = LOWORD(lParam);
            int h = HIWORD(lParam);

            graphicsOnResize(w, h);

            RECT rect;
            GetClientRect(hwnd, &rect);

            // ---- top-right control panel ----
            // Everything below is laid out relative to one panel rect
            // (hControlPanel) instead of each control computing its own
            // right-aligned offset independently -- that's what used to
            // leave Standing/Home/Save/Mirror at four different widths
            // with no shared edge. Two equal-width columns (colW) now
            // line up across every row, and the panel's solid backdrop
            // (see WM_CREATE) reads as one grouped control, not four
            // buttons floating loose over the viewport.
            int outerMargin = 12;
            int pad = 14;
            int rowGap = 8;
            int colGap = 8;
            int btnH = 30;
            int titleH = 20;
            int sliderH = 24;
            int comboRowH = 24;   // closed-box footprint in the layout; the control itself is taller (see below) so its dropdown list has room to show all 3 entries

            int contentW = 240;
            int colW = (contentW - colGap) / 2;

            int panelW = contentW + pad * 2;

            int relYTitle    = pad;
            int relYSelector = relYTitle    + titleH    + rowGap;  // robot picker (Semni/Rocky/Stilo)
            int relYRow1     = relYSelector + comboRowH + rowGap;  // Home | Standing
            int relYRow1b    = relYRow1     + btnH      + rowGap;  // Set Home | Set Standing
            int relYRow2     = relYRow1b    + btnH      + rowGap;  // Mirror Leg | Mirror Leg 2 (leg 2 only meaningful for Stilo, inert otherwise -- see canvas.c's ID_SAVE for where the old Save button that used to share this row moved to)
            int relYWeightRatio = relYRow2   + btnH      + rowGap;  // Body<->Leg ratio label+slider stack (see hWeightRatioLabel/hWeightRatioSlider) -- replaces the old separate Body Wt | Leg Wt edit-box row, removed per explicit user request
            int relYActualWeight = relYWeightRatio + 20 + 2 + sliderH + rowGap;  // label (20px) + 2px gap + full-width slider, then Weight (Rocky only, inert otherwise) -- separate real mass, written as Rob.txt's own weight value
            int relYSize     = relYActualWeight + btnH  + rowGap;  // Size: W x H mm (live readout, all robot kinds)
            int relYScale    = relYSize     + btnH       + rowGap; // Scale label + slider
            int relYSeg      = relYScale    + sliderH    + rowGap; // View Segments
            int relYRockyHide = relYSeg     + btnH       + rowGap; // Remove Leg | Remove Body (Rocky only, testing) -- Debug Log row moved to View > Print Debug Log
            int panelH       = relYRockyHide + btnH      + pad;

            int panelX = rect.right - outerMargin - panelW;
            int panelY = outerMargin;

            // HWND_BOTTOM (not SWP_NOZORDER) pins this at the bottom of
            // the Z-order on every resize -- belt-and-suspenders on top of
            // creation order (see WM_CREATE) so the backdrop can never end
            // up above the real controls and swallow their clicks.
            SetWindowPos(app->ui.hControlPanel, HWND_BOTTOM,
                 panelX, panelY, panelW, panelH,
                 SWP_NOACTIVATE);

            SetWindowPos(app->ui.hPanelTitle, NULL,
                 panelX + pad, panelY + relYTitle, contentW, titleH,
                 SWP_NOZORDER);

            int col1X = panelX + pad;
            int col2X = col1X + colW + colGap;

            // Height here (120) is the combo box's OWN window height, not
            // the row slot -- for a CBS_DROPDOWNLIST, Windows sizes the
            // closed box from the font metrics alone and uses the rest of
            // this height for how tall the dropped-down list can get, so
            // this needs to be taller than comboRowH (the layout slot
            // above) for all 3 entries to be visible when it's opened.
            SetWindowPos(app->ui.hRobotSelector, NULL,
                 col1X, panelY + relYSelector, contentW, 120,
                 SWP_NOZORDER);

            // Swapped from their original Standing-left/Home-right order.
            SetWindowPos(app->ui.hHomePositionButton, NULL,
                 col1X, panelY + relYRow1, colW, btnH,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hStandingPositionButton, NULL,
                 col2X, panelY + relYRow1, colW, btnH,
                 SWP_NOZORDER);

            // Set Home / Set Standing sit directly under the button whose
            // target pose they capture, so the column each is in matches
            // up with Home/Standing above.
            SetWindowPos(app->ui.hSetHomeButton, NULL,
                 col1X, panelY + relYRow1b, colW, btnH,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hSetStandingButton, NULL,
                 col2X, panelY + relYRow1b, colW, btnH,
                 SWP_NOZORDER);

            // Mirror Leg | Mirror Leg 2, side by side -- Leg 2 (see
            // ID_MIRROR_LEG2_BUTTON) is only meaningful for Stilo, harmlessly
            // inert for Semni/Rocky, same convention as the rest of this
            // panel's "always shown, only some kinds act on it" controls.
            SetWindowPos(app->ui.hMirrorButton, NULL,
                 col1X, panelY + relYRow2, colW, btnH,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hMirrorButton2, NULL,
                 col2X, panelY + relYRow2, colW, btnH,
                 SWP_NOZORDER);

            // weightLabelW/weightEditW: sized for the "Weight" row below
            // (Actual Weight) -- this used to also lay out a Body Wt |
            // Leg Wt two-column edit-box pair here, replaced by the
            // hWeightRatioLabel/hWeightRatioSlider row just below per
            // explicit user request (a slider instead of two boxes).
            int weightLabelW = 66;
            int weightEditW = colW - weightLabelW - colGap;

            // Body<->Leg ratio slider -- more discoverable alternative to
            // the two edit boxes this replaced (a slider reads immediately
            // as "one ratio, two ends"). Label stacked directly ABOVE a
            // FULL-WIDTH slider (rather than label-left/slider-right like
            // hScaleLabel/hScaleSlider below) per explicit user request --
            // the slider reads as the main control here, wide enough to
            // drag precisely, with the label just narrating its value.
            int weightRatioLabelH = 20;
            int weightRatioStackGap = 2;

            SetWindowPos(app->ui.hWeightRatioLabel, NULL,
                 col1X, panelY + relYWeightRatio, contentW, weightRatioLabelH,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hWeightRatioSlider, NULL,
                 col1X, panelY + relYWeightRatio + weightRatioLabelH + weightRatioStackGap, contentW, sliderH,
                 SWP_NOZORDER);

            // Weight -- own row, but sized like Body Wt/Leg Wt's own
            // edit boxes (weightEditW, half the row) rather than
            // stretched across the full content width -- it's a single
            // number, not a ratio pair, so it doesn't need the room and
            // reads oversized left that wide.
            SetWindowPos(app->ui.hActualWeightLabel, NULL,
                 col1X, panelY + relYActualWeight + (btnH - 20) / 2, weightLabelW, 20,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hActualWeightEdit, NULL,
                 col1X + weightLabelW + colGap, panelY + relYActualWeight + (btnH - 22) / 2, weightEditW, 22,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hRobotSizeLabel, NULL,
                 col1X, panelY + relYSize + (btnH - 20) / 2, contentW, 20,
                 SWP_NOZORDER);

            // Scale label + slider share the full content width, same as
            // the two-button rows above them.
            int scaleLabelWidth = 70;
            int sliderWidth = contentW - scaleLabelWidth - colGap;

            SetWindowPos(app->ui.hScaleLabel, NULL,
                 col1X, panelY + relYScale + (sliderH - 20) / 2, scaleLabelWidth, 20,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hScaleSlider, NULL,
                 col1X + scaleLabelWidth + colGap, panelY + relYScale, sliderWidth, sliderH,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hViewSegmentsButton, NULL,
                 col1X, panelY + relYSeg, contentW, btnH,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hRockyToggleLegButton, NULL,
                 col1X, panelY + relYRockyHide, colW, btnH,
                 SWP_NOZORDER);

            SetWindowPos(app->ui.hRockyToggleBodyButton, NULL,
                 col2X, panelY + relYRockyHide, colW, btnH,
                 SWP_NOZORDER);

            // ---- bottom-left hover status strip ----
            int hoverPad = 8;
            int hoverLabelW = 280;
            int hoverLabelH = 20;
            int hoverPanelW = hoverLabelW + hoverPad * 2;
            int hoverPanelH = hoverLabelH + hoverPad * 2;
            int hoverPanelX = outerMargin;
            int hoverPanelY = rect.bottom - outerMargin - hoverPanelH;

            // Same HWND_BOTTOM pinning as hControlPanel above.
            SetWindowPos(app->ui.hHoverPanel, HWND_BOTTOM,
                 hoverPanelX, hoverPanelY, hoverPanelW, hoverPanelH,
                 SWP_NOACTIVATE);

            SetWindowPos(app->ui.hHoverLabel, NULL,
                 hoverPanelX + hoverPad, hoverPanelY + hoverPad, hoverLabelW, hoverLabelH,
                 SWP_NOZORDER);

            // Any resize (a live border drag, minimize/restore, or
            // toggling fullscreen/maximize) can leave one of these child
            // controls' own clip region stale for a frame or two, since
            // the OpenGL viewport behind them repaints the whole client
            // rect continuously in the render loop and that repaint can
            // race the SetWindowPos calls above -- the robot picker combo
            // box in particular has been seen to vanish under the GL
            // repaint until a later hover forces Windows to repaint it on
            // its own. Force that repaint right now instead of waiting on
            // it.
            //
            // Deliberately targets each child individually rather than
            // RedrawWindow(hwnd, ..., RDW_ALLCHILDREN) on the whole window:
            // that form also marks hwnd's OWN client area invalid, and
            // RDW_UPDATENOW would then dispatch hwnd's WM_PAINT (which
            // calls renderCombinedFrame's covering GL SwapBuffers)
            // synchronously in the very same batch -- so it could end up
            // repainting the children and then immediately re-covering
            // them again before this call even returns, silently undoing
            // the fix. Only invalidating the children (never hwnd itself)
            // means this can only ever un-cover them, not re-cover them.
            HWND rockyPanelChildren[] = {
                app->ui.hControlPanel,
                app->ui.hPanelTitle,
                app->ui.hRobotSelector,
                app->ui.hStandingPositionButton,
                app->ui.hHomePositionButton,
                app->ui.hSetStandingButton,
                app->ui.hSetHomeButton,
                app->ui.hMirrorButton,
                app->ui.hMirrorButton2,
                app->ui.hWeightRatioLabel,
                app->ui.hWeightRatioSlider,
                app->ui.hActualWeightLabel,
                app->ui.hActualWeightEdit,
                app->ui.hRobotSizeLabel,
                app->ui.hScaleLabel,
                app->ui.hScaleSlider,
                app->ui.hViewSegmentsButton,
                app->ui.hDebugLogButton,
                app->ui.hRockyToggleLegButton,
                app->ui.hRockyToggleBodyButton,
                app->ui.hHoverPanel,
                app->ui.hHoverLabel,
            };
            int childCount = sizeof(rockyPanelChildren) / sizeof(rockyPanelChildren[0]);
            for (int i = 0; i < childCount; i++)
            {
                if (rockyPanelChildren[i])
                {
                    InvalidateRect(rockyPanelChildren[i], NULL, TRUE);
                    UpdateWindow(rockyPanelChildren[i]);
                }
            }
        }
        break;

        case WM_CREATE:
        {
             // -1 = nothing hovered. Otherwise these would sit at their
             // zero-initialized default (a valid circle index, 0) until
             // the first WM_MOUSEMOVE recomputes them, which could briefly
             // mislabel seam arc 1 / the head circle as hovered before the
             // mouse ever moves.
             app->hoveredCircleSegment = -1;
             app->hoveredBodyCircle = -1;
             app->hoveredRectSegment = -1;

             ensureSemniUIFonts();
             ensureSemniPanelClassRegistered();

             // Backdrop behind the whole top-right button cluster, created
             // first so every real control below (created after it) draws
             // on top of it -- see ensureSemniPanelClassRegistered's
             // comment. Real position/size is computed in WM_SIZE, which
             // fires once right after WM_CREATE.
             app->ui.hControlPanel = CreateWindowEx(
                WS_EX_STATICEDGE,
                L"SemniControlPanel",
                L"",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );

             app->ui.hPanelTitle = CreateWindow(
                L"STATIC",
                L"Robot Controls",
                WS_VISIBLE | WS_CHILD | SS_LEFT,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );
             SendMessage(app->ui.hPanelTitle, WM_SETFONT, (WPARAM)g_semniUITitleFont, TRUE);

             // Robot selector: picks which of the three robots (Semni/
             // Rocky/Stilo, see app.h's RobotKind) every control below
             // this acts on. CBS_DROPDOWNLIST (not a plain CBS_DROPDOWN)
             // so it's pick-one-from-a-list only, no free text entry.
             // Index order here MUST match RobotKind's own 0/1/2 values --
             // WM_COMMAND's CBN_SELCHANGE handler casts CB_GETCURSEL's
             // result straight to RobotKind.
             app->ui.hRobotSelector = CreateWindow(
                L"COMBOBOX",
                L"",
                WS_VISIBLE | WS_CHILD | CBS_DROPDOWNLIST | WS_VSCROLL,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_ROBOT_SELECTOR,
                NULL,
                NULL
            );
             SendMessage(app->ui.hRobotSelector, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);
             SendMessage(app->ui.hRobotSelector, CB_ADDSTRING, 0, (LPARAM)L"Semni");
             SendMessage(app->ui.hRobotSelector, CB_ADDSTRING, 0, (LPARAM)L"Rocky");
             SendMessage(app->ui.hRobotSelector, CB_ADDSTRING, 0, (LPARAM)L"Stilo");
             SendMessage(app->ui.hRobotSelector, CB_SETCURSEL, (WPARAM)app->robotScene.activeKind, 0);

             app->ui.hStandingPositionButton = CreateWindow(
                L"BUTTON",
                L"Standing",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_STANDING_POSITION_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hStandingPositionButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             app->ui.hHomePositionButton = CreateWindow(
                L"BUTTON",
                L"Home",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_HOME_POSITION_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hHomePositionButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             // Captures the CURRENT pose as the new Standing/Home target
             // (see app.h's hSetStandingButton/hSetHomeButton comment and
             // input.c's ID_SET_STANDING_BUTTON/ID_SET_HOME_BUTTON below) --
             // a row of their own, directly under the Standing/Home
             // buttons they modify.
             app->ui.hSetStandingButton = CreateWindow(
                L"BUTTON",
                L"Set Standing",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_SET_STANDING_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hSetStandingButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             app->ui.hSetHomeButton = CreateWindow(
                L"BUTTON",
                L"Set Home",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_SET_HOME_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hSetHomeButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             // Save itself is no longer a button here -- it's been folded
             // into the shared File > Save menu item (see canvas.c's
             // WM_COMMAND ID_SAVE handling), which now dispatches on
             // editorModeState.currentMode/app->robotScene.activeKind the
             // same way this button used to.
             app->ui.hMirrorButton = CreateWindow(
                L"BUTTON",
                L"Mirror Leg",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_MIRROR_LEG_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hMirrorButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             // Mirrors Stilo's leg 2 only (see ID_MIRROR_LEG2_BUTTON) --
             // always created/shown alongside hMirrorButton above, same
             // "harmlessly inert unless applicable" convention as
             // hViewSegmentsButton, rather than hidden/disabled per robot
             // kind (see app.h's ID_MIRROR_LEG2_BUTTON comment).
             app->ui.hMirrorButton2 = CreateWindow(
                L"BUTTON",
                L"Mirror Leg 2",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_MIRROR_LEG2_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hMirrorButton2, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             // Body<->Leg ratio: a single trackbar feeding whichever robot
             // kind is active's own bodyWeight/legWeight fields (see app.h's
             // Rocky comment) -- replaces the separate Body Wt/Leg Wt plain
             // text entry boxes this panel used to have (removed per
             // explicit user request: a slider reads as "one ratio, two
             // ends" where two independent-looking numbers didn't). See
             // ID_WEIGHT_RATIO_SLIDER's own
             // comment. Range 0-100 (body share as a percentage, leg share
             // is just 100 minus that), starts at 50/50 matching the 0.5/
             // 0.5 defaults every kind's bodyWeight/legWeight starts at
             // (see app_init.c's initAppState). Label's initial text
             // matches that same starting split so it doesn't briefly show
             // a stale value before the user's first slider move (same
             // reasoning as hScaleLabel's initial "Scale: 1.00" text).
             app->ui.hWeightRatioLabel = CreateWindow(
                L"STATIC",
                L"Body/Leg Ratio: 50 / 50",
                WS_VISIBLE | WS_CHILD | SS_LEFT,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );
             SendMessage(app->ui.hWeightRatioLabel, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             app->ui.hWeightRatioSlider = CreateWindow(
                TRACKBAR_CLASS,
                L"",
                WS_VISIBLE | WS_CHILD | TBS_HORZ | TBS_NOTICKS,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_WEIGHT_RATIO_SLIDER,
                NULL,
                NULL
            );

             SendMessage(app->ui.hWeightRatioSlider, TBM_SETRANGE, TRUE, MAKELONG(0, 100));
             SendMessage(app->ui.hWeightRatioSlider, TBM_SETPOS, TRUE, 50);

             // Separate real total-mass input -- own row, own field
             // (Rocky.actualWeight), NOT part of the Body Wt/Leg Wt
             // mass-center ratio. This is the number saveRockyAsRobArm
             // actually writes as Rob.txt's own "(gewicht)" weight value.
             app->ui.hActualWeightLabel = CreateWindow(
                L"STATIC",
                L"Weight",
                WS_VISIBLE | WS_CHILD | SS_LEFT,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );
             SendMessage(app->ui.hActualWeightLabel, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             app->ui.hActualWeightEdit = CreateWindowEx(
                WS_EX_CLIENTEDGE,
                L"EDIT",
                L"1.00",   // same two-decimal format refreshWeightEdit always uses
                WS_VISIBLE | WS_CHILD | ES_AUTOHSCROLL,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_ACTUAL_WEIGHT_EDIT,
                NULL,
                NULL
            );
             SendMessage(app->ui.hActualWeightEdit, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);
             // see weightEditSubclassProc's own comment -- Enter returns
             // focus to the main window instead of beeping/staying put.
             SetWindowSubclass(app->ui.hActualWeightEdit, weightEditSubclassProc, 0, (DWORD_PTR)hwnd);

             // Live real-world size readout (see config.h's
             // MM_PER_WORLD_UNIT and this file's updateRobotSizeLabel) --
             // full content width, own row, refreshed once right below
             // once app's fields have their real (post-initAppState)
             // values rather than left showing whatever placeholder text
             // it's created with.
             app->ui.hRobotSizeLabel = CreateWindow(
                L"STATIC",
                L"Size: - mm",
                WS_VISIBLE | WS_CHILD | SS_LEFT,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );
             SendMessage(app->ui.hRobotSizeLabel, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);
             updateRobotSizeLabel(app);

             // Robot size slider: 0.5 - 2.0 (see ROBOT_SCALE_MIN/MAX in
             // config.h), mapped to an integer trackbar range of 50-200
             // (WM_HSCROLL below divides the position back down by 100).
             // Starts at 100 (scale 1.0), matching graphics.c's
             // g_robotScale default. Label shows the live value (see
             // WM_HSCROLL below), matching the ArcSpline panel's
             // "Thickness: N px" label (ui.c) -- initial text set to match
             // this same 1.0 starting value so it doesn't briefly show a
             // stale value before the user's first slider move.
             app->ui.hScaleLabel = CreateWindow(
                L"STATIC",
                L"Scale: 1.00",
                WS_VISIBLE | WS_CHILD | SS_LEFT,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );
             SendMessage(app->ui.hScaleLabel, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             app->ui.hScaleSlider = CreateWindow(
                TRACKBAR_CLASS,
                L"",
                WS_VISIBLE | WS_CHILD | TBS_HORZ | TBS_NOTICKS,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_SCALE_SLIDER,
                NULL,
                NULL
            );

             SendMessage(app->ui.hScaleSlider, TBM_SETRANGE, TRUE, MAKELONG(50, 200));
             SendMessage(app->ui.hScaleSlider, TBM_SETPOS, TRUE, 100);

             // View Segments toggle: every curve on Semni (seam/thigh/shin
             // arcs) is a trimmed segment of some circle -- this reveals
             // the full circle behind each one. BS_AUTOCHECKBOX |
             // BS_PUSHLIKE gives it the same "stays visually pressed while
             // checked" look as the ArcSpline canvas's own View Segments
             // button (ui.c), and the button IS the toggle state (read via
             // BM_GETCHECK in WM_COMMAND below) rather than a separately
             // tracked bool driving it.
             app->ui.hViewSegmentsButton = CreateWindow(
                L"BUTTON",
                L"View Segments",
                WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX | BS_PUSHLIKE,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_VIEW_SEGMENTS_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hViewSegmentsButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             // The "Debug Log" button that used to sit here moved to
             // View > Print Debug Log (canvas.c's ID_DEBUG_LOG_MENU), which
             // prints the robot pose in Robot mode and the right thing in
             // the other modes. hDebugLogButton stays NULL.

             // Rocky-only testing toggles (see app.h's
             // ID_ROCKY_TOGGLE_LEG_BUTTON/ID_ROCKY_TOGGLE_BODY_BUTTON and
             // Rocky's own legHidden/bodyHidden comment) -- same checkbox-
             // as-button convention as hViewSegmentsButton above, so each
             // button IS its own toggle state (read via BM_GETCHECK in
             // WM_COMMAND below). Created for all kinds like the rest of
             // this panel, but only actually SHOWN while Rocky is active
             // -- see ID_ROBOT_SELECTOR's CBN_SELCHANGE handling, same
             // "hide what has nothing to act on" treatment as
             // hMirrorButton2.
             app->ui.hRockyToggleLegButton = CreateWindow(
                L"BUTTON",
                L"Remove Leg",
                WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX | BS_PUSHLIKE,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_ROCKY_TOGGLE_LEG_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hRockyToggleLegButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             app->ui.hRockyToggleBodyButton = CreateWindow(
                L"BUTTON",
                L"Remove Body",
                WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX | BS_PUSHLIKE,
                0, 0, 10, 10,
                hwnd,
                (HMENU)ID_ROCKY_TOGGLE_BODY_BUTTON,
                NULL,
                NULL
            );
             SendMessage(app->ui.hRockyToggleBodyButton, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);

             // Small backdrop behind the bottom-left hover label so the
             // status text stays legible no matter what color the 3D
             // scene behind it happens to be -- created before the label
             // itself so the label draws on top of it.
             app->ui.hHoverPanel = CreateWindowEx(
                WS_EX_STATICEDGE,
                L"SemniControlPanel",
                L"",
                WS_VISIBLE | WS_CHILD,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );

             // bottom-left hover status label
             app->ui.hHoverLabel = CreateWindow(
                L"STATIC",
                L"",
                WS_VISIBLE | WS_CHILD | SS_LEFT,
                0, 0, 10, 10,
                hwnd,
                NULL,
                NULL,
                NULL
            );
             SendMessage(app->ui.hHoverLabel, WM_SETFONT, (WPARAM)g_semniUIFont, TRUE);
        }
        break;

        // no WM_DESTROY handler existed before, so clicking the window's
        // close button destroyed the window but never told the message
        // loop to stop -- WinMain's PeekMessage loop kept spinning
        // (rendering to a now-dead HDC) and the process, and the console
        // AllocConsole opened alongside it, never exited. PostQuitMessage
        // queues WM_QUIT, which main.c's loop explicitly checks for and
        // returns 0 on, ending the process (and with it, the console).
        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        case WM_COMMAND:
            switch (LOWORD(wParam))
            {
                case ID_ROBOT_SELECTOR:
                    if (HIWORD(wParam) == CBN_SELCHANGE)
                    {
                        int sel = (int)SendMessage(app->ui.hRobotSelector, CB_GETCURSEL, 0, 0);
                        if (sel >= 0 && sel < ROBOT_KIND_COUNT)
                        {
                            app->robotScene.activeKind = (RobotKind)sel;

                            // Switch which kind's Robot-Size scale anchor
                            // (and ground-line anchor) is live -- see
                            // graphicsSetActiveRobotKind's comment for why
                            // each kind keeps its own independent anchor
                            // slot instead of sharing/resetting one.
                            graphicsSetActiveRobotKind(sel);
                        }

                        // Reset the newly-selected robot to its Home pose
                        // -- same "custom file first, hardcoded default as
                        // fallback" pattern as ID_HOME_POSITION_BUTTON
                        // below, so switching kinds always lands on a
                        // known, consistent pose instead of leaving
                        // whatever that robot was last left in (which
                        // could be mid-drag/off-screen/degenerate from an
                        // earlier session). Matches app_init.c's
                        // initAppState, which now seeds every robot into
                        // Home on startup for the same reason.
                        switch (app->robotScene.activeKind)
                        {
                            case ROBOT_KIND_ROCKY:
                                if (!loadRockyPoseFromFile("Poses\\rocky_home.txt", &app->robotScene.rocky))
                                    initRockyHomePosition(app);
                                break;

                            case ROBOT_KIND_STILO:
                                initStiloHomePosition(app);
                                loadStiloPoseFromFile("Poses\\stilo_home.txt", &app->robotScene.stilo);
                                break;

                            case ROBOT_KIND_SEMNI:
                            default:
                                if (!loadRobotPoseFromFile("Poses\\semni_home.txt", &app->robotScene.robot))
                                    initHomePosition(app);
                                break;
                        }

                        // Mirror Leg 2 only means anything for Stilo
                        // (its second, independent leg) -- Semni and
                        // Rocky each have exactly one leg, so the button
                        // used to just sit there doing nothing for them
                        // (see ID_MIRROR_LEG2_BUTTON's own comment).
                        // Hide it outright for those two instead, same
                        // "don't show a control that has nothing to act
                        // on" treatment the rest of this panel's kind-
                        // specific controls (Body Wt/Leg Wt/Weight) get.
                        if (app->ui.hMirrorButton2)
                            ShowWindow(app->ui.hMirrorButton2,
                                       (app->robotScene.activeKind == ROBOT_KIND_STILO) ? SW_SHOW : SW_HIDE);

                        // Rocky-only testing toggles (ID_ROCKY_TOGGLE_LEG_
                        // BUTTON/ID_ROCKY_TOGGLE_BODY_BUTTON) -- same
                        // "hide what has nothing to act on" treatment as
                        // hMirrorButton2 above, just gated on ROCKY
                        // instead of STILO.
                        if (app->ui.hRockyToggleLegButton)
                            ShowWindow(app->ui.hRockyToggleLegButton,
                                       (app->robotScene.activeKind == ROBOT_KIND_ROCKY) ? SW_SHOW : SW_HIDE);
                        if (app->ui.hRockyToggleBodyButton)
                            ShowWindow(app->ui.hRockyToggleBodyButton,
                                       (app->robotScene.activeKind == ROBOT_KIND_ROCKY) ? SW_SHOW : SW_HIDE);

                        // Clear any drag/hover state left over from
                        // whichever robot was active before -- meaningful
                        // for Semni and Rocky's body handle right now (see
                        // WM_LBUTTONDOWN/WM_MOUSEMOVE's own activeKind
                        // guards), but harmless to always reset.
                        app->draggingSeamArc1 = 0;
                        app->draggingSeamArc2 = 0;
                        app->draggingInner = 0;
                        app->draggingKnee = 0;
                        app->draggingThigh1 = 0;
                        app->draggingThigh2 = 0;
                        app->draggingFoot = 0;
                        app->draggingShin1 = 0;
                        app->draggingShin2 = 0;
                        app->draggingRockyBody = 0;
                        app->hoverRockyBody = 0;
                        app->draggingRockyEdge = ROCKY_EDGE_NONE;
                        app->hoverRockyEdge = ROCKY_EDGE_NONE;
                        app->draggingRockyKnee = 0;
                        app->hoverRockyKnee = 0;
                        app->draggingRockyFoot = 0;
                        app->hoverRockyFoot = 0;
                        app->draggingRockyMassCenter = 0;
                        app->hoverRockyMassCenter = 0;
                        app->draggingSemniMassCenter = 0;
                        app->hoverSemniMassCenter = 0;
                        app->draggingStiloMassCenter = 0;
                        app->hoverStiloMassCenter = 0;
                        app->activeHandle = 0;
                        app->hoveredCircleSegment = -1;
                        app->hoveredBodyCircle = -1;
                        app->hoveredRectSegment = -1;
                        SetWindowText(app->ui.hHoverLabel, L"");

                        // The ratio slider and Weight box are shared across
                        // all three kinds (see ID_WEIGHT_RATIO_SLIDER's own
                        // comment) -- refresh them to whichever kind just
                        // became active's OWN bodyWeight/legWeight/
                        // actualWeight, so switching kinds doesn't leave
                        // another robot's numbers showing.
                        {
                            float bw = 0.5f, lw = 0.5f, aw = 1.0f;
                            switch (app->robotScene.activeKind)
                            {
                                case ROBOT_KIND_ROCKY:
                                    bw = app->robotScene.rocky.bodyWeight;
                                    lw = app->robotScene.rocky.legWeight;
                                    aw = app->robotScene.rocky.actualWeight;
                                    break;
                                case ROBOT_KIND_STILO:
                                    bw = app->robotScene.stilo.bodyWeight;
                                    lw = app->robotScene.stilo.legWeight;
                                    aw = app->robotScene.stilo.actualWeight;
                                    break;
                                case ROBOT_KIND_SEMNI:
                                default:
                                    bw = app->robotScene.robot.bodyWeight;
                                    lw = app->robotScene.robot.legWeight;
                                    aw = app->robotScene.robot.actualWeight;
                                    break;
                            }

                            (void)aw;
                            refreshWeightEdit(app);
                            syncWeightRatioSlider(app, bw, lw);
                        }

                        // Switching kind swaps in a differently-sized
                        // robot entirely -- refresh the mm readout to match.
                        updateRobotSizeLabel(app);

                        SetFocus(app->hwndMain);
                        InvalidateRect(hwnd, NULL, TRUE);
                    }
                    break;

                case ID_MIRROR_LEG_BUTTON:
                    switch (app->robotScene.activeKind)
                    {
                        case ROBOT_KIND_ROCKY:
                            mirrorRockyLeg(&app->robotScene.rocky);
                            break;

                        case ROBOT_KIND_STILO:
                            mirrorStiloLeg(&app->robotScene.stilo);
                            break;

                        case ROBOT_KIND_SEMNI:
                        default:
                            mirrorHipLeg(&app->robotScene.robot);
                            break;
                    }
                    InvalidateRect(hwnd, NULL, FALSE);
                    SetFocus(app->hwndMain);  // return focus for keyboard input
                    break;

                // Separate real total-mass input -- live EN_CHANGE mirror
                // of the active kind's own actualWeight (the Body Wt/Leg Wt
                // edit boxes this used to sit alongside are gone -- see
                // ID_WEIGHT_RATIO_SLIDER's own comment -- so this is the
                // panel's only remaining plain-text weight field). Doesn't
                // move the on-canvas mass-center marker (it isn't part of
                // that ratio) -- it's just kept in sync so File > Save
                // (canvas.c) always reads back out whatever's currently
                // typed in without needing a redundant GetWindowText of
                // its own first.
                case ID_ACTUAL_WEIGHT_EDIT:
                    // Typing no longer applies live -- the value is confirmed
                    // only when the box loses focus: pressing Enter
                    // (weightEditSubclassProc) or clicking anything else
                    // (canvas, panel, another control). Esc cancels.
                    if (HIWORD(wParam) == EN_KILLFOCUS)
                        commitWeightEdit(app);
                    break;

                case ID_MIRROR_LEG2_BUTTON:
                    // Only meaningful for Stilo (its leg 2, see app.h's
                    // Stilo comment) -- harmlessly inert for Semni/Rocky,
                    // same convention as ID_VIEW_SEGMENTS_BUTTON being inert
                    // outside Semni, rather than hiding/disabling the
                    // button per robot kind (see app.h's
                    // ID_MIRROR_LEG2_BUTTON comment).
                    if (app->robotScene.activeKind == ROBOT_KIND_STILO)
                    {
                        mirrorStiloLeg2(&app->robotScene.stilo);
                        InvalidateRect(hwnd, NULL, FALSE);
                    }
                    SetFocus(app->hwndMain);  // return focus for keyboard input
                    break;

                case ID_STANDING_POSITION_BUTTON:
				    // Prefer a user-saved custom pose (see ID_SET_STANDING_
				    // BUTTON below) if one exists on disk for whichever
				    // robot is active -- only falls back to the hardcoded
				    // app_init.c default when no such file has ever been
				    // saved (loadXPoseFromFile returns 0 and leaves the
				    // robot untouched in that case, so the init* call below
				    // is what actually applies the default pose).
				    switch (app->robotScene.activeKind)
				    {
				        case ROBOT_KIND_ROCKY:
				            if (!loadRockyPoseFromFile("Poses\\rocky_standing.txt", &app->robotScene.rocky))
				                initRockyStandingPosition(app);
				            break;

				        case ROBOT_KIND_STILO:
				            // Stilo's struct just grew a knee stage
				            // (kneeCircle/kneeRadius/kneeAngle) and its shin
				            // arcs this session -- an OLDER stilo_standing.txt
				            // saved before that (back when Stilo went straight
				            // from hip to foot, no knee at all) has no
				            // KNEE_*/SHIN_ARC*/THIGH_ARC* keys, so loading it
				            // alone would leave those fields at whatever they
				            // were before this call (zero, on a fresh launch)
				            // instead of a real pose -- exactly what causes an
				            // extra hip-sized dot with no visible shin/foot.
				            // Seeding with the hardcoded default FIRST
				            // guarantees every field starts at a real value;
				            // the load on top only overwrites whichever keys
				            // the file actually has.
				            initStiloStandingPosition(app);
				            loadStiloPoseFromFile("Poses\\stilo_standing.txt", &app->robotScene.stilo);
				            break;

				        case ROBOT_KIND_SEMNI:
				        default:
				            if (!loadRobotPoseFromFile("Poses\\semni_standing.txt", &app->robotScene.robot))
				                initStandingPosition(app);
				            break;
				    }
				    InvalidateRect(hwnd, NULL, FALSE);
				    SetFocus(app->hwndMain);
				    break;

				case ID_HOME_POSITION_BUTTON:
				    // Same "custom file first, hardcoded default as
				    // fallback" pattern as Standing above.
				    switch (app->robotScene.activeKind)
				    {
				        case ROBOT_KIND_ROCKY:
				            if (!loadRockyPoseFromFile("Poses\\rocky_home.txt", &app->robotScene.rocky))
				                initRockyHomePosition(app);
				            break;

				        case ROBOT_KIND_STILO:
				            // same "seed the full default first, then load
				            // on top" fix as Standing above, for the same
				            // reason (an older stilo_home.txt predating
				            // Stilo's knee stage is missing those keys).
				            initStiloHomePosition(app);
				            loadStiloPoseFromFile("Poses\\stilo_home.txt", &app->robotScene.stilo);
				            break;

				        case ROBOT_KIND_SEMNI:
				        default:
				            if (!loadRobotPoseFromFile("Poses\\semni_home.txt", &app->robotScene.robot))
				                initHomePosition(app);
				            break;
				    }
				    InvalidateRect(hwnd, NULL, FALSE);
				    SetFocus(app->hwndMain);
				    break;

				case ID_SET_STANDING_BUTTON:
				    // Captures the CURRENT pose (not the default -- whatever
				    // is on screen right now) as the new Standing target for
				    // whichever robot is active, persisted to its own file
				    // so ID_STANDING_POSITION_BUTTON above picks it up from
				    // now on, including after restarting the app. All 6
				    // pose files (Standing/Home x Semni/Rocky/Stilo) now
				    // live in one Poses folder instead of loose in the
				    // working directory -- CreateDirectory is a no-op
				    // (returns FALSE, GetLastError() == ERROR_ALREADY_EXISTS)
				    // once it already exists, safe to ignore.
				    CreateDirectoryA("Poses", NULL);
				    switch (app->robotScene.activeKind)
				    {
				        case ROBOT_KIND_ROCKY:
				            saveRockyAsEquations("Poses\\rocky_standing.txt", app);
				            break;

				        case ROBOT_KIND_STILO:
				            saveStiloAsEquations("Poses\\stilo_standing.txt", app);
				            break;

				        case ROBOT_KIND_SEMNI:
				        default:
				            saveRobotAsEquations("Poses\\semni_standing.txt", app);
				            break;
				    }
				    SetFocus(app->hwndMain);
				    break;

				case ID_SET_HOME_BUTTON:
				    // Same idea as Set Standing above, for Home -- same
				    // Poses folder, same no-op-if-it-exists CreateDirectory.
				    CreateDirectoryA("Poses", NULL);
				    switch (app->robotScene.activeKind)
				    {
				        case ROBOT_KIND_ROCKY:
				            saveRockyAsEquations("Poses\\rocky_home.txt", app);
				            break;

				        case ROBOT_KIND_STILO:
				            saveStiloAsEquations("Poses\\stilo_home.txt", app);
				            break;

				        case ROBOT_KIND_SEMNI:
				        default:
				            saveRobotAsEquations("Poses\\semni_home.txt", app);
				            break;
				    }
				    SetFocus(app->hwndMain);
				    break;

                case ID_VIEW_SEGMENTS_BUTTON:
                {
                    // BS_AUTOCHECKBOX already flipped its own check state
                    // before this notification fires, so read it back
                    // rather than tracking a separate bool -- same pattern
                    // as the ArcSpline canvas's hViewSegBtn (ui.c). Works
                    // identically for all three robot kinds now (Rocky/
                    // Stilo each have their own compute/draw pair mirroring
                    // Semni's, see renderer.c/h's computeRocky*/
                    // computeStilo* and drawRocky/drawStilo's own View
                    // Segments blocks) -- whichever kind is active reads
                    // this same app->showCircleSegments flag.
                    BOOL nowChecked = (SendMessage(app->ui.hViewSegmentsButton, BM_GETCHECK, 0, 0) == BST_CHECKED);
                    app->showCircleSegments = nowChecked;
                    SetFocus(app->hwndMain);
                    break;
                }

                case ID_ROCKY_TOGGLE_LEG_BUTTON:
                {
                    // Same "button IS the toggle state" pattern as
                    // ID_VIEW_SEGMENTS_BUTTON above -- read back the
                    // checkbox BS_AUTOCHECKBOX already flipped, rather
                    // than tracking a separate bool. Drives Rocky's own
                    // legHidden (app.h), which both drawRocky (renderer.c)
                    // and robotCollidesWithEnvironment (canvas.c) gate on
                    // -- see their own comments for why a hidden part
                    // needs to drop out of BOTH, not just rendering, for
                    // this to actually be useful as an isolation test.
                    BOOL nowChecked = (SendMessage(app->ui.hRockyToggleLegButton, BM_GETCHECK, 0, 0) == BST_CHECKED);
                    app->robotScene.rocky.legHidden = nowChecked;
                    InvalidateRect(app->hwndMain, NULL, FALSE);
                    SetFocus(app->hwndMain);
                    break;
                }

                case ID_ROCKY_TOGGLE_BODY_BUTTON:
                {
                    BOOL nowChecked = (SendMessage(app->ui.hRockyToggleBodyButton, BM_GETCHECK, 0, 0) == BST_CHECKED);
                    app->robotScene.rocky.bodyHidden = nowChecked;
                    InvalidateRect(app->hwndMain, NULL, FALSE);
                    SetFocus(app->hwndMain);
                    break;
                }
            }
            break;
    }

    return DefWindowProc(hwnd, msg, wParam, lParam);
}
