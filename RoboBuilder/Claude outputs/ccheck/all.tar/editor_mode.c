#include "editor_mode.h"
#include "app.h"      // for the global `app` (Semni's own child controls live in app.ui)
#include "canvas.h"   // for hWndUI (the ArcSpline canvas's floating tool panel)
#include <stdio.h>

EditorModeState editorModeState;

void initEditorModeState(EditorModeState* modeState)
{
    if (!modeState) return;

    // Starts on the ArcSpline canvas -- that's the app's default startup
    // screen. The Semni robot editor is reached via Design Mode > Robot
    // (Semni) in the canvas's Mode menu (see canvas.c's WM_COMMAND).
    modeState->currentMode = EDITOR_MODE_ARCSPLINE;
    modeState->previousMode = EDITOR_MODE_ARCSPLINE;
}

void switchEditorMode(EditorMode newMode, EditorModeState* modeState)
{
    if (!modeState || newMode >= EDITOR_MODE_COUNT) return;

    if (modeState->currentMode == newMode) return;

    modeState->previousMode = modeState->currentMode;
    modeState->currentMode = newMode;

    applyEditorModeVisibility(modeState);

    logModeIfChanged();
}

const char* currentModeName(void)
{
    if (appMode == APP_MODE_SIMULATION) return "Simulation";
    return (editorModeState.currentMode == EDITOR_MODE_SEMNI) ? "Robot" : "Environment";
}

void logModeIfChanged(void)
{
    static const char* lastLogged = "Environment"; // the app starts in Environment
    const char* name = currentModeName();
    if (name != lastLogged)
    {
        printf("[Mode] Switched to: %s\n", name);
        lastLogged = name;
    }
}

const wchar_t* getEditorModeName(EditorMode mode)
{
    switch (mode)
    {
        // EDITOR_MODE_SEMNI is really "the Robot Editor screen is active"
        // (covers all 3 robot kinds, not just Semni -- see this enum's own
        // comment in editor_mode.h), so the log now calls it what the user
        // actually sees: "Design Robot". EDITOR_MODE_ARCSPLINE is the
        // separate canvas where the level/environment gets drawn, so it's
        // now called "Environment" instead of the internal "ArcSpline"
        // name. No more "(was: ...)" half -- just which mode it switched to.
        case EDITOR_MODE_SEMNI:
            return L"Robot";
        case EDITOR_MODE_ARCSPLINE:
            return L"Environment";
        default:
            return L"Unknown";
    }
}

void applyEditorModeVisibility(EditorModeState* modeState)
{
    if (!modeState) return;

    BOOL semniActive = (modeState->currentMode == EDITOR_MODE_SEMNI);

    // Semni's own child controls (children of the shared window) --
    // created once in handleInput's WM_CREATE and just shown/hidden here,
    // never re-created.
    if (app.ui.hControlPanel)
        ShowWindow(app.ui.hControlPanel, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hPanelTitle)
        ShowWindow(app.ui.hPanelTitle, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hRobotSelector)
        ShowWindow(app.ui.hRobotSelector, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hStandingPositionButton)
        ShowWindow(app.ui.hStandingPositionButton, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hHomePositionButton)
        ShowWindow(app.ui.hHomePositionButton, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hSetStandingButton)
        ShowWindow(app.ui.hSetStandingButton, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hSetHomeButton)
        ShowWindow(app.ui.hSetHomeButton, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hMirrorButton)
        ShowWindow(app.ui.hMirrorButton, semniActive ? SW_SHOW : SW_HIDE);
    // Mirror Leg 2 only means anything for Stilo (its second leg) -- also
    // gated on activeKind here, not just semniActive, so switching back
    // to the Robot Editor screen (from the ArcSpline canvas) while Semni
    // or Rocky was the last-active kind doesn't unconditionally reshow
    // it. See input.c's ID_ROBOT_SELECTOR handler for the other half of
    // this same gating, which fires on a KIND switch instead of a MODE
    // switch (this function only runs on the latter).
    if (app.ui.hMirrorButton2)
        ShowWindow(app.ui.hMirrorButton2,
                   (semniActive && app.robotScene.activeKind == ROBOT_KIND_STILO) ? SW_SHOW : SW_HIDE);
    // Rocky-only testing toggles (ID_ROCKY_TOGGLE_LEG_BUTTON/
    // ID_ROCKY_TOGGLE_BODY_BUTTON) -- same ANDed-with-semniActive
    // treatment as hMirrorButton2 just above, just gated on ROCKY
    // instead of STILO. Missing this is exactly the bug this function's
    // own hWeightRatioLabel/etc. comment already describes further
    // down: gate on activeKind alone (input.c's ID_ROBOT_SELECTOR
    // handler, which only fires on a KIND switch) and the button stays
    // visible in every EDITOR MODE too, including the ArcSpline
    // ("Environment") canvas, since nothing here was hiding it on a
    // MODE switch.
    if (app.ui.hRockyToggleLegButton)
        ShowWindow(app.ui.hRockyToggleLegButton,
                   (semniActive && app.robotScene.activeKind == ROBOT_KIND_ROCKY) ? SW_SHOW : SW_HIDE);
    if (app.ui.hRockyToggleBodyButton)
        ShowWindow(app.ui.hRockyToggleBodyButton,
                   (semniActive && app.robotScene.activeKind == ROBOT_KIND_ROCKY) ? SW_SHOW : SW_HIDE);
    if (app.ui.hScaleLabel)
        ShowWindow(app.ui.hScaleLabel, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hScaleSlider)
        ShowWindow(app.ui.hScaleSlider, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hViewSegmentsButton)
        ShowWindow(app.ui.hViewSegmentsButton, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hDebugLogButton)
        ShowWindow(app.ui.hDebugLogButton, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hHoverPanel)
        ShowWindow(app.ui.hHoverPanel, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hHoverLabel)
        ShowWindow(app.ui.hHoverLabel, semniActive ? SW_SHOW : SW_HIDE);

    // The Body<->Leg ratio slider + Weight edit box + the live
    // "Size: W x H mm" readout (see app.h's hWeightRatioLabel/
    // hWeightRatioSlider/hActualWeightLabel/hActualWeightEdit/
    // hRobotSizeLabel) -- these were missing from this function entirely,
    // so once created (input.c's WM_CREATE) they stayed visible in EVERY
    // mode, including the ArcSpline ("Environment") canvas. Gated the
    // same as the rest of Semni's own child controls above.
    if (app.ui.hWeightRatioLabel)
        ShowWindow(app.ui.hWeightRatioLabel, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hWeightRatioSlider)
        ShowWindow(app.ui.hWeightRatioSlider, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hActualWeightLabel)
        ShowWindow(app.ui.hActualWeightLabel, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hActualWeightEdit)
        ShowWindow(app.ui.hActualWeightEdit, semniActive ? SW_SHOW : SW_HIDE);
    if (app.ui.hRobotSizeLabel)
        ShowWindow(app.ui.hRobotSizeLabel, semniActive ? SW_SHOW : SW_HIDE);

    // The ArcSpline canvas's floating tool panel manages its own show/fade
    // via the hover hot-zone timer (see canvas.c's WM_TIMER), but force it
    // hidden immediately when entering Semni mode so it doesn't linger on
    // screen mid-fade over the robot editor.
    if (semniActive && hWndUI)
        ShowWindow(hWndUI, SW_HIDE);
}
