﻿#pragma once

#define MIN_R 0.05f
#define MAX_R 0.35f

// Rocky's rectangular torso resize range (see its body handle in
// input.c's WM_MOUSEWHEEL) -- kept separate from MIN_R/MAX_R (Semni's
// joint-CIRCLE radius range) since this bounds a rectangle's half-extents
// instead, and Rocky's default half-height (see initRockyStandingPosition,
// app_init.c) is already bigger than MAX_R.
//
// Lowered from an earlier 0.10f floor -- that made the rectangle unable to
// go much thinner/shorter than roughly half its default size. Still kept
// strictly positive (and comfortably above 0) so the rectangle can never
// collapse to a sliver or flip inside-out, just a much lower floor than
// before.
#define MIN_ROCKY_BODY_HALF 0.02f
#define MAX_ROCKY_BODY_HALF 0.70f

// How close the mouse needs to be (in local, pre-rotation world units) to
// one of Rocky's rectangle edges to count as hovering/grabbing it for a
// resize drag -- see input.c's hitTestRockyEdge.
#define ROCKY_EDGE_HIT_TOLERANCE 0.03f

// all draggable handles are drawn semi-transparent so they read as
// lightweight overlays instead of solid shapes sitting on top of the robot
#define HANDLE_ALPHA 0.45f

// handle sizes taper down the leg (hip > knee > foot) and along each limb
// (thigh bulge handles > shin bulge handles), echoing the limb getting
// thinner toward the foot.
#define HIP_HANDLE_RADIUS   0.020f
#define KNEE_HANDLE_RADIUS  0.016f
#define FOOT_HANDLE_RADIUS 0.012f

// Rocky's draggable Body/Leg Weight mass-center dot (renderer.c's
// drawRockyMassCenterMarker, input.c's hoverRockyMassCenter/
// draggingRockyMassCenter) -- sized between KNEE and FOOT, same small-and-
// precise feel. The earlier version of this marker hardcoded a raw radius
// of 6.0f directly in renderer.c, in *pixel*-scale thinking -- but every
// other handle radius in this file is in the same small normalized GL-
// space Rocky's own geometry lives in (MIN_SHIN_ARC_R is 0.05, e.g.), so
// 6.0f was roughly 300x too big for this coordinate space and likely part
// of why the marker was unusably hard to spot on screen.
#define MASS_CENTER_HANDLE_RADIUS 0.014f

// Simulation mode's center-of-mass indicator (renderer.c's
// drawSimulationMassCenterDropLine) -- a dashed green line dropping
// straight down from wherever the active robot kind's own
// compute*MassCenterWorld (computeSemniMassCenterWorld/
// computeRockyMassCenterWorld/computeStiloMassCenterWorld, all above)
// currently places its mass center, down to wherever that vertical drop
// actually reaches the environment (canvas.c's
// simFindGroundBelowRobotPoint) -- a plumb line, so it's obvious at a
// glance whether the mass center's drop point is still over the robot's
// own base of support or has drifted outside it (about to tip).
#define SIM_MASS_CENTER_ARROW_LENGTH   0.09f
#define SIM_MASS_CENTER_ARROW_HEAD_SIZE 0.035f

// simFindGroundBelowRobotPoint's own search bounds: MAX_LENGTH caps how
// far (in robot-local world units, same space SIM_MASS_CENTER_ARROW_LENGTH
// above is in) the drop line will search straight down before giving up
// and just drawing a line of that length -- keeps a robot with nothing
// drawn underneath it (floating, or the environment traced somewhere
// else entirely) from searching forever and still shows a bounded, sane-
// looking line instead of nothing at all. MAX_ITERATIONS bounds the
// sphere-tracing search itself (see that function's own comment for why
// it sphere-traces instead of stepping by a fixed increment) -- normally
// only a handful of steps are needed, this is just a hard ceiling so a
// pathological/glancing case can't spin forever. MAX_LENGTH raised from
// 3.0f (roughly the default view's whole -1.5..1.5 ortho height) to
// 20.0f, by explicit request -- a robot dragged high enough above the
// ground (well past what fits in the default view) had its dashed
// mass-center drop line visibly stop short of actually reaching the
// environment. MAX_ITERATIONS left as-is: sphere-tracing already
// converges in only a handful of steps for typical open space, so the
// existing ceiling comfortably covers the longer search too.
#define SIM_MASS_CENTER_DROP_MAX_LENGTH 20.0f
#define SIM_MASS_CENTER_DROP_MAX_ITERATIONS 64

// handle for the top/bottom seam fillet arcs -- sits at each arc's
// outward peak point; dragging it changes that arc's fillet radius
#define ARC_HANDLE_RADIUS 0.018f

// clamp range for the seam fillet radius. Must stay strictly positive
// (0 isn't a circle); the upper bound is kept modest on purpose -- past a
// certain size the arc reads as a straight line instead of a curve given
// the head/butt scale, so this is a deliberate cap, not just headroom.
// filletSafeAngleRange() uses this same constant to work out how far the
// seam handle can be dragged before hitting it, so the two stay in sync.
#define MIN_ARC_R 0.05f
#define MAX_ARC_R 6.0f

// extra angular headroom (in degrees) kept between a dragged seam handle
// and the exact edge of its valid range (see filletSafeAngleRange) -- just
// numerical safety margin, since the radius-cap bound already does the
// real work of keeping the arc from flattening out or flipping
#define ARC_ANGLE_MARGIN_DEG 1.0f

// SafeAngleRange's centerDeg (the point on the head circle farthest from
// the butt circle) is where a completely different degenerate case lives:
// at that exact angle, the arc's head tangent point, its bulge peak, and
// its butt tangent point all land exactly on the head-butt axis (bulge
// height goes to zero), and just past it the arc's bulge flips to the
// opposite side. This margin keeps the top/bottom seam handles from ever
// reaching or crossing centerDeg, so each stays on its own side (top
// bulges up, bottom bulges down) instead of flattening out and flipping
// into the other one's territory. Kept small (rather than 0) purely for
// numerical headroom right at the boundary -- loosened from an earlier,
// much more conservative value so the handle can be dragged in much
// closer to centerDeg before the clamp kicks in.
#define ARC_SIDE_MARGIN_DEG 1.0f

// the seam handle now sits at the arc's visible middle/bulge point rather
// than the head-circle tangent point, so dragging can no longer read the
// attach angle directly off the mouse's polar angle around the head
// circle (the handle isn't on that circle anymore). Instead it drags
// incrementally along one axis (vertical mouse movement): angle = (angle
// when the drag started) + (Y moved since then) * this sensitivity.
// Bulge height isn't a monotonic function of angle across the whole
// range (it peaks partway through, then falls back toward zero near
// SafeAngleRange's centerDeg), so an absolute mouse-position-to-angle
// solve can snap on click or feel non-linear near the edges --
// incremental dragging sidesteps that entirely, since it only ever asks
// "which way and how far did the mouse move", never "what angle does
// this exact position correspond to".
#define ARC_DRAG_SENSITIVITY_DEG_PER_UNIT 200.0f

// scroll handle sitting at the center of the head/butt circles, used to
// resize them (same radius for both -- they're the same kind of part)
#define HEAD_BUTT_HANDLE_RADIUS 0.018f

#define THIGH_HANDLE_RADIUS 0.014f
#define SHIN_HANDLE_RADIUS  0.010f

// Rocky's own shin1/shin2 handles (drawRockyLeg's drawHandle calls,
// input.c's Rocky-specific isNear hit-tests) -- deliberately bigger than
// SHIN_HANDLE_RADIUS above (which Semni's own shin handles still use), per
// explicit user request to make Rocky's easier to see/grab even though
// that means the two robots no longer match exactly.
#define ROCKY_SHIN_HANDLE_RADIUS 0.016f

// Tiny, non-interactive marker for Rob.txt's export reference point (the
// rectangle's own local bottom-left corner, pre-rotation) -- View
// Segments-only, purely informational (no hit-test, no drag), so it's
// deliberately much smaller than every real handle above.
#define ROCKY_REF_POINT_RADIUS 0.008f

// thigh arcs (between innerCircle/hip and kneeCircle/knee) use the same
// tangent-restricted-fillet construction as the head/butt seam arcs (see
// MIN_ARC_R/MAX_ARC_R above), but the hip/knee circles are much smaller
// and closer together than head/butt, so they get their own clamp/margin/
// sensitivity constants instead of sharing the head/butt-tuned ones.
// MAX_SEMNI_THIGH_ARC_R is picked with the same ratio to the hip-knee
// distance (~0.52 for the default pose) that MAX_ARC_R has to the
// head-butt distance (~1.2), so the "arc flattens past this size" cap
// scales with the limb instead of being tuned for a completely different
// part.
//
// Used ONLY by Semni's own thighArc1 (the convex fillet) -- thighArc2
// bulges the other way and is capped by its own MAX_THIGH_ARC2_CONCAVE_R
// below instead. filletSafeAngleRange's halfWidthDeg (the actual draggable
// angle range WM_MOUSEMOVE's draggingThigh1 clamps to, minus
// THIGH_ARC_ANGLE_MARGIN_DEG) shrinks as this cap gets smaller, so
// lowering it is how much thigh arc 1 specifically can be dragged, without
// touching thigh arc 2's own range at all. Lowered from an earlier 2.5f --
// that let thigh arc 1 swing much further than felt right; this cuts the
// draggable range down noticeably. Tune further by adjusting this same
// constant (up for more room, down for less).
//
// Named Semni-specific (rather than a plain MAX_THIGH_ARC_R) for
// historical reasons -- Stilo used to have a simpler hip-to-foot leg (no
// knee stage) that reused this same constant for a differently-scoped
// arc. Stilo now has the exact same hip->knee thigh-arc construction as
// Semni (see app.h's Stilo comment) and shares this constant for real --
// "exactly the same as Semni" for now includes the same draggable range.
#define MIN_THIGH_ARC_R 0.05f
#define MAX_SEMNI_THIGH_ARC_R 1.2f

// A per-arc MINIMUM radius floor (tried as MIN_SEMNI_THIGH_ARC1_R, briefly)
// is NOT a safe way to shrink thigh arc 1's draggable range, unlike the MAX
// cap above -- filletSafeAngleRange (which derives maxDelta, the range
// WM_MOUSEMOVE's draggingThigh1 actually clamps the ANGLE to) only takes a
// single maxRadius parameter and guarantees every angle inside its derived
// window already solves to a radius at or under that cap, so raising
// MAX_SEMNI_THIGH_ARC_R's cap never needs filletFromAttachAngle's own
// clamp to actually engage. There's no equivalent derivation for a MINIMUM
// -- nothing stops the angle from reaching a delta whose natural radius
// falls below a raised floor, so filletFromAttachAngle's minRadius clamp
// DOES engage there, recentering the fillet circle at a radius that no
// longer matches what internalTangentPoint computes assuming tangency --
// the arc visibly detaches from the knee circle instead of just going flat.
// Use THIGH_ARC_SIDE_MARGIN_DEG below (an ANGLE restriction, not a radius
// one) to shrink the near-center portion of the range instead -- it keeps
// every reachable angle's natural radius safely inside [MIN_THIGH_ARC_R,
// MAX_SEMNI_THIGH_ARC_R] with no clamp ever firing, so tangency can't break.

// same role as ARC_ANGLE_MARGIN_DEG/ARC_SIDE_MARGIN_DEG, kept as separate
// constants so the thigh arcs' feel can be tuned independently of the seam
// arcs'. THIGH_ARC_ANGLE_MARGIN_DEG is shared with thighArc2's own maxDelta
// calc; THIGH_ARC_SIDE_MARGIN_DEG is used ONLY by thighArc1 (thighArc2's
// concave range doesn't need a one-sided lock -- see the comment below).
// Both are shared with Stilo's own thighArc1Angle drag, same reasoning as
// MAX_SEMNI_THIGH_ARC_R above.
//
// THIGH_ARC_SIDE_MARGIN_DEG is the SAFE way to shrink thigh arc 1's
// draggable range (see the MIN-radius-floor warning above for why a
// radius floor isn't): it's a pure ANGLE restriction on the near-center end
// of the range WM_MOUSEMOVE's draggingThigh1 clamps delta to, and every
// angle in the range still solves to its own natural, un-clamped radius --
// no tangency-breaking possible. Raised from 1.0f (which let the drag reach
// almost all the way to the degenerate centerDeg point) to noticeably eat
// into the near-center portion of the range, on top of the far-end trim
// MAX_SEMNI_THIGH_ARC_R above already makes -- between the two, the total
// draggable span is now roughly half of the original.
#define THIGH_ARC_ANGLE_MARGIN_DEG 2.0f
#define THIGH_ARC_SIDE_MARGIN_DEG 30.0f

// thigh arc 2 is built with filletFromAttachAngleConcave instead of the
// usual filletFromAttachAngle -- it bulges INWARD (toward the hip-knee
// axis) rather than outward, so it needs its own radius cap: the concave
// construction's radius grows toward infinity much faster as the attach
// angle nears its own singularity than the convex one does for the same
// hip/knee layout (the singularity itself is a fixed ~85.6 degrees from
// this cap's center, set by hip/knee geometry alone), so reusing
// MAX_SEMNI_THIGH_ARC_R here would let it swing almost all the way to that
// singularity before clamping kicks in. Kept deliberately tight (~51
// degree safe half-width, vs the ~85.6 degree singularity) so the pinch
// stays shallow and well clear of the point where the math breaks down --
// verified numerically that the default thighArc2Angle (-130, a 40
// degree offset from this cap's center) still lands comfortably inside.
// Reuses MIN_THIGH_ARC_R/THIGH_ARC_ANGLE_MARGIN_DEG/
// THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT for everything else -- thigh
// arc 2 doesn't need its own SIDE_MARGIN either, since its concave range
// sits on the opposite side of the hip circle from thigh arc 1's convex
// one, so there's no shared degenerate point the two need to be kept
// apart from anymore.
#define MAX_THIGH_ARC2_CONCAVE_R 1.0f

// same role as ARC_DRAG_SENSITIVITY_DEG_PER_UNIT -- the thigh handle also
// drags incrementally rather than off an absolute mouse-to-angle solve,
// for the same reason (bulge height isn't monotonic across the whole
// angle range). The one difference: since the hip->knee axis isn't fixed
// horizontal like the head-butt axis, the drag reads the mouse's
// perpendicular-to-axis movement (geometry.h's perpOffsetOnAxis) instead
// of raw vertical screen movement, so it feels the same regardless of
// which way the leg is currently posed/rotated.
#define THIGH_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT 200.0f

// the shin (kneeCircle -> footCircle) arcs use the exact same tangent-
// restricted-fillet construction as the thigh arcs above, just one joint
// further down the chain -- same MIN/MAX_ARC_R + margin + sensitivity
// pattern, kept as separate constants so the shin's feel can be tuned
// independently. MAX_SHIN_ARC_R is picked with the same ratio to the
// knee-foot distance (~0.30 for the default pose) that MAX_ARC_R has to
// the head-butt distance, same reasoning as MAX_THIGH_ARC_R.
//
// MAX_SHIN_ARC_R and SHIN_ARC_SIDE_MARGIN_DEG below are also read by
// Rocky (adjustRockyShinArcs / drawRockyLeg's shin1Fillet) and by Stilo
// (its own knee->foot shin arcs, same construction as Semni's) -- no
// split needed for Rocky because its own knee/foot layout is deliberately
// near-identical to Semni's (same 0.08/0.05 radii, ~0.30 vs ~0.2986
// knee-foot distance), so tightening
// these for Semni's interactive shin arc 1 drag leaves Rocky's shared
// default shinArc1Angle (169.821564 deg, ~79.8 deg off its own centerDeg)
// comfortably inside its own safe range too -- verified numerically for
// both robots before lowering the cap. Rocky has no shin-arc-1 drag
// handle at all, so SHIN_ARC_SIDE_MARGIN_DEG (interactive-drag-only,
// same as THIGH_ARC_SIDE_MARGIN_DEG's exclusivity to thigh arc 1) never
// touches Rocky's behavior regardless.
//
// Range reduced the same safe way as thigh arc 1 (see the MIN-radius-
// floor warning above -- never touch MIN_SHIN_ARC_R for this): lowering
// MAX_SHIN_ARC_R alone barely shrinks the practical range since the
// fillet's natural radius grows fast near the singularity, so it's
// paired with a substantial SHIN_ARC_SIDE_MARGIN_DEG increase (a pure
// angle-window restriction) to actually cut the draggable span -- from
// ~86.8 deg down to ~49.6 deg (~57%, same ratio as thigh arc 1's cut),
// leaving ~4.7 deg of clearance around the default pose's own angle so
// it never gets nudged by adjustShinArcs's clampToSafeAngleRange.
#define MIN_SHIN_ARC_R 0.05f
#define MAX_SHIN_ARC_R 1.0f
#define SHIN_ARC_ANGLE_MARGIN_DEG 2.0f
#define SHIN_ARC_SIDE_MARGIN_DEG 35.0f
#define SHIN_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT 200.0f

// same role as MAX_THIGH_ARC2_CONCAVE_R above, for shin arc 2 -- it's
// also built with filletFromAttachAngleConcave instead of the usual
// filletFromAttachAngle, bulging inward toward the knee-foot axis
// instead of outward. Verified numerically: 0.5 gives a ~69 degree safe
// half-width around its own center, comfortably clear of the singularity
// for this knee/foot layout. Reuses MIN_SHIN_ARC_R/
// SHIN_ARC_ANGLE_MARGIN_DEG/SHIN_ARC_DRAG_SENSITIVITY_DEG_PER_UNIT for
// everything else -- no separate SIDE_MARGIN needed, same reasoning as
// thigh arc 2 (its concave range doesn't overlap shin arc 1's convex one).
#define MAX_SHIN_ARC2_CONCAVE_R 0.5f

// minimum thigh/shin length, so dragging the knee or foot circle along
// its constrained axis can't collapse the limb to zero or flip it
// through the pivot
#define MIN_LIMB_LENGTH 0.1f

// canvas view zoom (scroll wheel over empty space, i.e. not over a
// handle). Bounds are kept modest so the robot can't be scrolled away to
// an invisible speck or blown up past where the geometry is meaningful.
// STEP is multiplicative per wheel notch so repeated scrolling feels
// smooth rather than jumpy.
#define MIN_ZOOM 0.25f
#define MAX_ZOOM 8.0f
#define ZOOM_STEP 1.1f

// Design-space Y of the ground reference line (renderer.c's
// drawDashedHorizontalLine, called from renderApp/renderRobotScene) --
// pulled out to a shared constant rather than left as a literal -1.3f at
// each of its two call sites, so they can't drift apart from each other.
#define GROUND_LINE_DESIGN_Y -1.3f

// How many multiples of the CURRENT viewport's half-width the ground
// reference line extends to either side of center. Deliberately relative
// to the current view rather than either of the two things already tried:
//
//  - A width tied to the view's own halfX (ratio exactly 1, always exactly
//    matching the viewport) never shows an end at any zoom or pan, since
//    it's tautologically redefined to fill the screen every frame.
//
//  - A true fixed WORLD-space length (e.g. a flat 20.0f) shrinks/grows
//    with zoom like any ordinary object -- which sounds right, but means
//    its length RELATIVE to the viewport isn't fixed: halfWidth / halfX
//    works out to (fixed length * zoom / const), i.e. it scales linearly
//    with zoom. Zooming in shrinks the viewport far faster than the fixed
//    length does, so the line balloons to many, many screen-widths across
//    and panning far enough to reach its actual end becomes impractical --
//    exactly the "extends infinitely" symptom this constant replaces.
//
// Multiplying the CURRENT viewport halfX by this constant keeps the ratio
// between the line's length and the viewport fixed at every zoom level, so
// zooming in or out can never make it balloon or shrink -- it's always
// exactly GROUND_LINE_VIEWPORT_MULTIPLIER screen-widths across, and a user
// only ever needs to pan a small, zoom-independent distance to actually
// reach an end.
#define GROUND_LINE_VIEWPORT_MULTIPLIER 3.0f

// Robot "size" slider (top-right corner, Semni mode only -- see the
// trackbar created in input.c's WM_CREATE). A separate, permanent
// multiplier layered on top of the view zoom above (graphicsZoom/
// MIN_ZOOM/MAX_ZOOM), so setting a robot size doesn't get disturbed by
// mouse-wheel navigation zoom and vice versa. Range is 0.5-2.0 (was
// 0.25-1.0, shrink-only, capped at the design size) -- covers both
// shrinking (down to half) AND magnifying past the design size (up to
// double). graphics.c's g_robotScale DEFAULTS to 1.0 (this range's
// midpoint-ish, explicitly requested) -- briefly defaulted to this range's
// own minimum (0.5) earlier in this same project's history, reverted back
// to 1.0 per direct request ("i want the default scaling to be 1"), now
// paired with the MM_PER_WORLD_UNIT recalibration below so scale==1.0
// hits specific, exact per-robot mm targets.
//
// Implemented purely as a projection-level multiplier (graphics.c's
// g_robotScale, folded into effectiveZoom()) -- it never touches any
// robot struct's own raw fields (headRadius, kneeCircle, etc.), the same
// way ordinary camera zoom doesn't. But input.c's updateRobotSizeLabel and
// renderer.c's drawRobotSizeBox both deliberately treat it as if it DOES
// resize the robot for real, multiplying MM_PER_WORLD_UNIT's conversion by
// this slider's current value -- so the "Size: W x H mm" readout (and the
// matching in-scene bounding box label) tracks the slider instead of
// staying pinned to the fixed designed size. That's a presentation-layer
// choice, not a change to this constant's own meaning.
#define ROBOT_SCALE_MIN 0.5f
#define ROBOT_SCALE_MAX 2.0f

// The robot canvas's own base ortho half-extent (Y axis -- X derives from
// this via the current aspect ratio, same as every consumer below) at
// effectiveZoom() == 1 (g_zoom == 1, "Robot Size" slider == 1.0, i.e. the
// true, un-zoomed, un-resized design-size baseline) -- see graphics.c's
// applyProjection/screenToGL/graphicsZoom, renderer.c's own ortho setup,
// and canvas.c's robotPointToEnvWorld/robotLengthToEnvWorld, all of which
// derive their own halfY the same way: ROBOT_VIEW_HALF_EXTENT / zoom.
//
// This is the geometry MM_PER_WORLD_UNIT below is laid out against: at
// effectiveZoom()==1, half-extent 9.0 -> full height 18 world units, full
// width 32 units at 16:9 (32:18 reduces to 16:9) -- was left at 1.5
// (leftover from an earlier "zoom in further by default" tweak that never
// got reconciled with MM_PER_WORLD_UNIT) until this fix -- a ~6x mismatch
// that made the mm readout wildly understate how much of the actual screen
// the robot occupied at any given zoom/Robot-Size-slider setting (e.g. a
// robot labeled 118mm wide at Robot Size 2.0 was actually rendering at
// ~59% of the screen's width, not the ~10% "118 of 1200mm" would suggest).
//
// NOTE: MM_PER_WORLD_UNIT was later recalibrated (37.5 -> 75.0, see its own
// comment below) to hit specific per-robot mm targets directly, which as a
// side effect doubled what this same 32x18 grid now represents in real mm
// (2400 x 1350 instead of the 1200 x 675 originally derived here) -- left
// AS-IS on purpose (untouched) since the per-robot mm targets were the more
// concrete, explicit requirement; this constant still only controls how
// much of the SCREEN the robot occupies (a viewport/camera concern), which
// is independent of the mm LABEL'S conversion factor below.
#define ROBOT_VIEW_HALF_EXTENT 9.0f

// Starting value for graphics.c's own g_zoom (Design > Robot's camera
// zoom, see graphicsGetZoom's "zoom > 1 magnifies" convention) -- what the
// Robot editor opens at. Deliberately NOT what Ctrl+Numpad 0
// (graphicsResetView) returns to -- that resets to a flat 1.0 (100%), a
// neutral baseline distinct from this launch-time default. 5.0 == 500%.
#define ROBOT_INITIAL_ZOOM 5.0f

// Real-world size conversion factor (world units -> mm), used by input.c's
// live robot size readout (hRobotSizeLabel) and renderer.c's
// drawRobotSizeBox (both also scaled by the current ROBOT_SCALE_MIN/MAX
// slider value -- see its own comment above) -- NOT used by save.c's
// saveRockyAsRobArm Rob.txt/Arm.txt export any more (see ROCKY_EXPORT_SCALE
// below, a separate, unrelated conversion for that specific external
// consumer).
//
// Recalibrated from 37.5 to 75.0 (exactly double) so that at Robot Size
// slider == 1.0 (ROBOT_SCALE_MIN/MAX's default, see below), the "Size: W x
// H mm" readout hits exact, explicitly requested targets: 118 x 50 mm for
// Semni/Stilo, 88 x 23 mm for Rocky. Derived from each kind's real
// robotBoundingBoxLocal (input.c) design bounding box -- Semni/Stilo's
// full head+butt+seam-arc silhouette (1.569500 x 0.665749 world units,
// pose-independent since it only reads body/torso fields) and Rocky's
// ACTUAL runtime default rectangle, which is loaded from
// Poses/rocky_home.txt (BODY_HALF_WIDTH=0.156112, BODY_HALF_HEIGHT=
// 0.584827) rather than app_init.c's stale hardcoded 0.3/0.4 -- Rocky's
// display width/height are also swapped per updateRobotSizeLabel's own
// existing convention (raw 0.312224 x 1.169654 -> displayed 1.169654 x
// 0.312224). Verified in Python against the exact rounding formula
// updateRobotSizeLabel uses ((int)(units * MM_PER_WORLD_UNIT * robotScale
// + 0.5f)): 75.0 lands on EXACTLY 118x50 and 88x23, no rounding slop.
#define MM_PER_WORLD_UNIT 75.0f

// Real-world-size bounding box overlay (renderer.c's drawRobotSizeBox) --
// appears around the robot while the "Robot Size" slider (input.c's
// hScaleSlider) is being dragged, so the user can see its current real-
// world footprint (see MM_PER_WORLD_UNIT above, scaled by the slider) as
// it's being resized. Same stateless hold-then-fade shape as Simulation's
// gravity/gait toasts (SIMULATION_GRAVITY_TOAST_HOLD_MS/FADE_MS below) --
// HOLD keeps it fully visible for a moment after the last slider move,
// FADE eases it back out rather than popping off abruptly, so a quick
// nudge of the slider still reads clearly and a longer drag doesn't leave
// it stuck on screen once released.
#define ROBOT_SIZE_BOX_HOLD_MS 700
#define ROBOT_SIZE_BOX_FADE_MS 400

// Rob.txt/Arm.txt export scale (see save.c's saveRockyAsRobArm) -- converts
// our world units into whatever unit the specific external "his program"
// consumer expects, so a shape sized to look right in OUR editor doesn't
// come out "way smaller" once loaded there. This is NOT derived from any
// documented spec (unlike MM_PER_WORLD_UNIT above) -- it's purely
// empirical, calibrated from one side-by-side comparison: a rectangle
// eyeballed to visually match between the two editors measured 0.312224 x
// 1.169654 in our world units, and 0.825 x 3.25 in his program's own
// units, giving a ratio of 2.6423 (width) vs 2.7786 (height) -- about 5%
// apart, most likely just eyeballing imprecision rather than a real
// non-uniform scale, since both axes should logically share one scale.
// This constant is their average (2.7105); recalibrate if a more precise
// reference measurement becomes available.
//
// Applied to BOTH files' lengths (mass centers, joint, corners/arc
// points) -- NOT weight. Originally Rob.txt-only (named ROB_EXPORT_SCALE),
// but Rob.txt and Arm.txt share one joint/unit system by construction (the
// joint is the literal same physical point in both), so using a different
// scale for each would leave the leg wildly mismatched in size relative to
// the body once his program reassembles them -- renamed and extended to
// Arm.txt once that mismatch showed up.
#define ROCKY_EXPORT_SCALE 2.7105f

// Env.txt export scale (see canvas.c's saveEnvironmentSegmentsAsTxt) --
// same idea as ROCKY_EXPORT_SCALE above (converts our world units into
// "his program"'s own units for that same external consumer), but
// calibrated differently and independently: rather than eyeballing a
// shape, this compares two "full screen" reference exports directly --
// a straight line traced across our FULL canvas width came out
// 3.876643 world units wide (Env.txt: -1.941355 to 1.935288), while his
// program's own full-screen boundary (its two vertical screen-edge
// lines) is 31.9 units wide x 18 tall (a 16:9-ish frame, so both axes
// share one scale, same reasoning as ROCKY_EXPORT_SCALE). 31.9 /
// 3.876643 = 8.228769 -- recalibrate if a more precise reference
// measurement becomes available.
#define ENV_EXPORT_SCALE 8.228769f

// Both editor subsystems (ArcSpline canvas, Semni robot editor) now draw
// into the same shared window every frame instead of only one being drawn
// at a time -- switching Design Mode just decides which one is fully
// opaque and interactive vs. which one gets this dim overlay on top of it,
// so the inactive one stays visible as background context rather than
// vanishing outright. 0 = invisible overlay (no dimming), 1 = fully black.
#define INACTIVE_MODE_DIM_ALPHA 0.65f

// Simulation mode: pressing G nudges the whole robot straight down by this
// much (world units, same translateRobot used by the whole-robot drag --
// see canvas.c's WM_KEYDOWN). "Holding G repeats it" needs no extra
// bookkeeping here -- Windows' own key-repeat keeps re-sending WM_KEYDOWN
// for as long as the key is held, at whatever repeat rate the user's
// keyboard settings specify, so each repeat is just another ordinary
// single press of this same step. Kept in the same ballpark as input.c's
// arrow-key nudge step (0.05f) so it reads as a gentle, controllable pull
// rather than an instant drop.
#define SIMULATION_GRAVITY_STEP 0.02f

// Simulation mode's ground-collision check (canvas.c's
// robotCollidesWithEnvironment) tests the robot's 5 body circles PLUS its
// 6 connecting fillet arcs (seam/thigh/shin) against the drawn
// environment. The circles have a real radius to test against, but the
// arcs are drawn as bare curves with no inherent thickness of their own --
// this is the fallback "how wide is a limb" approximation used for those,
// in the robot's own world units (same space SIMULATION_GRAVITY_STEP is
// in). Deliberately on the slim side: too generous and the robot would
// visibly stop falling while still floating above the drawn line.
#define SIMULATION_ARC_COLLISION_THICKNESS 0.00375f

// The environment "line" is rendered in Simulation mode at a small FIXED
// half-width (canvas.c's simEnvLineHalfWidthWorld) instead of each
// stroke's own real measured thickness, and collision pads against that
// exact same half-width -- so render and collision always agree on where
// the line's surface is, and contact looks flush rather than sinking in
// or floating above it (see simEnvLineHalfWidthWorld's own comment).
// SIMULATION_ARC_COLLISION_THICKNESS above (converted into env-world
// units) is the base value, but on its own that comes out to a sliver
// often under a pixel wide on screen -- thin enough to visibly flicker in
// and out as the exact sub-pixel rounding shifts with zoom. This is the
// floor, in on-screen pixels at the CURRENT zoom, that the line is never
// allowed to render thinner than, so it stays visibly present at any zoom
// level; collision still matches it exactly either way, floor included.
#define SIM_ENV_LINE_MIN_PIXELS 2.0f


// Display-only padding for the two Simulation-mode contact indicators
// (canvas.c's drawSimulationContactDebug 'C'-toggle overlay and the
// always-on drawSimulationLiveContactDots) -- NOT used by anything that
// actually moves the robot. A resting contact point is, by design, never
// reported as colliding by the real check (pointCollidesWithAnyEnvironmentStroke):
// applyGravityStep's own binary search deliberately converges to the
// largest offset it can confirm does NOT collide (so a resting robot
// never visibly embeds), which leaves an intentional, tiny non-colliding
// gap at rest -- typically many times smaller than this value (see
// GRAVITY_CONTACT_SEARCH_ITERATIONS's own comment on how far that search
// converges). Querying the real function directly from the two display
// functions meant every normal resting contact point read as a miss (a
// real report of "the red contact dot never shows even though it's
// clearly resting on the ground") -- this is the extra slop added ONLY
// for those two functions' own hit test, in the robot's own world units
// (same space SIMULATION_GRAVITY_STEP is in), comfortably larger than the
// real resting gap but still small relative to any body part's own size,
// so it reads as "still basically flush" rather than "floating."
#define SIMULATION_CONTACT_VISUAL_TOLERANCE 0.001f

// canvas.c's seatRockyDanglingPoint: once Rocky's settle has converged,
// the second contact point (e.g. the foot while the knee is the pivot)
// can still hover a sub-pixel gap above the ground -- enough to miss
// SIMULATION_CONTACT_VISUAL_TOLERANCE above. That final pass
// binary-searches the rotation around the pivot to close the gap.
// SIMULATION_ROCKY_SEAT_MAX_GAP: largest gap (robot world units) it will
//   try to close -- anything bigger is treated as genuinely dangling.
// SIMULATION_ROCKY_SEAT_MAX_PIVOT_LIFT: how far a candidate rotation may
//   lift the robot to undo float rounding at the pivot before it counts
//   as blocked (kept tiny, well under the visual tolerance, so the pivot
//   itself stays flush).
// SIMULATION_ROCKY_SEAT_SEARCH_ITERATIONS: bisection depth; 10 halvings
//   of a bracket ~2x the gap leave well under a pixel at any reachable zoom.
#define SIMULATION_ROCKY_SEAT_MAX_GAP 0.02f
#define SIMULATION_ROCKY_SEAT_MAX_PIVOT_LIFT 0.0001f
#define SIMULATION_ROCKY_SEAT_SEARCH_ITERATIONS 10 // was 16; the bracket is only ~2x the gap, so 10 halvings leave <0.2% of it

// applyGravityStep (canvas.c) used to just undo a WHOLE gravity step the
// instant it detected a collision -- simple, but it means the robot always
// stops up to one full step's worth of world units short of actually
// touching the ground, not right at contact. That gap is a fixed number of
// WORLD units, so it stayed sub-pixel and invisible at normal zoom, but
// zooming in close enough makes those same world units cover many more
// screen pixels, turning it into a visible floating gap -- worse still
// once auto gravity's step size grew for the acceleration fix
// (SIMULATION_AUTO_GRAVITY_MAX_VELOCITY_PER_MS). Fix: once a step
// collides, binary-search within it for how far it can actually go before
// touching, this many iterations deep -- each iteration halves the
// remaining uncertainty, so this many fully collapses even the largest
// plausible step this app can produce to a gap far smaller than a screen
// pixel at any zoom level actually reachable.
#define GRAVITY_CONTACT_SEARCH_ITERATIONS 12

// Shift+G toggles "auto gravity" in Simulation mode on/off -- while on, a
// dedicated timer (see canvas.c's AUTO_GRAVITY_TIMER_ID) nudges things
// along on its own, until it's toggled off again (or canvas.c's mode-switch
// handling turns it off for you, leaving Simulation). This is just the
// FALLBACK cadence for when nothing else is happening -- WM_TIMER messages
// are low-priority in Windows (only synthesized once the queue is
// otherwise empty), so a steady stream of WM_MOUSEMOVE while the user is
// moving the cursor can starve it and stall the fall entirely. canvas.c's
// advanceAutoGravity is real-time based (GetTickCount deltas, not "one
// step per tick"), and is ALSO called directly from WM_MOUSEMOVE, so mouse
// movement drives the fall forward itself instead of blocking it -- this
// interval only matters for keeping things moving while the mouse is
// perfectly still. Matches the hot-zone UI's own 16ms tick
// (UI_HOTZONE_INTERVAL_MS, canvas.c).
#define SIMULATION_AUTO_GRAVITY_INTERVAL_MS 16

// [PERF] diagnostic threshold -- real milliseconds. Any single chunk of
// work canvas.c times against this (the Rocky settle fast-forward loop in
// applyGravityStep, and renderCombinedFrame's own render breakdown) prints
// a [PERF] line, with a rough breakdown, whenever it takes AT LEAST this
// long. 30ms corresponds to ~33fps -- comfortably above the "sometimes
// drops to 20fps" a real report described, so it should start catching
// samples as a slowdown is only just beginning, not only once it's already
// fully dropped to 20. Purely a diagnostic aid (temporary, by explicit
// request) -- doesn't change any actual behavior, only whether/when these
// specific printf calls fire.
#define SIMULATION_PERF_WARN_FRAME_MS 30

// Auto gravity uses REAL gravity: canvas.c's advanceAutoGravity converts
// this m/s^2 value into robot world units through MM_PER_WORLD_UNIT and the
// Robot Size slider (the same scale as the "Size: W x H mm" readout), so a
// fall takes as long as it would in real life for the robot's displayed
// size. Replaces the old hand-tuned 0.001 units/ms^2 (~75 m/s^2, ~7.6 g at
// Robot Size 1.0) and the weight multiplier -- mass doesn't change fall
// speed without air resistance.
#define SIMULATION_GRAVITY_MPS2 9.81f

// Safety cap on fall speed, in m/s. Not air resistance -- just a ceiling so
// a very long fall (or a huge time gap) can't turn into an enormous single
// tick. Well above anything reachable on screen: falling the full visible
// height (~1.35 m at Robot Size 1.0) only reaches ~5 m/s. (The old cap was
// 1.5 m/s, which the robot hit within ~20 ms, making every fall a constant
// glide.)
#define SIMULATION_AUTO_GRAVITY_MAX_VELOCITY_MPS 10.0f

// advanceAutoGravity (canvas.c) can be called from arbitrarily far-apart
// real-time gaps -- e.g. the window was blocked on something else for a
// while, or WM_TIMER got badly starved for longer than usual -- so the
// elapsed time it scales by is capped at this many milliseconds per call,
// otherwise a long-enough gap would make the robot teleport a large
// distance downward in one jump instead of visibly falling through it.
#define SIMULATION_AUTO_GRAVITY_MAX_DT_MS 100

// Bottom-left "AUTO GRAVITY ON"/"AUTO GRAVITY OFF" HUD toast (canvas.c's
// canvasRenderFrame), shown for a brief hold at full opacity then faded
// out, every time Shift+G toggles auto gravity. Both durations are in
// milliseconds, measured from GetTickCount() at the moment of the toggle.
#define SIMULATION_GRAVITY_TOAST_HOLD_MS 900
#define SIMULATION_GRAVITY_TOAST_FADE_MS 500

// Slope response: once applyGravityStep (canvas.c) lands the robot on
// something, it also nudges the whole-body angle (Semni.angle, the same
// field rotatePoint applies around getCenter() for every body part) toward
// the tilt of whichever environment edge it's actually resting on, instead
// of always staying bolt upright the way flat-ground-only physics would.
// It's a RIGID whole-body lean (same simplification the rest of Simulation's
// physics already makes -- one rigid translate/rotate, no per-joint IK), so
// on a sloped arc segment the robot settles lying flush against it rather
// than standing perfectly vertical on an incline.
//
// Closed as a FRACTION of the remaining angle gap per landed tick (rather
// than jumping straight to the target), so it reads as settling into the
// slope over a few ticks instead of snapping instantly -- most visible right
// after first touchdown, converges to ~0 remaining diff within well under a
// second at SIMULATION_AUTO_GRAVITY_INTERVAL_MS's cadence.
#define SIMULATION_SLOPE_ALIGN_RATE 0.18f

// Upper bound on how many degrees SIMULATION_SLOPE_ALIGN_RATE is allowed to
// rotate the robot in a single landed tick, independent of how large the
// remaining angle gap is -- keeps a big gap (e.g. the robot landing at a
// very different angle than the slope, like right after a fall) from
// visibly snapping/spinning in one frame instead of settling smoothly.
#define SIMULATION_SLOPE_ALIGN_MAX_STEP_DEG 4.0f

// After nudging the angle above, the robot's limbs can end up very slightly
// inside the ground (rotating a rigid body around its torso-level center
// can push a foot/knee down a hair, even though the body as a whole was
// already resting on the surface) -- resolveUpwardIfPenetrating (canvas.c)
// searches for the smallest upward correction, up to this many world units,
// that clears it again. Kept small on purpose: the rotation step per tick
// is already small (see MAX_STEP_DEG above), so any resulting penetration
// is always tiny -- this only ever needs to cover that, not a whole
// gravity-step's worth of overlap.
#define SIMULATION_SLOPE_CORRECTION_MAX 0.05f

// "Slow Motion" toggle button (Simulation mode only -- see canvas.c's
// hSlowMotionBtn/ID_SLOW_MOTION). While checked, simTimeScale is set to
// this instead of 1.0, and both advanceAutoGravity's elapsed-time
// integration AND applyGravityStep's slope-alignment step (see
// SIMULATION_SLOPE_ALIGN_RATE above) are scaled by it -- so both the fall
// itself and the tipping-into-a-slope settle noticeably slower, without
// changing anything about the underlying physics (same acceleration curve,
// same terminal velocity, same alignment behavior, just stretched out over
// more real time so it's easier to watch closely).
#define SIMULATION_SLOW_MOTION_SCALE 0.2f

// Simulation mode: hovering the hip or knee's own visible body circle and
// Shift+scrolling the wheel rotates that joint's angle (hipAngle/kneeAngle)
// directly -- see canvas.c's simHoveredJoint/findHoveredJointSim and its
// WM_MOUSEWHEEL handling. Shift-gated for the same reason Design > Robot
// mode's own hip/knee scroll-rotate is (input.c): a plain scroll while the
// cursor happens to be over a joint should still zoom, not surprise-rotate
// a limb. Degrees per wheel notch, same value Design mode's own
// Shift+scroll joint rotate uses, so the feel is consistent between the
// two places it's available.
#define SIMULATION_JOINT_ROTATE_STEP_DEG 2.0f

// E/Q resolves the whole SIMULATION_JOINT_ROTATE_STEP_DEG press as
// several of these smaller sub-rotations instead of one single jump --
// same "smooth instead of one big jump" fix as
// SIMULATION_WHOLE_BODY_ROTATE_SUBSTEP_DEG's own, but for a different
// symptom: the knee circle itself is far too small to ever tunnel
// through anything at a 2-degree step, but the LEGPUSH lift that step
// can trigger (see SIMULATION_LEG_PUSH_SEARCH_MAX below) is NOT small,
// and doing that entire lift in one binary-searched jump made the whole
// rectangle visibly snap upward in a single frame instead of rising
// smoothly. Resolving one sliver of the knee rotation at a time means
// whatever lift is needed accumulates gradually across several small
// pushes within one press instead of arriving all at once. Same value as
// the whole-body one so a held key reads at a similar smoothness either
// way; SIMULATION_JOINT_ROTATE_STEP_DEG divides evenly by this (2.0 / 0.2
// = 10 substeps per press).
#define SIMULATION_JOINT_ROTATE_SUBSTEP_DEG 0.2f

// Continuous, real-time-driven rotation rate for Rocky's knee (E/Q) while
// either key is genuinely HELD down -- see ROCKY_KNEE_HOLD_TIMER_ID's own
// comment (canvas.c) for the report this fixes. Holding E/Q used to just
// rely on Windows' own WM_KEYDOWN auto-repeat to keep re-firing the same
// fixed SIMULATION_JOINT_ROTATE_STEP_DEG jump over and over -- auto-repeat
// has its own OS-level initial delay before it even starts, then repeats
// at a fixed, often fairly coarse rate (a Control-Panel keyboard setting,
// nothing to do with the screen's own refresh rate), both of which read as
// a stutter at the start of a hold followed by a chunky, uneven-feeling
// rotation for the rest of it -- compared to the smooth, accelerating fall
// Shift+G's auto-gravity already gets from being driven by real elapsed
// time instead (see advanceAutoGravity's own comment, canvas.c) rather
// than by however often the OS happens to re-deliver a message. This value
// is picked to rotate at roughly the same OVERALL speed the old auto-
// repeat-driven stepping already felt like at a typical default OS repeat
// rate, so holding E/Q doesn't suddenly feel much faster or slower than
// before -- it should just feel smooth now instead of chunky.
#define SIMULATION_JOINT_ROTATE_RATE_DEG_PER_MS 0.05f

// Same reasoning as SIMULATION_AUTO_GRAVITY_MAX_DT_MS above, for the exact
// same kind of real-time-scaled stepping, just for the knee-hold driver
// instead of the gravity-fall one -- caps how much elapsed real time a
// single ROCKY_KNEE_HOLD_TIMER_ID tick is allowed to account for, so a
// stall (a slow frame, a modal dialog, anything that delays this timer's
// own callback from firing on schedule) can't be read back as one single
// huge knee jump the next time it finally runs.
#define SIMULATION_JOINT_ROTATE_HOLD_MAX_DT_MS 100

// E/Q's "glide over an obstruction" behavior (sweeping past a contact and
// jumping to clear ground on the far side) was removed by explicit
// request -- the foot was technically still passing through solid ground
// to get there, which is wrong regardless of how it reads.
//
// What replaced it (see canvas.c's WM_KEYDOWN, ROBOT_KIND_ROCKY branch)
// is a real lever, not a freeze: rotating the knee always applies in
// full, and if that would bury the leg (the foot circle OR either shin
// fillet arc -- see the Rocky struct's own comment on shinArc1Angle/
// shinArc2Angle in app.h) in the environment, the whole robot is pushed
// straight up instead, exactly like a real leg pressing its foot/shin
// against the ground would lever the torso upward rather than the leg
// simply stopping dead. Only when even a generous push (see
// SIMULATION_LEG_PUSH_SEARCH_MAX below) still can't clear it -- the leg
// boxed in on every side, an extreme edge case -- does it fall back to
// the old hard-stop-at-first-contact behavior, using the same
// GRAVITY_CONTACT_SEARCH_ITERATIONS binary search applyGravityStep uses
// for the whole-body landing.

// Starting distance and sanity cap for the "push the body up" search
// above. Doubles from START each attempt until the leg clears or MAX is
// reached, then binary-searches within whatever range that found --
// unlike SIMULATION_SLOPE_CORRECTION_MAX above (a small fixed budget for
// tiny post-ROTATION residuals from re-aligning to a slope), a
// deliberate leg extension can legitimately need to lift the body by far
// more than that, and there's no way to know the right amount in
// advance. Both are in the robot's own local world units, same space
// SIMULATION_GRAVITY_STEP is in -- START is one gravity step, MAX is
// several times Rocky's default knee-to-foot leg length (~0.3, see
// app_init.c's initRockyStandingPosition) so a genuinely large push
// still succeeds instead of being mistaken for "impossible."
#define SIMULATION_LEG_PUSH_SEARCH_START 0.02f
#define SIMULATION_LEG_PUSH_SEARCH_MAX 1.0f

// Rocky-only, and only relevant once the knee can be detached from the
// rectangle (see app.h's own comment on draggingRockyKnee): the
// whole-body gravity drop above stops the instant its LOWEST part (often
// the foot, if the knee was dragged far from the body) touches something
// -- the rectangle just ends up wherever that leaves it, which can look
// like it's floating well above the ground with a big gap underneath.
//
// See canvas.c's advanceRockySettle: called every gravity tick
// (applyGravityStep, alongside the whole-body translate above) while any
// part of Rocky is touching something, it tries two independent things,
// each by one small step in each direction, and keeps whichever helps:
// bending the KNEE (SIMULATION_LEG_SETTLE_STEP_DEG) and rotating the
// RECTANGLE itself (SIMULATION_BODY_SETTLE_STEP_DEG, Rocky's own
// `angle` field) -- so the torso can tip toward a more natural resting
// orientation, not just sink straight down at whatever angle it started
// at. Either one closes the "floating body" gap gradually over several
// ticks instead of all at once. By explicit request this runs EVERY
// tick, continuously, rather than once after landing -- earlier, a
// similar continuous idea (slope alignment, see applyGravityStep's own
// comment) caused a visible bounce/wobble, but that one accumulated a
// velocity/damping state across ticks that could overshoot. This has no
// such state: every tick is an independent deterministic search
// (dropActiveRobotToRest, the same binary-search idiom the rest of
// gravity already uses) that only ever COMMITS a change when it
// confirms the body genuinely falls further and stays collision-free --
// there's nothing to oscillate, so it can settle smoothly without the
// stuck-state risk the old knee pendulum had.
//
// Both kept deliberately small (smaller than one E/Q press or one
// Left/Right whole-body rotate press, SIMULATION_JOINT_ROTATE_STEP_DEG/
// SIMULATION_WHOLE_BODY_ROTATE_STEP_DEG) so the settle reads as a smooth
// gradual sink across many ticks rather than a single visible snap.
#define SIMULATION_LEG_SETTLE_STEP_DEG 1.0f
#define SIMULATION_BODY_SETTLE_STEP_DEG 1.0f

// Body-rotate probe's STARTING step size specifically after an E/Q knee
// press (canvas.c's WM_KEYDOWN kickoff), instead of the full
// SIMULATION_BODY_SETTLE_STEP_DEG above -- a real report showed that
// full-size step committing after nearly every single E/Q press, even
// when the pose was barely (if at all) genuinely unstable: the "did this
// help" test only checks bestDrop > SIMULATION_LEG_SETTLE_MIN_DROP
// (0.001f, deliberately tiny -- see its own comment), and ordinary
// binary-search noise from any knee-angle change routinely clears that
// bar, so the probe would confidently commit a full one-degree snap of
// the WHOLE rectangle for a gain as small as a thousandth of a unit --
// read as the body visibly "jumping" right after an otherwise smooth
// knee rotation. Starting this probe an order of magnitude finer after
// E/Q specifically (VK_LEFT/RIGHT's own kickoff still uses the full-size
// step, unchanged) means the very same tiny noise-level "improvement"
// only ever commits a proportionally tiny, effectively invisible nudge;
// a genuinely unstable pose still topples just as surely, it just
// accumulates over more, smaller ticks instead of one visible pop.
#define SIMULATION_BODY_SETTLE_STEP_AFTER_KNEE_DEG 0.1f

// The smallest drop advanceRockySettle will actually treat as "this step
// helped." dropActiveRobotToRest's own binary search (GRAVITY_CONTACT_
// SEARCH_ITERATIONS above) only converges to within roughly 1/2^12 of
// whatever range it grew to -- close to the true contact point, but not
// exact -- so right at the real resting pose, re-probing a tiny knee/body
// rotation can keep reporting a wafer-thin "drop" that's really just that
// search's own precision noise, not a genuine further settle. Without a
// floor, advanceRockySettle would happily commit that noise every single
// tick forever (never reaching a tick with truly nothing left to
// improve), which is exactly what reads as visible vibration instead of
// a clean stop. Comparing against this instead of a bare > 0.0f is what
// lets it actually finish and go quiet once it's really done.
#define SIMULATION_LEG_SETTLE_MIN_DROP 0.001f

// Same idea as SIMULATION_LEG_SETTLE_MIN_DROP just above, but for the
// "dangling point got closer without the body falling" gain checks
// (Probe 2's bestClearanceGain/scoutGain on the foot, Probe 1's
// bestClearanceGain/scoutGain on whichever of knee/foot isn't the
// pivot) instead of the whole-body vertical drop. A real report showed
// a leg settling to within ~0.001 of flush and then permanently
// stopping there, visibly still gapped: nearestEnvDistance here is a
// direct analytic distance, not dropActiveRobotToRest's binary search,
// so it doesn't carry that search's precision noise and never needed a
// floor anywhere near as coarse as SIMULATION_LEG_SETTLE_MIN_DROP to
// stay stable -- but sharing that same 0.001f threshold meant that once
// the remaining gap itself shrank to roughly that size, even a
// geometrically perfect step could no longer clear the bar (gain caps
// out at whatever the remaining gap is), so every further attempt read
// as "no improvement," shrinking the step instead of committing the
// last, genuinely real fraction of a millimeter -- repeatedly, all the
// way down to SIMULATION_LEG_SETTLE_MIN_STEP_DEG, at which point that
// probe gives up for good with the gap still open. This threshold is
// deliberately far smaller -- comfortably above float rounding error,
// but small enough to still recognize the last sliver of a closing gap
// as real progress instead of noise -- so the probes keep committing
// tiny genuine gains all the way to flush instead of stalling just
// short of it.
#define SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN 0.00002f

// Same idea again, but for Probe 1's newest fallback: does a candidate
// rotation lower the whole body's actual CENTER OF MASS (computeRockyMassCenterWorld),
// not just bring some other single point closer to the ground. Needed
// because bestDrop and bestClearanceGain can BOTH go structurally silent
// at once: once the pivot is a single already-touching point (nothing
// else anywhere near the ground -- typically the leg resting on just its
// convex shin arc or a lone circle, nothing else dangling close enough
// to register a gain), rotating around that point never changes ITS OWN
// clearance (that's the definition of pivoting around it) and nothing
// else is close enough for bestClearanceGain to see either, so both
// branches report zero for every candidate angle and the search grinds
// its step down to nothing and gives up -- even though the pose is
// nowhere near the real physical rest angle. A real report showed
// exactly this: a leg-only Rocky "converging" with its center-of-mass
// marker sitting well off to the side of its single ground contact,
// instead of balanced directly above it the way a real object resting on
// one round point actually settles. Center-of-mass height is the
// quantity gravity is actually minimizing, so it keeps working as a
// signal exactly when the other two go quiet -- same fine 0.00002f
// floor as SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN above and the same
// reasoning: computeRockyMassCenterWorld is closed-form geometry, not a
// noisy binary search, so it doesn't need SIMULATION_LEG_SETTLE_MIN_DROP's
// coarser floor either.
#define SIMULATION_LEG_SETTLE_MIN_COM_DROP 0.00002f

// How much closer to the ground a NEW category of toppling-pivot
// candidate (the leg's own knee/foot/arc versus Rocky's own rectangle
// corners, see rockyToppleContactPoints in canvas.c) has to be than
// whichever category was actually used as the pivot LAST tick, before
// Probe 1 is allowed to switch categories at all. Without this, a pose
// where a leg point and a body corner both sit at nearly the same tiny
// clearance (a real report showed BOTH flipping every single tick, not
// occasionally) makes rockyToppleContactPoints' plain "whichever
// candidate has the smaller clearance" comparison flip the PIVOT ITSELF
// back and forth between two entirely different points of the assembly
// on nothing more than float-level noise each tick -- not the gradual,
// same-kind crossing rockyPivotSide's own halving already handles (a
// leg point sliding to the other side of the center of mass as the leg
// itself rotates), but the pivot's very IDENTITY changing to a
// completely different part of the robot. Since rotating around a
// different point generally needs the OPPOSITE rotation sign to achieve
// the same physical effect, each such flip also tripped
// rockyBodyLastCommitDir's own cross-tick reversal guard, so the two
// existing anti-oscillation mechanisms ended up fighting each other:
// pivot flip, then several ticks of "shrinking instead of reversing,"
// then a small commit, then another flip -- real net progress, but at a
// small fraction of one real commit's worth of angle per tick, several
// times slower than it should be, which is why bodyAngle above showed
// it crawling for dozens of ticks without ever finishing the topple.
// This margin doesn't touch same-category comparisons (leg-vs-leg,
// corner-vs-corner still pick the plain closest, same as before) -- only
// gates a leg-to-body (or body-to-leg) HANDOFF, and only lets that
// handoff happen once the new category is genuinely, meaningfully
// closer, not just closer by a rounding hair.
#define SIMULATION_ROCKY_TOPPLE_PIVOT_HYSTERESIS 0.001f

// How many consecutive ticks rockyBodyLastCommitDir's own reversal guard
// (canvas.c) is allowed to block Probe 1 from reversing direction before
// that streak is instead treated as a legitimate need to correct an
// overshoot, and the reversal is let through for one tick. The guard
// itself exists for a real, narrower report: bestDrop and bestComDrop
// disagreeing on direction from one tick to the NEXT, bouncing bodyAngle
// between the same two fixed values forever, with the step never actually
// shrinking. But once that guard is in place, it has no way to tell that
// pathology apart from a completely different, equally real situation:
// Probe 1 pivoting several genuine degrees of forward progress, then
// legitimately needing to reverse ONE time to correct an overshoot and
// settle at the true resting angle just past where the forward run
// stopped. A real report showed exactly that turning into a brand new
// deadlock -- bodyAngle stuck dead at a single value indefinitely, every
// attempt to reverse blocked and the step shrunk down to nothing, with an
// unrelated E/Q knee tap the only thing reviving the step size (see that
// reset site's own comment) but never the guard itself, so the same
// block-then-revive cycle repeated forever with no net progress. A
// genuine same-tick flip-flop never produces a long RUN of consecutive
// blocks like this -- each one only takes a single tick to resolve into
// an ever-shrinking step, not a persistent, repeated demand to go the
// other way -- so a run this long is itself the signal that this isn't
// that pathology. Deliberately close to SIMULATION_LEG_SETTLE_STALEMATE_
// STREAK below's own "long enough to rule out a normal transient"
// reasoning.
#define SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK 6

// canvas.c's Probe 1 (Rocky body pivot): the pivot-side-flip halving and
// the reversal guard above only engage while the center of mass is within
// this horizontal distance (robot world units) of the current pivot --
// i.e. near balance, where rocking back and forth is the real risk. With
// the center of mass farther out than this over a single contact, the
// toppling direction is unambiguous and must not be blocked. Real report:
// Rocky "converged" standing on just its foot with the center of mass
// ~0.9 units off to the side, because the guard kept blocking the topple.
// For scale: Rocky's knee radius is 0.21.
#define SIMULATION_ROCKY_REVERSAL_GUARD_MAX_COM_OFFSET 0.05f

// Companion to the above: the guard also stays armed (whatever the offset)
// when the second-closest contact is within this distance (robot world
// units) of the ground AND the center of mass lies horizontally between
// the two contacts -- a body resting on two supports can't rotate at all,
// so any back-and-forth there is pure vibration. ~1 px at default zoom.
#define SIMULATION_ROCKY_SUPPORT_CONTACT_TOL 0.005f

// While E/Q is HELD (Windows auto-repeat, not a single tap), how often --
// in real milliseconds -- WM_KEYDOWN is allowed to re-prime the settle
// probes back to full step size (reviveRockyBodyProbeStepSizes, canvas.c),
// the same revive a keyup already does once on release. A real report
// showed a long hold visibly lagging behind an equivalent run of taps:
// each tap's own keyup re-primes the probes at full strength after every
// single nudge, but a hold only ever got that once, whenever it finally
// released, so the whole hold's worth of kneeAngle movement was chased by
// whatever step size had already shrunk down from before the hold began.
// Throttled rather than done on every single repeat (which can fire every
// 30-50ms or faster depending on the OS's own key-repeat rate setting) --
// reviving THAT often would mean rockyBodySettleStep never gets a chance
// to actually refine down and find the true resting angle at all while
// held, since it would be forced back up to full size dozens of times a
// second. This value is a deliberate middle ground: frequent enough that
// a hold still feels like it's making the same kind of steady progress a
// run of taps would, infrequent enough (well over
// SIMULATION_AUTO_GRAVITY_INTERVAL_MS's own much smaller tick cadence) to
// still let several real settle ticks run at a refining step size between
// each revive, rather than fighting its own refinement.
#define SIMULATION_ROCKY_EQ_HOLD_REVIVE_INTERVAL_MS 200

// How many consecutive ticks Probe 2 (knee) and Probe 1 (body) are allowed
// to BOTH commit a real move on the very same tick before that streak is
// treated as a stalemate and both step sizes are force-halved. The two
// probes run back to back inside the same advanceRockySettle call, each
// one committing based on whatever the OTHER just left behind one tick
// (or, this same tick, for Probe 1 watching Probe 2) earlier -- and
// neither probe's own same-tick straddle check can see that, since each
// only compares its own two candidate directions against each other, not
// against what the other probe is doing. Two separate real reports showed
// this going wrong with two DIFFERENT pairs of criteria (bestComDrop vs
// bestClearanceGain with the knee as the primary contact; bestDrop vs
// bestClearanceGain with a different part as the primary contact and the
// knee left as a perpetually-almost-touching dangling point) -- so this
// watches for the general SHAPE of the problem (both probes committing
// every tick, forever) rather than guarding each specific pairing by
// hand. A handful of ticks with both probes firing is completely normal
// (e.g. right after a fresh landing, before either probe's step has had a
// chance to shrink), so this only fires once the streak is long enough to
// rule that out.
#define SIMULATION_LEG_SETTLE_STALEMATE_STREAK 6

// How many consecutive ticks a probe is allowed to commit a real,
// above-noise move via one of its DIRECT branches (not the scout fallback
// -- see rockyKneeSettleGrowthStreak's own comment in canvas.c for why
// that distinction matters) while the OTHER probe stays completely silent,
// before that probe's step size is grown back up (doubled, capped at its
// own starting SIMULATION_LEG_SETTLE_STEP_DEG/SIMULATION_BODY_SETTLE_STEP_DEG)
// instead of staying wherever it last happened to shrink to. Without this,
// a step that was forced down by the stalemate detector above (or by an
// ordinary same-tick straddle) stays that small for the REST of that
// landing's settle, even long after whatever coupling or straddle caused
// the shrink is over and only one probe is left cleanly, monotonically
// converging with nothing to fight -- a real report showed exactly this:
// hundreds of ticks of bestComDrop alone committing a fixed ~0.03-degree
// step, sweeping tens of degrees at a crawl that had nothing left to do
// with the earlier stalemate it was defusing. Deliberately set higher than
// SIMULATION_LEG_SETTLE_STALEMATE_STREAK above -- growing the step back up
// carries more risk of reintroducing an oscillation than shrinking it does
// (shrinking can only ever make the search more careful; growing can make
// it overshoot again), so this waits for a longer run of clean, one-probe-
// only progress before trusting it enough to speed back up. If growing
// turns out to be premature, the very next tick's ordinary same-tick
// straddle check or the stalemate detector above will simply shrink it
// straight back down -- there is no separate "undo" needed.
#define SIMULATION_LEG_SETTLE_GROWTH_STREAK 10

// Threshold (degrees) below which advanceRockySettle's PER-CALL rotation is
// considered small enough to batch several calls into one timer tick -- see
// applyGravityStep's own fast-forward loop for the mechanics. Chosen well
// below any step size that's still visually meaningful on its own: the
// starting SIMULATION_LEG_SETTLE_STEP_DEG/SIMULATION_BODY_SETTLE_STEP_DEG
// are 1.0f, and even the FIRST couple of halvings after a fresh landing
// (0.5, 0.25) still read as real, deliberate motion -- but a real report's
// slow tail was crawling at a stable ~0.03 degrees per tick, comfortably
// under this floor, indistinguishable from doing several of those same
// tiny steps within one rendered frame instead of one every 16ms. Kept
// well clear of the 0.125/0.0625 range too, so a step still mid-shrink
// (still resolving a genuine straddle) isn't prematurely batched before
// it's actually reached its stable size.
#define SIMULATION_LEG_SETTLE_FAST_FORWARD_MAX_STEP_DEG 0.1f

// How many advanceRockySettle calls the fast-forward loop above is allowed
// to make within a single timer tick once it's in the small-step regime
// (SIMULATION_LEG_SETTLE_FAST_FORWARD_MAX_STEP_DEG). Each call is fully
// unmodified -- same criteria, same floors, same straddle/stalemate guards
// -- this only controls how many of those already-decided, already-safe
// steps get to play out before the next frame, cutting a multi-second,
// hundreds-of-ticks crawl down to a fraction of a second without changing
// a single decision along the way. 16 is a deliberately modest starting
// budget (an ~16x speedup on the tiny-step tail specifically, nothing
// else) rather than something large enough to risk collapsing a long
// settle into one indistinguishable jump; the loop still exits the moment
// any call in the batch produces a real (non-tiny) rotation or reaches
// rockySettleConverged, so this is a ceiling, not a fixed cost paid every
// tick.
#define SIMULATION_LEG_SETTLE_FAST_FORWARD_TICKS 16

// Real-time (GetTickCount) budget, in milliseconds, for the fast-forward
// loop above -- a companion cap alongside SIMULATION_LEG_SETTLE_FAST_
// FORWARD_TICKS itself, added after the [PERF] instrumentation confirmed
// this loop as the actual cause of the FPS-drops-to-~20 report (not
// rendering -- see renderCombinedFrame's own [PERF] breakdown, which stayed
// near 0ms on the same dips). The TICKS ceiling alone assumes every
// advanceRockySettle call is cheap, but each one does a real collision/
// distance search against the whole environment, and that cost isn't
// constant -- with enough active contact points a full batch of 16 was
// measured taking 100-140ms in a single WM_TIMER tick, all of it BEFORE
// that tick's own repaint could even be scheduled. This budget bounds that
// worst case directly: the loop still always makes its first call
// regardless of budget (same reasoning as the TICKS comment above -- a
// full-size step's very first call already exits the loop on its own, so
// forward progress on every tick is never blocked by this), but from the
// second call onward it stops batching further once this many real
// milliseconds have already been spent this tick, leaving any remaining
// ticks for the batch to pick back up on the NEXT WM_TIMER tick instead of
// stalling the current one. Set comfortably below SIMULATION_PERF_WARN_
// FRAME_MS so a full-budget batch plus the render side still has headroom
// before crossing that threshold itself.
#define SIMULATION_LEG_SETTLE_FAST_FORWARD_BUDGET_MS 8

// Floor for advanceRockySettle's own per-probe step size (separate from
// SIMULATION_LEG_SETTLE_STEP_DEG/SIMULATION_BODY_SETTLE_STEP_DEG above,
// which are just the STARTING size). A fixed 1-degree-ish step that
// never shrinks can decide "converged" too early -- there are poses
// where the real remaining improvement at THAT step size rounds down
// under SIMULATION_LEG_SETTLE_MIN_DROP even though a genuinely lower
// resting position exists a finer fraction of a degree away (the same
// "coarse step overshoots a narrow useful window" problem the original
// one-shot version of this search used to guard against by halving its
// step on every failed attempt). So now each probe does the same: halve
// its OWN step whenever a try finds nothing worth committing, instead of
// immediately giving up, and only that probe's search is considered
// exhausted once its step has shrunk below this floor. Both probes have
// to be exhausted before advanceRockySettle calls the whole thing
// converged and stops for good -- see rockySettleConverged.
#define SIMULATION_LEG_SETTLE_MIN_STEP_DEG 0.01f

// Hard cap, in world units, on how far advanceRockySettle is allowed to
// actually TRANSLATE the body in a single tick when a probe finds a real
// drop to commit. Without this, a real report showed the body appearing
// to sit still (small angle steps swinging the dangling foot, or tiny
// sub-threshold drops) and then suddenly SNAP down by a large amount the
// instant dropActiveRobotToRest's search finally found a big opening --
// its search isn't bounded by the small per-tick angle step above, only
// by SIMULATION_LEG_PUSH_SEARCH_MAX, so a single 1-degree knee/body
// change can reveal a resting depth far bigger than the angle change
// itself would suggest (a long shin arc swinging past a critical point,
// for instance). Capping the committed translate to the same order of
// magnitude as ordinary per-tick gravity (SIMULATION_GRAVITY_STEP) means
// any leftover drop just gets picked up on the following tick(s) instead
// -- either by applyGravityStep's own normal fall (if the remaining gap
// is bigger than one gravity step) or by advanceRockySettle re-probing
// again immediately (if it's smaller), so a big resting-depth discovery
// still reads as a smooth multi-frame sink instead of an instant snap.
#define SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK SIMULATION_GRAVITY_STEP

// Fixed (NOT adaptive/shrinking) lookahead angle both settle probes use
// to escape a local "flat spot" before giving up and halving their own
// fine step. A real report showed Rocky settling into a visibly dangling
// -- foot pose (rectangle resting on one corner, foot hanging in open
// air) that never improved further even with auto-gravity left running:
// the fine step (SIMULATION_LEG_SETTLE_STEP_DEG, shrinking toward
// SIMULATION_LEG_SETTLE_MIN_STEP_DEG) had landed exactly on a point where
// the foot's height barely changes with kneeAngle -- a near-zero local
// slope -- even though continuing further in the same direction clearly
// keeps helping. Halving an already-tiny step can never discover that:
// every even-finer neighboring angle is just as flat. Scouting this much
// bigger, constant-size angle purely to test "is there real improvement
// out here" (never committed directly -- only used to decide whether to
// keep nudging by the normal small per-tick step instead of shrinking
// it) breaks out of that trap while still moving at the same smooth,
// gradual pace as everywhere else in the settle system.
#define SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG 20.0f

// Simulation mode: plain Left/Right (no Shift) rotates the WHOLE robot
// (Semni.angle) -- see canvas.c's WM_KEYDOWN. Same value (and Left =
// positive / Right = negative sign convention) as Design > Robot mode's
// own Left/Right nudge (input.c's WM_KEYDOWN, `angle += 2.0f` / `-=
// 2.0f`), so a press feels identical between the two editors. Joint
// rotation (hip/knee) is the Shift-gated action instead -- see
// SIMULATION_JOINT_ROTATE_STEP_DEG and WM_MOUSEWHEEL's Shift check.
#define SIMULATION_WHOLE_BODY_ROTATE_STEP_DEG 2.0f

// Whole-body rotate (VK_LEFT/RIGHT above) turns the rectangle about its
// own CENTER, not about whichever corner is currently touching the
// ground -- so a robot balanced on a short/narrow edge can have a corner
// far from that center sweep a noticeable arc for even one single 2-
// degree press, and Windows' own key-repeat can fire many presses per
// second while the key is held. resolveUpwardIfPenetrating (called once
// per press, after the FULL step is already applied) only pushes back
// UP when the robot's new position is found actually colliding -- it
// can't help if a single press's corner travel is larger than the
// ground line's own thickness (SIMULATION_ARC_COLLISION_THICKNESS/
// simEnvLineHalfWidthWorld): the corner can then land clean on the far
// side of the line in one discrete step, never once testing as
// colliding at either the before or after angle, which reads as the
// rectangle "passing through the ground line" when rotated while
// resting on a narrow edge. Splitting each press into several smaller
// sub-rotations (canvas.c's WM_KEYDOWN), each followed by its own
// resolveUpwardIfPenetrating check, keeps every single sub-step's worst-
// case corner travel comfortably under that thickness, so the corner is
// forced to pass THROUGH the "currently colliding" state (and get
// pushed back up) at some sub-step instead of skipping over it entirely
// -- same reasoning as advanceAutoGravity's own per-tick sub-stepping
// fix for straight-line falls, applied here to rotation instead.
#define SIMULATION_WHOLE_BODY_ROTATE_SUBSTEP_DEG 0.2f

// Rocky's knee-to-foot pendulum (an automatic damped swing while Auto
// Gravity was on and the foot wasn't resting) was removed by explicit
// request -- it kept producing "stuck"/embedded states that were hard to
// reason about on top of the manual E/Q rotation. E/Q (SIMULATION_JOINT_
// ROTATE_STEP_DEG above) is now the only way Rocky's knee moves in
// Simulation mode; the whole-body "drop until it touches something"
// gravity above is unaffected.

// ---- Scripted gait ("Walk" toggle, Shift+W -- see canvas.c's gaitActive/
// advanceGait/gaitCycle) ----
//
// Semni has one leg, not two (no second innerCircle/kneeCircle/footCircle
// to alternate onto) -- so this isn't a classic alternating bipedal walk,
// it's a single-leg hop/pivot cycle: crouch, push off, swing the leg
// forward through the air, land, repeat. canvas.c's gaitCycle table drives
// hipAngle/kneeAngle/whole-body angle as DELTAS from whatever pose the
// robot was in the moment Walk was toggled on (gaitBaseline), plus a
// vertical "hop" bob and continuous forward world-X translation -- so
// whatever pose you've already dialed in (Design > Robot, or Simulation's
// own Shift+scroll/arrow-key posing) becomes the neutral stance the gait
// cycles around, rather than assuming any one fixed geometry.
//
// This is a first-pass, purely SCRIPTED cycle -- it does not look at the
// drawn environment at all (no foot-placement/terrain-following yet, see
// the "what's next" discussion this came out of), so the numbers below are
// a reasonable starting guess, not a tuned result: expect to adjust them
// (including possibly FLIPPING a sign, if a swing reads as going the wrong
// direction once you can actually see it) after watching it run once.

// How long one full crouch -> push -> swing -> land cycle takes, in real
// milliseconds, before Slow Motion's simTimeScale scales it down the same
// way it scales auto-gravity's fall speed.
#define SIMULATION_GAIT_CYCLE_MS 1200.0f

// Forward world-X distance covered per FULL cycle (continuous, not a
// discrete jump at the loop boundary -- see advanceGait's phaseUnwrapped).
#define SIMULATION_GAIT_STEP_LENGTH 0.18f

// Peak vertical "hop" bob, world units, relative to gaitBaseline's Y --
// purely oscillatory (returns to 0 every cycle), separate from the
// continuously-accumulating forward step length above.
#define SIMULATION_GAIT_HOP_HEIGHT 0.06f

// How far the hip swings the leg forward/back from the baseline pose over
// the course of a cycle, in degrees.
#define SIMULATION_GAIT_HIP_SWING_DEG 24.0f

// How far the knee bends (relative to baseline) during the crouch and the
// forward swing (bent to clear the ground), in degrees.
#define SIMULATION_GAIT_KNEE_BEND_DEG 30.0f

// Small whole-body forward lean during the push/swing portion of the
// cycle, in degrees -- purely cosmetic (sells the "leaning into the hop"
// look), independent of hipAngle/kneeAngle.
#define SIMULATION_GAIT_BODY_LEAN_DEG 6.0f
