﻿#pragma once
#include "bmp.h"
#include "ui_state.h"
#include "geometry.h"

Image* canvasToImage(void);

// The same drawing as canvasToImage, rendered `scale` times finer (ink
// mask only, 1 = ink). Used by the tracer to measure where the middle of
// each stroke is more precisely than the normal raster allows; the
// segmentation itself still runs on canvasToImage's raster. Pixel (x, y)
// of the normal raster covers [x*scale, (x+1)*scale) here. Caller frees.
// NULL if the canvas is empty or memory runs out.
uint8_t* canvasInkMask(int scale, int* outW, int* outH);
void displayImageOnCanvas(Image* img);

void setSegmentOverlay(ArcSegment* segments, int count, int imgW, int imgH, BOOL stretched);

// Debug only (View > Print Debug Log in Environment mode): the trace
// raster's scale, and each segment's ink re-centering shift as applied by
// the last setSegmentOverlay -- 3 floats per segment (shiftX, shiftY,
// radiusShift), in trace-raster pixels.
float traceRasterPxPerWorld(void);
extern float segmentInkShiftDebug[MAX_ARC_SEGMENTS * 3];

// NEW: converts one pixel-space branch/junction point into world
// coordinates and appends it to branchMarkersWorld for WM_PAINT to draw.
// No-op once MAX_BRANCH_MARKERS has been reached.
void addBranchMarker(int imgW, int imgH, int px, int py, BOOL stretched);
