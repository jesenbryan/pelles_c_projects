﻿#pragma once
#include "ui_state.h"   // for BOOL

void RunTracePipeline(void);
void RunUploadPipeline(void);

// When TRUE, suppresses the [DEBUG] Path Analysis / Arc Segmentation
// console dumps runPipelineOnImage prints on every trace (debug.c's
// debugPrintPath/debugPrintSegments) -- useful console output while
// actually drawing/tracing in Design > Environment, but pure noise when
// it fires from ID_MODE_SIMULATION's own automatic re-trace on entering
// Simulation mode (canvas.c), which the user never asked for and just
// wants the environment ready to collide against. Set/cleared right
// around that one RunTracePipeline() call, same save-and-restore idiom
// as canvas.c's own gSuppressGravityDebug -- every other caller
// (View Segments, Comparison Mode, Save, window-resize-while-simulating)
// leaves it FALSE and keeps seeing the normal debug output.
extern BOOL gSuppressTraceDebugPrints;

// Traces + builds segments for the most recently uploaded BMP, if it hasn't
// been traced yet (upload no longer auto-traces - see RunUploadPipeline).
// Safe to call any time; it's a no-op if there's nothing pending. Returns
// TRUE if it actually ran the pipeline.
BOOL RunPendingUploadTrace(void);

// TRUE if Save's unconditional retrace (canvas.c's ID_SAVE handler) would
// actually have something to trace right now -- an already-drawn canvas
// curve, or an uploaded BMP still waiting on its first trace. Lets that
// Save handler skip calling RunTracePipeline() entirely when neither is
// true (e.g. the user only came here to save a robot and never touched the
// Environment canvas at all), instead of calling it anyway and swallowing
// the "Canvas is empty" console prints that call would otherwise produce.
BOOL CanvasHasTraceableContent(void);
