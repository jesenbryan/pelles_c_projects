#include "canvas.h"
#include "ui.h"            // For SetComparisonModeUI
#include "pipeline.h"      // For RunUploadPipeline
#include "canvas_bridge.h" // For canvasToImage
#include "bmp_ui.h"        // For saveBMP_UI
#include "render.h"        // For renderSegmentsToImage
#include "editor_mode.h"   // For switchEditorMode -- Design Mode > Robot (Semni) launches the robot editor
#include "graphics.h"      // For graphicsOnResize/screenToGL -- renderCombinedFrame draws both subsystems
#include "renderer.h"      // For renderRobotScene -- the Semni half of renderCombinedFrame
#include "robot.h"         // For translateRobot -- dragging the robot into position in Simulation mode
#include "config.h"        // For INACTIVE_MODE_DIM_ALPHA
#include "sim_camera.h"    // Simulation mode's own independent zoom/pan (see sim_camera.h)
#include "save.h"          // For saveCanvasAsBMP/saveRockyAsEquations/saveRockyAsRobArm/saveSemniAsRobLeg/saveStiloAsRobLeg -- File > Save (ID_SAVE below) now dispatches to these directly, folded in from the old Robot editor Save button. saveRobotAsEquations/saveStiloAsEquations are declared here too but no longer called from this file -- they're still used by input.c's Standing/Home pose buttons (Poses\*.txt).
#include "help_dialog.h"   // For showControlsHelpDialog -- Help > Controls Help... (ID_HELP below)
#include "env_export.h"   // For saveEnvironmentSegmentsAsTxt (moved out of this file)
#include "input.h"        // For commitWeightEdit -- File > Save confirms the Weight box first
#include "debug.h"        // For ClearConsoleLog -- Simulation's Reset button (ID_RESET_ROBOT below)
#include <math.h>
#include <windowsx.h>  // GET_X_LPARAM/GET_Y_LPARAM: SIGNED mouse coords (negative when a captured drag leaves the window)
#include <string.h>
#include <stdlib.h>        // For wcstod (Rocky's Body/Leg Weight edit boxes, read in ID_SAVE below)
#include <wchar.h>

// High-resolution clock for the [PERF] timings and the settle fast-forward
// budget, in milliseconds (fractional). GetTickCount() only advances every
// ~15.6 ms on Windows, so every duration it measured came out as 0, 15/16
// or 31/32 ms -- too coarse to diagnose a hitch, and it made the 8 ms
// fast-forward budget effectively a 15.6 ms one.
static double perfNowMs(void)
{
    static LARGE_INTEGER freq = { 0 };
    LARGE_INTEGER now;
    if (freq.QuadPart == 0)
        QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    return (double)now.QuadPart * 1000.0 / (double)freq.QuadPart;
}
#include <stdio.h>         // For fopen/fprintf/fscanf -- Environment autosave (saveEnvironmentAutosave/loadEnvironmentAutosave below)

HWND hWndGL = NULL;
int glWindowWidth = 800;
int glWindowHeight = 600;
GLuint fontBase = 0;

CanvasState canvas = { .zoom = 1.0f };
AppMode appMode = APP_MODE_DESIGN;

// Environment's own View Segments / Comparison Mode state, saved when
// Simulation is entered and restored when leaving it -- Simulation always
// shows the reconstructed drawing (Comparison Mode on) without the View
// Segments overlay, but that shouldn't overwrite what the user had set up in
// Design > Environment. envViewStateSaved guards against re-selecting
// Simulation while already in it (which would save Simulation's own state).
static BOOL envViewStateSaved = FALSE;
static BOOL envSavedShowSegments = FALSE;
static BOOL envSavedComparisonMode = FALSE;

// Starts on Environment (not Robot) so the app opens straight into a
// usable canvas -- Robot is now a real destination (see the ID_LAYER_ROBOT
// handling in WM_COMMAND below), not the placeholder it used to be, and
// selecting it switches the whole app into the Semni robot editor rather
// than just tagging strokes.
DesignLayer designLayer = LAYER_ENVIRONMENT;

// Whether renderCombinedFrame HIDES whichever Design-mode layer (Robot or
// Environment) ISN'T the active one entirely (opacity 0) instead of just
// dimming it (the normal INACTIVE_MODE_DIM_ALPHA fade) -- see
// renderCombinedFrame's own dimAmount comment. On by default -- toggled
// from the View > Hide Inactive Layer menu item (main.c's buildMainMenu,
// WM_COMMAND's ID_TOGGLE_HIDE_INACTIVE handling below) for anyone who'd
// rather see the inactive layer's normal dim fade instead of it vanishing
// outright. Simulation is unaffected either way -- it already always draws
// both layers at full opacity regardless of this flag (see
// renderCombinedFrame's own simulationActive handling).
BOOL hideInactiveLayer = TRUE;

// Whether canvasRenderFrame draws the real-time FPS counter, top-right,
// just above the Probe 2 Settle button -- toggled from the View > Show FPS
// menu item (main.c's buildMainMenu, WM_COMMAND's ID_TOGGLE_SHOW_FPS
// handling below). See fpsDisplayValue's own comment for how the number
// itself is measured. Starts TRUE (unlike hideInactiveLayer's own
// "unobtrusive by default" reasoning) -- this exists specifically because
// a real report described the simulation as "sometimes isn't as smooth",
// so it should be visible from the first frame without an extra step,
// rather than requiring the user to already know to turn it on before
// they can even start diagnosing that.
BOOL showFpsOverlay = TRUE;

// Simulation-only console log toggles -- see ui_state.h's own comment and
// the SIM_LOG/SIM_FPS_LOG macros there. Off by default.
BOOL simPhysicsLogEnabled = FALSE;
BOOL simFpsLogEnabled = FALSE;

float segmentPointsWorld[MAX_SEGMENT_POINTS * 2];   // NEW
int   segmentStarts[MAX_ARC_SEGMENTS];              // NEW
int   segmentCounts[MAX_ARC_SEGMENTS];              // NEW
float segmentBoundsWorld[MAX_ARC_SEGMENTS * 4];       // per-segment bounding box (minX, minY, maxX, maxY), see ui_state.h

float segmentCircleCenterWorld[MAX_ARC_SEGMENTS * 2]; // NEW: ghost circle centers
float segmentCircleRadiusWorld[MAX_ARC_SEGMENTS];     // NEW: ghost circle radii (world X axis)
float segmentCircleRadiusWorldY[MAX_ARC_SEGMENTS];    // NEW: ghost circle radii (world Y axis) -
                                                       // needed because "stretched" (BMP) mode scales
                                                       // x/y independently, so the ghost circle is
                                                       // really an ellipse in world space

// Each reconstructed segment's original stroke radius, in raw SOURCE-IMAGE
// pixels -- the same unit strokeThickness[] above is already in. See
// canvas_bridge.c's setSegmentOverlay for how it's derived (measured from
// the pre-thinning raster, since thinningZhangSuen collapses every stroke
// to a 1px skeleton before arc-fitting ever runs, destroying its width).
// Used by the segment ghost overlay below (with the exact same
// *canvas.zoom/glWindowWidth constant-screen-pixel-width formula real
// strokes use) and render.c's renderSegmentsToImage, so the
// "reconstructed" drawing reads as the same weight as whatever it was fit
// from, instead of one hardcoded flat width regardless of the original.
float segmentAvgRadiusPx[MAX_ARC_SEGMENTS];

// Same original-stroke radius as segmentAvgRadiusPx above, but converted
// into a genuine WORLD-SPACE (EWS) length instead of a raw pixel count --
// see canvas_bridge.c's setSegmentOverlay for the derivation. Used by
// Simulation's ground collision (pointCollidesWithAnyEnvironmentStroke
// below) as EXTRA tolerance on top of the robot's own radius, so a falling
// robot's edge stops at this segment's actual RENDERED surface instead of
// its bare mathematical centerline -- without this, collision and
// rendering silently disagree about where "the ground" actually is by
// roughly this segment's own half-thickness.
float segmentThicknessWorld[MAX_ARC_SEGMENTS];

// NEW: which segment (if any) the mouse is currently hovering over.
// -1 means "none". Declared here (before ResetCanvas) since it's referenced there.
static int hoveredSegment = -1;

// NEW: endpoint-snap - lets the user hover near the start/end point of an
// existing stroke and have the NEXT stroke's start point snap exactly onto
// it, so straight-line strokes can be chained end-to-end into a polyline.
static BOOL  snapEndpointAvailable = FALSE;
static float snapEndpointX = 0.0f, snapEndpointY = 0.0f;

// Simulation mode only: which of the robot's rotatable joints the cursor
// is currently hovering -- a computeSemniBodyCircles (renderer.h) index,
// 2 (hip) or 3 (knee), or -1 for neither. Kept current every WM_MOUSEMOVE
// (see findHoveredJointSim) and read by WM_MOUSEWHEEL to decide whether a
// scroll should rotate that joint instead of zooming the camera.
static int simHoveredJoint = -1;

// NEW: state for the "hover top-right corner to reveal the UI panel" behavior
static BOOL hotZoneHighlighted = FALSE; // cursor is currently inside the corner hot zone
static BOOL uiShown            = FALSE; // panel is at least partially faded in
static int  uiAlpha             = 0;    // current fade alpha, 0 (invisible) - 255 (opaque)

// The Clear/Thickness/Color/Trace/View Segments/Comparison Mode panel
// (hWndUI, ui.c) is Design > Environment-only tooling -- none of it applies
// to Robot design mode or Simulation. WM_TIMER's hot-zone check below
// already refuses to show it outside Design > Environment, but that check
// only runs while canvas.c's own WndProc is actually receiving WM_TIMER --
// which it ISN'T while Robot design mode is active (editorModeState.
// currentMode routes WM_TIMER to input.c's handleInput instead once Robot
// takes over the shared window -- see main.c's WndProcShared). So if the
// panel was already showing right when the user switches to Robot mode (or
// Simulation, which forces ArcSpline to be "active" but still isn't
// Environment), it would otherwise stay stuck on screen indefinitely with
// no WM_TIMER ever ticking to fade it back out. Called directly from the
// mode-switch WM_COMMAND handling below instead, so hiding it doesn't
// depend on the timer being alive at all.
static void HideUIPanelImmediately(void)
{
    if (hWndUI) ShowWindow(hWndUI, SW_HIDE);
    uiShown = FALSE;
    uiAlpha = 0;
    hotZoneHighlighted = FALSE;
}

// Environment autosave (Feature: whatever is drawn in the Environment
// design layer is saved automatically, so closing and reopening the app
// restores the last drawn environment). Distinct from the EnvExport
// folder's Env.txt/Env.bmp files File > Save writes (env_export.c's
// saveEnvironmentSegmentsAsTxt) -- those are a lossy, SCALED arc-fit
// export meant for an external consumer to read, not a faithful
// round-trippable copy of the raw strokes. This instead dumps the exact
// raw stroke data (strokeStarts/strokeThickness/strokeColor/strokeLayer/
// points) needed to reconstruct canvas's drawing state byte-for-byte, in
// canvas.c's own native (unscaled) world units.
//
// Written to Autosave\Environment.txt, its own top-level folder separate
// from EnvExport/RockyExport/etc, so it's obviously not one of the
// exported files meant for another program to read -- it's this app's own
// internal save-state.
#define ENV_AUTOSAVE_FOLDER "Autosave"
#define ENV_AUTOSAVE_PATH   "Autosave\\Environment.txt"
#define ENV_AUTOSAVE_PNG_PATH "Autosave\\Environment.png"

// ---- Minimal PNG writer (no zlib needed) ----
// Writes a 1-bit black/white PNG using uncompressed ("stored") deflate
// blocks -- valid PNG any viewer opens, just not compressed. At 1 bit per
// pixel a full-window image is only ~100-150 KB.
static unsigned long pngCrcTable[256];
static int pngCrcTableReady = 0;

static unsigned long pngCrc(const unsigned char* buf, size_t len, unsigned long crc)
{
    if (!pngCrcTableReady)
    {
        for (unsigned long n = 0; n < 256; n++)
        {
            unsigned long c = n;
            for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320UL ^ (c >> 1) : c >> 1;
            pngCrcTable[n] = c;
        }
        pngCrcTableReady = 1;
    }
    for (size_t i = 0; i < len; i++) crc = pngCrcTable[(crc ^ buf[i]) & 0xFF] ^ (crc >> 8);
    return crc;
}

static void pngPut32(unsigned char* p, unsigned long v)
{
    p[0] = (unsigned char)(v >> 24); p[1] = (unsigned char)(v >> 16);
    p[2] = (unsigned char)(v >> 8);  p[3] = (unsigned char)v;
}

static void pngWriteChunk(FILE* f, const char* type, const unsigned char* data, unsigned long len)
{
    unsigned char hdr[8];
    pngPut32(hdr, len);
    memcpy(hdr + 4, type, 4);
    fwrite(hdr, 1, 8, f);
    if (len) fwrite(data, 1, len, f);
    unsigned long crc = pngCrc((const unsigned char*)type, 4, 0xFFFFFFFFUL);
    if (len) crc = pngCrc(data, len, crc);
    unsigned char c4[4];
    pngPut32(c4, crc ^ 0xFFFFFFFFUL);
    fwrite(c4, 1, 4, f);
}

// ink[y*w+x] != 0 -> black pixel, else white.
static BOOL writeBinaryPng(const char* path, const uint8_t* ink, int w, int h)
{
    size_t rowBytes = 1 + (size_t)(w + 7) / 8;            // filter byte + packed bits
    size_t rawLen = rowBytes * (size_t)h;
    unsigned char* raw = (unsigned char*)calloc(rawLen, 1);
    if (!raw) return FALSE;
    for (int y = 0; y < h; y++)
    {
        unsigned char* row = raw + (size_t)y * rowBytes;    // row[0] = filter 0 (none)
        for (int x = 0; x < w; x++)
            if (!ink[(size_t)y * w + x])                    // 1 bit = white in grayscale
                row[1 + x / 8] |= (unsigned char)(0x80 >> (x % 8));
    }

    size_t blocks = (rawLen + 65534) / 65535;
    if (blocks == 0) blocks = 1;
    size_t zLen = 2 + rawLen + blocks * 5 + 4;
    unsigned char* z = (unsigned char*)malloc(zLen);
    if (!z) { free(raw); return FALSE; }
    size_t o = 0;
    z[o++] = 0x78; z[o++] = 0x01;                           // zlib header, no compression
    size_t pos = 0;
    unsigned long a = 1, b = 0;                             // Adler-32
    do
    {
        size_t n = rawLen - pos;
        if (n > 65535) n = 65535;
        z[o++] = (pos + n >= rawLen) ? 1 : 0;              // BFINAL, BTYPE=00 (stored)
        z[o++] = (unsigned char)(n & 0xFF); z[o++] = (unsigned char)(n >> 8);
        z[o++] = (unsigned char)(~n & 0xFF); z[o++] = (unsigned char)((~n >> 8) & 0xFF);
        memcpy(z + o, raw + pos, n);
        for (size_t i = 0; i < n; i++) { a = (a + raw[pos + i]) % 65521UL; b = (b + a) % 65521UL; }
        o += n; pos += n;
    } while (pos < rawLen);
    pngPut32(z + o, (b << 16) | a); o += 4;

    BOOL ok = FALSE;
    FILE* f = fopen(path, "wb");
    if (f)
    {
        static const unsigned char sig[8] = { 137, 80, 78, 71, 13, 10, 26, 10 };
        unsigned char ihdr[13];
        pngPut32(ihdr, (unsigned long)w);
        pngPut32(ihdr + 4, (unsigned long)h);
        ihdr[8] = 1;   // bit depth
        ihdr[9] = 0;   // grayscale
        ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
        fwrite(sig, 1, 8, f);
        pngWriteChunk(f, "IHDR", ihdr, 13);
        pngWriteChunk(f, "IDAT", z, (unsigned long)o);
        pngWriteChunk(f, "IEND", NULL, 0);
        ok = (fclose(f) == 0);
    }
    free(z);
    free(raw);
    return ok;
}

// Autosave companion image: the drawing exactly as the tracing pipeline
// sees it (canvasToImage's black-on-white raster, fitted to the drawing's
// bounds at the current window size) -- handy for eyeballing what was
// saved and for reproducing a tracing problem outside the app. Removed when
// the drawing is empty.
static void saveEnvironmentAutosavePng(void)
{
    Image* img = (canvas.pointCount >= 1 && canvas.strokeCount >= 1) ? canvasToImage() : NULL;
    if (!img)
    {
        DeleteFileA(ENV_AUTOSAVE_PNG_PATH);
        return;
    }
    writeBinaryPng(ENV_AUTOSAVE_PNG_PATH, img->bin, img->width, img->height);
    free(img->data);
    free(img->bin);
    free(img->radius);
    free(img);
}

// Writes the CURRENT drawing (every stroke/point in strokeStarts/
// strokeThickness/strokeColor/strokeLayer/points) to ENV_AUTOSAVE_PATH.
// Called automatically whenever the drawing actually changes (WM_LBUTTONUP
// finishing a stroke, ResetCanvas clearing everything) rather than only on
// an explicit File > Save, so the app can restore whatever was last drawn
// even if it's closed without ever touching File > Save.
static void saveEnvironmentAutosave(void)
{
    CreateDirectoryA(ENV_AUTOSAVE_FOLDER, NULL);

    saveEnvironmentAutosavePng(); // Autosave/Environment.png next to the .txt -- see its comment

    FILE* f = fopen(ENV_AUTOSAVE_PATH, "w");
    if (!f) return; // best-effort -- a failed autosave shouldn't interrupt drawing

    fprintf(f, "%d\n", canvas.strokeCount);
    for (int s = 0; s < canvas.strokeCount; s++)
    {
        fprintf(f, "%d %.6f %lu %d\n", strokeStarts[s], strokeThickness[s],
                (unsigned long)strokeColor[s], (int)strokeLayer[s]);
    }

    fprintf(f, "%d\n", canvas.pointCount);
    for (int i = 0; i < canvas.pointCount; i += 2)
        fprintf(f, "%.6f %.6f\n", points[i], points[i + 1]);

    fclose(f);
}

// Restores whatever saveEnvironmentAutosave last wrote, straight into the
// same strokeStarts/strokeThickness/strokeColor/strokeLayer/points/canvas
// state it was read from -- called once, from WM_CREATE, right as the app
// starts up. If ENV_AUTOSAVE_PATH doesn't exist yet (first ever launch) or
// is malformed/truncated, this just leaves the canvas in its normal empty
// startup state instead of partially applying a corrupt read -- every
// early-return below happens BEFORE canvas.strokeCount/pointCount are
// ever touched, so a bad file can't leave the canvas in a half-loaded,
// inconsistent state.
static void loadEnvironmentAutosave(void)
{
    FILE* f = fopen(ENV_AUTOSAVE_PATH, "r");
    if (!f) return;

    int strokeCountRead = 0;
    if (fscanf(f, "%d", &strokeCountRead) != 1) { fclose(f); return; }
    if (strokeCountRead < 0) strokeCountRead = 0;
    if (strokeCountRead > MAX_STROKES) strokeCountRead = MAX_STROKES;

    for (int s = 0; s < strokeCountRead; s++)
    {
        int start, layer;
        float thick;
        unsigned long colorVal;
        if (fscanf(f, "%d %f %lu %d", &start, &thick, &colorVal, &layer) != 4) { fclose(f); return; }
        strokeStarts[s] = start;
        strokeThickness[s] = thick;
        strokeColor[s] = (COLORREF)colorVal;
        strokeLayer[s] = (DesignLayer)layer;
    }

    int pointCountRead = 0;
    if (fscanf(f, "%d", &pointCountRead) != 1) { fclose(f); return; }
    if (pointCountRead < 0) pointCountRead = 0;
    if (pointCountRead > MAX_POINTS) pointCountRead = MAX_POINTS;

    for (int i = 0; i < pointCountRead; i += 2)
    {
        float x, y;
        if (fscanf(f, "%f %f", &x, &y) != 2) { fclose(f); return; }
        points[i] = x;
        points[i + 1] = y;
    }

    fclose(f);

    // Only commit the counts once every point/stroke has been read
    // successfully -- see this function's own comment on why every
    // early-return above happens before this line.
    canvas.strokeCount = strokeCountRead;
    canvas.pointCount = pointCountRead;
}

void ResetCanvas(void)
{
    canvas.pointCount = 0;
    canvas.strokeCount = 0;
    canvas.hasBackgroundImage = FALSE;
    canvas.panX = 0.0f;
    canvas.panY = 0.0f;
    canvas.zoom = 1.0f;
    canvas.showSegments = FALSE;        // NEW
    canvas.segmentResultCount = 0;      // NEW
    canvas.comparisonMode = FALSE;      // NEW
    hoveredSegment = -1;                // NEW: avoid a stale highlight index
    snapEndpointAvailable = FALSE;      // NEW: avoid a stale endpoint-snap highlight
    branchMarkerCount = 0;              // NEW: avoid stale branch-point markers
	UpdateProjection();

	// Persist the cleared state too, so hitting Clear right before closing
	// the app is remembered as "empty" on next launch instead of the
	// autosave silently keeping whatever was drawn before the Clear.
	saveEnvironmentAutosave();
}

// Undo: drops the last stroke (its points are always the tail of points[],
// starting at strokeStarts[last]). Re-traces if View Segments / Comparison
// Mode is showing the reconstruction, so that overlay never shows a stroke
// that's gone, and autosaves like any other drawing change.
void UndoLastStroke(void)
{
    if (drawing) return;                       // never pull a stroke out from under an active drag
    if (canvas.strokeCount <= 0) return;

    int last = canvas.strokeCount - 1;
    canvas.pointCount = strokeStarts[last];
    canvas.strokeCount = last;

    hoveredSegment = -1;
    snapEndpointAvailable = FALSE;
    branchMarkerCount = 0;

    if (canvas.showSegments || canvas.comparisonMode)
    {
        if (canvas.strokeCount > 0)
            RunTracePipeline();
        else
            canvas.segmentResultCount = 0;     // nothing left to trace
    }

    saveEnvironmentAutosave();
    if (hWndGL) InvalidateRect(hWndGL, NULL, FALSE);
}

GLuint canvasTexture = 0;

float bgLeft = -1.0f, bgRight = 1.0f, bgBottom = -1.0f, bgTop = 1.0f; // NEW

float branchMarkersWorld[MAX_BRANCH_MARKERS * 2];
int   branchMarkerCount = 0;

// NEW: pan state
static BOOL panning = FALSE;
static int  panLastX = 0, panLastY = 0;

// Simulation mode: dragging anywhere (instead of drawing a new stroke)
// moves the WHOLE robot rigidly, letting the user set its starting
// position within the environment. Uses screenToGL (graphics.h) rather
// than this file's own canvas.zoom/panX/panY conversion -- the robot is
// rendered through Semni's own, entirely separate zoom/pan (graphics.c's
// g_zoom/g_panX/g_panY), so only screenToGL is guaranteed to agree with
// wherever the robot is actually drawn on screen.
//
// The "am I dragging right now" flag itself lives in app.draggingRobotSim
// (app.h), not as a static here, so renderRobot (renderer.c) can also see
// it to render the robot's outline in blue while a drag is in progress --
// only the drag's own last-position bookkeeping needs to stay local to
// this file.
static float dragRobotLastWX = 0.0f, dragRobotLastWY = 0.0f;

// app.hoveringRobotSim (app.h) tracks whether the cursor is over the
// robot's body in Simulation mode -- updated every WM_MOUSEMOVE below (the
// only place the current cursor position is known) and read back by
// WM_SETCURSOR (whose lParam/wParam don't carry a position) to only show
// the move cursor, and by WM_LBUTTONDOWN to only start a whole-robot drag,
// when the mouse is genuinely over the robot rather than anywhere on the
// canvas. Lives on app (like draggingRobotSim above) rather than as a
// local static here, so renderRobot (renderer.c) can also read it to
// highlight the robot yellow on hover.

// NEW: shift-line "hold still to snap" state - lets the user snap to a
// horizontal / vertical / 45-degree diagonal line just by holding the
// cursor still for a couple of seconds, without needing to also hold Ctrl
// (see the instant Ctrl+Shift snap in WM_MOUSEMOVE for the immediate
// version). A truly stationary cursor never generates WM_MOUSEMOVE
// messages, so the dwell check itself has to live in WM_TIMER, which is
// what actually notices time passing.
#define SHIFT_HOLD_SNAP_MS       700    // how long to hold still before it snaps
#define SHIFT_HOLD_TOLERANCE_DEG 5.0f   // how close to 0/45/90/135 deg counts as "close enough"
#define SHIFT_HOLD_JITTER_PX     3      // cursor motion below this still counts as "holding still"

static BOOL  shiftHoldActive       = FALSE; // TRUE while a shift-line drag is in progress
static BOOL  shiftHoldSnapped      = FALSE; // TRUE once the dwell timer has locked the angle
static int   shiftHoldStrokeStart  = 0;     // points[] index of this stroke's first (x,y)
static int   shiftHoldPixelX       = 0;     // last raw cursor position (screen px)
static int   shiftHoldPixelY       = 0;
static float shiftHoldWorldX       = 0.0f;  // last raw cursor position (world), pre-snap
static float shiftHoldWorldY       = 0.0f;
static DWORD shiftHoldLastMoveTick = 0;     // GetTickCount() at the last meaningful cursor move
static float shiftHoldSnapAngleRad = 0.0f;  // locked angle, valid only if shiftHoldSnapped

// Snapshot of the in-progress stroke's freehand points from the instant
// Shift was first pressed this drag (see updateDrawingPoint) -- Shift
// truncates points[] down to just the stroke's start point and re-derives
// a straight line from there every move, which would otherwise permanently
// throw away whatever freehand path came before Shift was pressed.
// Restored verbatim the moment Shift is released, so releasing it goes
// back to exactly what was drawn before, not wherever the straight line
// happened to end up. Sized like points[] itself since the in-progress
// stroke could in principle be almost that long.
static float shiftHoldFreehandBackup[MAX_POINTS];
static int   shiftHoldFreehandBackupCount = 0;

float points[MAX_POINTS];
int strokeStarts[MAX_STROKES];
float strokeThickness[MAX_STROKES];
COLORREF strokeColor[MAX_STROKES];
DesignLayer strokeLayer[MAX_STROKES];
BOOL drawing = FALSE;

static HGLRC hRC;
static HDC hDC;

// "Slow Motion" toggle (see hSlowMotionBtn/ID_SLOW_MOTION, WM_CREATE/
// WM_COMMAND below) -- 1.0 is normal speed, SIMULATION_SLOW_MOTION_SCALE
// (config.h) while checked. Read by advanceAutoGravity (scales the elapsed
// real time physics integrates over) and applyGravityStep's slope-
// alignment step, so both the fall and the tipping-into-a-slope settle
// down together by the same factor, without touching the underlying
// acceleration/terminal velocity/alignment-rate constants themselves.
// Declared up here (rather than next to autoGravityActive further down,
// where it's toggled) because applyGravityStep -- defined earlier in this
// file than that -- already needs to read it.
static float simTimeScale = SIMULATION_SLOW_MOTION_SCALE; // Slow Motion is ON by default (by request)

// The Simulation-mode-only "Slow Motion" button itself -- a plain WS_CHILD
// of hWndGL (unlike hWndUI's buttons, which live in their own floating
// hover-reveal popup that's Design > Environment-only and explicitly
// hidden the instant Simulation is entered, see HideUIPanelImmediately).
// Created once in WM_CREATE, shown/hidden alongside entering/leaving
// Simulation mode in WM_COMMAND's ID_MODE_SIMULATION handling. Anchored to
// the client area's top-left corner, which needs no WM_SIZE repositioning
// since that corner's offset from the origin never changes on resize.
static HWND hSlowMotionBtn = NULL;

// Same idea as hSlowMotionBtn just above, for the "Walk" toggle (Shift+W --
// see gaitActive/advanceGait). Positioned directly below Slow Motion's
// button (see WM_CREATE), shown/hidden alongside it.
static HWND hWalkBtn = NULL;

// "Reset" -- a plain (non-toggle) push button directly below Walk, same
// hidden-until-Simulation treatment. Restores whichever robot was active
// back to the exact pose (position/angle/kneeAngle/etc -- see
// simulationStartSnapshot below) it had at the MOMENT Simulation mode was
// entered, not some separate hardcoded "factory" pose -- "starting
// position" means the run's own starting point, the same way a game level
// restart returns you to where that attempt began, not to a fixed origin.
static HWND hResetBtn = NULL;

// Probe 2 (the knee-bending settle probe in advanceRockySettle, gated by
// rockyProbe2Enabled below) is the source of every settle-pose bug this
// project has chased -- Probe 1's whole-body pivot-around-current-contact
// already implements correct toppling on its own. Rather than deleting
// Probe 2 outright, it's gated behind this checkbox so it can be switched
// off (to compare against pure Probe 1 toppling) without losing the code
// or the ability to switch it back on. Anchored to the client area's
// TOP-RIGHT corner (unlike Slow Motion/Walk/Reset above, which sit at a
// fixed top-left offset that never needs adjusting) -- WM_SIZE below
// repositions it on every resize since its distance from the left edge
// changes with window width. Starts checked (TRUE) so default behavior
// is unchanged from before this toggle existed.
// Layout constants for hProbe2ToggleBtn (WM_CREATE/WM_SIZE below) -- kept
// together here rather than scattered as magic numbers at each call site,
// since both places need to agree on the exact same button size/margin.
#define PROBE2_TOGGLE_WIDTH_PX  150
#define PROBE2_TOGGLE_HEIGHT_PX 28
#define PROBE2_TOGGLE_MARGIN_PX 10

// Vertical space reserved above hProbe2ToggleBtn, at the same top-right
// corner, for the FPS counter (View > Show FPS, ID_TOGGLE_SHOW_FPS) drawn
// by canvasRenderFrame -- see fpsDisplayValue's own comment. Reserved
// UNCONDITIONALLY (the button is offset down by this amount regardless of
// whether the overlay is currently switched on) rather than only when
// showFpsOverlay is TRUE, so toggling it on/off never shifts the button
// and everything else pinned below it -- it would be jarring for Probe 2
// Settle to visibly jump position every time this is toggled.
#define FPS_OVERLAY_RESERVED_HEIGHT_PX 24

// How often (real milliseconds) the FPS counter's displayed number is
// recomputed -- see fpsDisplayValue's own comment for why this isn't just
// updated every single frame.
#define FPS_UPDATE_INTERVAL_MS 500

static HWND hProbe2ToggleBtn = NULL;

// Backing state for hProbe2ToggleBtn -- see its comment just above and
// the entry-condition check in advanceRockySettle. TRUE = Probe 2 runs
// normally (pre-existing behavior); FALSE = advanceRockySettle skips
// straight to Probe 1's body-pivot toppling, never bending the knee.
static BOOL rockyProbe2Enabled = TRUE;

// Whole-RobotScene snapshot (Semni + Rocky + Stilo + activeKind, plain
// value struct -- see app.h -- so a raw copy is safe, no pointers inside
// any of the three) taken once, right when Simulation mode is entered
// (WM_COMMAND's ID_MODE_SIMULATION handling below). ID_RESET_ROBOT copies
// it straight back over app.robotScene. haveSimulationStartSnapshot exists
// so Reset can no-op safely if it's ever somehow clicked before that
// capture has happened (shouldn't be reachable -- the button stays
// hidden until Simulation mode is entered, which is exactly when the
// capture runs -- but a silent no-op is a lot safer than restoring
// whatever garbage a zero-initialized RobotScene would contain).
static RobotScene simulationStartSnapshot;
static BOOL haveSimulationStartSnapshot = FALSE;

HDC canvasGetHDC(void)
{
    return hDC;
}

static void segmentGhostColor(int index, float* r, float* g, float* b)
{
    // Cycle through a handful of distinguishable hues per segment
    static const float palette[6][3] = {
        {0.85f, 0.20f, 0.20f}, {0.20f, 0.55f, 0.85f}, {0.20f, 0.75f, 0.35f},
        {0.85f, 0.55f, 0.15f}, {0.60f, 0.30f, 0.80f}, {0.20f, 0.75f, 0.75f}
    };
    int i = index % 6;
    *r = palette[i][0];
    *g = palette[i][1];
    *b = palette[i][2];
}

static void drawMarkerDisc(float cx, float cy, float r, float red, float green, float blue, float alpha)
{
    const int segments = 20;
    glColor4f(red, green, blue, alpha);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= segments; i++) {
        float theta = (2.0f * 3.14159265f * i) / segments;
        glVertex2f(cx + r * cosf(theta), cy + r * sinf(theta));
    }
    glEnd();
}

// Distance from a world-space point to a world-space line segment.
// Half-width, in world units, of a stroke `thicknessPx` screen pixels wide,
// for the Design-mode stroke and Comparison Mode ribbons. This used to be
// thicknessPx * zoom / glWindowWidth, which ignored that the visible world
// is 2 * zoom * aspect units wide (UpdateProjection), so every line came
// out thicknessPx / aspect pixels wide -- about 1.1 px for a "2 px" stroke
// on a 16:9 window, and thinner still the wider the window. The tracer
// stamps strokes at their full thickness, so that also made the drawing
// and its reconstruction disagree: a ~1.1 px line lights one or two pixel
// rows depending on where it falls between them, which is what made
// Comparison Mode look thinner or thicker than the original. At the real
// width (2 px) a horizontal/vertical line always covers exactly two rows.
static float designStrokeHalfWidthWorld(float thicknessPx, float zoom)
{
    float aspect = (float)glWindowWidth / (float)glWindowHeight;
    float worldWidth = 2.0f * zoom * ((aspect >= 1.0f) ? aspect : 1.0f);
    return 0.5f * thicknessPx * worldWidth / (float)glWindowWidth;
}

static float distPointToSegment(float px, float py, float ax, float ay, float bx, float by)
{
    float dx = bx - ax;
    float dy = by - ay;
    float len2 = dx * dx + dy * dy;

    if (len2 < 1e-9f) {
        float ddx = px - ax, ddy = py - ay;
        return sqrtf(ddx * ddx + ddy * ddy);
    }

    float t = ((px - ax) * dx + (py - ay) * dy) / len2;
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;

    float projX = ax + t * dx;
    float projY = ay + t * dy;
    float ddx = px - projX, ddy = py - projY;
    return sqrtf(ddx * ddx + ddy * ddy);
}

// Same projection math as distPointToSegment above, but also hands back
// WHERE on the segment the closest point actually is -- needed wherever a
// caller wants to draw a marker at the contact point, not just test a
// distance.
static float closestPointOnSegment(float px, float py, float ax, float ay, float bx, float by,
                                    float* outX, float* outY, float* outT)
{
    float dx = bx - ax;
    float dy = by - ay;
    float len2 = dx * dx + dy * dy;

    float t;
    if (len2 < 1e-9f) {
        t = 0.0f;
    } else {
        t = ((px - ax) * dx + (py - ay) * dy) / len2;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;
    }

    float projX = ax + t * dx;
    float projY = ay + t * dy;
    if (outX) *outX = projX;
    if (outY) *outY = projY;
    if (outT) *outT = t;

    float ddx = px - projX, ddy = py - projY;
    return sqrtf(ddx * ddx + ddy * ddy);
}

// TRUE if segment (p1x,p1y)-(p2x,p2y) properly crosses segment
// (p3x,p3y)-(p4x,p4y) in their interiors. Boundary-touching cases
// (collinear overlap, an endpoint exactly on the other segment) are
// deliberately left uncaught here -- they're already correctly picked up
// by distSegmentToSegment's endpoint-distance fallback below (the
// distance comes out ~0 either way), and a general-purpose intersection
// routine would need to special-case several degenerate configurations
// this collision system never actually produces.
static BOOL segmentsProperlyIntersect(float p1x, float p1y, float p2x, float p2y,
                                       float p3x, float p3y, float p4x, float p4y)
{
    float d1 = (p4x - p3x) * (p1y - p3y) - (p4y - p3y) * (p1x - p3x);
    float d2 = (p4x - p3x) * (p2y - p3y) - (p4y - p3y) * (p2x - p3x);
    float d3 = (p2x - p1x) * (p3y - p1y) - (p2y - p1y) * (p3x - p1x);
    float d4 = (p2x - p1x) * (p4y - p1y) - (p2y - p1y) * (p4x - p1x);

    return ((d1 > 0.0f) != (d2 > 0.0f)) && ((d3 > 0.0f) != (d4 > 0.0f));
}

// Exact (no sampling/discretization) minimum distance between segment A
// (ax0,ay0)-(ax1,ay1) and segment B (bx0,by0)-(bx1,by1), with the closest
// point ON SEGMENT A written to *outAX/*outAY. Two non-crossing 2D
// segments always have their true closest point pair at one segment's
// ENDPOINT against the other -- checking all 4 endpoint-vs-opposite-
// segment distances and keeping the smallest is exact, not an
// approximation. segmentsProperlyIntersect above covers the one case
// that check alone would miss: segments crossing cleanly through each
// other's interior, where the true distance is 0 but neither segment has
// an endpoint anywhere near the crossing (exactly the case a fast-moving
// edge sweeping through a thin line in one step would hit -- this is
// what let robotCollidesWithEnvironment's Rocky rectangle-edge test go
// straight through a thin ground line between two discrete point samples
// before this function replaced that sampling loop entirely).
static float distSegmentToSegment(float ax0, float ay0, float ax1, float ay1,
                                   float bx0, float by0, float bx1, float by1,
                                   float* outAX, float* outAY, float* outAT)
{
    if (segmentsProperlyIntersect(ax0, ay0, ax1, ay1, bx0, by0, bx1, by1))
    {
        // The exact crossing point isn't worth solving for here -- for a
        // visual marker, the two segments are already essentially on top
        // of each other, so segment A's own midpoint reads as "right at
        // the contact" closely enough.
        if (outAX) *outAX = (ax0 + ax1) * 0.5f;
        if (outAY) *outAY = (ay0 + ay1) * 0.5f;
        if (outAT) *outAT = 0.5f;
        return 0.0f;
    }

    float bestDist, bestX, bestY, bestT;

    // A's own endpoints against segment B -- the closest point ON A is
    // trivially the endpoint itself (t=0 or t=1).
    bestDist = distPointToSegment(ax0, ay0, bx0, by0, bx1, by1);
    bestX = ax0; bestY = ay0; bestT = 0.0f;

    {
        float d = distPointToSegment(ax1, ay1, bx0, by0, bx1, by1);
        if (d < bestDist) { bestDist = d; bestX = ax1; bestY = ay1; bestT = 1.0f; }
    }

    // B's endpoints against segment A -- the closest point ON A here is
    // wherever that endpoint projects onto A, t included.
    {
        float projX, projY, projT;
        float d = closestPointOnSegment(bx0, by0, ax0, ay0, ax1, ay1, &projX, &projY, &projT);
        if (d < bestDist) { bestDist = d; bestX = projX; bestY = projY; bestT = projT; }
    }
    {
        float projX, projY, projT;
        float d = closestPointOnSegment(bx1, by1, ax0, ay0, ax1, ay1, &projX, &projY, &projT);
        if (d < bestDist) { bestDist = d; bestX = projX; bestY = projY; bestT = projT; }
    }

    if (outAX) *outAX = bestX;
    if (outAY) *outAY = bestY;
    if (outAT) *outAT = bestT;
    return bestDist;
}

// Converts a point in the robot's own Simulation-mode world space into the
// ArcSpline environment's Simulation-mode world space. The robot's joints
// (Semni's own coordinate system, see graphics.c) and the environment's
// traced strokes (this file's points[], canvas.zoom/panX/panY's own
// coordinate system) are two completely different, unrelated numeric
// spaces -- they only visually line up on screen because Simulation mode
// drives both subsystems' projections from the SAME sim_camera zoom/pan
// (see UpdateProjection and graphics.c's applyProjection). Both
// projections ultimately map their own world space to the same shared NDC
// (-1..1) before OpenGL ever gets involved, so routing a point through
// that shared NDC -- world(robot) -> ndc -> world(env) -- is what lets
// gravity's ground-collision check (below) compare the robot's body
// circles against the environment's strokes directly, in one consistent
// frame, instead of comparing two unrelated sets of raw numbers.
static void robotPointToEnvWorld(float rx, float ry, float* ex, float* ey)
{
    float aspect = (float)glWindowWidth / (float)glWindowHeight;

    // Robot's own current half-extent + pan, computed exactly the way
    // graphics.c's applyProjection/screenToGL do (including the robot-size
    // slider, graphicsGetRobotScale) -- has to match or the converted
    // point won't actually correspond to where the robot is drawn.
    float robotZoom = simCameraGetZoom() * graphicsGetRobotScale();
    float robotHalfY = ROBOT_VIEW_HALF_EXTENT / robotZoom;
    float robotHalfX = robotHalfY * aspect;
    float robotPanX, robotPanY;
    simCameraGetWorldPan(robotHalfX, robotHalfY, &robotPanX, &robotPanY);

    // Environment's own current half-extent + pan, computed exactly the
    // way UpdateProjection above does.
    float envZoom = 1.0f / simCameraGetZoom();
    float envHalfX, envHalfY;
    if (aspect >= 1.0f) { envHalfX = aspect * envZoom; envHalfY = envZoom; }
    else                { envHalfX = envZoom; envHalfY = envZoom / aspect; }
    float envPanX, envPanY;
    simCameraGetWorldPan(envHalfX, envHalfY, &envPanX, &envPanY);

    float ndcX = (rx - robotPanX) / robotHalfX;
    float ndcY = (ry - robotPanY) / robotHalfY;

    *ex = ndcX * envHalfX + envPanX;
    *ey = ndcY * envHalfY + envPanY;
}

// Same idea as robotPointToEnvWorld, but for a LENGTH (e.g. a circle's
// radius) rather than a point -- pan cancels out for a pure length/vector
// conversion, so this is just a uniform scale by the ratio of the two
// subsystems' half-extents. Using the Y half-extent specifically is
// arbitrary but safe: both subsystems derive halfX from halfY via the
// exact same `aspect` value (see robotPointToEnvWorld), so the X and Y
// ratios are always identical -- this is a uniform scale, not a stretch.
static float robotLengthToEnvWorld(float rlen)
{
    float aspect = (float)glWindowWidth / (float)glWindowHeight;

    float robotZoom = simCameraGetZoom() * graphicsGetRobotScale();
    float robotHalfY = ROBOT_VIEW_HALF_EXTENT / robotZoom;

    float envZoom = 1.0f / simCameraGetZoom();
    float envHalfY = (aspect >= 1.0f) ? envZoom : (envZoom / aspect);

    return rlen * (envHalfY / robotHalfY);
}

// Single source of truth for the environment line's Simulation-mode
// half-width, in env-world-space units -- used by BOTH the renderer (the
// Comparison Mode ribbon and its raw-stroke fallback, canvas.c's main
// paint routine) and collision (pointCollidesWithAnyEnvironmentStroke,
// just below) so the two can never drift apart the way they did before:
// collision was treating the environment as a bare zero-width centerline
// while the ribbon was drawn extending a visible half-width above (and
// below) that same centerline, so even mathematically exact contact at
// the centerline still looked like sinking into the top half of the
// rendered line. Now both sides ask this one function for the same
// answer, so contact always looks flush right where the line's own drawn
// surface actually is.
//
// robotLengthToEnvWorld(SIMULATION_ARC_COLLISION_THICKNESS) is the base
// value (note: this ratio is independent of simCameraGetZoom() -- it
// cancels out algebraically, by design, since neither collision nor this
// line's "true" thickness should change just because the camera zoomed),
// but that alone often comes out under a screen pixel wide, which flickers
// in and out of visibility as sub-pixel rounding shifts with zoom/pan.
// SIM_ENV_LINE_MIN_PIXELS (config.h) is a floor on top of it, converted
// from on-screen pixels into world units at the CURRENT zoom (unlike the
// base value, this floor DOES depend on zoom -- the whole point is a
// constant apparent size on screen), so the line never thins down to an
// invisible sliver at any zoom level.
static float simEnvLineHalfWidthWorld(void)
{
    float fixedHalfWidth = robotLengthToEnvWorld(SIMULATION_ARC_COLLISION_THICKNESS);

    float aspect = (float)glWindowWidth / (float)glWindowHeight;
    float zoom = 1.0f / simCameraGetZoom();
    float envHalfY = (aspect >= 1.0f) ? zoom : (zoom / aspect);
    // glOrtho maps 2*envHalfY world units to glWindowHeight pixels
    // (UpdateProjection) -- so this is world units per on-screen pixel,
    // vertically.
    float worldPerPixelY = (2.0f * envHalfY) / (float)glWindowHeight;
    float minHalfWidth = (SIM_ENV_LINE_MIN_PIXELS * worldPerPixelY) * 0.5f;

    return (fixedHalfWidth > minHalfWidth) ? fixedHalfWidth : minHalfWidth;
}

// TRUE if the env-world-space point (ecx, ecy) comes within eRadius of the
// RECONSTRUCTED (arc-fitted) environment, not the raw hand-drawn strokes --
// segmentPointsWorld/segmentStarts/segmentCounts (canvas_bridge.c's
// setSegmentOverlay), the same poly-line-sampled arc data the Comparison
// Mode/View Segments ghost overlay renders. Each fitted arc is still
// walked as consecutive point-pairs here (distPointToSegment doesn't care
// whether those points came from a raw stroke or a sampled arc), so this
// is a drop-in swap of the DATA SOURCE, not the collision math itself.
//
// Deliberately not filtered by layer -- unlike the raw strokes this used
// to read from, segments have no per-segment layer tag (setSegmentOverlay
// doesn't carry one through), but that's moot in practice: the Robot
// layer can't have strokes drawn into it at all (see WM_LBUTTONDOWN), so
// canvasToImage's rasterization -- and therefore every fitted segment --
// only ever comes from Environment-layer content anyway.
//
// Requires a trace to have actually run first (see the ID_MODE_SIMULATION
// handler in WM_COMMAND, which re-traces automatically on every entry into
// Simulation so this never runs stale or empty against strokes drawn since
// the last manual Trace press). If canvas.segmentResultCount is 0 (nothing
// traceable, or tracing never ran), the loop below just does nothing and
// this returns FALSE -- same as "no strokes" used to behave.
//
// Tests against a small FIXED epsilon on top of eRadius (the CALLER's own
// radius, e.g. the robot's body circle) -- segmentPointsWorld is only the
// fitted arc's bare mathematical CENTERLINE, so some padding is still
// needed here (same reasoning the connecting fillet arcs have their own
// SIMULATION_ARC_COLLISION_THICKNESS pad for: a contact test against a
// bare curve with literally zero thickness would let the robot visibly
// clip through it depending on the local angle of approach).
//
// Previously this added segmentThicknessWorld[s] instead -- the
// RECONSTRUCTION's own measured stroke half-width (canvas_bridge.c's
// avgRadiusPx-derived value, matching what the Comparison Mode ribbon
// renders at). That seemed right at first (matching the VISIBLE line's
// real surface instead of its invisible centerline), but it's actually
// the wrong quantity for physics: it's just however wide the mouse
// happened to be dragged while drawing that stroke, with zero relation to
// the robot's own size. A big, deliberately-thick pen stroke is fine for
// a large robot but reads as an oversized ledge for a small one (Rocky at
// its default size sitting ~18% of its own body height above a normal
// stroke, purely because the stroke was drawn thick relative to Rocky
// specifically) -- and there's no stroke width a user could pick that
// works uniformly across every robot size. Using the SAME small constant
// the arcs already use makes the environment consistently near-centerline
// for collision regardless of pen pressure or robot scale, matching how
// the fillet arcs already treat their own bare curves.
//
// Debug: TRUE suppresses [COLLIDE]/[GRAVITY] prints for the CURRENT
// applyGravityStep call -- set by applyGravityStep itself based on whether
// the robot was already resting last tick, so the console doesn't scroll
// forever while Shift+G keeps re-confirming a robot that already landed.
static BOOL gSuppressGravityDebug = FALSE;

// ---- Collision broad phase ----
// Every environment query below used to run its exact distance math
// against EVERY sampled piece of EVERY traced segment (each segment is
// sampled into ~24 points, so a 9-segment stage is ~200+ pieces), and
// the settle probes run those queries thousands of times per tick --
// cost grew linearly with how much was drawn (a real report: one
// settle call going from a few ms on a single line to ~37 ms on a
// 9-segment stage, visibly stuttering). These bounding-box tests throw
// away segments/pieces that are provably farther than the query's
// radius BEFORE doing any exact math, so only the few pieces actually
// near the robot are measured. Pure rejection: anything they skip could
// never have passed the exact test anyway, so results are unchanged.
//
// ENV_BROADPHASE_SLACK keeps float rounding at the exact boundary from
// ever rejecting something the exact test would have accepted.
#define ENV_BROADPHASE_SLACK 1e-6f

// TRUE if env segment s's bounding box (segmentBoundsWorld), grown by
// pad, overlaps the query box [minX,maxX] x [minY,maxY].
static BOOL envSegmentBoxNear(int s, float minX, float minY, float maxX, float maxY, float pad)
{
    const float* b = &segmentBoundsWorld[s * 4];
    pad += ENV_BROADPHASE_SLACK;
    return !(maxX + pad < b[0] || minX - pad > b[2] || maxY + pad < b[1] || minY - pad > b[3]);
}

// Same test for one piece (ax,ay)-(bx,by) of a segment.
static BOOL envPieceBoxNear(float ax, float ay, float bx, float by,
                            float minX, float minY, float maxX, float maxY, float pad)
{
    float pMinX = (ax < bx) ? ax : bx, pMaxX = (ax < bx) ? bx : ax;
    float pMinY = (ay < by) ? ay : by, pMaxY = (ay < by) ? by : ay;
    pad += ENV_BROADPHASE_SLACK;
    return !(maxX + pad < pMinX || minX - pad > pMaxX || maxY + pad < pMinY || minY - pad > pMaxY);
}

// Squared distance from a point to a box (0 if inside) -- a lower bound
// on the distance to anything inside that box.
static float pointBoxDist2(float px, float py, float minX, float minY, float maxX, float maxY)
{
    float dx = (px < minX) ? (minX - px) : ((px > maxX) ? (px - maxX) : 0.0f);
    float dy = (py < minY) ? (minY - py) : ((py > maxY) ? (py - maxY) : 0.0f);
    return dx * dx + dy * dy;
}

static BOOL pointCollidesWithAnyEnvironmentStroke(float ecx, float ecy, float eRadius)
{
    // combinedRadius = eRadius + the environment line's OWN rendered
    // half-width (simEnvLineHalfWidthWorld, defined just above). This
    // used to be just eRadius alone, on the theory that adding anything
    // else was double-counting the same "bare curve, no radius" padding
    // arcs/edges already get from their caller -- but that reasoning
    // missed that the environment's line is ALSO drawn with its own
    // visible half-width (centerline +/- simEnvLineHalfWidthWorld, see
    // the Comparison Mode ribbon), not as a bare zero-width centerline.
    // Treating the environment as zero-width for collision while
    // rendering it with real width meant a robot could settle exactly at
    // the centerline -- mathematically flush contact -- while still
    // visibly overlapping the top half of the drawn line, since the
    // line's actual top surface sits a half-width ABOVE that centerline.
    // Adding the same half-width back in here (now that render and
    // collision both source it from the one shared function) fixes that:
    // a real body circle passes its own true radius plus this env
    // half-width, and an arc/edge sample adds SIMULATION_ARC_COLLISION_
    // THICKNESS's own padding on top of that same env half-width -- which
    // is correct, not double-counting, because those are two genuinely
    // different drawn thicknesses (the robot's own curve stroke, and the
    // environment's own line stroke) that both have to be accounted for
    // to land contact exactly on the two visible surfaces meeting, not on
    // either one's invisible centerline.
    float envHalfWidth = simEnvLineHalfWidthWorld();
    float combinedRadius = eRadius + envHalfWidth;

    for (int s = 0; s < canvas.segmentResultCount; s++)
    {
        int start = segmentStarts[s];
        int count = segmentCounts[s];
        if (count < 2) continue;
        if (!envSegmentBoxNear(s, ecx, ecy, ecx, ecy, combinedRadius)) continue; // broad phase

        for (int i = 0; i < count - 1; i++)
        {
            float ax = segmentPointsWorld[(start + i) * 2];
            float ay = segmentPointsWorld[(start + i) * 2 + 1];
            float bx = segmentPointsWorld[(start + (i + 1)) * 2];
            float by = segmentPointsWorld[(start + (i + 1)) * 2 + 1];
            if (!envPieceBoxNear(ax, ay, bx, by, ecx, ecy, ecx, ecy, combinedRadius)) continue;

            float dist = distPointToSegment(ecx, ecy, ax, ay, bx, by);
            if (dist < combinedRadius)
            {
                if (!gSuppressGravityDebug)
                    SIM_LOG("[COLLIDE] seg=%d line=(%.5f,%.5f)-(%.5f,%.5f) pt=(%.5f,%.5f) dist=%.5f eRadius=%.5f combined=%.5f\n",
                           s, ax, ay, bx, by, ecx, ecy, dist, eRadius, combinedRadius);
                return TRUE;
            }
        }
    }

    return FALSE;
}

// Debug/indicator ONLY -- never used by anything that actually moves the
// robot (robotCollidesWithEnvironment, dropActiveRobotToRest, and
// resolveUpwardIfPenetrating all keep calling
// pointCollidesWithAnyEnvironmentStroke directly, unpadded, so none of
// gravity/settle's real physics changes here). See
// SIMULATION_CONTACT_VISUAL_TOLERANCE's own comment (config.h) for why a
// perfectly normal resting contact point still needs this extra slop to
// actually show up red instead of reading as a miss.
static float simContactVisualToleranceWorld(void)
{
    return robotLengthToEnvWorld(SIMULATION_CONTACT_VISUAL_TOLERANCE);
}

static BOOL pointVisuallyContactsEnvironmentStroke(float ecx, float ecy, float eRadius)
{
    return pointCollidesWithAnyEnvironmentStroke(ecx, ecy, eRadius + simContactVisualToleranceWorld());
}

// Edge counterpart to pointCollidesWithAnyEnvironmentStroke, for a
// world-space robot EDGE (ax,ay)-(bx,by) rather than a single point --
// used by Rocky's rectangle sides (the actual boundary of a real filled
// shape, same as a circle's own surface, so eRadius is always 0.0f here
// -- see the original per-sample call site's own comment on why edges
// need zero extra robot-side padding). Exact via distSegmentToSegment,
// not sampled: replaces what used to be a per-edge point-sampling loop
// (fixed, then adaptively grown up to a several-thousand-sample safety
// cap -- see git history for that attempt) with ONE closed-form distance
// check per environment piece -- both correct at any zoom (no
// discretization gap for a fast/long edge to slip through) and far
// cheaper (a piece is now tested once instead of up to thousands of
// times). If outT is non-NULL and this returns TRUE, it's filled with
// the parametric position (0=caller's A start, 1=A's end) of the closest
// point ON THE CALLER'S EDGE -- callers that only need yes/no
// (robotCollidesWithEnvironment) pass NULL; callers drawing a contact
// marker (the live/debug dot overlays) use it to place a single dot
// exactly where contact is happening, by re-applying this same t to
// their own robot-space edge endpoints.
static BOOL edgeCollidesWithAnyEnvironmentStroke(float ax, float ay, float bx, float by,
                                                  float eRadius, float* outT)
{
    float envHalfWidth = simEnvLineHalfWidthWorld();
    float combinedRadius = eRadius + envHalfWidth;

    // Query box for the broad phase: the robot edge's own bounding box.
    float qMinX = (ax < bx) ? ax : bx, qMaxX = (ax < bx) ? bx : ax;
    float qMinY = (ay < by) ? ay : by, qMaxY = (ay < by) ? by : ay;

    for (int s = 0; s < canvas.segmentResultCount; s++)
    {
        int start = segmentStarts[s];
        int count = segmentCounts[s];
        if (count < 2) continue;
        if (!envSegmentBoxNear(s, qMinX, qMinY, qMaxX, qMaxY, combinedRadius)) continue; // broad phase

        for (int i = 0; i < count - 1; i++)
        {
            float ex0 = segmentPointsWorld[(start + i) * 2];
            float ey0 = segmentPointsWorld[(start + i) * 2 + 1];
            float ex1 = segmentPointsWorld[(start + (i + 1)) * 2];
            float ey1 = segmentPointsWorld[(start + (i + 1)) * 2 + 1];
            if (!envPieceBoxNear(ex0, ey0, ex1, ey1, qMinX, qMinY, qMaxX, qMaxY, combinedRadius)) continue;

            float t;
            float dist = distSegmentToSegment(ax, ay, bx, by, ex0, ey0, ex1, ey1, NULL, NULL, &t);

            if (dist < combinedRadius)
            {
                if (!gSuppressGravityDebug)
                    SIM_LOG("[COLLIDE] seg=%d line=(%.5f,%.5f)-(%.5f,%.5f) edge=(%.5f,%.5f)-(%.5f,%.5f) dist=%.5f eRadius=%.5f combined=%.5f\n",
                           s, ex0, ey0, ex1, ey1, ax, ay, bx, by, dist, eRadius, combinedRadius);
                // t is the parametric position (0=A's start, 1=A's end)
                // of the closest point ON THE CALLER'S EDGE -- handed
                // back instead of raw env-space coordinates so a caller
                // that wants to draw a marker in ROBOT-space can just
                // re-apply this same t to its own robot-space endpoints
                // (rectEdges[e].start/end) rather than having to invert
                // the robot<->env world mapping.
                if (outT) *outT = t;
                return TRUE;
            }
        }
    }

    return FALSE;
}

// Debug-only companion to pointCollidesWithAnyEnvironmentStroke: returns
// the raw geometric distance from (ecx, ecy) to the NEAREST environment
// segment's centerline, with no radius/padding applied at all -- unlike
// the real collision check, this doesn't stop early and doesn't care
// about any combinedRadius, it just answers "how far is this point from
// the drawn line." Exists so the [GRAVITY] per-body-part dump below can
// report an actual signed gap (dist - combinedRadius: positive = still
// floating, negative = overlapping, ~0 = flush) for each part instead of
// a bottom_y estimate that can silently go stale if the real collision
// formula changes and this debug math doesn't get updated to match --
// exactly what happened when simEnvLineHalfWidthWorld's env-side padding
// was added to collision but the old bottom_y print was never updated to
// include it, making logs look like there was a mystery gap that was
// really just this print lagging behind the actual math.
static float nearestEnvDistance(float ecx, float ecy)
{
    float best = -1.0f;

    for (int s = 0; s < canvas.segmentResultCount; s++)
    {
        int start = segmentStarts[s];
        int count = segmentCounts[s];
        if (count < 2) continue;

        // Broad phase: skip a segment/piece whose bounding box is already
        // farther away than the best distance found so far.
        const float* sb = &segmentBoundsWorld[s * 4];
        if (best >= 0.0f && pointBoxDist2(ecx, ecy, sb[0], sb[1], sb[2], sb[3]) > best * best) continue;

        for (int i = 0; i < count - 1; i++)
        {
            float ax = segmentPointsWorld[(start + i) * 2];
            float ay = segmentPointsWorld[(start + i) * 2 + 1];
            float bx = segmentPointsWorld[(start + (i + 1)) * 2];
            float by = segmentPointsWorld[(start + (i + 1)) * 2 + 1];
            if (best >= 0.0f
                && pointBoxDist2(ecx, ecy, (ax < bx) ? ax : bx, (ay < by) ? ay : by,
                                 (ax < bx) ? bx : ax, (ay < by) ? by : ay) > best * best)
                continue;

            float dist = distPointToSegment(ecx, ecy, ax, ay, bx, by);
            if (best < 0.0f || dist < best)
                best = dist;
        }
    }

    return best; // -1.0f if there are no traced segments at all
}

// Simulation mode's mass-center drop line (renderer.c's
// drawSimulationMassCenterDropLine) needs to know where a straight drop
// from `from` (robot-local space) actually reaches the environment.
// Marches straight down (decreasing robot-local Y, same X) and returns
// the robot-local Y where it makes contact.
//
// Sphere-traces rather than stepping by a fixed increment: nearestEnvDistance
// already returns the TRUE distance from any point to the closest traced
// segment, so nothing anywhere around that point is closer than that --
// advancing by exactly that distance each iteration can never step clean
// over a genuinely thin environment line the way a fixed coarse step
// could (miss it by landing a sample on either side without ever testing
// a point close enough to register), and it still converges in only a
// handful of iterations for the common case of ground not too far below.
// nearestEnvDistance itself works in env-world units, not robot-local
// ones, so each step is converted back via robotLengthToEnvWorld's own
// scale ratio (see its comment -- this mapping is a uniform scale, no
// rotation, so a straight vertical march in robot-local space really
// does correspond to a straight vertical march in env-world space too).
//
// SIM_MASS_CENTER_DROP_MAX_LENGTH/MAX_ITERATIONS (config.h) bound the
// search so a robot with nothing drawn underneath it doesn't search
// forever -- it just draws a line of that capped length instead.
static float simFindGroundBelowRobotPoint(PointF from)
{
    float envScale = robotLengthToEnvWorld(1.0f); // env-world units per one robot-local unit
    if (envScale <= 0.0f)
        return from.y - SIM_MASS_CENTER_DROP_MAX_LENGTH; // defensive -- zoom/scale should never be <= 0

    float touchThreshold = simEnvLineHalfWidthWorld();
    float traveled = 0.0f;

    for (int i = 0; i < SIM_MASS_CENTER_DROP_MAX_ITERATIONS; i++)
    {
        float y = from.y - traveled;
        float ecx, ecy;
        robotPointToEnvWorld(from.x, y, &ecx, &ecy);

        float envDist = nearestEnvDistance(ecx, ecy);
        if (envDist < 0.0f)
            break; // nothing traced in the environment at all -- fall back below

        if (envDist <= touchThreshold)
            return y; // close enough to call it contact

        traveled += envDist / envScale;
        if (traveled >= SIM_MASS_CENTER_DROP_MAX_LENGTH)
            break;
    }

    return from.y - SIM_MASS_CENTER_DROP_MAX_LENGTH;
}

// Purely for the cyan "sampled but not touching" dots drawSimulationLiveContactDots
// restores around the knee/foot circles below, by explicit request -- NOT
// used for any actual hit detection, which still goes through the exact,
// unsampled findCircleContactDirections just below. Re-added after being
// removed as dead code once its old caller (drawSimulationContactDebug)
// was deleted; brought back now that there's a new caller again.
static void computeCircleSamplePoints(PointF center, float radius, PointF outPts[ARC_SAMPLE_COUNT])
{
    for (int i = 0; i < ARC_SAMPLE_COUNT; i++)
    {
        float theta = (2.0f * 3.14159265f * i) / ARC_SAMPLE_COUNT;
        outPts[i].x = center.x + radius * cosf(theta);
        outPts[i].y = center.y + radius * sinf(theta);
    }
}

// Max distinct simultaneous contact points findCircleContactDirections
// (below) will ever report for one circle -- a robot's leg circle only
// realistically touches a small handful of separate places at once (a
// V-shaped notch is 2; more than that would mean an extremely jagged
// hand-drawn environment), so this is a generous cap, not a tuned limit.
#define MAX_CIRCLE_CONTACT_POINTS 4

// EXACT (no sampling, no discretization gap at any zoom), used by the
// always-on live-dot renderer (drawSimulationLiveContactDots) where
// reliability matters more than illustrative detail. Walks every
// environment piece directly and groups
// consecutive in-range pieces (within combinedRadius -- eRadius here is
// the circle's OWN real radius, same padding formula
// pointCollidesWithAnyEnvironmentStroke and its visual-tolerance wrapper
// use) into one "run" per stroke -- an ORDINARY single contact against a
// long or gently curved line, in-range across many consecutive pieces,
// still collapses to exactly one reported point (a run only ends when a
// piece goes OUT of range, or the pieces belong to a different traced
// stroke); only a genuinely separate contact area starts a second run.
// Each run contributes its own single closest point. Returns the number
// of contacts found (0 if none), filling up to maxContacts slots in
// outDirX/outDirY with unit directions from (ecx,ecy) toward each
// contact point, so the caller can place each dot by re-applying that
// direction, scaled by the shape's OWN robot-space radius, to its own
// robot-space center -- same reasoning already used for the rectangle
// edges' parametric t.
static int findCircleContactDirections(float ecx, float ecy, float eRadius,
                                        float outDirX[], float outDirY[], int maxContacts)
{
    float combinedRadius = eRadius + simContactVisualToleranceWorld() + simEnvLineHalfWidthWorld();
    int count = 0;

    for (int s = 0; s < canvas.segmentResultCount && count < maxContacts; s++)
    {
        int start = segmentStarts[s];
        int pieceCount = segmentCounts[s];
        if (pieceCount < 2) continue;
        if (!envSegmentBoxNear(s, ecx, ecy, ecx, ecy, combinedRadius)) continue; // broad phase

        BOOL inRun = FALSE;
        float bestDist = 0.0f, bestX = 0.0f, bestY = 0.0f;

        for (int i = 0; i < pieceCount - 1; i++)
        {
            float ax = segmentPointsWorld[(start + i) * 2];
            float ay = segmentPointsWorld[(start + i) * 2 + 1];
            float bx = segmentPointsWorld[(start + (i + 1)) * 2];
            float by = segmentPointsWorld[(start + (i + 1)) * 2 + 1];

            // A piece the broad phase rejects is simply a miss -- it
            // still has to reach the else-branch below so an open run
            // gets closed exactly as before.
            float px = 0.0f, py = 0.0f;
            float dist = combinedRadius;
            if (envPieceBoxNear(ax, ay, bx, by, ecx, ecy, ecx, ecy, combinedRadius))
                dist = closestPointOnSegment(ecx, ecy, ax, ay, bx, by, &px, &py, NULL);

            if (dist < combinedRadius)
            {
                if (!inRun || dist < bestDist)
                {
                    bestDist = dist;
                    bestX = px;
                    bestY = py;
                }
                inRun = TRUE;
            }
            else if (inRun)
            {
                if (count < maxContacts)
                {
                    float dx = bestX - ecx, dy = bestY - ecy;
                    float len = sqrtf(dx * dx + dy * dy);
                    outDirX[count] = (len > 1e-6f) ? dx / len : 0.0f;
                    outDirY[count] = (len > 1e-6f) ? dy / len : -1.0f;
                    count++;
                }
                inRun = FALSE;
            }
        }

        if (inRun && count < maxContacts)
        {
            float dx = bestX - ecx, dy = bestY - ecy;
            float len = sqrtf(dx * dx + dy * dy);
            outDirX[count] = (len > 1e-6f) ? dx / len : 0.0f;
            outDirY[count] = (len > 1e-6f) ? dy / len : -1.0f;
            count++;
        }
    }

    return count;
}

// TRUE if any of the robot's 5 body circles (head/butt/hip/knee/foot --
// see computeSemniBodyCircles, renderer.h) OR its 6 connecting fillet arcs
// (seam1/2, thigh1/2, shin1/2 -- see computeSemniArcPoints) overlaps any
// Environment-layer stroke, in the robot's CURRENT pose/position. Used by
// the G ("gravity") hotkey below to stop the robot from sinking through
// whatever ground the user has drawn. The arcs are sampled as poly-lines
// (computeSemniArcPoints walks the exact same trimmed curve drawArc
// renders, not the full untrimmed fillet circle -- that would be far too
// generous) and tested with a fixed stand-in thickness, since -- unlike
// the circles -- they're drawn as bare curves with no radius of their own.
// Generalized over all three robot kinds (see app.h's RobotKind) so
// Simulation mode's gravity/collision/drag all act on whichever robot is
// currently active (app.robotScene.activeKind), not just Semni. Every
// call site below always passed app.robotScene.robot -- the live global
// state, never a hypothetical detached copy -- so there was nothing lost
// dropping the parameter and reading app.robotScene directly per kind.
//
// Semni's branch is untouched line-for-line from the original
// single-robot version. Stilo (6 body circles + 6 fillet arcs, same
// "circles + connecting curves" shape as Semni, just a different count)
// follows the identical pattern. Rocky additionally has a rectangular
// torso (no equivalent in Semni/Stilo) with no radius of its own, so its
// 4 edges are sampled the same way the fillet arcs are -- bare outline
// curves padded by SIMULATION_ARC_COLLISION_THICKNESS -- rather than left
// untested, which would let the box visually sink through the ground
// while only the leg's circles were ever checked.
static BOOL robotCollidesWithEnvironment(void)
{
    float eArcThickness = robotLengthToEnvWorld(SIMULATION_ARC_COLLISION_THICKNESS);

    switch (app.robotScene.activeKind)
    {
        case ROBOT_KIND_ROCKY:
        {
            // Testing-only toggles (ID_ROCKY_TOGGLE_LEG_BUTTON/
            // ID_ROCKY_TOGGLE_BODY_BUTTON, see app.h's Rocky comment) --
            // a hidden part is dropped out of collision entirely, not
            // just rendering (drawRocky has the matching guard), so
            // gravity/settle behavior for the remaining part alone can
            // actually be tested without the hidden part's own geometry
            // silently still anchoring/blocking it.
            if (!app.robotScene.rocky.legHidden)
            {
                CircleSegment bodyCircles[NUM_ROCKY_BODY_CIRCLES];
                computeRockyBodyCircles(app.robotScene.rocky, bodyCircles);

                for (int c = 0; c < NUM_ROCKY_BODY_CIRCLES; c++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(bodyCircles[c].center.x, bodyCircles[c].center.y, &ecx, &ecy);
                    float eRadius = robotLengthToEnvWorld(bodyCircles[c].radius);

                    if (pointCollidesWithAnyEnvironmentStroke(ecx, ecy, eRadius))
                        return TRUE;
                }

                PointF arcPts[NUM_ROCKY_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
                int arcCounts[NUM_ROCKY_CIRCLE_SEGMENTS];
                computeRockyArcPoints(app.robotScene.rocky, arcPts, arcCounts);

                // Was a per-SAMPLE-POINT test (each of the ARC_SAMPLE_COUNT
                // points making up the arc's polyline, individually padded
                // by eArcThickness and checked in isolation) -- a real
                // report showed the shin arc visibly resting against the
                // ground with NO contact point marked there at all, because
                // the true touch point fell between two consecutive
                // samples: neither sample's own tiny padded circle happened
                // to overlap the ground line, even though the polyline
                // SEGMENT connecting them clearly did. Exactly the same
                // discretization gap the rectangle edges used to have (see
                // edgeCollidesWithAnyEnvironmentStroke's own comment) --
                // fixed there by testing exact edges instead of sampled
                // points, so it's fixed here the same way: test each
                // consecutive PAIR of arc samples as a line segment via
                // edgeCollidesWithAnyEnvironmentStroke (still padded by
                // eArcThickness, same as before -- the curve still has no
                // real thickness of its own), instead of each sample alone.
                // drawArc renders this exact same polyline, so this now
                // tests precisely what's actually drawn on screen, with no
                // gap for a touch point to hide in between samples.
                for (int a = 0; a < NUM_ROCKY_CIRCLE_SEGMENTS; a++)
                {
                    for (int i = 0; i + 1 < arcCounts[a]; i++)
                    {
                        float ax, ay, bx, by;
                        robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &ax, &ay);
                        robotPointToEnvWorld(arcPts[a][i + 1].x, arcPts[a][i + 1].y, &bx, &by);

                        if (edgeCollidesWithAnyEnvironmentStroke(ax, ay, bx, by, eArcThickness, NULL))
                            return TRUE;
                    }
                }
            }

            // Unlike the fillet arcs just above -- bare 1D curves with no
            // inherent thickness of their own, which is why they need
            // eArcThickness as a stand-in -- these rectangle edges are the
            // actual boundary of a real FILLED shape (the torso rect),
            // rendered as literally these same corner points with nothing
            // extra added around them (drawRockyBodyRect uses identical
            // corner construction to computeRockyRectSegments). That
            // makes a rectangle edge point exactly like a circle's own
            // surface -- real geometry that already needs zero extra
            // robot-side slop -- not like a bare curve that needs padding
            // invented for it. Passing eArcThickness here was treating a
            // real edge as if it were a bare curve, which meant collision
            // stopped the rectangle eArcThickness (~0.0004 world units)
            // above the environment's actual rendered surface -- a small
            // but real, constant, structural gap, not a search-precision
            // residual (see gap= in the [GRAVITY] debug dump: edges were
            // converging to exactly eArcThickness above 0, every time).
            // Passing 0.0f instead means combinedRadius inside
            // pointCollidesWithAnyEnvironmentStroke reduces to just
            // simEnvLineHalfWidthWorld() alone -- the same treatment
            // circles already get -- so the rectangle's real edge now
            // settles flush against the environment's real rendered
            // surface, with nothing invented added on either side.
            if (!app.robotScene.rocky.bodyHidden)
            {
                RockyEdgeSegment rectEdges[NUM_ROCKY_RECT_SEGMENTS];
                computeRockyRectSegments(app.robotScene.rocky, rectEdges);

                // Was a per-edge point-sampling loop (ARC_SAMPLE_COUNT,
                // later grown adaptively -- see git history/backups for
                // that attempt's own comment) -- both versions could,
                // even at their densest, only ever narrow the odds of a
                // fast/long edge slipping through a thinned-out collision
                // band between two samples, never fully rule it out, and
                // the adaptive version's sample counts (needed to even
                // approach "fully ruled out" at high sim-camera zoom)
                // made this the single most expensive check in the whole
                // gravity tick -- visible as real lag once the sample
                // count climbed into the hundreds or thousands per edge,
                // computed up to GRAVITY_CONTACT_SEARCH_ITERATIONS times
                // per tick. A straight robot edge and a straight
                // environment line piece are both plain line segments,
                // so their true minimum distance has an exact closed-form
                // answer (edgeCollidesWithAnyEnvironmentStroke) -- zero
                // sampling, zero discretization gap at ANY zoom, and each
                // environment piece is now tested exactly once instead of
                // up to thousands of times.
                for (int e = 0; e < NUM_ROCKY_RECT_SEGMENTS; e++)
                {
                    float esx, esy, eex, eey;
                    robotPointToEnvWorld(rectEdges[e].start.x, rectEdges[e].start.y, &esx, &esy);
                    robotPointToEnvWorld(rectEdges[e].end.x, rectEdges[e].end.y, &eex, &eey);

                    if (edgeCollidesWithAnyEnvironmentStroke(esx, esy, eex, eey, 0.0f, NULL))
                        return TRUE;
                }
            }

            return FALSE;
        }

        case ROBOT_KIND_STILO:
        {
            CircleSegment bodyCircles[NUM_STILO_BODY_CIRCLES];
            computeStiloBodyCircles(app.robotScene.stilo, bodyCircles);

            for (int c = 0; c < NUM_STILO_BODY_CIRCLES; c++)
            {
                float ecx, ecy;
                robotPointToEnvWorld(bodyCircles[c].center.x, bodyCircles[c].center.y, &ecx, &ecy);
                float eRadius = robotLengthToEnvWorld(bodyCircles[c].radius);

                if (pointCollidesWithAnyEnvironmentStroke(ecx, ecy, eRadius))
                    return TRUE;
            }

            PointF arcPts[NUM_STILO_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
            int arcCounts[NUM_STILO_CIRCLE_SEGMENTS];
            computeStiloArcPoints(app.robotScene.stilo, arcPts, arcCounts);

            for (int a = 0; a < NUM_STILO_CIRCLE_SEGMENTS; a++)
            {
                for (int i = 0; i < arcCounts[a]; i++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &ecx, &ecy);

                    if (pointCollidesWithAnyEnvironmentStroke(ecx, ecy, eArcThickness))
                        return TRUE;
                }
            }

            return FALSE;
        }

        case ROBOT_KIND_SEMNI:
        default:
        {
            CircleSegment bodyCircles[NUM_ROBOT_BODY_CIRCLES];
            computeSemniBodyCircles(app.robotScene.robot, bodyCircles);

            for (int c = 0; c < NUM_ROBOT_BODY_CIRCLES; c++)
            {
                float ecx, ecy;
                robotPointToEnvWorld(bodyCircles[c].center.x, bodyCircles[c].center.y, &ecx, &ecy);
                float eRadius = robotLengthToEnvWorld(bodyCircles[c].radius);

                if (pointCollidesWithAnyEnvironmentStroke(ecx, ecy, eRadius))
                    return TRUE;
            }

            PointF arcPts[NUM_ROBOT_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
            int arcCounts[NUM_ROBOT_CIRCLE_SEGMENTS];
            computeSemniArcPoints(app.robotScene.robot, arcPts, arcCounts);

            for (int a = 0; a < NUM_ROBOT_CIRCLE_SEGMENTS; a++)
            {
                for (int i = 0; i < arcCounts[a]; i++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &ecx, &ecy);

                    if (pointCollidesWithAnyEnvironmentStroke(ecx, ecy, eArcThickness))
                        return TRUE;
                }
            }

            return FALSE;
        }
    }
}

// Which physical part of the leg a RockyLegContact came from -- lets a
// caller tell "the knee circle is what's touching" apart from "a shin arc
// point is what's touching" without comparing world positions against an
// epsilon. See rockyKneeBendWouldAbandonArcContact below for why this
// distinction matters: Probe 2's knee bend rotates the WHOLE shin (arc
// included) rigidly around the knee joint, which can only ever preserve a
// KNEE or FOOT contact (their own distance from the knee joint doesn't
// change), never an ARC contact (an arc point's distance from the knee
// joint is fixed too, but its ANGLE around the knee sweeps with the bend,
// so the specific point that was touching stops touching the instant the
// knee moves at all).
typedef enum { ROCKY_LEG_CONTACT_KNEE, ROCKY_LEG_CONTACT_FOOT, ROCKY_LEG_CONTACT_ARC,
               // Not actually a LEG part -- a Rocky rectangle corner --
               // only ever produced by rockyToppleContactPoints below, never
               // by rockyLegContactPoints itself. Kept in this same enum
               // (rather than a whole separate type) so rockyToppleContactPoints
               // can reuse RockyLegContact/RockyLegContactKind as-is instead
               // of duplicating both. Deliberately never produced by
               // rockyLegContactPoints -- legRestingOnImmovableJoint further
               // below specifically wants to know whether something on the
               // LEG itself has settled, regardless of whether the body is
               // separately resting on a corner, and relies on this value
               // never showing up from that call. See rockyToppleContactPoints'
               // own comment for the full story.
               ROCKY_LEG_CONTACT_BODY_CORNER } RockyLegContactKind;

// One candidate contact point on the leg -- either joint circle, or a
// single sample point along one of the two shin fillet arcs -- together
// with its clearance to the environment, using the same nearestEnvDistance
// minus combinedRadius convention every other clearance check in this file
// already uses (see e.g. Probe 2's own baseFootClearance just below).
typedef struct { PointF world; float clearance; RockyLegContactKind kind; } RockyLegContact;

// Finds the CLOSEST and SECOND-CLOSEST points on the whole leg outline --
// knee circle, foot circle, AND both shin fillet arcs (computeRockyArcPoints'
// shin1/shin2, the convex and concave curves connecting them) -- to the
// environment right now. rockyTopplePivotWorld below wants the closest, to
// pivot Probe 1's rotation around; rockyDanglingPointClearance wants the
// second-closest, the "next in line" contact Probe 1's rotation is actually
// trying to bring down.
//
// This used to only ever compare the knee and foot CIRCLES -- correct when
// one of those two joints is what's actually touching, but wrong whenever
// the leg rests on its SIDE instead, where the shin fillet arc between them
// genuinely bulges out past both circles (that's the whole point of a
// fillet: a smooth outer curve instead of a sharp inner corner) and is the
// TRUE contact. Neither knee nor foot is a clean winner in that case -- both
// merely hover nearby, roughly tied -- so which one used to "win" the old
// knee-vs-foot comparison could flip from tick to tick on tiny numeric
// noise. Since Probe 1 pivots around whatever rockyTopplePivotWorld
// returns, a flip meant the rotation suddenly held a DIFFERENT point fixed
// than the tick before, undoing whatever alignment progress had just been
// made and restarting around the new point -- exactly what read as the leg
// oscillating back and forth forever instead of settling once its convex
// side was what actually touched the ground. Including the arc samples as
// candidates here fixes that: the true lowest point on the whole leg
// outline wins, arc included, so the pivot stops jumping between two
// points that were never the real contact to begin with.
static void rockyLegContactPoints(const Rocky* r, RockyLegContact* closest, RockyLegContact* secondClosest)
{
    PointF center = getRockyCenter(*r);
    PointF kneeWorld = rotatePoint(r->kneeCircle, center, r->angle);
    PointF footWorld = jointToWorld(r->footCircle, r->kneeCircle, r->kneeAngle, center, r->angle);

    float kecx, kecy, fecx, fecy;
    robotPointToEnvWorld(kneeWorld.x, kneeWorld.y, &kecx, &kecy);
    robotPointToEnvWorld(footWorld.x, footWorld.y, &fecx, &fecy);

    float kneeCombinedRadius = robotLengthToEnvWorld(r->kneeRadius) + simEnvLineHalfWidthWorld();
    float footCombinedRadius = robotLengthToEnvWorld(r->footRadius) + simEnvLineHalfWidthWorld();

    RockyLegContact best = { kneeWorld, nearestEnvDistance(kecx, kecy) - kneeCombinedRadius, ROCKY_LEG_CONTACT_KNEE };
    RockyLegContact second = { footWorld, nearestEnvDistance(fecx, fecy) - footCombinedRadius, ROCKY_LEG_CONTACT_FOOT };
    if (second.clearance < best.clearance)
    {
        RockyLegContact tmp = best;
        best = second;
        second = tmp;
    }

    // Bare curves, same eArcThickness stand-in for their own missing
    // thickness that robotCollidesWithEnvironment's own arc test already
    // uses (see its comment) -- consistent with treating a circle's
    // clearance as nearestEnvDistance minus its OWN radius plus the
    // environment's half-width, just with eArcThickness standing in for
    // "the arc's own radius" since a bare curve has none of its own.
    float eArcThickness = robotLengthToEnvWorld(SIMULATION_ARC_COLLISION_THICKNESS);
    float arcCombinedRadius = eArcThickness + simEnvLineHalfWidthWorld();

    PointF arcPts[NUM_ROCKY_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
    int arcCounts[NUM_ROCKY_CIRCLE_SEGMENTS];
    computeRockyArcPoints(*r, arcPts, arcCounts);

    for (int a = 0; a < NUM_ROCKY_CIRCLE_SEGMENTS; a++)
    {
        for (int i = 0; i < arcCounts[a]; i++)
        {
            float aecx, aecy;
            robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &aecx, &aecy);
            float clearance = nearestEnvDistance(aecx, aecy) - arcCombinedRadius;

            if (clearance < best.clearance)
            {
                second = best;
                best.world = arcPts[a][i];
                best.clearance = clearance;
                best.kind = ROCKY_LEG_CONTACT_ARC;
            }
            else if (clearance < second.clearance)
            {
                second.world = arcPts[a][i];
                second.clearance = clearance;
                second.kind = ROCKY_LEG_CONTACT_ARC;
            }
        }
    }

    *closest = best;
    *secondClosest = second;
}

// ---- Simulation "show contact" debug overlay (plain C, no modifier) ----

// On by default -- so the pivot/non-pivot contact dots below are visible
// from the moment Simulation mode starts, without needing to remember to
// press C first. Read by drawSimulationLiveContactDots, called from
// renderCombinedFrame right after the robot itself is drawn.
static BOOL showContactDebug = TRUE;

// Draws NOTHING for a point that isn't currently colliding -- just one
// dot exactly where contact is actually happening right now (red for the
// current toppling pivot, half-size orange for every other genuinely
// touching point), gated by the same plain-C toggle (showContactDebug)
// that used to gate a much noisier full-sample overlay here (every point
// robotCollidesWithEnvironment tests, hit or miss, big red or dim green --
// removed by explicit request once this replaced it, along with the
// one-shot [CONTACT] console dump that only that older overlay printed).
// Live only: no accumulated trail, a dot disappears the instant that
// point stops colliding, same as any other per-frame overlay.
//
// Same per-kind sampling robotCollidesWithEnvironment itself uses (body
// circles, shin/thigh fillet arcs, and for Rocky the rectangle edges),
// including Rocky's own legHidden/bodyHidden testing toggles
// (ID_ROCKY_TOGGLE_LEG_BUTTON/ID_ROCKY_TOGGLE_BODY_BUTTON) -- a hidden
// part isn't sampled here either, consistent with it not being sampled
// for real collision.
// Defined further down with the robot-generic settle accessors.
static void semniContactCandidates(const Semni* sm, BOOL legPart, RockyLegContact* best, RockyLegContact* second);

static void drawSimulationLiveContactDots(void)
{
    if (appMode != APP_MODE_SIMULATION) return;
    if (!showContactDebug) return; // now what the plain-C toggle actually gates

    // This calls pointCollidesWithAnyEnvironmentStroke up to ~250 times
    // EVERY FRAME purely to decide dot color -- suppressed here so that
    // doesn't flood the console with [COLLIDE] lines for as long as the
    // toggle leaves this overlay switched on.
    BOOL savedSuppressGravityDebug = gSuppressGravityDebug;
    gSuppressGravityDebug = TRUE;

    const float liveContactDotRadius = 0.0015f;

    // Pivot (red) and non-pivot (orange) Rocky-leg dots are the SAME size
    // -- only color tells them apart. Bumped back up from 0.008f, by
    // explicit request. Still its own constant rather than reusing
    // liveContactDotRadius (0.0015f, unchanged, still used by every OTHER
    // red dot this function draws -- Rocky's rectangle edges, and the
    // whole STILO/SEMNI cases below -- none of which this request
    // touches). The pivot dot is still always drawn LAST/on top of every
    // orange dot (see the deferred pivotWorld draw at the bottom of the
    // ROCKY case below), so an exact-same-size overlap still resolves in
    // red's favor rather than whichever happened to be tested last.
    const float liveContactDotRadiusPivot = 0.016f;
    const float liveContactDotRadiusNonPivot = liveContactDotRadiusPivot;

    // Restores the dim "sampled but not touching" dots a real report
    // pointed out as missing since drawSimulationContactDebug (the old
    // toggle-gated diagnostic overlay this function replaced) was deleted
    // -- that one drew a small cyan dot at every point it tested, hit or
    // miss, not just the hits; this function only ever drew the hits.
    // Every case below now draws one of these wherever it already has a
    // sample point in hand that DIDN'T register as touching, alongside
    // (never instead of) its own existing hit-color logic.
    const float liveMissDotRadius = 0.006f;
    const float liveMissR = 0.25f, liveMissG = 0.85f, liveMissB = 0.95f, liveMissA = 0.7f;

    float eArcThickness = robotLengthToEnvWorld(SIMULATION_ARC_COLLISION_THICKNESS);

    switch (app.robotScene.activeKind)
    {
        case ROBOT_KIND_ROCKY:
        {
            if (!app.robotScene.rocky.legHidden)
            {
                // Which leg point is the CURRENT toppling pivot (same
                // point rockyTopplePivotWorld/Probe 1 rotate around) --
                // computed once here, by explicit request, so every dot
                // below can tell "this is the point toppling is actually
                // pivoting on" (drawn red, last, on top) apart from "this
                // is just ANOTHER point that also happens to be touching
                // right now" (a non-pivot contact, drawn orange). Only the
                // dot's own color/size/draw-order changes here -- no
                // recoloring of the knee/foot/shin outline itself, per
                // explicit request.
                RockyLegContact pivotContact, pivotSecond;
                rockyLegContactPoints(&app.robotScene.rocky, &pivotContact, &pivotSecond);

                // The single pivot point's own world position, drawn once
                // at the very end of this case instead of inline where
                // it's found -- see liveContactDotRadiusPivot's comment
                // above for why deferring it is what actually prevents
                // overlap. pivotHasContact stays FALSE (nothing drawn) in
                // the (normal) case where the pivot itself isn't currently
                // registering as a genuine hit by this function's own
                // exact tests, even though rockyLegContactPoints picked it
                // as closest -- there is then nothing red to draw at all,
                // only whichever orange points are genuinely touching.
                BOOL pivotHasContact = FALSE;
                float pivotDrawX = 0.0f, pivotDrawY = 0.0f;

                CircleSegment bodyCircles[NUM_ROCKY_BODY_CIRCLES];
                computeRockyBodyCircles(app.robotScene.rocky, bodyCircles);

                for (int c = 0; c < NUM_ROCKY_BODY_CIRCLES; c++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(bodyCircles[c].center.x, bodyCircles[c].center.y, &ecx, &ecy);
                    float eRadius = robotLengthToEnvWorld(bodyCircles[c].radius);

                    // EXACT test (findCircleContactDirections), not the
                    // debug overlay's sampled ring above -- this renderer
                    // is always on, so it can't afford the sampled ring's
                    // discretization gap (a fixed 41-point ring can leave
                    // the true tangent point sitting between two samples,
                    // making a genuinely-touching circle show NO dot at
                    // all). Finds every distinct contact this circle
                    // actually has (handles knee+foot both touching at
                    // once, and a single circle touching in two places)
                    // with zero discretization error at any zoom.
                    //
                    // Index 0 is always the knee, index 1 always the foot
                    // (computeRockyBodyCircles' own comment) -- matched
                    // straight against pivotContact.kind to tell this
                    // circle's contacts apart: the pivot circle's contacts
                    // are deferred to the end (drawn red, on top), a
                    // merely-touching non-pivot circle's are drawn right
                    // here in orange.
                    BOOL isPivotCircle = (c == 0 && pivotContact.kind == ROCKY_LEG_CONTACT_KNEE) ||
                                         (c == 1 && pivotContact.kind == ROCKY_LEG_CONTACT_FOOT);

                    float contactDirX[MAX_CIRCLE_CONTACT_POINTS], contactDirY[MAX_CIRCLE_CONTACT_POINTS];
                    int contactCount = findCircleContactDirections(ecx, ecy, eRadius, contactDirX, contactDirY, MAX_CIRCLE_CONTACT_POINTS);
                    for (int k = 0; k < contactCount; k++)
                    {
                        float rx = bodyCircles[c].center.x + contactDirX[k] * bodyCircles[c].radius;
                        float ry = bodyCircles[c].center.y + contactDirY[k] * bodyCircles[c].radius;
                        if (isPivotCircle)
                        {
                            // Multiple contact directions are possible on
                            // one circle (see the comment above) -- if so,
                            // only the FIRST is kept as the one red dot;
                            // this circle is still the pivot either way,
                            // and drawing more than one red dot for a
                            // single pivot joint would misrepresent it as
                            // multiple separate pivot points.
                            if (!pivotHasContact)
                            {
                                pivotHasContact = TRUE;
                                pivotDrawX = rx;
                                pivotDrawY = ry;
                            }
                        }
                        else
                        {
                            drawMarkerDisc(rx, ry, liveContactDotRadiusNonPivot, 1.0f, 0.55f, 0.0f, 1.0f);
                        }
                    }

                    // Cyan "sampled but not touching" dots around this
                    // circle's own circumference -- separate from the
                    // exact findCircleContactDirections test just above,
                    // which only ever reports genuine hits and has no
                    // notion of "the points that were checked and missed."
                    // Skips drawing anywhere a sample happens to fall
                    // close enough to register as a hit itself, so this
                    // never fights the real (red/orange) dot for the same
                    // spot -- it only fills in what's actually NOT
                    // touching around the rest of the circle.
                    PointF circleSamplePts[ARC_SAMPLE_COUNT];
                    computeCircleSamplePoints(bodyCircles[c].center, bodyCircles[c].radius, circleSamplePts);
                    for (int s = 0; s < ARC_SAMPLE_COUNT; s++)
                    {
                        float secx, secy;
                        robotPointToEnvWorld(circleSamplePts[s].x, circleSamplePts[s].y, &secx, &secy);
                        if (!pointVisuallyContactsEnvironmentStroke(secx, secy, eArcThickness))
                            drawMarkerDisc(circleSamplePts[s].x, circleSamplePts[s].y, liveMissDotRadius, liveMissR, liveMissG, liveMissB, liveMissA);
                    }
                }

                PointF arcPts[NUM_ROCKY_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
                int arcCounts[NUM_ROCKY_CIRCLE_SEGMENTS];
                computeRockyArcPoints(app.robotScene.rocky, arcPts, arcCounts);

                for (int a = 0; a < NUM_ROCKY_CIRCLE_SEGMENTS; a++)
                {
                    for (int i = 0; i < arcCounts[a]; i++)
                    {
                        float ecx, ecy;
                        robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &ecx, &ecy);
                        if (pointVisuallyContactsEnvironmentStroke(ecx, ecy, eArcThickness))
                        {
                            // Same pivot-vs-non-pivot test as the circles
                            // above, but by exact position instead of a
                            // fixed index -- there's no small fixed count
                            // of "the arc points" the way there's exactly
                            // one knee and one foot, so identifying THIS
                            // sample as the pivot means matching it
                            // against pivotContact.world directly. Safe as
                            // exact equality (not an epsilon compare):
                            // both this loop and rockyLegContactPoints call
                            // the same deterministic computeRockyArcPoints
                            // on the same Rocky struct, so the pivot
                            // sample's coordinates are bit-identical here.
                            BOOL isPivotSample = (pivotContact.kind == ROCKY_LEG_CONTACT_ARC &&
                                                   arcPts[a][i].x == pivotContact.world.x &&
                                                   arcPts[a][i].y == pivotContact.world.y);
                            if (isPivotSample)
                            {
                                pivotHasContact = TRUE;
                                pivotDrawX = arcPts[a][i].x;
                                pivotDrawY = arcPts[a][i].y;
                            }
                            else
                            {
                                drawMarkerDisc(arcPts[a][i].x, arcPts[a][i].y, liveContactDotRadiusNonPivot, 1.0f, 0.55f, 0.0f, 1.0f);
                            }
                        }
                        else
                        {
                            drawMarkerDisc(arcPts[a][i].x, arcPts[a][i].y, liveMissDotRadius, liveMissR, liveMissG, liveMissB, liveMissA);
                        }
                    }
                }

                // The single deferred pivot dot, drawn last so it always
                // wins any overlap with an orange non-pivot dot (see the
                // liveContactDotRadiusPivot comment above) -- bigger
                // (liveContactDotRadiusPivot) and red, versus every
                // non-pivot dot's exactly-half-size liveContactDotRadiusNonPivot/orange.
                if (pivotHasContact)
                    drawMarkerDisc(pivotDrawX, pivotDrawY, liveContactDotRadiusPivot, 0.95f, 0.1f, 0.1f, 1.0f);
            }

            if (!app.robotScene.rocky.bodyHidden)
            {
                RockyEdgeSegment rectEdges[NUM_ROCKY_RECT_SEGMENTS];
                computeRockyRectSegments(app.robotScene.rocky, rectEdges);

                // Per-edge point sampling (not the old single-closest-point
                // test), so a rectangle lying flat along a whole line shows
                // a dot running the full length of the actual contact
                // instead of just one or two near the corners -- a real
                // report: "when its lying down it should show a lot of
                // contact points on the line and not just 2 on each
                // corner". Same sampling style the STILO/SEMNI cases and
                // the knee/foot circles above already use in this function
                // (pointVisuallyContactsEnvironmentStroke per sample, draw
                // only the hits) -- purely a visual choice for THIS
                // overlay; actual collision/settle logic elsewhere
                // (robotCollidesWithEnvironment, dropActiveRobotToRest,
                // etc.) is untouched and still uses its own exact tests.
                //
                // Point COUNT is scaled per edge by its own length, not a
                // flat ARC_SAMPLE_COUNT for every edge -- by explicit
                // request, after a flat count made the short sides read as
                // noticeably denser than the long ones (same point count,
                // packed into a much shorter run). Matches the long
                // sides' own point-to-point SPACING instead (using the
                // longest edge's spacing at the usual ARC_SAMPLE_COUNT as
                // the target), so every edge's dots read at a consistent
                // density regardless of that edge's length.
                float edgeLen[NUM_ROCKY_RECT_SEGMENTS];
                float longestEdgeLen = 0.0f;
                for (int e = 0; e < NUM_ROCKY_RECT_SEGMENTS; e++)
                {
                    float dx = rectEdges[e].end.x - rectEdges[e].start.x;
                    float dy = rectEdges[e].end.y - rectEdges[e].start.y;
                    edgeLen[e] = sqrtf(dx * dx + dy * dy);
                    if (edgeLen[e] > longestEdgeLen)
                        longestEdgeLen = edgeLen[e];
                }
                float targetSpacing = longestEdgeLen / (float)(ARC_SAMPLE_COUNT - 1);

                for (int e = 0; e < NUM_ROCKY_RECT_SEGMENTS; e++)
                {
                    int pointCount = ARC_SAMPLE_COUNT;
                    if (targetSpacing > 0.0f)
                    {
                        pointCount = (int)(edgeLen[e] / targetSpacing + 0.5f) + 1;
                        if (pointCount < 2) pointCount = 2;
                        if (pointCount > ARC_SAMPLE_COUNT) pointCount = ARC_SAMPLE_COUNT;
                    }

                    BOOL sampleHit[ARC_SAMPLE_COUNT];

                    for (int i = 0; i < pointCount; i++)
                    {
                        float t = (float)i / (float)(pointCount - 1);
                        float rx = rectEdges[e].start.x + (rectEdges[e].end.x - rectEdges[e].start.x) * t;
                        float ry = rectEdges[e].start.y + (rectEdges[e].end.y - rectEdges[e].start.y) * t;
                        sampleHit[i] = FALSE;

                        float ecx, ecy;
                        robotPointToEnvWorld(rx, ry, &ecx, &ecy);
                        // liveContactDotRadiusPivot, not the tiny
                        // liveContactDotRadius (0.0015f) -- at the leg
                        // dots' now much bigger 0.016f size, the rectangle's
                        // own contact dots would otherwise shrink to
                        // functionally invisible by comparison. Still just
                        // red, same as before -- this isn't a pivot in the
                        // leg's sense, only reusing that constant's CURRENT
                        // size so every Rocky contact dot reads at a
                        // consistent scale.
                        if (pointVisuallyContactsEnvironmentStroke(ecx, ecy, 0.0f))
                        {
                            sampleHit[i] = TRUE;
                            drawMarkerDisc(rx, ry, liveContactDotRadiusPivot, 0.95f, 0.1f, 0.1f, 1.0f);
                        }
                        else
                            drawMarkerDisc(rx, ry, liveMissDotRadius, liveMissR, liveMissG, liveMissB, liveMissA);
                    }

                    // Exact pass for contacts the samples above step over:
                    // an edge resting on a CORNER of the environment (e.g.
                    // the top of a step) touches it at a single point
                    // somewhere between two samples, so neither sample is
                    // close enough to turn red even though the edge really
                    // is resting there. For each environment segment, find
                    // the closest point on this edge exactly
                    // (distSegmentToSegment) and, if it's within the same
                    // visual tolerance the samples use, draw a red dot at
                    // it -- unless a sampled red dot (or an exact dot from
                    // a neighbouring segment, e.g. the other side of the
                    // same corner) is already within one sample spacing.
                    {
                        float ax, ay, bx, by;
                        robotPointToEnvWorld(rectEdges[e].start.x, rectEdges[e].start.y, &ax, &ay);
                        robotPointToEnvWorld(rectEdges[e].end.x, rectEdges[e].end.y, &bx, &by);
                        float pad = simEnvLineHalfWidthWorld() + simContactVisualToleranceWorld();
                        float qMinX = (ax < bx) ? ax : bx, qMaxX = (ax < bx) ? bx : ax;
                        float qMinY = (ay < by) ? ay : by, qMaxY = (ay < by) ? by : ay;
                        float spacingT = 1.0f / (float)(pointCount - 1);

                        float exactT[MAX_ARC_SEGMENTS];
                        int exactCount = 0;

                        for (int s = 0; s < canvas.segmentResultCount; s++)
                        {
                            int start = segmentStarts[s];
                            int count = segmentCounts[s];
                            if (count < 2) continue;
                            if (!envSegmentBoxNear(s, qMinX, qMinY, qMaxX, qMaxY, pad)) continue;

                            float bestDist = pad, bestT = -1.0f;
                            for (int k = 0; k < count - 1; k++)
                            {
                                float ex0 = segmentPointsWorld[(start + k) * 2];
                                float ey0 = segmentPointsWorld[(start + k) * 2 + 1];
                                float ex1 = segmentPointsWorld[(start + k + 1) * 2];
                                float ey1 = segmentPointsWorld[(start + k + 1) * 2 + 1];
                                if (!envPieceBoxNear(ex0, ey0, ex1, ey1, qMinX, qMinY, qMaxX, qMaxY, pad)) continue;

                                float t;
                                float d = distSegmentToSegment(ax, ay, bx, by, ex0, ey0, ex1, ey1, NULL, NULL, &t);
                                if (d < bestDist) { bestDist = d; bestT = t; }
                            }
                            if (bestT < 0.0f) continue; // this segment isn't touching the edge

                            BOOL covered = FALSE;
                            for (int i = 0; i < pointCount && !covered; i++)
                                if (sampleHit[i] && fabsf((float)i * spacingT - bestT) <= spacingT)
                                    covered = TRUE;
                            for (int j = 0; j < exactCount && !covered; j++)
                                if (fabsf(exactT[j] - bestT) <= spacingT)
                                    covered = TRUE;
                            if (covered) continue;

                            exactT[exactCount++] = bestT;
                            float rx = rectEdges[e].start.x + (rectEdges[e].end.x - rectEdges[e].start.x) * bestT;
                            float ry = rectEdges[e].start.y + (rectEdges[e].end.y - rectEdges[e].start.y) * bestT;
                            drawMarkerDisc(rx, ry, liveContactDotRadiusPivot, 0.95f, 0.1f, 0.1f, 1.0f);
                        }
                    }
                }
            }
            break;
        }

        case ROBOT_KIND_STILO:
        {
            CircleSegment bodyCircles[NUM_STILO_BODY_CIRCLES];
            computeStiloBodyCircles(app.robotScene.stilo, bodyCircles);

            for (int c = 0; c < NUM_STILO_BODY_CIRCLES; c++)
            {
                float ecx, ecy;
                robotPointToEnvWorld(bodyCircles[c].center.x, bodyCircles[c].center.y, &ecx, &ecy);
                float eRadius = robotLengthToEnvWorld(bodyCircles[c].radius);
                if (pointVisuallyContactsEnvironmentStroke(ecx, ecy, eRadius))
                    drawMarkerDisc(bodyCircles[c].center.x, bodyCircles[c].center.y, liveContactDotRadius, 0.95f, 0.1f, 0.1f, 1.0f);
                else
                    drawMarkerDisc(bodyCircles[c].center.x, bodyCircles[c].center.y, liveMissDotRadius, liveMissR, liveMissG, liveMissB, liveMissA);
            }

            PointF arcPts[NUM_STILO_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
            int arcCounts[NUM_STILO_CIRCLE_SEGMENTS];
            computeStiloArcPoints(app.robotScene.stilo, arcPts, arcCounts);

            for (int a = 0; a < NUM_STILO_CIRCLE_SEGMENTS; a++)
            {
                for (int i = 0; i < arcCounts[a]; i++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &ecx, &ecy);
                    if (pointVisuallyContactsEnvironmentStroke(ecx, ecy, eArcThickness))
                        drawMarkerDisc(arcPts[a][i].x, arcPts[a][i].y, liveContactDotRadius, 0.95f, 0.1f, 0.1f, 1.0f);
                    else
                        drawMarkerDisc(arcPts[a][i].x, arcPts[a][i].y, liveMissDotRadius, liveMissR, liveMissG, liveMissB, liveMissA);
                }
            }
            break;
        }

        case ROBOT_KIND_SEMNI:
        default:
        {
            // Same overlay as Rocky's case above (it used to draw one tiny dot
            // at each circle's CENTER, which is why no contact ever showed on
            // Semni's circles): exact rim contact points via
            // findCircleContactDirections, the current topple pivot in red
            // (drawn last, on top), every other touching point in orange,
            // cyan "sampled but not touching" dots around each circle and
            // along each fillet.
            //
            // Pivot = the lowest of Semni's leg/body contact candidates (the
            // same candidates Probe 1 pivots around -- semniContactCandidates).
            // Deliberately NOT settleToppleContactPoints: that updates the
            // settle's leg/body hysteresis state, and drawing must never
            // change what the simulation does.
            RockyLegContact legBest, legSecond, bodyBest, bodySecond;
            semniContactCandidates(&app.robotScene.robot, TRUE, &legBest, &legSecond);
            semniContactCandidates(&app.robotScene.robot, FALSE, &bodyBest, &bodySecond);
            RockyLegContact pivotContact = (legBest.clearance <= bodyBest.clearance) ? legBest : bodyBest;

            BOOL pivotHasContact = FALSE;
            float pivotDrawX = 0.0f, pivotDrawY = 0.0f;

            CircleSegment bodyCircles[NUM_ROBOT_BODY_CIRCLES];
            computeSemniBodyCircles(app.robotScene.robot, bodyCircles);

            for (int c = 0; c < NUM_ROBOT_BODY_CIRCLES; c++)
            {
                float ecx, ecy;
                robotPointToEnvWorld(bodyCircles[c].center.x, bodyCircles[c].center.y, &ecx, &ecy);
                float eRadius = robotLengthToEnvWorld(bodyCircles[c].radius);

                // Circle candidates carry the circle's own center as .world
                // (same computeSemniBodyCircles call), so exact equality is safe.
                BOOL isPivotCircle = (pivotContact.kind != ROCKY_LEG_CONTACT_ARC
                                      && pivotContact.world.x == bodyCircles[c].center.x
                                      && pivotContact.world.y == bodyCircles[c].center.y);

                float contactDirX[MAX_CIRCLE_CONTACT_POINTS], contactDirY[MAX_CIRCLE_CONTACT_POINTS];
                int contactCount = findCircleContactDirections(ecx, ecy, eRadius, contactDirX, contactDirY, MAX_CIRCLE_CONTACT_POINTS);
                for (int k = 0; k < contactCount; k++)
                {
                    float rx = bodyCircles[c].center.x + contactDirX[k] * bodyCircles[c].radius;
                    float ry = bodyCircles[c].center.y + contactDirY[k] * bodyCircles[c].radius;
                    if (isPivotCircle)
                    {
                        if (!pivotHasContact) { pivotHasContact = TRUE; pivotDrawX = rx; pivotDrawY = ry; }
                    }
                    else
                    {
                        drawMarkerDisc(rx, ry, liveContactDotRadiusNonPivot, 1.0f, 0.55f, 0.0f, 1.0f);
                    }
                }

                PointF circleSamplePts[ARC_SAMPLE_COUNT];
                computeCircleSamplePoints(bodyCircles[c].center, bodyCircles[c].radius, circleSamplePts);
                for (int sIdx = 0; sIdx < ARC_SAMPLE_COUNT; sIdx++)
                {
                    float secx, secy;
                    robotPointToEnvWorld(circleSamplePts[sIdx].x, circleSamplePts[sIdx].y, &secx, &secy);
                    if (!pointVisuallyContactsEnvironmentStroke(secx, secy, eArcThickness))
                        drawMarkerDisc(circleSamplePts[sIdx].x, circleSamplePts[sIdx].y, liveMissDotRadius, liveMissR, liveMissG, liveMissB, liveMissA);
                }
            }

            PointF arcPts[NUM_ROBOT_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
            int arcCounts[NUM_ROBOT_CIRCLE_SEGMENTS];
            computeSemniArcPoints(app.robotScene.robot, arcPts, arcCounts);

            for (int a = 0; a < NUM_ROBOT_CIRCLE_SEGMENTS; a++)
            {
                for (int i = 0; i < arcCounts[a]; i++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &ecx, &ecy);
                    if (pointVisuallyContactsEnvironmentStroke(ecx, ecy, eArcThickness))
                    {
                        // Arc candidates carry the exact sample as .world
                        // (same computeSemniArcPoints call) -- the seam arcs'
                        // kind is BODY_CORNER, so match by position only.
                        BOOL isPivotSample = (pivotContact.world.x == arcPts[a][i].x
                                              && pivotContact.world.y == arcPts[a][i].y);
                        if (isPivotSample)
                        {
                            pivotHasContact = TRUE;
                            pivotDrawX = arcPts[a][i].x;
                            pivotDrawY = arcPts[a][i].y;
                        }
                        else
                        {
                            drawMarkerDisc(arcPts[a][i].x, arcPts[a][i].y, liveContactDotRadiusNonPivot, 1.0f, 0.55f, 0.0f, 1.0f);
                        }
                    }
                    else
                    {
                        drawMarkerDisc(arcPts[a][i].x, arcPts[a][i].y, liveMissDotRadius, liveMissR, liveMissG, liveMissB, liveMissA);
                    }
                }
            }

            if (pivotHasContact)
                drawMarkerDisc(pivotDrawX, pivotDrawY, liveContactDotRadiusPivot, 0.95f, 0.1f, 0.1f, 1.0f);
            break;
        }
    }

    gSuppressGravityDebug = savedSuppressGravityDebug;
}

// Rigidly moves whichever robot is currently active (app.robotScene.
// activeKind) by (dx, dy) -- dispatches to translateRobot/translateRocky/
// translateStilo. Used by Simulation mode's gravity search and
// whole-robot drag below, both of which need to move "the robot on
// screen" without caring which kind that happens to be.
static void translateActiveRobot(float dx, float dy)
{
    switch (app.robotScene.activeKind)
    {
        case ROBOT_KIND_ROCKY:
            translateRocky(&app.robotScene.rocky, dx, dy);
            break;

        case ROBOT_KIND_STILO:
            translateStilo(&app.robotScene.stilo, dx, dy);
            break;

        case ROBOT_KIND_SEMNI:
        default:
            translateRobot(&app.robotScene.robot, dx, dy);
            break;
    }
}

// TRUE if (wx, wy) falls inside whichever robot is currently active --
// generalizes isPointInsideRobotBody (Semni-only, robot.c) to all three
// kinds for Simulation mode's hover/drag-start hit-testing. Stilo is pure
// circles + arcs like Semni, so it gets the identical circle-containment
// test via computeStiloBodyCircles.
//
// Rocky's rectangular torso USED to have no interior-point hit-test
// anywhere else in this app (input.c's own hoverRockyBody is a proximity
// check to the body's center handle, HIP_HANDLE_RADIUS, not a true
// rectangle-interior test) -- Simulation mode's whole-body drag matched
// that same convention instead of inventing a different one, which meant
// clicking most of the visible rectangle (anywhere outside a small
// HIP_HANDLE_RADIUS circle at its exact center) didn't start a drag at
// all, a real report of "only some part of it" grabs the body. A real
// rotated-rectangle test fixes that: undo the rectangle's own rotation
// around its center (rotatePoint by -angle, the exact inverse of however
// drawRockyBodyRect/computeRockyRectSegments built it), then it's a plain
// axis-aligned half-width/half-height box test in that unrotated frame.
//
// Both the rectangle test and the leg circles below respect Rocky's own
// legHidden/bodyHidden testing toggles (ID_ROCKY_TOGGLE_LEG_BUTTON/
// ID_ROCKY_TOGGLE_BODY_BUTTON) -- a hidden part shouldn't be draggable by
// clicking where it used to be any more than it's still rendered or
// collision-tested there.
static BOOL isPointInsideActiveRobotBody(float wx, float wy)
{
    switch (app.robotScene.activeKind)
    {
        case ROBOT_KIND_ROCKY:
        {
            PointF center = getRockyCenter(app.robotScene.rocky);

            if (!app.robotScene.rocky.bodyHidden)
            {
                float cdx = wx - center.x, cdy = wy - center.y;
                if (sqrtf(cdx * cdx + cdy * cdy) <= HIP_HANDLE_RADIUS)
                    return TRUE;

                PointF local = rotatePoint((PointF){ wx, wy }, center, -app.robotScene.rocky.angle);
                if (fabsf(local.x - center.x) <= app.robotScene.rocky.bodyHalfWidth
                    && fabsf(local.y - center.y) <= app.robotScene.rocky.bodyHalfHeight)
                    return TRUE;
            }

            if (!app.robotScene.rocky.legHidden)
            {
                CircleSegment bodyCircles[NUM_ROCKY_BODY_CIRCLES];
                computeRockyBodyCircles(app.robotScene.rocky, bodyCircles);
                for (int i = 0; i < NUM_ROCKY_BODY_CIRCLES; i++)
                {
                    float dx = wx - bodyCircles[i].center.x;
                    float dy = wy - bodyCircles[i].center.y;
                    if (sqrtf(dx * dx + dy * dy) <= bodyCircles[i].radius)
                        return TRUE;
                }
            }
            return FALSE;
        }

        case ROBOT_KIND_STILO:
        {
            CircleSegment bodyCircles[NUM_STILO_BODY_CIRCLES];
            computeStiloBodyCircles(app.robotScene.stilo, bodyCircles);
            for (int i = 0; i < NUM_STILO_BODY_CIRCLES; i++)
            {
                float dx = wx - bodyCircles[i].center.x;
                float dy = wy - bodyCircles[i].center.y;
                if (sqrtf(dx * dx + dy * dy) <= bodyCircles[i].radius)
                    return TRUE;
            }
            return FALSE;
        }

        case ROBOT_KIND_SEMNI:
        default:
            return isPointInsideRobotBody(app.robotScene.robot, wx, wy);
    }
}

// Simulation mode only: which of the robot's ROTATABLE joints (hip = body
// circle index 2, knee = index 3 -- see computeSemniBodyCircles' documented
// ordering, renderer.h) the given world-space point falls inside, or -1 if
// neither. Head/butt/foot are deliberately excluded -- they have no
// independent rotation angle of their own to spin (foot's position is
// fully determined by kneeCircle + kneeAngle + a fixed local offset, no
// extra degree of freedom there). Feeds WM_MOUSEWHEEL's joint-rotate
// feature below: hovering the hip or knee's own visible body circle and
// scrolling rotates hipAngle/kneeAngle directly, without needing to leave
// Simulation and go pose it in the separate Design > Robot editor.
static int findHoveredJointSim(Semni robot, float wx, float wy)
{
    CircleSegment bodyCircles[NUM_ROBOT_BODY_CIRCLES];
    computeSemniBodyCircles(robot, bodyCircles);

    for (int i = 2; i <= 3; i++)
    {
        float dx = wx - bodyCircles[i].center.x;
        float dy = wy - bodyCircles[i].center.y;
        if (sqrtf(dx * dx + dy * dy) <= bodyCircles[i].radius)
            return i;
    }

    return -1;
}

// Companion to applyGravityStep's downward binary search below, but
// searching UPWARD instead, within a small fixed budget
// (SIMULATION_SLOPE_CORRECTION_MAX) rather than a whole gravity step --
// used right after nudging the robot's angle toward the slope it's resting
// on, since rotating a rigid body around its torso-level center can push a
// limb a hair into the ground even though the body as a whole was already
// settled. No-ops if the robot isn't actually colliding right now.
static void resolveUpwardIfPenetrating(HWND hWnd, float maxCorrection)
{
    if (!robotCollidesWithEnvironment()) return;

    float safe = maxCorrection;    // largest offset assumed to clear
    float blocked = 0.0f;          // smallest offset confirmed NOT to clear

    for (int i = 0; i < GRAVITY_CONTACT_SEARCH_ITERATIONS; i++)
    {
        float mid = (safe + blocked) * 0.5f;

        translateActiveRobot(0.0f, mid);
        BOOL hit = robotCollidesWithEnvironment();
        translateActiveRobot(0.0f, -mid);

        if (hit) blocked = mid;
        else     safe = mid;
    }

    translateActiveRobot(0.0f, safe);
    InvalidateRect(hWnd, NULL, FALSE);
}

// Drops the whole active robot (translateActiveRobot -- same rigid,
// all-parts-together move applyGravityStep itself uses) straight down
// from wherever it is RIGHT NOW until first contact, in one call --
// unlike applyGravityStep, which is built around one small fixed-size
// SIMULATION_GRAVITY_STEP nudge per call (right for a per-tick fall), this
// grows the search range from scratch each time, so it finds the TRUE
// resting height in a single shot regardless of how big the actual gap
// turns out to be. Used by advanceRockySettle below to answer "how
// far would the body fall if the knee were bent differently," which
// needs a real answer for a potentially large gap, not one tick's worth.
// Returns how far down it moved (0.0f if it couldn't move at all -- it
// was already resting, or already embedded right where it started).
static float dropActiveRobotToRest(void)
{
    if (robotCollidesWithEnvironment())
        return 0.0f; // already touching/embedded -- nothing to drop

    float safe = 0.0f;      // largest confirmed-clear drop so far
    float push = SIMULATION_LEG_PUSH_SEARCH_START;

    // Tracks whether the doubling search below ever actually FOUND a
    // collision boundary, as opposed to just running out of search range
    // (SIMULATION_LEG_PUSH_SEARCH_MAX) without ever touching anything.
    // That distinction matters a lot to advanceRockySettle's own probes:
    // they call this to answer "would a candidate kneeAngle/bodyAngle let
    // the robot fall further," and pick whichever candidate reports the
    // BIGGEST drop -- without this flag, a candidate that actually swings
    // the tested part out past the edge of a short environment segment
    // (open air, no ground anywhere below within range) used to come back
    // reporting a drop of roughly SIMULATION_LEG_PUSH_SEARCH_MAX, which a
    // real report showed reads to those probes as "by far the best
    // option" -- bigger than any genuine nearby resting-height
    // improvement -- so they'd confidently commit to rotating the body
    // (or knee) straight off the edge of a small platform, and the very
    // next ordinary gravity tick then free-falls with nothing left
    // underneath it at all. "Ran out of search range" has to report back
    // as "no improvement here" (0.0f), not as the deepest drop anyone's
    // found yet.
    BOOL foundGround = FALSE;

    for (;;)
    {
        translateActiveRobot(0.0f, -push);
        BOOL hits = robotCollidesWithEnvironment();
        translateActiveRobot(0.0f, push); // undo probe

        if (hits) { foundGround = TRUE; break; }

        safe = push;
        if (push >= SIMULATION_LEG_PUSH_SEARCH_MAX)
            break; // sanity cap -- nothing below it for a long way (freefall)

        push *= 2.0f;
    }

    if (!foundGround)
        return 0.0f; // open air the whole way out -- not a real resting
                      // spot, so this is not an "improvement" of any size

    float blocked = push;

    for (int i = 0; i < GRAVITY_CONTACT_SEARCH_ITERATIONS; i++)
    {
        float mid = (safe + blocked) * 0.5f;

        translateActiveRobot(0.0f, -mid);
        BOOL hits = robotCollidesWithEnvironment();
        translateActiveRobot(0.0f, mid); // undo probe

        if (hits) blocked = mid; else safe = mid;
    }

    translateActiveRobot(0.0f, -safe);
    return safe;
}

// Rocky-only: called every single gravity tick (applyGravityStep, below,
// calls this every time any part of Rocky is touching something -- see
// its own comment), tries two independent one-small-step probes -- bend
// the KNEE, and rotate the RECTANGLE itself (Rocky's own `angle` field)
// -- and commits whichever of them (if either) lets the body fall any
// further right now. This is specifically for the knee-detach feature
// (app.h's own comment on draggingRockyKnee): once the knee can sit far
// from the rectangle, gravity's own whole-body drop stops the instant
// its LOWEST part (often the foot) touches something, leaving the
// rectangle exactly as high up (and at whatever ORIENTATION) that pose
// geometrically places it -- which can look like the body is floating,
// when really it's just resting on top of an oddly long/offset leg.
// Real robots settle that kind of thing by both the knee bending AND the
// torso tipping under its own weight until something else (the
// rectangle itself) also finds the ground; being called every tick lets
// this happen gradually, over as many ticks as it takes, rather than
// snapping to the final pose the instant it lands.
//
// Each probe is independent coordinate-descent, one variable at a time
// (first kneeAngle, then r->angle, each against whatever the OTHER just
// ended up as) -- not a single combined search over both together, so a
// resting pose that only opens up once BOTH change together at once
// could be missed. In practice this converges fine over enough ticks
// since each variable's own improvement still keeps nudging the other's
// available range too, and it keeps each individual probe cheap and easy
// to reason about.
//
// Deliberately does only ONE bounded step per probe per call rather than
// hill-climbing to full convergence in one shot -- called continuously
// (every tick, by explicit request) instead of once, it doesn't need to
// finish in a single call; a tiny fixed step per tick is what actually
// produces a smooth multi-frame sink/tip rather than an instant snap.
// Safe to call this often because there's no velocity or damping state
// carried between calls (unlike the removed knee pendulum) -- each probe
// is an independent, deterministic test that only ever commits a change
// it has already confirmed (via dropActiveRobotToRest, the same
// binary-search idiom the rest of gravity uses) genuinely lets the body
// fall further while staying collision-free, so there is nothing here
// that can accumulate into an oscillation or a stuck state.
// Persists across calls: TRUE once BOTH probes below are individually
// exhausted (see rockyKneeSettleStep/rockyBodySettleStep) for the
// CURRENT landing, so this stops actually re-probing every subsequent
// tick instead of continuing to test forever. Reset to FALSE by
// applyGravityStep right when a FRESH landing begins (see its own
// comment) so a robot that's lifted off and lands again later still
// gets a full settle pass of its own.
static BOOL rockySettleConverged = FALSE;

// Each probe's OWN current step size, shrinking independently as it runs
// out of room -- separate statics (not the SIMULATION_LEG_SETTLE_STEP_DEG/
// SIMULATION_BODY_SETTLE_STEP_DEG constants, which are just where these
// start) because a fixed step that never adapts can call things
// "converged" too early: the real remaining improvement at a 1-degree
// step can round down under SIMULATION_LEG_SETTLE_MIN_DROP even though a
// genuinely lower resting pose exists a finer fraction of a degree away
// (a real report of exactly this -- settling stopping with the body
// still visibly floating). Halving on every failed attempt instead of
// giving straight up is the same "a coarse step can overshoot a narrow
// useful window" fix the original one-shot version of this search used,
// just kept as per-probe state now that this runs continuously instead
// of to completion in one call. Both reset to their starting constants
// by applyGravityStep alongside rockySettleConverged.
static float rockyKneeSettleStep = 0.0f;
// Semni only: Probe 2's step size for the HIP joint (rockyKneeSettleStep
// above doubles as Semni's KNEE step). The rocky* settle state variables are
// shared by whichever robot is settling -- Rocky and Semni both run
// advanceRockySettle now; only one robot is ever active at a time.
static float semniHipSettleStep = 0.0f;
static float rockyBodySettleStep = 0.0f;

// Counts consecutive ticks where BOTH probes below committed a real,
// above-noise move on the SAME tick, regardless of WHICH of their own
// criteria each one used. A genuine settle only rarely needs that more
// than once or twice in a row -- normally one probe finds something, its
// step keeps going while the other's runs dry and starts shrinking, and
// they converge. A long streak of BOTH committing every single tick is
// the signature of the two probes chasing a target the other one keeps
// moving: Probe 2 bends the knee based on the body angle Probe 1 set last
// tick, then Probe 1 pivots the body based on the knee angle Probe 2 just
// set, each one finding a genuine-by-its-own-narrow-measure improvement
// forever without either commit branch ever shrinking its step (see those
// branches' own "no need to refine yet" comments) -- because neither
// probe's own directionsStraddle-style check looks at what the OTHER
// probe just did or is about to do. Two separate real reports showed this:
// once with the knee circle as the primary contact (bodyAngle/kneeAngle
// drifting via bestComDrop/bestClearanceGain, now separately guarded by
// legRestingOnImmovableJoint above) and once with a DIFFERENT part as the
// primary contact and the knee as the dangling point instead (drifting via
// bestDrop/bestClearanceGain this time) -- two different pairs of
// criteria, same underlying symptom, so this checks for the SHAPE of the
// problem (both probes committing every tick, forever) rather than any
// one specific pairing, to catch whichever combination shows up next.
// Reset to 0 whenever a tick doesn't have both probes committing, and by
// every rockySettleConverged/step-size reset below (a fresh landing
// deserves a fresh streak count too).
static int rockyBothProbesCommittedStreak = 0;

// Mirror image of rockyBothProbesCommittedStreak just above, for the
// OPPOSITE problem: once either step size has been shrunk (by a same-tick
// straddle, a scout-fallback shrink, or the stalemate detector itself),
// nothing ever grows it back up again for the rest of that landing's
// settle -- even long after whatever caused the shrink is over and only
// ONE probe is left cleanly, monotonically committing real progress every
// tick with the other probe completely silent (nothing left to fight). A
// real report showed exactly this: after the stalemate detector correctly
// broke a knee/body lockstep and halved both steps down to their floor,
// Probe 2 went quiet (legRestingOnImmovableJoint) and Probe 1 alone kept
// committing a genuine bestComDrop improvement, tick after tick, but only
// ever a fixed ~0.03-degree step each time -- hundreds of ticks to sweep
// what should have been a much faster descent, because the step had
// nothing left to shrink FOR anymore but also no way back up. These two
// counters track each probe's own streak of "I committed via a DIRECT
// branch (bestDrop/bestComDrop/bestClearanceGain -- NOT the scout
// fallback) while the other probe stayed silent this tick," and once one
// reaches SIMULATION_LEG_SETTLE_GROWTH_STREAK, that probe's step is
// doubled (capped back at its own starting SIMULATION_LEG_SETTLE_STEP_DEG/
// SIMULATION_BODY_SETTLE_STEP_DEG) and the streak resets. Deliberately
// excludes scout-branch commits: reaching the scout fallback at all means
// the direct branches already found NOTHING at the CURRENT step size,
// which is a sign this step is already too coarse for the current pose,
// not evidence it's safe to grow bigger. Deliberately requires the OTHER
// probe to be silent too, same "SHAPE of the problem" idea as the
// stalemate streak: growing while both probes are active would be growing
// straight into the same kind of coupling the stalemate detector exists to
// catch. Reset to 0 whenever that probe doesn't cleanly qualify this tick,
// and by every rockySettleConverged/step-size reset below, same as
// rockyBothProbesCommittedStreak.
static int rockyKneeSettleGrowthStreak = 0;
static int rockyBodySettleGrowthStreak = 0;

// Which side of the body's own center of mass the CURRENT toppling pivot
// sits on -- 0 before any tick has measured it yet (or right after a
// fresh-landing reset, alongside rockyBodySettleStep itself), -1 once
// measured left of the mass center's X, +1 once measured right. Compared
// every advanceRockySettle tick against the SAME reading from the tick
// before: a flip (-1 -> +1 or the reverse) means the point gravity is
// pivoting around is alternating which side of the mass it's on, tick to
// tick -- the contact straddling directly under the body instead of
// settling to one side of it -- which reads as visible shaking even
// though directionsStraddle (below) never catches it, since that check
// only compares the two ROTATE directions tried within a single tick, not
// which point is acting as the pivot from one tick to the next. Halved
// (rockyBodySettleStep *= 0.5f) on every such flip, same binary-search
// idea directionsStraddle already uses for its own kind of straddle, by
// explicit request, so a genuinely straddling contact converges onto the
// true balance point instead of oscillating across it forever.
static int rockyPivotSide = 0;

// The pivot DIRECTION (-1 or +1, matching the dir loop below; 0 = no
// commit yet, or just reset by a fresh landing) that Probe 1 actually
// committed to on its MOST RECENT commit, whichever of bestDrop/
// bestComDrop/bestClearanceGain/the scout fallback made that commit.
// This is a different axis from rockyPivotSide just above -- that one
// tracks which SIDE of the mass center the contact point sits on
// (catches the pivot itself alternating sides); this one tracks which
// way the body last actually turned (catches the CHOSEN criterion
// alternating instead). A real report showed bodyAngle stuck bouncing
// forever between two values 0.25deg apart, one tick committing via
// bestDrop in one direction, the next tick committing via bestComDrop
// in the OTHER direction from the new angle -- each criterion was
// individually correct by its own narrow measure at the moment it
// fired, and directionsStraddle never caught it because on any single
// tick only ONE direction ever qualified (never both at once), so
// there was nothing to straddle within that tick; the two opposing
// commits were spread across separate ticks instead. Checked right
// before any of Probe 1's three direct branches (or the scout
// fallback) would commit: if the direction about to be applied is the
// exact reverse of the direction just committed last tick, that's the
// same oscillation shape directionsStraddle/rockyPivotSide already
// guard against, just visible only across ticks instead of within
// one -- so it's treated the same way, halving rockyBodySettleStep
// instead of reversing, rather than committing. Reset to 0 at every
// fresh-landing reset, alongside rockyPivotSide itself.
static int rockyBodyLastCommitDir = 0;

// Counts CONSECUTIVE ticks where rockyBodyLastCommitDir's own guard
// (immediately above) actually blocked a reversal -- incremented in each
// of its four copies (bestDrop/bestComDrop/bestClearanceGain/scout) right
// where they shrink instead of committing, reset to 0 by any real commit
// in ANY direction (same four places) as well as everywhere
// rockyBodyLastCommitDir itself is reset. A real report showed the guard
// becoming a NEW deadlock of its own: once Probe 1 had already pivoted
// several degrees of genuine forward progress and then needed one clean
// reversal to correct an overshoot, every attempt to do so kept getting
// blocked and shrunk forever, with nothing ever letting it through -- see
// SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK's own comment (config.h)
// for the exact reasoning on why a long-enough run of blocks is treated
// as that, not as the original same-tick criterion-flip-flop this guard
// exists for.
static int rockyBodyReversalBlockedStreak = 0;

// Set TRUE for the duration of an E/Q-triggered settle pass (see the
// WM_KEYDOWN kickoff below) to stop Probe 2 (knee-bending) from firing
// while the USER is the one actively driving kneeAngle -- without this,
// Probe 2's own "improve the resting fit" search runs every 16ms via the
// postRotateSettleActive timer and directly fights the player's own E/Q
// presses (LEGPUSH lifts the body to clear the leg the user just bent,
// then Probe 2 bends it back and drops the body again a tick later),
// which is what read as the body visibly jittering up and down while
// holding E or Q. Probe 1 (body-rotate/topple) and the plain gravity
// drop are NOT suppressed -- neither one touches kneeAngle, so neither
// one fights the user, and a genuinely unstable rotate still topples.
// Left FALSE (the normal case) for VK_LEFT/RIGHT's own topple kickoff,
// where nothing else is driving kneeAngle and Probe 2 is safe to run.
static BOOL rockyKneeSettleSuppressed = FALSE;


// Same idea as rockyLegContactPoints above -- finds the CLOSEST and
// SECOND-CLOSEST candidate points to the environment -- but the pool now
// spans the WHOLE assembly: the leg's own three parts (via
// rockyLegContactPoints, when the leg isn't hidden) PLUS Rocky's own four
// rectangle corners (when the body isn't hidden), not the leg alone. This
// is deliberately a SEPARATE function from rockyLegContactPoints, not a
// change to it -- rockyLegContactPoints itself still only ever looks at
// the leg, exactly as before, because legRestingOnImmovableJoint further
// below genuinely wants that narrower answer (see its own comment: a
// dangling foot should keep Probe 2 actively trying to bring it down
// even while the body is separately resting on a corner, not freeze
// kneeAngle just because the corner happens to already be flush).
//
// This wider version exists for rockyTopplePivotWorld/rockyDanglingPointClearance
// just below, which need the TRUE closest point across the whole
// assembly -- a real report showed exactly why the leg-only version
// wasn't enough for them: a Rocky resting flush on its own rectangle
// corner (screenshot: one red dot right at the corner, on the ground
// line, nothing else), with the foot dangling a hair off the ground and
// never quite reaching it, forever. rockyTopplePivotWorld (leg-only at
// the time) kept pivoting the whole assembly around whichever LEG point
// happened to be closest -- the foot itself, the closest thing ON the
// leg, but still genuinely off the ground -- never around the corner
// that was ACTUALLY touching, so nothing ever rotated the assembly
// around its real, physical contact to bring the foot the rest of the
// way down. A real object toppling over its own corner pivots around
// THAT corner, not around some other part of itself that merely happens
// to be nearest the ground -- same "pivot around whatever's actually
// touching, not around some unrelated reference point" idea
// rockyLegContactPoints' own comment already covers for the leg-only
// case, just widened to cover the body too.
//
// Rectangle corners are tested exactly (computeRockyRectSegments' own
// four segment start points, one call, cheap), not sampled along each
// edge -- if a whole edge were genuinely flush against a straight
// environment surface, at least one of its two corners reads the same
// near-zero clearance as every other point on that edge, so a corner-only
// test still finds the true contact without the cost of a full edge
// sampling pass (this runs inside the same per-tick fast-forward loop
// applyGravityStep already calls advanceRockySettle from, so it matters).
// Clearance uses combinedRadius = simEnvLineHalfWidthWorld() alone (no
// eArcThickness-style padding) -- a rectangle corner is real filled-shape
// geometry, not a bare curve, matching robotCollidesWithEnvironment's own
// treatment of these exact same edges (see its own comment on why
// eArcThickness would be the wrong convention here).
//
// A hidden leg or hidden body simply contributes nothing to the pool
// (each guarded the same way the rest of this file already treats a
// hidden part -- not sampled, not collided, not pivoted around). If
// BOTH are hidden there is genuinely nothing left to test at all;
// rockyTopplePivotWorld's own fallback (see below) covers that
// degenerate case, not this function.
// Sticky memory of which CATEGORY (the leg's own knee/foot/arc, or one of
// Rocky's own rectangle corners) most recently won the toppling pivot --
// 0 before anything has been decided yet (or right after a fresh-landing
// reset, alongside rockyPivotSide/rockyBodyLastCommitDir), +1 once a leg
// point has won, -1 once a body corner has. See
// SIMULATION_ROCKY_TOPPLE_PIVOT_HYSTERESIS's own comment (config.h) for
// the real report this exists for: a leg point and a body corner sitting
// at nearly the same tiny clearance made the plain "whichever candidate
// has the smaller clearance wins" comparison flip the pivot's entire
// IDENTITY back and forth between two completely different parts of the
// robot every single tick, not the gradual same-kind crossing
// rockyPivotSide already handles. rockyToppleContactPoints below only
// lets a leg<->body handoff happen once the new category is closer by
// more than that hysteresis margin, using this to remember which side
// of that margin last tick's decision landed on.
static int rockyToppleLastPivotCategory = 0;

// Shared by Rocky (rockyToppleContactPoints) and Semni (settleToppleContactPoints):
// picks the pivot/second contact out of the LEG category's best two and the
// BODY category's best two, with the same leg-vs-body hysteresis
// (rockyToppleLastPivotCategory) so the pivot doesn't flip categories on
// tiny numeric noise.
static void combineToppleCategories(BOOL haveLeg, RockyLegContact legBest, RockyLegContact legSecond,
                                    BOOL haveBody, RockyLegContact bodyBest, RockyLegContact bodySecond,
                                    RockyLegContact* closest, RockyLegContact* secondClosest)
{
    BOOL useLeg;
    if (!haveLeg)
        useLeg = FALSE;
    else if (!haveBody)
        useLeg = TRUE;
    else if (rockyToppleLastPivotCategory == 0)
        useLeg = (legBest.clearance <= bodyBest.clearance);
    else if (rockyToppleLastPivotCategory > 0)
        useLeg = !(bodyBest.clearance < legBest.clearance - SIMULATION_ROCKY_TOPPLE_PIVOT_HYSTERESIS);
    else
        useLeg = (legBest.clearance < bodyBest.clearance - SIMULATION_ROCKY_TOPPLE_PIVOT_HYSTERESIS);

    rockyToppleLastPivotCategory = useLeg ? 1 : -1;

    RockyLegContact best = useLeg ? legBest : bodyBest;
    RockyLegContact otherCategoryBest = useLeg ? bodyBest : legBest;
    RockyLegContact sameCategorySecond = useLeg ? legSecond : bodySecond;
    RockyLegContact second = (otherCategoryBest.clearance < sameCategorySecond.clearance) ? otherCategoryBest : sameCategorySecond;

    *closest = best;
    *secondClosest = second;
}

static void rockyToppleContactPoints(const Rocky* r, RockyLegContact* closest, RockyLegContact* secondClosest)
{
    // Never-wins placeholders (huge clearance) for whichever half of the
    // assembly is hidden.
    RockyLegContact legBest = { { 0.0f, 0.0f }, 1e9f, ROCKY_LEG_CONTACT_KNEE };
    RockyLegContact legSecond = legBest;
    BOOL haveLeg = !r->legHidden;

    if (haveLeg)
        rockyLegContactPoints(r, &legBest, &legSecond);

    RockyLegContact bodyBest = { { 0.0f, 0.0f }, 1e9f, ROCKY_LEG_CONTACT_BODY_CORNER };
    RockyLegContact bodySecond = bodyBest;
    BOOL haveBody = !r->bodyHidden;

    if (haveBody)
    {
        RockyEdgeSegment rectEdges[NUM_ROCKY_RECT_SEGMENTS];
        computeRockyRectSegments(*r, rectEdges);

        float combinedRadius = simEnvLineHalfWidthWorld();

        for (int e = 0; e < NUM_ROCKY_RECT_SEGMENTS; e++)
        {
            PointF cornerWorld = rectEdges[e].start; // each segment's own start is one distinct corner -- 4 segments cover all 4 corners exactly once
            float ecx, ecy;
            robotPointToEnvWorld(cornerWorld.x, cornerWorld.y, &ecx, &ecy);
            float clearance = nearestEnvDistance(ecx, ecy) - combinedRadius;

            RockyLegContact candidate = { cornerWorld, clearance, ROCKY_LEG_CONTACT_BODY_CORNER };

            if (candidate.clearance < bodyBest.clearance) { bodySecond = bodyBest; bodyBest = candidate; }
            else if (candidate.clearance < bodySecond.clearance) { bodySecond = candidate; }
        }
    }

    // Decide which CATEGORY wins the pivot -- see rockyToppleLastPivotCategory's
    // own comment above and SIMULATION_ROCKY_TOPPLE_PIVOT_HYSTERESIS's
    // (config.h) for the full reasoning. Only the very first tick since a
    // fresh-landing reset (rockyToppleLastPivotCategory == 0, nothing to
    // be sticky about yet) picks the plain closest with no margin;
    // every tick after that requires the OTHER category to beat whichever
    // one is currently pivoting by more than the hysteresis margin before
    // switching.
    combineToppleCategories(haveLeg, legBest, legSecond, haveBody, bodyBest, bodySecond, closest, secondClosest);
}

// Same idea as resolveUpwardIfPenetrating (further up), but as a plain
// probe that returns how much correction it applied instead of always
// committing/repainting -- called right after rotateRockyBodyAroundPivot
// above, every time Probe 1 below tries a candidate rotation. `pivot` is
// picked as whichever point is ALREADY closest to the ground (gap close
// to, or exactly, 0 -- see rockyTopplePivotWorld), and the whole point of
// pivoting around it is to hold it EXACTLY fixed through the rotation --
// but floating-point rounding in the rotate-then-compensate math
// (rotatePoint, then a translate built from the difference of two
// rotated points) can leave that same point a hair embedded afterward,
// even though it's mathematically meant to land back exactly where it
// started. That's exactly the scenario SIMULATION_SLOPE_CORRECTION_MAX's
// own comment describes: "rotating a rigid body... can push a limb a
// hair into the ground even though the body as a whole was already
// settled." Left uncorrected, dropActiveRobotToRest's own very first
// check (robotCollidesWithEnvironment -> return 0.0f immediately) would
// silently report EVERY candidate direction as "no improvement" no
// matter how much genuine room exists elsewhere -- which is exactly what
// a real report showed: Probe 1 never committing a single rotation,
// scout included, across multiple different poses, once its pivot point
// was sitting at gap ~ 0 (which is the common case -- that's what makes
// it the pivot in the first place). Bounded to the same tiny budget
// resolveUpwardIfPenetrating uses, since this is meant to erase a
// sub-precision rounding residual, not resolve a genuine collision -- a
// real block still comes back as "no improvement" afterward, it's just
// no longer drowned out by this false one first.
static float clearPivotRoundingResidual(void)
{
    if (!robotCollidesWithEnvironment()) return 0.0f;

    float safe = SIMULATION_SLOPE_CORRECTION_MAX;
    float blocked = 0.0f;

    for (int i = 0; i < GRAVITY_CONTACT_SEARCH_ITERATIONS; i++)
    {
        float mid = (safe + blocked) * 0.5f;

        translateActiveRobot(0.0f, mid);
        BOOL hit = robotCollidesWithEnvironment();
        translateActiveRobot(0.0f, -mid);

        if (hit) blocked = mid; else safe = mid;
    }

    translateActiveRobot(0.0f, safe);
    return safe;
}

// ---- Robot-generic settle accessors (Rocky + Semni) ----
//
// advanceRockySettle's Probe 2 (passive joint swing) and Probe 1 (whole-body
// topple around a ground contact) were written against Rocky's struct
// directly. These give it the same handful of things for whichever robot is
// active, so Semni runs the exact same settle logic:
//   body angle + rotation center, center of mass, hidden flags,
//   Probe 2 joints (Rocky: knee; Semni: knee then hip) and the foot's
//   clearance, and the contact candidates Probe 1 pivots around.
// Semni's contact categories mirror Rocky's: LEG = hip/knee/foot circles +
// thigh/shin arcs (hip circle plays the role of Rocky's body-fixed knee
// circle), BODY = head/butt circles + seam arcs (Rocky's rectangle corners).

static BOOL settleSupportedKind(void)
{
    return app.robotScene.activeKind == ROBOT_KIND_ROCKY || app.robotScene.activeKind == ROBOT_KIND_SEMNI;
}

static float* settleBodyAnglePtr(void)
{
    return (app.robotScene.activeKind == ROBOT_KIND_ROCKY) ? &app.robotScene.rocky.angle : &app.robotScene.robot.angle;
}

static PointF settleBodyCenter(void)
{
    return (app.robotScene.activeKind == ROBOT_KIND_ROCKY) ? getRockyCenter(app.robotScene.rocky) : getCenter(app.robotScene.robot);
}

static PointF settleMassCenter(void)
{
    return computeSimulationMassCenterWorld(&app);
}

static BOOL settleLegHidden(void)
{
    return (app.robotScene.activeKind == ROBOT_KIND_ROCKY) ? app.robotScene.rocky.legHidden : FALSE;
}

static BOOL settleBodyHidden(void)
{
    return (app.robotScene.activeKind == ROBOT_KIND_ROCKY) ? app.robotScene.rocky.bodyHidden : FALSE;
}

static int settleJointCount(void)
{
    return (app.robotScene.activeKind == ROBOT_KIND_ROCKY) ? 1 : 2;
}

static float* settleJointPtr(int j)
{
    if (app.robotScene.activeKind == ROBOT_KIND_ROCKY) return &app.robotScene.rocky.kneeAngle;
    return (j == 0) ? &app.robotScene.robot.kneeAngle : &app.robotScene.robot.hipAngle;
}

static float* settleJointStepPtr(int j)
{
    return (j == 0) ? &rockyKneeSettleStep : &semniHipSettleStep;
}

static const char* settleJointName(int j)
{
    if (app.robotScene.activeKind == ROBOT_KIND_ROCKY) return "kneeAngle";
    return (j == 0) ? "kneeAngle" : "hipAngle";
}

static BOOL settleAllJointStepsBelow(float minStep)
{
    for (int j = 0; j < settleJointCount(); j++)
        if (*settleJointStepPtr(j) >= minStep) return FALSE;
    return TRUE;
}

// Clearance (env world units) of the foot circle -- the end of the leg that
// Probe 2's "swing the dangling foot closer" criterion measures.
static float settleFootClearance(void)
{
    CircleSegment foot;
    if (app.robotScene.activeKind == ROBOT_KIND_ROCKY)
    {
        CircleSegment c[NUM_ROCKY_BODY_CIRCLES];
        computeRockyBodyCircles(app.robotScene.rocky, c);
        foot = c[1];
    }
    else
    {
        CircleSegment c[NUM_ROBOT_BODY_CIRCLES];
        computeSemniBodyCircles(app.robotScene.robot, c);
        foot = c[4];
    }
    float ecx, ecy;
    robotPointToEnvWorld(foot.center.x, foot.center.y, &ecx, &ecy);
    return nearestEnvDistance(ecx, ecy) - (robotLengthToEnvWorld(foot.radius) + simEnvLineHalfWidthWorld());
}

static void settleInsertCandidate(RockyLegContact cand, RockyLegContact* best, RockyLegContact* second)
{
    if (cand.clearance < best->clearance) { *second = *best; *best = cand; }
    else if (cand.clearance < second->clearance) { *second = cand; }
}

// Best/second contact candidates on Semni, from either its LEG parts
// (legPart TRUE) or its BODY parts -- see the category note above.
static void semniContactCandidates(const Semni* sm, BOOL legPart, RockyLegContact* best, RockyLegContact* second)
{
    RockyLegContact none = { { 0.0f, 0.0f }, 1e9f, legPart ? ROCKY_LEG_CONTACT_KNEE : ROCKY_LEG_CONTACT_BODY_CORNER };
    *best = none;
    *second = none;

    float halfW = simEnvLineHalfWidthWorld();

    CircleSegment circles[NUM_ROBOT_BODY_CIRCLES];
    computeSemniBodyCircles(*sm, circles);
    for (int c = 0; c < NUM_ROBOT_BODY_CIRCLES; c++)
    {
        BOOL isLeg = (c >= 2); // 0 head, 1 butt | 2 hip, 3 knee, 4 foot
        if (isLeg != legPart) continue;
        float ecx, ecy;
        robotPointToEnvWorld(circles[c].center.x, circles[c].center.y, &ecx, &ecy);
        RockyLegContact cand;
        cand.world = circles[c].center;
        cand.clearance = nearestEnvDistance(ecx, ecy) - (robotLengthToEnvWorld(circles[c].radius) + halfW);
        cand.kind = !legPart ? ROCKY_LEG_CONTACT_BODY_CORNER : (c == 4 ? ROCKY_LEG_CONTACT_FOOT : ROCKY_LEG_CONTACT_KNEE);
        settleInsertCandidate(cand, best, second);
    }

    float arcPad = robotLengthToEnvWorld(SIMULATION_ARC_COLLISION_THICKNESS) + halfW;
    PointF arcPts[NUM_ROBOT_CIRCLE_SEGMENTS][ARC_SAMPLE_COUNT];
    int arcCounts[NUM_ROBOT_CIRCLE_SEGMENTS];
    computeSemniArcPoints(*sm, arcPts, arcCounts);
    for (int a = 0; a < NUM_ROBOT_CIRCLE_SEGMENTS; a++)
    {
        BOOL isLeg = (a >= 2); // 0-1 seam | 2-3 thigh, 4-5 shin
        if (isLeg != legPart) continue;
        for (int i = 0; i < arcCounts[a]; i++)
        {
            float ecx, ecy;
            robotPointToEnvWorld(arcPts[a][i].x, arcPts[a][i].y, &ecx, &ecy);
            RockyLegContact cand;
            cand.world = arcPts[a][i];
            cand.clearance = nearestEnvDistance(ecx, ecy) - arcPad;
            cand.kind = legPart ? ROCKY_LEG_CONTACT_ARC : ROCKY_LEG_CONTACT_BODY_CORNER;
            settleInsertCandidate(cand, best, second);
        }
    }
}

// Closest/second-closest LEG contact (Rocky: rockyLegContactPoints).
static void settleLegContactPoints(RockyLegContact* closest, RockyLegContact* secondClosest)
{
    if (app.robotScene.activeKind == ROBOT_KIND_ROCKY)
        rockyLegContactPoints(&app.robotScene.rocky, closest, secondClosest);
    else
        semniContactCandidates(&app.robotScene.robot, TRUE, closest, secondClosest);
}

// Pivot + dangling point over the WHOLE robot (Rocky: rockyToppleContactPoints).
static void settleToppleContactPoints(RockyLegContact* closest, RockyLegContact* secondClosest)
{
    if (app.robotScene.activeKind == ROBOT_KIND_ROCKY)
    {
        rockyToppleContactPoints(&app.robotScene.rocky, closest, secondClosest);
        return;
    }
    RockyLegContact legBest, legSecond, bodyBest, bodySecond;
    semniContactCandidates(&app.robotScene.robot, TRUE, &legBest, &legSecond);
    semniContactCandidates(&app.robotScene.robot, FALSE, &bodyBest, &bodySecond);
    combineToppleCategories(TRUE, legBest, legSecond, TRUE, bodyBest, bodySecond, closest, secondClosest);
}

static PointF settleTopplePivotWorld(void)
{
    if (settleLegHidden() && settleBodyHidden())
        return settleBodyCenter();
    RockyLegContact closest, secondClosest;
    settleToppleContactPoints(&closest, &secondClosest);
    return closest.world;
}

static float settleDanglingPointClearance(void)
{
    RockyLegContact closest, secondClosest;
    settleToppleContactPoints(&closest, &secondClosest);
    return secondClosest.clearance;
}

// Rotates the whole body by deltaAngle around `pivot` (a world point,
// captured before the call) instead of around the body's own center: a
// plain angle change only ever rotates around the center, so this follows
// it with a compensating translate that puts `pivot` back where it was --
// the standard "rotate about center, then translate" trick. Returns the
// (dx, dy) shift applied, so a caller can undo it exactly (translate by
// its negation, then restore the angle) without re-deriving anything.
// Works for whichever robot is active (Rocky or Semni).
static PointF rotateActiveBodyAroundPivot(PointF pivot, float deltaAngle)
{
    PointF center = settleBodyCenter();
    PointF pivotAfterSpin = rotatePoint(pivot, center, deltaAngle);
    PointF shift = { pivot.x - pivotAfterSpin.x, pivot.y - pivotAfterSpin.y };

    *settleBodyAnglePtr() += deltaAngle;
    translateActiveRobot(shift.x, shift.y);
    return shift;
}

// Halves rockyBodySettleStep for a reversal-guard block, but never below
// SIMULATION_LEG_SETTLE_MIN_STEP_DEG. The guard is meant to give up after
// SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK consecutive blocks and let
// the reversal through -- but a plain halving on every block (plus the
// pivot-side-flip halving) took a 1 deg step below the floor in 7 halvings,
// so Probe 1 stopped running before the guard ever released, and the
// settle "converged" with the body still visibly toppling (real report:
// Rocky balanced on its foot with the center of mass far to one side).
static void shrinkRockyBodyStepForReversalGuard(void)
{
    rockyBodySettleStep *= 0.5f;
    if (rockyBodySettleStep < SIMULATION_LEG_SETTLE_MIN_STEP_DEG)
        rockyBodySettleStep = SIMULATION_LEG_SETTLE_MIN_STEP_DEG;
}

// ---- Final "seat the dangling point" pass (run once, right before
// advanceRockySettle latches rockySettleConverged) ----
//
// Probe 1 stops once its step size falls below
// SIMULATION_LEG_SETTLE_MIN_STEP_DEG, and that alone doesn't guarantee
// the second contact point (e.g. the foot, while the knee is the pivot)
// actually reached the ground. A real report showed a Rocky resting on
// its knee with the foot visibly flush but NOT registering as a contact
// (no orange dot): it was hovering a sub-pixel gap above the line, just
// past SIMULATION_CONTACT_VISUAL_TOLERANCE. Same fix applyGravityStep
// already uses for a vertical drop: binary-search the remaining rotation
// around the pivot for the largest angle that does NOT collide, so the
// dangling point converges onto the surface instead of stopping
// wherever the last whole step happened to land.
//
// Only fires for a SMALL remaining gap (SIMULATION_ROCKY_SEAT_MAX_GAP) --
// a point genuinely dangling far above the ground is left alone -- and
// only commits if the rotation doesn't raise the center of mass (a
// physically real rest pose never needs to climb to close a gap).
//
// Unlike Probe 1, a candidate here is NOT allowed to "fix" a collision by
// lifting the whole robot (clearPivotRoundingResidual's full
// SIMULATION_SLOPE_CORRECTION_MAX budget): any lift bigger than
// SIMULATION_ROCKY_SEAT_MAX_PIVOT_LIFT counts as blocked. Otherwise a
// dangling point pushed INTO the ground would just be "cured" by lifting
// the pivot off it instead -- trading one hovering contact for another.

// Rotates by deltaDeg around pivot, measures, then fully undoes itself.
// Returns TRUE if that orientation is blocked (collides beyond a
// rounding-sized pivot lift, or the dangling point went below zero).
static BOOL rockySeatProbe(PointF pivot, float deltaDeg,
                           float* outDanglingClearance, float* outComY)
{
    float* bodyAngle = settleBodyAnglePtr();
    float baseAngle = *bodyAngle;
    PointF shift = rotateActiveBodyAroundPivot(pivot, deltaDeg);

    // Dangling point below the surface -> blocked, no collision test needed.
    float clearance = settleDanglingPointClearance();
    BOOL blocked = (clearance < 0.0f);

    // Otherwise: a collision here is either float rounding at the pivot
    // (fine) or something real. Instead of clearPivotRoundingResidual's
    // 12-step search for the exact lift (this made the whole seat pass
    // cost ~60-70 ms -- real [PERF] report), just test the one lift we'd
    // accept: if lifting by SIMULATION_ROCKY_SEAT_MAX_PIVOT_LIFT clears
    // it, it was rounding; if not, it's blocked. At most 2 checks.
    float lift = 0.0f;
    if (!blocked && robotCollidesWithEnvironment())
    {
        lift = SIMULATION_ROCKY_SEAT_MAX_PIVOT_LIFT;
        translateActiveRobot(0.0f, lift);
        if (robotCollidesWithEnvironment())
            blocked = TRUE;
    }

    if (outDanglingClearance) *outDanglingClearance = clearance;
    if (outComY) *outComY = settleMassCenter().y;

    if (lift > 0.0f)
        translateActiveRobot(0.0f, -lift);
    translateActiveRobot(-shift.x, -shift.y);
    *bodyAngle = baseAngle;
    return blocked;
}

static void seatRockyDanglingPoint(void)
{
    if (settleLegHidden() && settleBodyHidden())
        return;

    BOOL savedSuppress = gSuppressGravityDebug;
    gSuppressGravityDebug = TRUE; // this search calls robotCollidesWithEnvironment dozens of times

    RockyLegContact pivotContact, dangling;
    settleToppleContactPoints(&pivotContact, &dangling);

    float envPerRobot = robotLengthToEnvWorld(1.0f);
    float gapRobot = (envPerRobot > 0.0f) ? dangling.clearance / envPerRobot : 0.0f;

    // Skip when the gap is already small enough to register as a visible
    // contact (half of SIMULATION_CONTACT_VISUAL_TOLERANCE, for margin) --
    // nothing a viewer could see would change, and most convergences land
    // here, so this also avoids the whole search's cost.
    if (dangling.clearance <= 0.0f
        || gapRobot <= 0.5f * SIMULATION_CONTACT_VISUAL_TOLERANCE
        || gapRobot > SIMULATION_ROCKY_SEAT_MAX_GAP)
    {
        gSuppressGravityDebug = savedSuppress;
        return; // already touching (or visibly so), or genuinely dangling -- nothing to seat
    }

    PointF pivot = pivotContact.world;
    float lx = dangling.world.x - pivot.x;
    float ly = dangling.world.y - pivot.y;
    float lever = sqrtf(lx * lx + ly * ly);
    if (lever < 1e-5f)
    {
        gSuppressGravityDebug = savedSuppress;
        return;
    }

    // Rotation (deg) that would close the gap if the dangling point moved
    // straight down; doubled so the bracket's far end is safely past it.
    float spanDeg = 2.0f * (gapRobot / lever) * (180.0f / 3.14159265f);
    if (spanDeg > SIMULATION_BODY_SETTLE_STEP_DEG) spanDeg = SIMULATION_BODY_SETTLE_STEP_DEG;
    if (spanDeg < 1e-4f) spanDeg = 1e-4f;

    float baseComY = settleMassCenter().y;

    // Which way lowers the dangling point? Try a small nudge each way.
    float cMinus = 0.0f, cPlus = 0.0f;
    BOOL bMinus = rockySeatProbe(pivot, -0.1f * spanDeg, &cMinus, NULL);
    BOOL bPlus  = rockySeatProbe(pivot,  0.1f * spanDeg, &cPlus, NULL);
    int dir = 0;
    if (!bMinus && cMinus < dangling.clearance && (bPlus || cMinus <= cPlus)) dir = -1;
    else if (!bPlus && cPlus < dangling.clearance) dir = 1;

    if (dir == 0)
    {
        SIM_LOG("[SETTLE] seat: dangling kind=%d gap=%.6f (robot units) -- neither rotation direction lowers it, leaving as is\n",
               (int)dangling.kind, gapRobot);
        gSuppressGravityDebug = savedSuppress;
        return;
    }

    if (!rockySeatProbe(pivot, dir * spanDeg, NULL, NULL))
    {
        SIM_LOG("[SETTLE] seat: dangling kind=%d gap=%.6f -- still not blocked %.5f deg out, leaving as is (not a small residual gap)\n",
               (int)dangling.kind, gapRobot, dir * spanDeg);
        gSuppressGravityDebug = savedSuppress;
        return;
    }

    float safe = 0.0f, blockedAt = spanDeg;
    for (int i = 0; i < SIMULATION_ROCKY_SEAT_SEARCH_ITERATIONS; i++)
    {
        float mid = 0.5f * (safe + blockedAt);
        if (rockySeatProbe(pivot, dir * mid, NULL, NULL)) blockedAt = mid;
        else                                                  safe = mid;
    }

    float seatedClearance = 0.0f, seatedComY = baseComY;
    rockySeatProbe(pivot, dir * safe, &seatedClearance, &seatedComY);

    if (seatedComY > baseComY + 1e-6f)
    {
        SIM_LOG("[SETTLE] seat: dangling kind=%d gap=%.6f -- closing it would RAISE the center of mass by %.6f, leaving as is\n",
               (int)dangling.kind, gapRobot, seatedComY - baseComY);
        gSuppressGravityDebug = savedSuppress;
        return;
    }

    rotateActiveBodyAroundPivot(pivot, dir * safe);
    float lift = 0.0f;
    if (robotCollidesWithEnvironment())
        lift = clearPivotRoundingResidual();

    float seatedGapRobot = (envPerRobot > 0.0f) ? seatedClearance / envPerRobot : 0.0f;
    SIM_LOG("[SETTLE] seat: pivot kind=%d, dangling kind=%d gap %.6f -> %.6f (robot units) after rotating %.6f deg (pivot lift %.6f)%s\n",
           (int)pivotContact.kind, (int)dangling.kind, gapRobot, seatedGapRobot, dir * safe, lift,
           (seatedGapRobot > SIMULATION_CONTACT_VISUAL_TOLERANCE)
               ? " -- STILL above tolerance: something else (arc/body edge) blocked the rotation first"
               : "");

    gSuppressGravityDebug = savedSuppress;
}

// [PERF] breakdown of the most recent advanceRockySettle call's two
// convergence-only extras (the sanity-check scout and the seat pass) --
// reset at the top of every call, read by the settle fast-forward's
// [PERF] line so a slow call can be attributed. 0 when that part didn't run.
static double perfLastSettleSanityMs = 0.0;
static double perfLastSettleSeatMs = 0.0;

// Naming (by request): Probe 1 = TOPPLING (whole-body rotation around a
// ground contact), Probe 2 = PASSIVE JOINT SWING (knee / hip). Execution
// order inside each settle call is unchanged from before the rename:
// Probe 2 (joint swing) runs first, then Probe 1 (toppling) -- the numbers
// are names only, not the order they run in.
static void advanceRockySettle(void)
{
    perfLastSettleSanityMs = 0.0;
    perfLastSettleSeatMs = 0.0;

    if (!settleSupportedKind())
        return; // Rocky and Semni only -- see the robot-generic settle accessors

    if (rockySettleConverged)
        return; // both probes already confirmed exhausted for this landing

    // Lazily initialize on first-ever use (also re-primed by
    // applyGravityStep on every fresh landing -- see its own comment) --
    // 0.0f only ever occurs before either has been set, since a real
    // landing always (re)sets both to their starting constants.
    if (rockyKneeSettleStep <= 0.0f)
        rockyKneeSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
    if (rockyBodySettleStep <= 0.0f)
        rockyBodySettleStep = SIMULATION_BODY_SETTLE_STEP_DEG;
    if (semniHipSettleStep <= 0.0f)
        semniHipSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;

    // Whichever robot is settling (Rocky or Semni) -- see the robot-generic
    // settle accessors. These stand in for the old Rocky* r fields.
    float* bodyAngle = settleBodyAnglePtr();
    BOOL legHidden = settleLegHidden();
    BOOL bodyHidden = settleBodyHidden();

    // Whether the leg's CURRENT ground contact is somewhere Probe 2 should
    // leave alone -- if so, Probe 2 below is skipped for this tick. Covers
    // all three parts of the leg (ARC, KNEE, and now FOOT too -- see its
    // own paragraph below for why FOOT was added), each for its own
    // distinct reason.
    //
    // ARC: bending the knee rotates the WHOLE shin, arc included, rigidly
    // around the knee joint, which CANNOT preserve an ARC contact -- the
    // specific arc point currently touching sweeps around the knee as it
    // bends while the ground stays put, so the instant the knee moves at
    // all, that exact point lifts away while the rest of the arc swings
    // past without ever re-touching the same spot. dropActiveRobotToRest
    // then correctly (by its own narrow measure) reports a real drop into
    // the gap Probe 2 itself just pried open -- not genuine progress, just
    // Probe 2 repeatedly prying a real, already-settled arc contact loose
    // and falling into the gap it made, tick after tick, never converging.
    // A real report showed exactly this: a leg-only Rocky correctly
    // balancing on its convex shin arc (see rockyLegContactPoints' own
    // comment above), then kneeAngle drifting steadily for hundreds of
    // ticks afterward until the contact finally landed back on the knee
    // circle instead.
    //
    // KNEE: even more direct -- kneeAngle is BY DEFINITION a rotation
    // around the knee joint, so the knee's own position (and therefore its
    // clearance to the ground) never changes no matter what kneeAngle is
    // -- there is no candidate bend that can ever move an already-resting
    // knee contact even a hair closer. This used to be assumed safe for
    // Probe 2 (its clearance checks "judge that fairly", per an earlier
    // version of this comment) -- but those checks only ever look at the
    // DANGLING FOOT's clearance, never the knee's own, so with the knee
    // genuinely already resting, that foot-clearance chase has nothing to
    // do with the real contact at all. A real report showed exactly this
    // going wrong: bodyAngle and kneeAngle drifting in lockstep by a full
    // degree each, tick after tick, seemingly forever -- Probe 2 kept
    // finding tiny "progress" swinging the dangling foot around the
    // now-fixed knee, and Probe 1 kept finding tiny "progress" pivoting
    // the body to compensate, netting almost no real movement of the foot
    // but spinning the body around the planted knee indefinitely.
    //
    // FOOT: unlike the other two, bending the knee CAN genuinely move a
    // planted foot -- it stays the same fixed distance from the knee, so a
    // small bend just swings it along its own circle -- which is exactly
    // why this used to be the one contact Probe 2 was still allowed to
    // work against. The trouble: once the foot is already flush,
    // dropActiveRobotToRest is a WHOLE-BODY drop test, not just a check of
    // the foot's own clearance, and further knee bends can keep uncovering
    // more real, non-noise room to fall -- not by moving the foot's
    // contact closer (it's already flush), but by crouching the body down
    // over it. With nothing modeling the muscular effort a real crouch
    // requires, that has no natural stopping point of its own: it either
    // winds all the way until the knee circle takes over as the resting
    // contact instead (a real report showed kneeAngle reaching -137
    // degrees that way), or -- as a real report showed by explicit
    // request -- it can also converge cleanly with the foot still correctly
    // planted, red contact marker and all, but only after curling the shin
    // into an exaggerated hook shape first (kneeAngle winding ~11 degrees
    // from its landing angle before the scout fallback finally found
    // bending further would start hurting the foot's own clearance).
    // Neither is the natural "just stay where it landed" pose a planted
    // foot should settle into, so FOOT now joins ARC and KNEE here: once
    // the foot itself is genuinely resting (clearance already ~0), Probe 2
    // leaves it alone too, freezing kneeAngle at whatever angle the foot
    // happened to land at. This does NOT block Probe 2's other,
    // still-legitimate job of swinging a still-DANGLING foot down to first
    // reach the ground (e.g. the rectangle resting on its own corner, foot
    // hanging in the air) -- rockyLegContactPoints only ever looks at the
    // leg's own three parts, so a dangling foot with nothing on the leg
    // yet resting reports a large, not-yet-near-zero clearance regardless
    // of which part happens to be closest, and this check stays FALSE
    // until something on the leg genuinely settles.
    //
    // Probe 1's body rotation (pivoting the whole assembly around whatever
    // point is actually touching, fixed) is already the correct settling
    // mechanism for ALL THREE cases -- see its own comment further below
    // -- so Probe 2 just steps aside until none of them is true anymore.
    // Compared against SIMULATION_LEG_SETTLE_MIN_DROP (not a bare < 0.0f)
    // for the same reason every other clearance check in this function is:
    // a hair of float noise right at 0 shouldn't flip this on and off tick
    // to tick.
    //
    // Tried, and REVERTED, adding a symmetric "BODY CORNER" case here
    // (checking rockyToppleContactPoints' wider leg+body answer, freezing
    // Probe 2 whenever a body corner was the immovable pivot): a real
    // report showed kneeAngle winding past -280 degrees with a corner
    // long since settled as Probe 1's pivot, which looked at first like
    // the exact same "crouching over an already-fixed point" pathology
    // FOOT's own paragraph describes. But unlike FOOT/KNEE/ARC -- where
    // the frozen point and the point Probe 2 moves are THE SAME point --
    // a resting corner and a still-dangling foot are DIFFERENT points on
    // rigid parts connected by an adjustable knee, so bending the knee
    // can still genuinely swing the foot closer while the corner stays
    // fixed; that's the whole "does NOT block Probe 2's still-legitimate
    // job of swinging a still-dangling foot down" case the paragraph
    // above this one already calls out by name. Freezing on the corner
    // alone fired the instant the corner registered as resting -- which
    // is essentially IMMEDIATELY, since a topple pivot only wins the
    // selection in the first place by already being near-zero-clearance
    // -- silencing Probe 2 before it ever got to swing the foot down at
    // all, not just once it had genuinely finished. A real report showed
    // this plainly too: the knee probe staying quiet for an entire
    // multi-degree body-toppling pass, the foot never gaining any ground
    // at all. Left as leg-only, exactly as it was before that attempt --
    // the genuine -280-degree runaway needs a more targeted fix specific
    // to whatever lets a whole-body drop keep reporting real room while
    // a corner's own clearance doesn't actually move, not a blanket
    // freeze on the corner merely existing.
    BOOL legRestingOnImmovableJoint = FALSE;
    // Captured alongside legRestingOnImmovableJoint purely for the
    // diagnostic printf below (Probe 2's own else-branch, further down)
    // -- not used for any decision here.
    RockyLegContactKind pivotKindForDiagnostic = ROCKY_LEG_CONTACT_KNEE;
    float legRestingOnImmovableJointClearanceForDiagnostic = 0.0f;
    if (!legHidden)
    {
        RockyLegContact currentContact, currentSecondContact;
        settleLegContactPoints(&currentContact, &currentSecondContact);
        legRestingOnImmovableJoint = (currentContact.kind == ROCKY_LEG_CONTACT_ARC || currentContact.kind == ROCKY_LEG_CONTACT_KNEE || currentContact.kind == ROCKY_LEG_CONTACT_FOOT)
                                   && (currentContact.clearance < SIMULATION_LEG_SETTLE_MIN_DROP);
        pivotKindForDiagnostic = currentContact.kind;
        legRestingOnImmovableJointClearanceForDiagnostic = currentContact.clearance;
    }

    // Whether each probe committed a real move on THIS tick -- used only
    // by the both-probes-committed stalemate check at the very bottom of
    // this function (rockyBothProbesCommittedStreak's own comment above
    // explains why that check exists). Left FALSE by every path that
    // doesn't commit (skip, straddle, scout-only, nothing found at all).
    BOOL probe2Committed = FALSE;
    BOOL probe1Committed = FALSE;

    // TRUE for this tick only when one of Probe 1's four reversal-guard
    // branches actually fired (bestDrop/bestComDrop/bestClearanceGain's
    // direct checks, or the scout fallback's own copy) -- every one of
    // those branches only fires when a real, above-threshold improvement
    // WAS found in the blocked direction, just set aside for one tick to
    // stop it bouncing against last tick's own commit. That is the
    // opposite of "no further improvement exists": real improvement was
    // found and deliberately deferred. Used below to stop the convergence
    // check from latching TRUE on the exact tick this fires -- a real
    // report showed the guard's own blocked-streak reaching its release
    // threshold (SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK) on the SAME
    // tick rockyBodySettleStep's repeated halving (one halving per blocked
    // tick, six of them by the time the streak reaches its threshold)
    // pushed it below SIMULATION_LEG_SETTLE_MIN_STEP_DEG -- convergence
    // fired that same tick and froze the loop for good, so the guard's own
    // release (which was only ever going to take effect the FOLLOWING
    // tick, once its own "< streak" check finally reads false) never
    // actually got to run. The convergence sanity check just above this
    // comment's own block didn't catch that case either: it only scouts a
    // single full-size SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG probe, and the
    // genuine improvement the guard was blocking here was only real at the
    // tiny, already-six-times-halved step size Probe 1 was actually
    // using -- a full-size probe overshoots straight past it into a worse
    // pose and reports no improvement at all. This flag catches that case
    // directly instead, by watching whether a real improvement was found
    // and blocked on this exact tick, regardless of step size.
    BOOL rockyBodyReversalGuardBlockedThisTick = FALSE;

    // Narrower than the two flags just above: TRUE only for a commit via
    // one of that probe's DIRECT branches (bestDrop/bestComDrop/
    // bestClearanceGain), never the scout fallback -- used only by the
    // growth-streak check near the bottom of this function
    // (rockyKneeSettleGrowthStreak's own comment above explains why the
    // scout case is deliberately excluded there).
    BOOL probe2DirectCommit = FALSE;
    BOOL probe1DirectCommit = FALSE;

    // Probe 2: bend the knee. Skipped entirely while the leg is hidden
    // (ID_ROCKY_TOGGLE_LEG_BUTTON, app.h's legHidden comment) -- with no
    // leg being rendered or collision-tested, bending an invisible knee
    // around an invisible foot can never affect anything real (the
    // rectangle's own position/rotation is untouched by kneeAngle -- see
    // getRockyCenter), so this used to just spin kneeAngle through
    // hundreds of degrees for no visible effect, flooding the console
    // with [SETTLE] lines about a foot nobody can see or collide with.
    // Also skipped while legRestingOnImmovableJoint (see its own comment
    // just above), and while rockyProbe2Enabled is FALSE -- the top-right
    // "Probe 2 Settle" checkbox (WM_CREATE/WM_COMMAND's ID_PROBE2_TOGGLE)
    // lets this whole probe be switched off at runtime, leaving only
    // Probe 1's whole-body pivot-around-current-contact toppling active,
    // without deleting any of this code.
    // Probe 2 runs once per settle joint: Rocky's knee, or Semni's knee
    // then hip (each with its own step size -- settleJointStepPtr). Both
    // use the same foot-clearance criterion (settleFootClearance).
    for (int settleJoint = 0; settleJoint < settleJointCount(); settleJoint++)
    {
    // At most ONE joint commits per settle call -- otherwise Semni (knee +
    // hip) could drop the body twice per call where Rocky (knee only) drops
    // once, settling twice as fast. The other joint gets its turn next call.
    if (probe2Committed)
        break;
    float* joint = settleJointPtr(settleJoint);
    float* jointStep = settleJointStepPtr(settleJoint);
    if (!legHidden && !rockyKneeSettleSuppressed && !legRestingOnImmovableJoint && rockyProbe2Enabled && (*jointStep) >= SIMULATION_LEG_SETTLE_MIN_STEP_DEG)
    {
        float baseKneeAngle = (*joint);
        float bestDrop = 0.0f;
        float bestKneeAngle = baseKneeAngle;

        // Baseline clearance of the FOOT alone, captured before either
        // candidate angle is tried below. This is the
        // fallback criterion for when dropActiveRobotToRest can't see an
        // improvement at all: see the comment inside the loop for why
        // that happens and why this catches it.
        float baseFootClearance = settleFootClearance();

        float bestClearanceGain = 0.0f;
        float bestClearanceKneeAngle = baseKneeAngle;

        // Per-direction values, same reason Probe 1 keeps its own
        // dropAtDir[] below: needed after this loop to tell WHICH kind
        // of improvement each direction found (see the straddle check
        // right after this loop).
        float dropAtDir[2] = { 0.0f, 0.0f };
        float gainAtDir[2] = { 0.0f, 0.0f };

        int dirIndex = 0;
        for (int dir = -1; dir <= 1; dir += 2, dirIndex++)
        {
            (*joint) = baseKneeAngle + dir * (*jointStep);

            float drop = dropActiveRobotToRest();
            if (drop > 0.0f)
                translateActiveRobot(0.0f, drop); // undo the probe's own move

            dropAtDir[dirIndex] = drop;

            if (drop > bestDrop)
            {
                bestDrop = drop;
                bestKneeAngle = (*joint);
            }

            // Fallback for exactly the "rectangle rests on a corner,
            // foot dangles in mid-air" pose a real report showed:
            // dropActiveRobotToRest tests a whole-body translate, but
            // bending the knee never moves the rectangle's own corners
            // -- once THOSE are already what's resting on the ground,
            // any candidate kneeAngle re-collides via that same corner
            // the instant the body is pushed down at all, so drop comes
            // back exactly 0.0f no matter how much closer the dangling
            // foot itself would get. Comparing the foot's own clearance
            // directly catches that case: if this candidate angle
            // doesn't embed anything and brings the foot measurably
            // closer to the ground than the baseline, that is a real
            // improvement even though the body itself never moves.
            if (!robotCollidesWithEnvironment())
            {
                float clearance = settleFootClearance();
                float gain = baseFootClearance - clearance;

                if (clearance >= 0.0f)
                    gainAtDir[dirIndex] = gain;

                if (clearance >= 0.0f && gain > bestClearanceGain)
                {
                    bestClearanceGain = gain;
                    bestClearanceKneeAngle = (*joint);
                }
            }
        }

        (*joint) = baseKneeAngle;

        // One direction wants to bend the knee to let the body fall
        // further (bestDrop) while the OPPOSITE direction wants to swing
        // the dangling foot closer instead (bestClearanceGain) -- both
        // genuinely real at the SAME time, just from opposite candidate
        // angles. Committing whichever one happens to win this tick, then
        // finding the other one winning again next tick once the first
        // is undone by the resulting pose change, is exactly what a real
        // report showed as the knee (and the whole robot along with it)
        // visibly rocking back and forth instead of settling -- see
        // Probe 1's own directionsStraddle just below for the mirror
        // image of this same fix (generalized there to any pair of its
        // three criteria, not just drop-vs-gain). Shrinking here instead
        // of picking a side lets a finer step eventually resolve which
        // one the geometry actually favors, same as the existing
        // same-criterion straddle idea.
        BOOL crossCriterionStraddle =
               (dropAtDir[0] > SIMULATION_LEG_SETTLE_MIN_DROP && gainAtDir[1] > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN)
            || (dropAtDir[1] > SIMULATION_LEG_SETTLE_MIN_DROP && gainAtDir[0] > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN);

        // Compared against SIMULATION_LEG_SETTLE_MIN_DROP rather than a
        // bare > 0.0f -- see that constant's own comment on why: without
        // a floor, the search binary search's own precision noise right
        // at the true resting pose reads as an endless string of
        // wafer-thin "improvements," which is exactly what showed up as
        // visible vibration instead of a clean stop.
        if (crossCriterionStraddle)
        {
            SIM_LOG("[SETTLE] %s=%.2f both directions improve but by different criteria (drop=%.5f/%.5f gain=%.5f/%.5f) -- shrinking instead of picking one, to avoid rocking back and forth\n",
                   settleJointName(settleJoint), (*joint), dropAtDir[0], dropAtDir[1], gainAtDir[0], gainAtDir[1]);
            (*jointStep) *= 0.5f;
        }
        else if (bestDrop > SIMULATION_LEG_SETTLE_MIN_DROP)
        {
            // Cap what's actually applied THIS tick -- see
            // SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK's own comment: a
            // small angle step can still uncover a large resting-depth
            // change, and applying all of it in one tick is what read as
            // a sudden snap after looking "stuck." Any amount left over
            // just shows up again as a fresh bestDrop next tick (from the
            // now-lower position), so nothing is lost, only spread out.
            float appliedDrop = bestDrop;
            if (appliedDrop > SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK)
                appliedDrop = SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK;

            (*joint) = bestKneeAngle;
            translateActiveRobot(0.0f, -appliedDrop);
            probe2Committed = TRUE;
            probe2DirectCommit = TRUE;
            SIM_LOG("[SETTLE] %s=%.2f bent the knee %.4f deg, body fell %.5f further this tick (of %.5f available)\n",
                   settleJointName(settleJoint), (*joint), (*jointStep), appliedDrop, bestDrop);
            // Keep this probe's step size as-is -- it's still finding
            // real gains at this scale, no need to refine yet.
        }
        else if (bestClearanceGain > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN)
        {
            // The body itself didn't fall any further, but the dangling
            // foot is now genuinely closer to the ground than it was --
            // commit the knee rotation alone. No translateActiveRobot
            // call here: the body isn't moving, only the foot swings
            // around the still-fixed knee.
            (*joint) = bestClearanceKneeAngle;
            probe2Committed = TRUE;
            probe2DirectCommit = TRUE;
            SIM_LOG("[SETTLE] %s=%.2f swung the dangling foot %.4f deg closer to the ground (clearance improved %.5f, body stayed put)\n",
                   settleJointName(settleJoint), (*joint), (*jointStep), bestClearanceGain);
        }
        else
        {
            // Before shrinking further, scout a much bigger, FIXED angle
            // in each direction -- see SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG's
            // own comment for why a shrinking step alone can get stuck on
            // a local flat spot. Only ever used to decide direction/
            // worthwhileness; the actual committed move below is still
            // just one ordinary (*jointStep)-sized nudge, so this
            // can't itself cause a visible jump.
            BOOL scoutedKnee = FALSE;

            // Both directions are measured and undone before either is
            // judged -- this used to just try dir=-1 (clockwise) first and
            // commit to it the instant it cleared the threshold below,
            // never even scouting dir=+1 (counterclockwise) at all once
            // clockwise passed. That made clockwise win by going first,
            // not by being the better option, which is exactly the
            // clockwise-tipping bias a real report noticed. Scouting both
            // first and picking the larger improvement (same drop-before-
            // gain priority the direct branch above already uses) removes
            // that order bias; see the winner-selection loop just below.
            float scoutDropAtDir[2] = { 0.0f, 0.0f };
            float scoutGainAtDir[2] = { -1.0f, -1.0f };
            BOOL scoutClearAtDir[2] = { FALSE, FALSE };

            int scoutDirIndex = 0;
            for (int dir = -1; dir <= 1; dir += 2, scoutDirIndex++)
            {
                (*joint) = baseKneeAngle + dir * SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG;

                float scoutDrop = dropActiveRobotToRest();
                if (scoutDrop > 0.0f)
                    translateActiveRobot(0.0f, scoutDrop); // undo the probe's own move

                BOOL scoutClear = !robotCollidesWithEnvironment();
                float scoutGain = -1.0f;

                if (scoutClear)
                {
                    float sClearance = settleFootClearance();
                    scoutGain = baseFootClearance - sClearance;
                }

                scoutDropAtDir[scoutDirIndex] = scoutDrop;
                scoutGainAtDir[scoutDirIndex] = scoutGain;
                scoutClearAtDir[scoutDirIndex] = scoutClear;

                (*joint) = baseKneeAngle; // undo this trial, same as the direct branch's own undo above
            }

            // Same drop-before-gain priority the direct branch above uses
            // (bestDrop checked before bestClearanceGain): a real drop
            // candidate always wins over a mere clearance-gain candidate
            // regardless of magnitude, and within the same criterion the
            // larger value wins. scoutDirIndex 0 is dir=-1 (clockwise), 1
            // is dir=+1 (counterclockwise) -- an exact tie between two
            // equally-good candidates still favors index 0 (clockwise)
            // below, same as the direct branch's own strict '>' compares,
            // but that residual tie-break is now the ONLY place clockwise
            // gets an edge, not an unconditional first-past-the-post win.
            int scoutWinner = -1;
            BOOL scoutWinnerIsDrop = FALSE;

            for (int i = 0; i < 2; i++)
            {
                BOOL isDropCandidate = scoutDropAtDir[i] > SIMULATION_LEG_SETTLE_MIN_DROP;
                BOOL isGainCandidate = !isDropCandidate && scoutClearAtDir[i] && scoutGainAtDir[i] > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN;

                if (!isDropCandidate && !isGainCandidate)
                    continue;

                if (scoutWinner == -1)
                {
                    scoutWinner = i;
                    scoutWinnerIsDrop = isDropCandidate;
                }
                else if (isDropCandidate && !scoutWinnerIsDrop)
                {
                    scoutWinner = i;
                    scoutWinnerIsDrop = TRUE;
                }
                else if (isDropCandidate == scoutWinnerIsDrop)
                {
                    if (isDropCandidate && scoutDropAtDir[i] > scoutDropAtDir[scoutWinner])
                        scoutWinner = i;
                    else if (!isDropCandidate && scoutGainAtDir[i] > scoutGainAtDir[scoutWinner])
                        scoutWinner = i;
                }
            }

            if (scoutWinner != -1)
            {
                int dir = (scoutWinner == 0) ? -1 : 1;
                float scoutDrop = scoutDropAtDir[scoutWinner];
                float scoutGain = scoutGainAtDir[scoutWinner];

                (*joint) = baseKneeAngle + dir * (*jointStep);

                // The scout already measured a real, collision-safe
                // drop (scoutDrop) -- but it measured it OUT AT the
                // full scouted angle, not here at the small nudge. Re-
                // probing dropActiveRobotToRest() at the nudge angle
                // (the previous version of this fix) mostly finds
                // almost nothing, because the ground clearance opens up
                // gradually across the whole scouted range, not right at
                // its very start -- that read as the body creeping down
                // by a few thousandths per tick while still rotating
                // through tens of degrees, i.e. still visibly "floating"
                // for a long time, just no longer perfectly frozen.
                // Instead, spend from the SAME per-tick budget
                // (SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK) the real
                // bestDrop branch above already uses, straight out of
                // scoutDrop, so the body catches up in only a handful of
                // ticks instead of dozens. This is optimistic -- the
                // clearance at the nudge angle isn't actually the same
                // clearance measured at the scouted angle -- so verify
                // afterward and fall back to whatever's genuinely safe
                // right here if it turns out to overshoot into the
                // environment. Skipped when this nudge was only the
                // clearanceGain (dangling-foot) case, matching the real
                // branch above: the body genuinely isn't meant to move
                // there, only the foot swings.
                float nudgeAppliedDrop = 0.0f;
                if (scoutDrop > SIMULATION_LEG_SETTLE_MIN_DROP)
                {
                    nudgeAppliedDrop = scoutDrop;
                    if (nudgeAppliedDrop > SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK)
                        nudgeAppliedDrop = SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK;
                    translateActiveRobot(0.0f, -nudgeAppliedDrop);

                    if (robotCollidesWithEnvironment())
                    {
                        // Optimistic budget didn't actually fit at this
                        // angle -- undo it and fall back to the old,
                        // always-safe approach: whatever's genuinely
                        // available right here, found the same way
                        // dropActiveRobotToRest already searches.
                        translateActiveRobot(0.0f, nudgeAppliedDrop);
                        nudgeAppliedDrop = dropActiveRobotToRest();
                        if (nudgeAppliedDrop > SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK)
                            nudgeAppliedDrop = SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK;
                        if (nudgeAppliedDrop > 0.0f)
                            translateActiveRobot(0.0f, -nudgeAppliedDrop);
                        else
                            nudgeAppliedDrop = 0.0f;
                    }
                }

                SIM_LOG("[SETTLE] %s=%.2f scouted real improvement %.1f deg out (drop=%.5f clearanceGain=%.5f), fell %.5f this tick -- nudging that way instead of shrinking\n",
                       settleJointName(settleJoint), (*joint), dir * SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG, scoutDrop, scoutGain, nudgeAppliedDrop);
                scoutedKnee = TRUE;
                probe2Committed = TRUE;
            }

            if (!scoutedKnee)
            {
                (*joint) = baseKneeAngle;
                (*jointStep) *= 0.5f; // nothing here, and nothing further out either -- get finer before giving up
            }
        }
    }
    else if (!legHidden)
    {
        // Diagnostic only, temporary -- a real report showed Probe 2
        // staying completely silent (no [SETTLE] kneeAngle=... lines at
        // all) for long stretches while Probe 1 alone kept pivoting the
        // body, with the foot left visibly dangling well clear of the
        // ground the whole time and no [SETTLE] converged line either
        // (so it wasn't genuine convergence). rockyKneeSettleSuppressed
        // was the leading suspect (its own comment describes it as set
        // TRUE on every E/Q WM_KEYDOWN) but turned out to never actually
        // be set TRUE anywhere in this file -- only ever declared FALSE
        // and reset to FALSE -- so it can't be the real cause; this
        // prints whichever of the four OTHER conditions is actually
        // false instead of guessing further.
        SIM_LOG("[SETTLE] Probe 2 (%s) skipped this tick -- suppressed=%d legRestingOnImmovableJoint=%d(kind=%d clearance=%.5f) probe2Enabled=%d step=%.5f (min=%.5f)\n",
               settleJointName(settleJoint), rockyKneeSettleSuppressed, legRestingOnImmovableJoint,
               legRestingOnImmovableJoint ? (int)pivotKindForDiagnostic : -1,
               legRestingOnImmovableJointClearanceForDiagnostic,
               rockyProbe2Enabled, (*jointStep), SIMULATION_LEG_SETTLE_MIN_STEP_DEG);
    }
    } // end per-joint Probe 2 loop

    // Probe 1: rotate the rectangle itself. This used to just change
    // (*bodyAngle) directly, which always rotates around (bodyX, bodyY) --
    // Rocky's own rectangle center -- no matter what's actually touching
    // the ground. That's why a real report showed the body permanently
    // stuck hovering next to a planted foot (screenshot: only the foot
    // circle on the ground, the knee circle and rectangle floating well
    // above it, [SETTLE] converged and never moving again): rotating
    // around the CENTER swings the foot along its own arc too, and once
    // that arc reaches its lowest point, further rotation in the same
    // direction starts lifting the foot back up, so the confirmed drop
    // shrinks toward zero and the probe "correctly" (by its own narrow
    // measure) concludes there's nothing left to gain -- even though the
    // rectangle is still plainly floating. A real object balanced on one
    // point doesn't spin around its own centroid when gravity tips it;
    // it pivots around whatever's actually touching the ground, and keeps
    // doing so until either its center of mass swings over that point or
    // something else comes down to meet it. rockyTopplePivotWorld picks
    // that contact point (knee or foot, whichever is closer to the
    // ground) once, before either direction is tried, and
    // rotateRockyBodyAroundPivot rotates around THAT instead of the
    // center -- see both their own comments above for the mechanics.
    // dropActiveRobotToRest still only re-tests straight-down clearance
    // afterward, on top of the pivot, so a candidate only ever commits if
    // it genuinely opens up more room to fall, same guarantee as before.
    if (rockyBodySettleStep >= SIMULATION_LEG_SETTLE_MIN_STEP_DEG)
    {
        float baseBodyAngle = (*bodyAngle);
        PointF pivot = settleTopplePivotWorld(); // same contact point for both directions below

        // The anti-oscillation machinery below (pivot-side-flip halving and
        // the reversal guard) is only meant for a body rocking back and
        // forth near BALANCE, where the center of mass sits almost over the
        // pivot. When the center of mass is far off to one side of the only
        // contact, the torque direction is unambiguous -- the body simply
        // has to topple that way -- so blocking or shrinking that move just
        // freezes an impossible pose (see SIMULATION_ROCKY_REVERSAL_GUARD_MAX_COM_OFFSET).
        //
        // "Far from the pivot" alone isn't enough, though: resting on TWO
        // contacts (e.g. knee AND foot both on the ground) with the center
        // of mass BETWEEN them is a stable rest pose even though the center
        // of mass is far from either one. There, no rotation is physically
        // possible, and without the guard Probe 1 just alternates pivots
        // (knee, foot, knee, ...) nudging +/- one step forever (real
        // report: bodyAngle bouncing 451.00 <-> 451.25). So the guard stays
        // armed whenever the second-closest contact is also touching and
        // the center of mass lies horizontally between the two.
        float reversalGuardComX = settleMassCenter().x;
        float reversalGuardComOffset = fabsf(pivot.x - reversalGuardComX);
        BOOL reversalGuardArmed = (reversalGuardComOffset <= SIMULATION_ROCKY_REVERSAL_GUARD_MAX_COM_OFFSET);
        if (!reversalGuardArmed && !(legHidden && bodyHidden))
        {
            RockyLegContact supportA, supportB;
            settleToppleContactPoints(&supportA, &supportB);
            if (supportB.clearance <= robotLengthToEnvWorld(SIMULATION_ROCKY_SUPPORT_CONTACT_TOL))
            {
                float supportLo = (supportA.world.x < supportB.world.x) ? supportA.world.x : supportB.world.x;
                float supportHi = (supportA.world.x < supportB.world.x) ? supportB.world.x : supportA.world.x;
                if (reversalGuardComX >= supportLo && reversalGuardComX <= supportHi)
                    reversalGuardArmed = TRUE; // supported on both sides -- a real rest pose, keep anti-oscillation on
            }
        }

        // Binary-division fix for a specific vibration report, by explicit
        // request -- see rockyPivotSide's own comment above for the full
        // reasoning. Measured off the CURRENT (pre-rotation) mass center,
        // same baseBodyAngle pose the pivot itself was just picked from.
        {
            float pivotComX = settleMassCenter().x;
            int currentPivotSide = (pivot.x < pivotComX) ? -1 : 1;
            if (rockyPivotSide != 0 && currentPivotSide != rockyPivotSide && reversalGuardArmed)
            {
                SIM_LOG("[SETTLE] bodyAngle=%.2f pivot flipped sides of the center of mass (side=%d -> %d) -- halving rockyBodySettleStep to stop it vibrating across center\n",
                       (*bodyAngle), rockyPivotSide, currentPivotSide);
                rockyBodySettleStep *= 0.5f;
            }
            else if (rockyPivotSide != 0 && currentPivotSide != rockyPivotSide)
            {
                SIM_LOG("[SETTLE] bodyAngle=%.2f pivot flipped sides of the center of mass (side=%d -> %d), but the center of mass is %.4f away and not between two contacts -- a real topple, not vibration, so not halving and not reversal-guarding\n",
                       (*bodyAngle), rockyPivotSide, currentPivotSide, reversalGuardComOffset);
                rockyBodyReversalBlockedStreak = 0;
            }
            rockyPivotSide = currentPivotSide;
        }

        float bestDrop = 0.0f;
        float bestBodyAngle = baseBodyAngle;
        PointF bestShift = { 0.0f, 0.0f };
        float bestResidual = 0.0f;
        int bestDropDir = 0; // -1/+1 once bestDrop has a real winner -- see rockyBodyLastCommitDir above

        // Fallback for the exact mirror of Probe 2's "dangling foot" case
        // above, just from the other direction: as long as the point
        // rockyTopplePivotWorld picked is ALREADY on the ground, holding
        // it fixed (rotateRockyBodyAroundPivot) means dropActiveRobotToRest
        // can never see any benefit from rotating -- it's blocked by that
        // same pivot at ~0 clearance no matter which way the body turns,
        // right up until the OTHER point (the dangling one) also reaches
        // the ground. Without tracking that point's own clearance
        // directly, Probe 1 is structurally blind to the entire toppling
        // motion in between -- a fixed-size angle step can then jump
        // straight past the one instant both points cross zero together,
        // planting the dangling point while lifting the pivot back off,
        // exactly the overshoot a real report showed (pressing E once
        // swinging past the two-contact pose instead of landing on it).
        // See rockyDanglingPointClearance's own comment for the mechanics.
        // Skipped entirely when the leg is hidden -- same reasoning as
        // Probe 2's own !legHidden guard above: with no leg being
        // rendered or collision-tested, its knee/foot circles are just
        // stale numbers left over in the Rocky struct, not anything real
        // that's actually resting on (or dangling above) the ground. Using
        // them here would silently drive body rotation off of clearance
        // values that have nothing to do with what's actually visible or
        // collidable -- exactly the kind of ungrounded nudge a real report
        // showed as a bare rectangle (no leg) endlessly rocking a degree or
        // two around 90 instead of settling flush, once this fallback
        // started firing off invisible-leg geometry it was never meant to
        // look at for a legless Rocky.
        float baseDanglingClearance = legHidden ? 0.0f : settleDanglingPointClearance();
        float bestClearanceGain = 0.0f;
        float bestClearanceBodyAngle = baseBodyAngle;
        PointF bestClearanceShift = { 0.0f, 0.0f };
        float bestClearanceResidual = 0.0f;
        int bestClearanceGainDir = 0; // same idea as bestDropDir above

        // Third fallback, alongside bestDrop and bestClearanceGain just
        // above: the actual height of the whole body's CENTER OF MASS
        // (computeRockyMassCenterWorld), not just some other single
        // point's distance to the ground. Needed because bestDrop AND
        // bestClearanceGain can BOTH go structurally silent at the same
        // time -- see SIMULATION_LEG_SETTLE_MIN_COM_DROP's own comment in
        // config.h for exactly when and why (a single already-touching
        // pivot with nothing else close enough to register a gain, e.g.
        // the leg resting on just its convex shin arc, nothing else
        // dangling nearby). Center-of-mass height is the quantity gravity
        // is actually minimizing, so this keeps the search moving toward
        // the true physical rest angle even in that silent case, instead
        // of grinding its step down to nothing and stopping with the mass
        // center visibly off to the side of the single contact point --
        // exactly what a real report showed for a leg-only Rocky resting
        // on its convex shin arc.
        //
        // Deliberately given PRIORITY OVER bestClearanceGain below (tried
        // first, not last) -- a real report showed the two disagreeing
        // and ping-ponging forever once both were live at once: at one
        // angle bestComDrop found real progress rotating one way; one
        // step later, from the NEW angle, bestClearanceGain found real
        // progress rotating back. Both readings were individually
        // correct, but bestClearanceGain's own notion of "the dangling
        // point" is whichever leg point rockyLegContactPoints currently
        // finds SECOND-closest -- and that identity can itself flip
        // between different points (say, the knee versus a nearby arc
        // sample) as the angle changes by one step, making its
        // improvement reading non-monotonic across ticks in a way no
        // single-tick straddle check can catch (see the unified
        // directionsStraddle check below, which only compares the two
        // CANDIDATE directions within the SAME tick). bestComDrop has no
        // such identity to flip -- it's one smooth scalar (the whole
        // body's actual mass-weighted height) -- so it doesn't have this
        // failure mode, and giving it priority means a disagreement
        // between the two resolves in favor of the one actually tied to
        // gravity's real objective.
        float baseComY = settleMassCenter().y;
        float bestComDrop = 0.0f;
        float bestComBodyAngle = baseBodyAngle;
        PointF bestComShift = { 0.0f, 0.0f };
        float bestComResidual = 0.0f;
        int bestComDropDir = 0; // same idea as bestDropDir above

        // Raw drop found in EACH direction, kept separately from bestDrop
        // above (which only remembers the winner) -- see the unified
        // directionsStraddle check right after this loop for why all
        // three matter, not just whichever is largest. gainAtDir is the
        // same idea for the dangling-point clearance gain, comDropAtDir
        // for the center-of-mass drop.
        float dropAtDir[2] = { 0.0f, 0.0f };
        float gainAtDir[2] = { 0.0f, 0.0f };
        float comDropAtDir[2] = { 0.0f, 0.0f };

        int dirIndex = 0;
        for (int dir = -1; dir <= 1; dir += 2, dirIndex++)
        {
            float deltaAngle = dir * rockyBodySettleStep;
            PointF shift = rotateActiveBodyAroundPivot(pivot, deltaAngle);

            // Clears a possible sub-precision rounding residual left by
            // the pivot rotation itself (see clearPivotRoundingResidual's
            // own comment) BEFORE asking dropActiveRobotToRest whether
            // this candidate helps -- otherwise its very first check
            // would see the pivot point as still (falsely) colliding and
            // report 0.0f no matter what.
            float residual = clearPivotRoundingResidual();

            float drop = dropActiveRobotToRest();
            if (drop > 0.0f)
                translateActiveRobot(0.0f, drop); // undo the probe's own vertical move

            dropAtDir[dirIndex] = drop;

            if (drop > bestDrop)
            {
                bestDrop = drop;
                bestBodyAngle = (*bodyAngle);
                bestShift = shift;
                bestResidual = residual;
                bestDropDir = dir;
            }

            // Same "did this get measurably closer, without embedding"
            // check Probe 2's own dangling-foot fallback uses just above
            // -- see the comment before this loop for why Probe 1 needs
            // its own copy of it. Measured right here, after the pivot
            // rotation + residual correction but before undoing them
            // below, so it reflects exactly this candidate's world pose.
            // Collision checked ONCE and shared by both the center-of-
            // mass measurement just below (meaningful regardless of
            // legHidden/bodyHidden -- computeRockyMassCenterWorld already
            // accounts for either part being hidden on its own) and the
            // dangling-point gain measurement (still leg-only, guarded by
            // its own !legHidden nested inside).
            if (!robotCollidesWithEnvironment())
            {
                PointF com = settleMassCenter();
                float comDrop = baseComY - com.y;
                comDropAtDir[dirIndex] = comDrop;

                if (comDrop > bestComDrop)
                {
                    bestComDrop = comDrop;
                    bestComBodyAngle = (*bodyAngle);
                    bestComShift = shift;
                    bestComResidual = residual;
                    bestComDropDir = dir;
                }

                if (!legHidden)
                {
                    float clearance = settleDanglingPointClearance();
                    float gain = baseDanglingClearance - clearance;

                    // A "dangling point closer" move must not RAISE the center of mass:
                    // gravity never lifts a body just to bring a hovering point down.
                    // Without this, a COM-drop commit one tick and a gain commit back
                    // the other way the next tick bounced bodyAngle +/- one step forever
                    // (real report: 334.39 <-> 335.39, COM rising 0.01465 on every gain step).
                    if (clearance >= 0.0f && comDrop >= -SIMULATION_LEG_SETTLE_MIN_COM_DROP)
                        gainAtDir[dirIndex] = gain;

                    if (clearance >= 0.0f && comDrop >= -SIMULATION_LEG_SETTLE_MIN_COM_DROP && gain > bestClearanceGain)
                    {
                        bestClearanceGain = gain;
                        bestClearanceBodyAngle = (*bodyAngle);
                        bestClearanceShift = shift;
                        bestClearanceResidual = residual;
                        bestClearanceGainDir = dir;
                    }
                }
            }

            if (residual > 0.0f)
                translateActiveRobot(0.0f, -residual); // undo the residual correction too
            translateActiveRobot(-shift.x, -shift.y); // undo this candidate's pivot rotation
            (*bodyAngle) = baseBodyAngle;
        }

        // Whether EITHER candidate direction has ANY criterion (drop,
        // center-of-mass, or dangling-point gain -- doesn't matter which)
        // showing a real, above-noise improvement right now. Used below
        // to decide "both directions want something, so shrink instead
        // of picking one" -- a single unified check standing in for what
        // used to be three separate ad hoc ones (a flat edge straddling
        // its own flush angle, one direction's drop against the other's
        // gain, one direction's comDrop against the other's comDrop).
        // Collapsing them into one general "does this direction have ANY
        // qualifying signal" test catches every pairing, including
        // combinations no earlier version of this code ever explicitly
        // named (a real report showed exactly one: one tick's comDrop
        // winning, the very next tick's gain winning back, forever --
        // two DIFFERENT criteria, each only checked in isolation against
        // its own kind on the SAME tick, so neither of the old pairwise
        // checks ever saw the conflict). A rigid body settling against a
        // surface only has one genuinely stable angle at a time; if both
        // directions look like progress by SOME measure, the true
        // resting angle is still being bracketed, not found -- shrinking
        // the step lets a finer step resolve it instead of ping-ponging
        // between two angles that each look right by a different
        // yardstick.
        BOOL dirQualifies[2];
        for (int i = 0; i < 2; i++)
        {
            dirQualifies[i] = (dropAtDir[i] > SIMULATION_LEG_SETTLE_MIN_DROP)
                            || (comDropAtDir[i] > SIMULATION_LEG_SETTLE_MIN_COM_DROP)
                            || (gainAtDir[i] > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN);
        }
        BOOL directionsStraddle = dirQualifies[0] && dirQualifies[1];

        if (directionsStraddle)
        {
            SIM_LOG("[SETTLE] bodyAngle=%.2f both directions still improve (drop=%.5f/%.5f comDrop=%.5f/%.5f gain=%.5f/%.5f) -- shrinking instead of picking one, to avoid oscillating across the exact resting angle\n",
                   (*bodyAngle), dropAtDir[0], dropAtDir[1], comDropAtDir[0], comDropAtDir[1], gainAtDir[0], gainAtDir[1]);
            rockyBodySettleStep *= 0.5f;
        }
        else if (rockyBodyLastCommitDir != 0 && bestDrop > SIMULATION_LEG_SETTLE_MIN_DROP && bestDropDir == -rockyBodyLastCommitDir
                 && rockyBodyReversalBlockedStreak < SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK
                 && reversalGuardArmed)
        {
            // bestDrop would fire below, but in the OPPOSITE direction
            // from whatever Probe 1 actually committed last tick -- see
            // rockyBodyLastCommitDir's own comment above for the real
            // report this guards against (bestDrop and bestComDrop
            // disagreeing on direction from one tick to the next,
            // bouncing bodyAngle between two fixed values forever).
            // Shrinking here instead of reversing is the same fix
            // directionsStraddle/rockyPivotSide already use for their own
            // shape of this problem. See rockyBodyReversalBlockedStreak's
            // own comment for the extra trailing condition above.
            rockyBodyReversalBlockedStreak++;
            rockyBodyReversalGuardBlockedThisTick = TRUE;
            SIM_LOG("[SETTLE] bodyAngle=%.2f bestDrop wants to pivot back the OPPOSITE way from last tick's own commit (dir %d -> %d) -- shrinking instead of reversing, to stop it bouncing between two angles forever (blocked streak %d/%d)\n",
                   (*bodyAngle), rockyBodyLastCommitDir, bestDropDir, rockyBodyReversalBlockedStreak, SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK);
            shrinkRockyBodyStepForReversalGuard();
        }
        else if (bestDrop > SIMULATION_LEG_SETTLE_MIN_DROP)
        {
            // Same per-tick cap as the knee probe above, same reason --
            // see SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK's comment. The
            // pivot shift AND its residual correction are applied in full
            // (they're what makes this a real pivot instead of a
            // center-spin, and what keeps it there without a false
            // self-collision) -- only the LEFTOVER straight-down settling
            // on top of them is capped/gradual.
            float appliedDrop = bestDrop;
            if (appliedDrop > SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK)
                appliedDrop = SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK;

            (*bodyAngle) = bestBodyAngle;
            translateActiveRobot(bestShift.x, bestShift.y);
            if (bestResidual > 0.0f)
                translateActiveRobot(0.0f, bestResidual);
            translateActiveRobot(0.0f, -appliedDrop);
            probe1Committed = TRUE;
            probe1DirectCommit = TRUE;
            // Only a genuine REVERSAL (a new committed direction that
            // actually differs from the last one) clears the blocked-
            // streak below -- an ordinary commit that just continues the
            // SAME direction doesn't mean the standoff with the opposite
            // direction is resolved, only that this direction still has
            // its own separate progress available too. Zeroing on every
            // commit (tried first) let a run of same-direction commits
            // keep quietly erasing the streak just before it reached
            // SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK, so the genuine
            // reversal it was there to eventually allow never actually
            // got its turn -- see that constant's own comment (config.h).
            if (bestDropDir != rockyBodyLastCommitDir)
                rockyBodyReversalBlockedStreak = 0;
            rockyBodyLastCommitDir = bestDropDir;
            SIM_LOG("[SETTLE] bodyAngle=%.2f pivoted the assembly %.4f deg around its ground contact, it fell %.5f further this tick (of %.5f available)\n",
                   (*bodyAngle), rockyBodySettleStep, appliedDrop, bestDrop);
        }
        else if (rockyBodyLastCommitDir != 0 && bestComDrop > SIMULATION_LEG_SETTLE_MIN_COM_DROP && bestComDropDir == -rockyBodyLastCommitDir
                 && rockyBodyReversalBlockedStreak < SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK
                 && reversalGuardArmed)
        {
            // Same reversal guard as bestDrop's own copy just above, for
            // the exact bestDrop-then-bestComDrop-reversing pairing the
            // real report showed -- see rockyBodyLastCommitDir's comment.
            rockyBodyReversalBlockedStreak++;
            rockyBodyReversalGuardBlockedThisTick = TRUE;
            SIM_LOG("[SETTLE] bodyAngle=%.2f bestComDrop wants to pivot back the OPPOSITE way from last tick's own commit (dir %d -> %d) -- shrinking instead of reversing, to stop it bouncing between two angles forever (blocked streak %d/%d)\n",
                   (*bodyAngle), rockyBodyLastCommitDir, bestComDropDir, rockyBodyReversalBlockedStreak, SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK);
            shrinkRockyBodyStepForReversalGuard();
        }
        else if (bestComDrop > SIMULATION_LEG_SETTLE_MIN_COM_DROP)
        {
            // Checked BEFORE bestClearanceGain just below -- see this
            // block's own top-of-scope comment (right after
            // bestClearanceGain's declaration) for why the priority is
            // this way around now.
            (*bodyAngle) = bestComBodyAngle;
            translateActiveRobot(bestComShift.x, bestComShift.y);
            if (bestComResidual > 0.0f)
                translateActiveRobot(0.0f, bestComResidual);
            probe1Committed = TRUE;
            probe1DirectCommit = TRUE;
            // See bestDrop's own copy of this same check just above for
            // why only a genuine direction CHANGE clears the streak.
            if (bestComDropDir != rockyBodyLastCommitDir)
                rockyBodyReversalBlockedStreak = 0;
            rockyBodyLastCommitDir = bestComDropDir;
            SIM_LOG("[SETTLE] bodyAngle=%.2f pivoted the assembly %.4f deg around its ground contact, center of mass dropped %.5f further (no further translation, gravity settling by mass alone)\n",
                   (*bodyAngle), rockyBodySettleStep, bestComDrop);
        }
        else if (rockyBodyLastCommitDir != 0 && bestClearanceGain > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN && bestClearanceGainDir == -rockyBodyLastCommitDir
                 && rockyBodyReversalBlockedStreak < SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK
                 && reversalGuardArmed)
        {
            // Same reversal guard again, this time for bestClearanceGain --
            // see rockyBodyLastCommitDir's comment above.
            rockyBodyReversalBlockedStreak++;
            rockyBodyReversalGuardBlockedThisTick = TRUE;
            SIM_LOG("[SETTLE] bodyAngle=%.2f bestClearanceGain wants to pivot back the OPPOSITE way from last tick's own commit (dir %d -> %d) -- shrinking instead of reversing, to stop it bouncing between two angles forever (blocked streak %d/%d)\n",
                   (*bodyAngle), rockyBodyLastCommitDir, bestClearanceGainDir, rockyBodyReversalBlockedStreak, SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK);
            shrinkRockyBodyStepForReversalGuard();
        }
        else if (bestClearanceGain > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN)
        {
            // The whole body isn't falling any further (the pivot's still
            // blocking that test) and the center of mass isn't measurably
            // lower either, but the dangling knee/foot is now genuinely
            // closer to the ground than it was -- commit the rotation
            // alone, same idea as Probe 2's own dangling-foot branch just
            // above. Still need to replay the shift + residual (a pivot
            // rotation always moves bodyX/bodyY to keep the pivot itself
            // fixed, unlike Probe 2's pure kneeAngle change), just no
            // extra straight-down translateActiveRobot on top -- there is
            // genuinely nothing further to fall yet at this angle.
            (*bodyAngle) = bestClearanceBodyAngle;
            translateActiveRobot(bestClearanceShift.x, bestClearanceShift.y);
            if (bestClearanceResidual > 0.0f)
                translateActiveRobot(0.0f, bestClearanceResidual);
            probe1Committed = TRUE;
            probe1DirectCommit = TRUE;
            // See bestDrop's own copy of this same check further above
            // for why only a genuine direction CHANGE clears the streak.
            if (bestClearanceGainDir != rockyBodyLastCommitDir)
                rockyBodyReversalBlockedStreak = 0;
            rockyBodyLastCommitDir = bestClearanceGainDir;
            SIM_LOG("[SETTLE] bodyAngle=%.2f pivoted the assembly %.4f deg around its ground contact, dangling point %.5f closer to the ground (no further translation)\n",
                   (*bodyAngle), rockyBodySettleStep, bestClearanceGain);
        }
        else
        {
            // Same scouting idea as the knee probe above, same reason --
            // now checking the drop criterion, the center-of-mass
            // criterion, AND the dangling-point clearance criterion at
            // the bigger scouted angle, mirroring the direct branch's own
            // three criteria (and their priority order) just above. Same
            // contact-point pivot as the direct branch, not a center-spin.
            BOOL scoutedBody = FALSE;

            // Both directions are measured and undone before either is
            // judged -- see the knee probe's own scout branch above for
            // the full reasoning: trying dir=-1 (clockwise) first and
            // committing to it the instant it cleared the threshold below
            // meant clockwise silently won every time both directions were
            // actually viable, never even scouting dir=+1 (counterclockwise)
            // once clockwise passed. Scouting both first and picking the
            // larger improvement (same drop-before-comDrop-before-gain
            // priority the direct branch above uses) removes that order
            // bias.
            float scoutDropAtDir[2] = { 0.0f, 0.0f };
            float scoutGainAtDir[2] = { -1.0f, -1.0f };
            float scoutComDropAtDir[2] = { 0.0f, 0.0f };
            BOOL scoutClearAtDir[2] = { FALSE, FALSE };

            int scoutDirIndex = 0;
            for (int dir = -1; dir <= 1; dir += 2, scoutDirIndex++)
            {
                float scoutDelta = dir * SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG;
                PointF scoutShift = rotateActiveBodyAroundPivot(pivot, scoutDelta);

                // Same false-self-collision fix as the direct branch above
                // -- see clearPivotRoundingResidual's own comment -- needed
                // here too, since the scout's OWN pivot rotation has the
                // exact same rounding-residual risk.
                float scoutResidual = clearPivotRoundingResidual();

                float scoutDrop = dropActiveRobotToRest();
                if (scoutDrop > 0.0f)
                    translateActiveRobot(0.0f, scoutDrop); // undo the probe's own vertical move

                // Same dangling-point and center-of-mass measurements as
                // the direct branch's own loop above, just out at the
                // full scouted angle -- see the comment before that loop
                // for why these are needed at all (dropActiveRobotToRest
                // alone can't see either).
                BOOL scoutClear = !robotCollidesWithEnvironment();
                float scoutGain = -1.0f;
                float scoutComDrop = 0.0f;
                if (scoutClear)
                {
                    PointF scoutCom = settleMassCenter();
                    scoutComDrop = baseComY - scoutCom.y;

                    if (!legHidden)
                    {
                        float scoutClearance = settleDanglingPointClearance();
                        scoutGain = baseDanglingClearance - scoutClearance;
                    }
                }

                scoutDropAtDir[scoutDirIndex] = scoutDrop;
                scoutGainAtDir[scoutDirIndex] = scoutGain;
                scoutComDropAtDir[scoutDirIndex] = scoutComDrop;
                scoutClearAtDir[scoutDirIndex] = scoutClear;

                if (scoutResidual > 0.0f)
                    translateActiveRobot(0.0f, -scoutResidual); // undo the scout's residual correction too
                translateActiveRobot(-scoutShift.x, -scoutShift.y); // undo the scout's pivot rotation
                (*bodyAngle) = baseBodyAngle;
            }

            // Same drop-before-comDrop-before-gain priority as the direct
            // branch above, generalized to a tier number (2=drop,
            // 1=comDrop, 0=gain) so a higher tier always beats a lower
            // one regardless of magnitude, and only ties within the SAME
            // tier are broken by magnitude. scoutDirIndex 0 is dir=-1
            // (clockwise), 1 is dir=+1 (counterclockwise).
            int scoutWinner = -1;
            int scoutWinnerTier = -1;
            float scoutWinnerValue = 0.0f;

            for (int i = 0; i < 2; i++)
            {
                int tier;
                float value;

                if (scoutDropAtDir[i] > SIMULATION_LEG_SETTLE_MIN_DROP)
                {
                    tier = 2;
                    value = scoutDropAtDir[i];
                }
                else if (scoutClearAtDir[i] && scoutComDropAtDir[i] > SIMULATION_LEG_SETTLE_MIN_COM_DROP)
                {
                    tier = 1;
                    value = scoutComDropAtDir[i];
                }
                else if (scoutClearAtDir[i] && scoutGainAtDir[i] > SIMULATION_LEG_SETTLE_MIN_CLEARANCE_GAIN
                         && scoutComDropAtDir[i] >= -SIMULATION_LEG_SETTLE_MIN_COM_DROP) // same "never raise the COM" rule as the direct gain branch
                {
                    tier = 0;
                    value = scoutGainAtDir[i];
                }
                else
                {
                    continue;
                }

                if (scoutWinner == -1 || tier > scoutWinnerTier || (tier == scoutWinnerTier && value > scoutWinnerValue))
                {
                    scoutWinner = i;
                    scoutWinnerTier = tier;
                    scoutWinnerValue = value;
                }
            }

            if (scoutWinner != -1 && rockyBodyLastCommitDir != 0 && ((scoutWinner == 0) ? -1 : 1) == -rockyBodyLastCommitDir
                && rockyBodyReversalBlockedStreak < SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK
                 && reversalGuardArmed)
            {
                // Same reversal guard as the three direct branches above
                // (see rockyBodyLastCommitDir's comment) -- the scouted
                // angle is real progress by its own measure, but it's
                // back the way Probe 1 just came from last tick, so
                // committing it would be the exact same cross-tick
                // bounce, just found via the scout path instead of a
                // direct branch. scoutedBody stays FALSE, which falls
                // through to the shrink just below, same as finding no
                // scouted improvement at all. See
                // rockyBodyReversalBlockedStreak's own comment for the
                // extra trailing condition above.
                rockyBodyReversalBlockedStreak++;
                rockyBodyReversalGuardBlockedThisTick = TRUE;
                SIM_LOG("[SETTLE] bodyAngle=%.2f scouted improvement is back the OPPOSITE way from last tick's own commit -- shrinking instead of reversing, same as the direct branches above (blocked streak %d/%d)\n",
                       (*bodyAngle), rockyBodyReversalBlockedStreak, SIMULATION_ROCKY_BODY_REVERSAL_BLOCK_STREAK);
            }
            else if (scoutWinner != -1)
            {
                int dir = (scoutWinner == 0) ? -1 : 1;
                float scoutDrop = scoutDropAtDir[scoutWinner];
                float scoutGain = scoutGainAtDir[scoutWinner];
                float scoutComDrop = scoutComDropAtDir[scoutWinner];

                float nudgeDelta = dir * rockyBodySettleStep;
                rotateActiveBodyAroundPivot(pivot, nudgeDelta); // committed, kept below
                clearPivotRoundingResidual(); // same fix, also kept -- see above

                // Same follow-up as the knee probe's scout branch, same
                // reasoning -- see its comment for the full explanation:
                // spend straight from scoutDrop (already known safe out
                // at the full scouted angle), capped to the same per-
                // tick budget the real bestDrop branch above uses,
                // rather than re-measuring the (usually tiny) clearance
                // actually available at the small nudge angle. Verified
                // afterward and pulled back to whatever's genuinely safe
                // here if the optimistic amount doesn't actually fit.
                // Skipped when this nudge was only the scoutComDrop or
                // scoutGain case, matching the direct branch above and
                // Probe 2's own scout branch: the body genuinely isn't
                // meant to drop any further here, only pivot.
                float nudgeAppliedDrop = 0.0f;
                if (scoutDrop > SIMULATION_LEG_SETTLE_MIN_DROP)
                {
                    nudgeAppliedDrop = scoutDrop;
                    if (nudgeAppliedDrop > SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK)
                        nudgeAppliedDrop = SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK;
                    translateActiveRobot(0.0f, -nudgeAppliedDrop);

                    if (robotCollidesWithEnvironment())
                    {
                        translateActiveRobot(0.0f, nudgeAppliedDrop);
                        nudgeAppliedDrop = dropActiveRobotToRest();
                        if (nudgeAppliedDrop > SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK)
                            nudgeAppliedDrop = SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK;
                        if (nudgeAppliedDrop > 0.0f)
                            translateActiveRobot(0.0f, -nudgeAppliedDrop);
                        else
                            nudgeAppliedDrop = 0.0f;
                    }
                }

                SIM_LOG("[SETTLE] bodyAngle=%.2f pivoted around its ground contact, scouted real improvement %.1f deg out (drop=%.5f comDrop=%.5f gain=%.5f), fell %.5f this tick -- nudging that way instead of shrinking\n",
                       (*bodyAngle), dir * SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG, scoutDrop, scoutComDrop, scoutGain, nudgeAppliedDrop);
                scoutedBody = TRUE;
                probe1Committed = TRUE;
                // See bestDrop's own copy of this same check further above
                // for why only a genuine direction CHANGE clears the streak.
                if (dir != rockyBodyLastCommitDir)
                    rockyBodyReversalBlockedStreak = 0;
                rockyBodyLastCommitDir = dir;
            }

            if (!scoutedBody)
            {
                if (rockyBodyReversalGuardBlockedThisTick) shrinkRockyBodyStepForReversalGuard(); else rockyBodySettleStep *= 0.5f;
            }
        }
    }

    // Stalemate check: Probe 2 and Probe 1 run sequentially in THIS same
    // call, each one committing based on whatever the OTHER one just left
    // behind (Probe 2 above bent the knee using the body angle from
    // Probe 1's PREVIOUS tick; Probe 1 just above pivoted the body using
    // the kneeAngle Probe 2 only just set, this same tick). Neither
    // probe's own directionsStraddle-style check can see that -- each one
    // only compares its OWN two candidate directions against each other,
    // never against what the other probe did. If both probes keep finding
    // a genuine-by-their-own-narrow-measure improvement every tick without
    // either commit branch ever shrinking its step (see those branches'
    // own "no need to refine yet" comments), the two can chase each
    // other's moving target indefinitely, no matter WHICH pair of their
    // criteria happens to be driving it -- two separate real reports
    // showed this with two different pairs (bestComDrop/bestClearanceGain
    // with the knee as the primary contact, now separately guarded by
    // legRestingOnImmovableJoint above; and bestDrop/bestClearanceGain
    // with a different part as the primary contact and the knee left as
    // the perpetually-almost-touching dangling point instead). Checking
    // for the SHAPE of the problem here -- both probes committing every
    // tick, forever -- catches either pairing, and whatever pairing shows
    // up next, without needing a bespoke guard for each one. Forcing both
    // steps to shrink once that's happened too many ticks in a row breaks
    // the loop the same way a same-tick straddle does, and still lets a
    // genuinely slow (but real) multi-tick convergence run its course as
    // long as it isn't BOTH probes firing on literally every single tick.
    if (probe2Committed && probe1Committed)
    {
        rockyBothProbesCommittedStreak++;
        if (rockyBothProbesCommittedStreak >= SIMULATION_LEG_SETTLE_STALEMATE_STREAK)
        {
            SIM_LOG("[SETTLE] both probes have committed a move on every one of the last %d ticks -- treating as a stalemate (each one chasing an improvement the other's last move created) and shrinking both step sizes\n",
                   rockyBothProbesCommittedStreak);
            for (int j = 0; j < settleJointCount(); j++) *settleJointStepPtr(j) *= 0.5f;
            rockyBodySettleStep *= 0.5f;
            rockyBothProbesCommittedStreak = 0;
        }
    }
    else
    {
        rockyBothProbesCommittedStreak = 0;
    }

    // Growth check: the mirror image of the stalemate check just above --
    // see rockyKneeSettleGrowthStreak's own comment for the full
    // reasoning. Each probe's own streak only advances on a tick where
    // THAT probe committed via a direct branch (not scout) AND the other
    // probe stayed completely silent; anything else (no commit, a scout
    // commit, or the other probe also committing) resets it back to 0,
    // same "SHAPE of the problem" idea as the stalemate check.
    if (probe2DirectCommit && !probe1Committed)
    {
        rockyKneeSettleGrowthStreak++;
        if (rockyKneeSettleGrowthStreak >= SIMULATION_LEG_SETTLE_GROWTH_STREAK)
        {
            rockyKneeSettleGrowthStreak = 0;
            if (rockyKneeSettleStep < SIMULATION_LEG_SETTLE_STEP_DEG)
            {
                float grownKneeStep = rockyKneeSettleStep * 2.0f;
                if (grownKneeStep > SIMULATION_LEG_SETTLE_STEP_DEG)
                    grownKneeStep = SIMULATION_LEG_SETTLE_STEP_DEG;
                SIM_LOG("[SETTLE] kneeAngle=%.2f committed a clean improvement on every one of the last %d ticks with the body probe quiet -- growing the step back up from %.4f to %.4f deg to cover ground faster\n",
                       (*settleJointPtr(0)), SIMULATION_LEG_SETTLE_GROWTH_STREAK, rockyKneeSettleStep, grownKneeStep);
                rockyKneeSettleStep = grownKneeStep;
            }
            // Semni's hip joint grows back the same way (no-op for Rocky,
            // which only has the one Probe 2 joint).
            if (settleJointCount() > 1 && semniHipSettleStep < SIMULATION_LEG_SETTLE_STEP_DEG)
            {
                semniHipSettleStep *= 2.0f;
                if (semniHipSettleStep > SIMULATION_LEG_SETTLE_STEP_DEG)
                    semniHipSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
            }
        }
    }
    else
    {
        rockyKneeSettleGrowthStreak = 0;
    }

    if (probe1DirectCommit && !probe2Committed)
    {
        rockyBodySettleGrowthStreak++;
        if (rockyBodySettleGrowthStreak >= SIMULATION_LEG_SETTLE_GROWTH_STREAK)
        {
            rockyBodySettleGrowthStreak = 0;
            if (rockyBodySettleStep < SIMULATION_BODY_SETTLE_STEP_DEG)
            {
                float grownBodyStep = rockyBodySettleStep * 2.0f;
                if (grownBodyStep > SIMULATION_BODY_SETTLE_STEP_DEG)
                    grownBodyStep = SIMULATION_BODY_SETTLE_STEP_DEG;
                SIM_LOG("[SETTLE] bodyAngle=%.2f committed a clean improvement on every one of the last %d ticks with the knee probe quiet -- growing the step back up from %.4f to %.4f deg to cover ground faster\n",
                       (*bodyAngle), SIMULATION_LEG_SETTLE_GROWTH_STREAK, rockyBodySettleStep, grownBodyStep);
                rockyBodySettleStep = grownBodyStep;
            }
        }
    }
    else
    {
        rockyBodySettleGrowthStreak = 0;
    }

    // Probe 2 is skipped entirely while the leg is hidden (its own
    // !legHidden guard above), which means rockyKneeSettleStep just
    // sits at whatever it was last reset to and never shrinks -- for a
    // legHidden Rocky, waiting for it to drop below the MIN threshold
    // here was waiting for something that can never happen. That left
    // rockySettleConverged permanently unreachable for a legless Rocky,
    // no matter how thoroughly Probe 1 alone had already converged: the
    // settle timer (postRotateSettleActive/advancePostRotateSettle) never
    // saw "atRest" and so never shut itself back off, leaving it running
    // forever at whatever cadence WM_TIMER (throttled hard by any mouse
    // movement, see WM_MOUSEMOVE's own anti-starvation comment) happened
    // to manage -- which is exactly what a real report showed: a legless
    // Rocky's body visibly creeping a little further every time the mouse
    // moved, long after it had actually finished settling. Treat Probe 2
    // as trivially "already at its floor" when there's no leg for it to
    // ever run against, same as Probe 2's own skip condition, so
    // convergence only ever waits on whichever probe(s) can actually run.
    //
    // The exact same unreachability hits during an E/Q press: Probe 2's
    // OWN top-level guard is "!legHidden && !rockyKneeSettleSuppressed
    // && rockyKneeSettleStep >= MIN" -- rockyKneeSettleSuppressed is set
    // TRUE for the whole duration of the keypress (so the user's own
    // manual knee-bend isn't fought by the settle probe), which means
    // Probe 2 doesn't run then either, and rockyKneeSettleStep is just as
    // stuck as the legHidden case. Without bypassing it here too,
    // rockySettleConverged can never go TRUE while E/Q is held, so
    // advancePostRotateSettle keeps calling applyGravityStep -- a REAL
    // fall step -- every tick for as long as the key (or mouse movement,
    // which also unconditionally pumps the same driver) keeps going,
    // which is exactly "press e or q once and the whole robot starts
    // falling, faster when the cursor moves."
    // legRestingOnImmovableJoint added here alongside legHidden/
    // rockyKneeSettleSuppressed -- same reasoning, a real gap this
    // diagnostic pass found: whenever Probe 2's own top-level guard
    // (further up) is false because the leg's current contact is one
    // Probe 2 must leave alone (ARC/KNEE/FOOT already resting), the
    // block that shrinks rockyKneeSettleStep is never even entered, so
    // it just sits at whatever it was last reset to (its full starting
    // value, typically) forever -- waiting for it to drop below
    // SIMULATION_LEG_SETTLE_MIN_STEP_DEG was waiting for something that
    // can structurally never happen while this stays true, exactly like
    // the legHidden and rockyKneeSettleSuppressed cases already handled
    // here. Without this, a landing where the leg settles onto ARC/KNEE/
    // FOOT while Probe 1 ALSO happens to run its own step down to zero
    // (nothing left revives it, e.g. no further E/Q taps) left both
    // probes completely silent forever -- no further [SETTLE] lines, no
    // [SETTLE] converged line either -- instead of cleanly recognizing
    // this as the resting pose the way it was clearly meant to.
    if ((legHidden || rockyKneeSettleSuppressed || legRestingOnImmovableJoint || settleAllJointStepsBelow(SIMULATION_LEG_SETTLE_MIN_STEP_DEG))
        && rockyBodySettleStep < SIMULATION_LEG_SETTLE_MIN_STEP_DEG
        && !rockyBodyReversalGuardBlockedThisTick)
    {
        // Diagnostic only, temporary -- before actually latching
        // converged, re-check at a full, un-shrunk scout angle (the same
        // SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG Probe 1's own scout
        // fallback further up already uses for exactly this "is there
        // real improvement further out" question) whether genuine
        // progress is still available in either direction right now.
        // rockyBodySettleStep having shrunk below the floor is NOT the
        // same guarantee as "no more progress exists anywhere" -- it can
        // shrink there purely from repeated directionsStraddle/pivot-
        // flip/reversal-guard halvings during a twisty settle, and the
        // step only ever grows back via a strict run of
        // SIMULATION_LEG_SETTLE_GROWTH_STREAK consecutive CLEAN single-
        // probe commits, which frequent halving events right near the
        // true resting angle can keep preventing from ever completing --
        // even while real, unresolved improvement remains on one side.
        // This measures what a full-size probe finds RIGHT NOW, purely
        // to check that assumption before trusting it, then fully undoes
        // itself either way -- no committed state changes as a result of
        // this block, converged or not.
        //
        // Only runs while View > Simulation Log is on: its whole output is
        // one [SETTLE] log line, and it costs two full 20 deg scout drops
        // (a real report showed convergence ticks taking ~80 ms).
        double perfSanityStart = perfNowMs();
        if (simPhysicsLogEnabled && !(bodyHidden && legHidden))
        {
            PointF sanityPivot = settleTopplePivotWorld();
            float sanityBaseAngle = (*bodyAngle);
            float sanityBaseComY = settleMassCenter().y;
            float sanityDrop[2] = { 0.0f, 0.0f };
            float sanityComDrop[2] = { 0.0f, 0.0f };
            int si = 0;
            for (int sdir = -1; sdir <= 1; sdir += 2, si++)
            {
                float sanityDelta = sdir * SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG;
                PointF sanityShift = rotateActiveBodyAroundPivot(sanityPivot, sanityDelta);
                float sanityResidual = clearPivotRoundingResidual();
                float d = dropActiveRobotToRest();
                if (d > 0.0f)
                    translateActiveRobot(0.0f, d);
                sanityDrop[si] = d;
                if (!robotCollidesWithEnvironment())
                {
                    PointF com = settleMassCenter();
                    sanityComDrop[si] = sanityBaseComY - com.y;
                }
                if (sanityResidual > 0.0f)
                    translateActiveRobot(0.0f, -sanityResidual);
                translateActiveRobot(-sanityShift.x, -sanityShift.y);
                (*bodyAngle) = sanityBaseAngle;
            }
            SIM_LOG("[SETTLE] convergence sanity check -- scouted %.1f deg each way from the current pivot: drop=%.5f/%.5f comDrop=%.5f/%.5f (min thresholds: drop>%.5f comDrop>%.5f)\n",
                   SIMULATION_LEG_SETTLE_SCOUT_STEP_DEG, sanityDrop[0], sanityDrop[1], sanityComDrop[0], sanityComDrop[1],
                   (double)SIMULATION_LEG_SETTLE_MIN_DROP, (double)SIMULATION_LEG_SETTLE_MIN_COM_DROP);
        }

        // Both probes have been refined all the way down to the floor
        // and still found nothing worth committing -- THIS is the
        // resting pose. Stop actually testing from here on (until the
        // next fresh landing) rather than continuing to probe every tick
        // for the same nothing.
        // Close any small leftover gap under the second contact point
        // before calling this the rest pose -- see seatRockyDanglingPoint.
        perfLastSettleSanityMs = perfNowMs() - perfSanityStart;

        double perfSeatStart = perfNowMs();
        seatRockyDanglingPoint();
        perfLastSettleSeatMs = perfNowMs() - perfSeatStart;

        rockySettleConverged = TRUE;
        SIM_LOG("[SETTLE] converged -- kneeAngle=%.2f bodyAngle=%.2f, no further improvement found\n",
               (*settleJointPtr(0)), (*bodyAngle));
    }
    else if (rockyBodyReversalGuardBlockedThisTick
             && (legHidden || rockyKneeSettleSuppressed || legRestingOnImmovableJoint || settleAllJointStepsBelow(SIMULATION_LEG_SETTLE_MIN_STEP_DEG))
             && rockyBodySettleStep < SIMULATION_LEG_SETTLE_MIN_STEP_DEG)
    {
        // Every OTHER condition for convergence was true this tick (knee
        // side done, body step at its floor) except this one -- purely so
        // it's visible in the log that convergence was deliberately held
        // off specifically because the reversal guard just set aside a
        // real improvement, not because nothing was found. Without this
        // line the log otherwise looks identical to any other blocked-
        // streak tick, giving no hint that this was the one tick
        // convergence would otherwise have latched on.
        SIM_LOG("[SETTLE] convergence held off -- bodySettleStep is at its floor but the reversal guard just blocked a genuine improvement this tick, so this is not actually the resting pose yet\n");
    }
}

// Applies one gravity step to the robot -- tentatively translates it down
// by `step` world units, then checks robotCollidesWithEnvironment. If that
// collides, binary-searches within the step (GRAVITY_CONTACT_SEARCH_ITERATIONS,
// config.h) for how far it can actually descend before touching, instead of
// just undoing the whole step -- otherwise the robot always stops up to one
// full step short of the ground, a gap that's invisible in world units at
// normal zoom but turns into an obvious floating gap once you zoom in close
// enough (see config.h's comment on GRAVITY_CONTACT_SEARCH_ITERATIONS).
// Shared by the plain G keypress (one SIMULATION_GRAVITY_STEP per press, or
// per Windows auto-repeat tick while held) and the Shift+G auto-gravity
// timer (an accelerating step, see autoGravityVelocity below) -- see
// WM_KEYDOWN/WM_TIMER below. Returns TRUE if the step was blocked (i.e. it
// landed on something this tick), so auto-gravity's timer handler knows
// when to reset its velocity back to 0.
// Debug-print-only helper: whichever robot is active, some single "how
// high up is it" number for the [GRAVITY] log lines below. Rocky's torso
// position is bodyY rather than y (see app.h) -- Stilo happens to share
// Semni's exact "y" field name/convention already, needing no branch.
static float activeRobotDebugY(void)
{
    if (app.robotScene.activeKind == ROBOT_KIND_ROCKY)
        return app.robotScene.rocky.bodyY;
    if (app.robotScene.activeKind == ROBOT_KIND_STILO)
        return app.robotScene.stilo.y;
    return app.robotScene.robot.y;
}

// Same idea as activeRobotDebugY just above, but for the whole-body
// rotation angle instead -- used by the VK_LEFT/RIGHT rotation HUD
// (canvasRenderFrame) to show whichever robot is actually active right
// now. All three kinds name this field "angle" (app.h), just on
// different structs, so this is the one place that has to know that.
static float activeRobotAngleDegrees(void)
{
    if (app.robotScene.activeKind == ROBOT_KIND_ROCKY)
        return app.robotScene.rocky.angle;
    if (app.robotScene.activeKind == ROBOT_KIND_STILO)
        return app.robotScene.stilo.angle;
    return app.robotScene.robot.angle;
}

static BOOL applyGravityStep(HWND hWnd, float step)
{
    // wasLanded persists across calls (it's a local static): TRUE means the
    // robot was already resting as of the last call, so this tick's prints
    // (and any nested [COLLIDE] prints) are suppressed unless something
    // actually changes -- see gSuppressGravityDebug's own comment above.
    static BOOL wasLanded = FALSE;
    BOOL suppressThisCall = wasLanded;
    gSuppressGravityDebug = suppressThisCall;

    float yBefore = activeRobotDebugY();
    translateActiveRobot(0.0f, -step);

    BOOL landed = robotCollidesWithEnvironment();
    if (!suppressThisCall)
        SIM_LOG("[GRAVITY] step=%.6f y_before=%.6f y_after_step=%.6f landed=%d\n",
               step, yBefore, activeRobotDebugY(), landed);
    if (landed)
    {
        // Back out to the last known-safe position (before this step), then
        // binary-search the largest downward offset within [0, step] that
        // doesn't collide, converging on the true contact point instead of
        // leaving a whole-step-sized gap above it.
        translateActiveRobot(0.0f, step);

        float safe = 0.0f;      // largest offset confirmed NOT to collide
        float blocked = step;   // smallest offset confirmed TO collide

        for (int i = 0; i < GRAVITY_CONTACT_SEARCH_ITERATIONS; i++)
        {
            float mid = (safe + blocked) * 0.5f;

            translateActiveRobot(0.0f, -mid);
            BOOL hit = robotCollidesWithEnvironment();
            translateActiveRobot(0.0f, mid); // undo probe

            if (hit) blocked = mid;
            else     safe = mid;
        }

        translateActiveRobot(0.0f, -safe);

        if (!suppressThisCall)
        {
            SIM_LOG("[GRAVITY]   search: safe=%.6f blocked=%.6f y_final=%.6f\n",
                   safe, blocked, activeRobotDebugY());

            // envHalfWidth: the SAME value simEnvLineHalfWidthWorld() gives
            // collision (pointCollidesWithAnyEnvironmentStroke) and the
            // renderer (the Comparison Mode ribbon) right now -- printed
            // once here so it's visible per-run without having to
            // reverse-engineer it from eRadius/combined below.
            //
            // Per-body-part breakdown -- generalized to all three kinds so
            // a gap can be diagnosed no matter which robot is active.
            // Reports dist/combined/gap instead of a bottom_y estimate:
            // dist is the TRUE geometric distance to the nearest traced
            // segment (nearestEnvDistance, no padding applied), combined
            // is exactly the combinedRadius the real collision check used
            // for that same part, and gap = dist - combined is the signed
            // result -- positive means still floating by that many world
            // units, negative means overlapping by that many, ~0.00000
            // means flush. This replaces a bottom_y print that assumed a
            // flat horizontal line and that went stale the moment
            // simEnvLineHalfWidthWorld's env-side padding was added to
            // collision without a matching update here -- gap is computed
            // from the exact same inputs the real check uses, so it can't
            // drift out of sync with the actual physics again the same
            // way, and it works for a sloped or curved line just as well
            // as a flat one.
            float envHalfWidth = simEnvLineHalfWidthWorld();
            SIM_LOG("[GRAVITY]   envHalfWidth=%.5f\n", envHalfWidth);

            if (app.robotScene.activeKind == ROBOT_KIND_SEMNI)
            {
                CircleSegment dbgCircles[NUM_ROBOT_BODY_CIRCLES];
                computeSemniBodyCircles(app.robotScene.robot, dbgCircles);
                static const char* dbgNames[NUM_ROBOT_BODY_CIRCLES] = { "head", "butt", "hip", "knee", "foot" };
                for (int c = 0; c < NUM_ROBOT_BODY_CIRCLES; c++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(dbgCircles[c].center.x, dbgCircles[c].center.y, &ecx, &ecy);
                    float eRadius = robotLengthToEnvWorld(dbgCircles[c].radius);
                    float combined = eRadius + envHalfWidth;
                    float dist = nearestEnvDistance(ecx, ecy);
                    SIM_LOG("[GRAVITY]   circle=%-4s world=(%.5f,%.5f) radius=%.5f dist=%.5f combined=%.5f gap=%.5f\n",
                           dbgNames[c], ecx, ecy, eRadius, dist, combined, dist - combined);
                }
            }
            else if (app.robotScene.activeKind == ROBOT_KIND_ROCKY)
            {
                CircleSegment dbgCircles[NUM_ROCKY_BODY_CIRCLES];
                computeRockyBodyCircles(app.robotScene.rocky, dbgCircles);
                static const char* dbgNames[NUM_ROCKY_BODY_CIRCLES] = { "knee", "foot" };
                for (int c = 0; c < NUM_ROCKY_BODY_CIRCLES; c++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(dbgCircles[c].center.x, dbgCircles[c].center.y, &ecx, &ecy);
                    float eRadius = robotLengthToEnvWorld(dbgCircles[c].radius);
                    float combined = eRadius + envHalfWidth;
                    float dist = nearestEnvDistance(ecx, ecy);
                    SIM_LOG("[GRAVITY]   circle=%-4s world=(%.5f,%.5f) radius=%.5f dist=%.5f combined=%.5f gap=%.5f\n",
                           dbgNames[c], ecx, ecy, eRadius, dist, combined, dist - combined);
                }

                // No eArcThickness-style stand-in here anymore -- see
                // the matching comment on the real check in
                // robotCollidesWithEnvironment (Rocky branch) for why: a
                // rectangle edge is a real filled boundary, not a bare
                // curve, so it needs zero extra robot-side padding, same
                // as a circle's own real radius.
                float edgeCombined = envHalfWidth;
                RockyEdgeSegment dbgEdges[NUM_ROCKY_RECT_SEGMENTS];
                computeRockyRectSegments(app.robotScene.rocky, dbgEdges);
                static const char* edgeNames[NUM_ROCKY_RECT_SEGMENTS] = { "top", "right", "bottom", "left" };
                for (int e = 0; e < NUM_ROCKY_RECT_SEGMENTS; e++)
                {
                    float esx, esy, eex, eey;
                    robotPointToEnvWorld(dbgEdges[e].start.x, dbgEdges[e].start.y, &esx, &esy);
                    robotPointToEnvWorld(dbgEdges[e].end.x, dbgEdges[e].end.y, &eex, &eey);

                    // Same per-sample walk robotCollidesWithEnvironment
                    // actually does for this edge (ARC_SAMPLE_COUNT points
                    // along it, not just the two endpoints) -- reports
                    // whichever sample is closest, so a rotated/tilted
                    // edge's true nearest point is what gets measured,
                    // not just wherever its corners happen to land.
                    float minDist = -1.0f;
                    for (int i = 0; i < ARC_SAMPLE_COUNT; i++)
                    {
                        float t = (float)i / (float)(ARC_SAMPLE_COUNT - 1);
                        float lx = dbgEdges[e].start.x + (dbgEdges[e].end.x - dbgEdges[e].start.x) * t;
                        float ly = dbgEdges[e].start.y + (dbgEdges[e].end.y - dbgEdges[e].start.y) * t;
                        float ecx, ecy;
                        robotPointToEnvWorld(lx, ly, &ecx, &ecy);
                        float d = nearestEnvDistance(ecx, ecy);
                        if (minDist < 0.0f || d < minDist) minDist = d;
                    }

                    SIM_LOG("[GRAVITY]   edge=%-6s world=(%.5f,%.5f)-(%.5f,%.5f) dist=%.5f combined=%.5f gap=%.5f\n",
                           edgeNames[e], esx, esy, eex, eey, minDist, edgeCombined, minDist - edgeCombined);
                }
            }
            else if (app.robotScene.activeKind == ROBOT_KIND_STILO)
            {
                CircleSegment dbgCircles[NUM_STILO_BODY_CIRCLES];
                computeStiloBodyCircles(app.robotScene.stilo, dbgCircles);
                static const char* dbgNames[NUM_STILO_BODY_CIRCLES] = { "butt", "head", "hip1", "feet1", "hip2", "feet2" };
                for (int c = 0; c < NUM_STILO_BODY_CIRCLES; c++)
                {
                    float ecx, ecy;
                    robotPointToEnvWorld(dbgCircles[c].center.x, dbgCircles[c].center.y, &ecx, &ecy);
                    float eRadius = robotLengthToEnvWorld(dbgCircles[c].radius);
                    float combined = eRadius + envHalfWidth;
                    float dist = nearestEnvDistance(ecx, ecy);
                    SIM_LOG("[GRAVITY]   circle=%-5s world=(%.5f,%.5f) radius=%.5f dist=%.5f combined=%.5f gap=%.5f\n",
                           dbgNames[c], ecx, ecy, eRadius, dist, combined, dist - combined);
                }
            }
        }

        // Plain gravity + contact only: once the fall is stopped by the
        // binary search above, the robot stays exactly where it landed.
        // (Previously this also incrementally rotated the whole body to
        // align with the ground slope every landed tick -- removed because
        // that per-tick lean + re-settle read as a visible bounce/wobble
        // instead of a clean stop.)
        //
        // Rocky specifically gets one more thing here, called EVERY tick
        // this block runs (by explicit request this is continuous, unlike
        // the removed slope-alignment idea referenced just above): if the
        // knee was dragged far from the rectangle (the knee-detach
        // feature, app.h's own comment on draggingRockyKnee), the LEG can
        // land on something while the body itself is still floating well
        // above the ground -- see advanceRockySettle's own comment for
        // why running it every tick is safe here (no velocity/damping
        // state to oscillate, unlike the old knee pendulum), and how it
        // bends the knee AND rotates the rectangle a little further each
        // call (by explicit request, so the body can tip instead of only
        // ever sinking straight down) until there's nowhere left to go --
        // advanceRockySettle stops re-probing on its own once that
        // happens (rockySettleConverged), which is what actually keeps
        // this from reading as endless vibration.
        //
        // !suppressThisCall here means a FRESH landing (wasLanded was
        // FALSE going into this call) -- reset the convergence flag AND
        // both probes' step sizes right at that moment so a robot that's
        // lifted off (E/Q, a drag, or just walking off a ledge) and lands
        // again later still gets its own full settle pass at full
        // resolution, instead of staying permanently "already converged"
        // (or stuck at whatever fine step size it had refined down to)
        // from whatever the PREVIOUS landing settled into.
        if (!suppressThisCall)
        {
            // Diagnostic only, temporary -- pin down whether THIS reset
            // (a fresh landed=FALSE -> TRUE transition between two
            // applyGravityStep calls, not any of the four UI-event-driven
            // resets elsewhere) is what's clearing rockyBodyLastCommitDir/
            // rockyToppleLastPivotCategory mid-settle and letting Probe 1
            // commit what looks like a reversal without the guard above
            // catching it. If this line shows up sandwiched inside an
            // otherwise-continuous settle run (no mode switch, no key/
            // mouse release logged nearby), that confirms a landed/not-
            // landed flicker -- most likely rotateRockyBodyAroundPivot's
            // own sub-precision residual correction nudging the pivot
            // corner's world Y by a hair -- is the real culprit, not a UI
            // event.
            SIM_LOG("[SETTLE] fresh landing detected (landed=FALSE -> TRUE) -- resetting probe step sizes and anti-oscillation state\n");

            rockySettleConverged = FALSE;
            rockyKneeSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
            semniHipSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
            rockyBodySettleStep = SIMULATION_BODY_SETTLE_STEP_DEG;
            rockyBothProbesCommittedStreak = 0;
            rockyKneeSettleGrowthStreak = 0;
            rockyBodySettleGrowthStreak = 0;
            rockyPivotSide = 0;
            rockyBodyLastCommitDir = 0;
            rockyToppleLastPivotCategory = 0;
            rockyBodyReversalBlockedStreak = 0;
        }

        if (!settleSupportedKind())
        {
            advanceRockySettle(); // no-op for every other kind -- its own early return
        }
        else
        {
            // Runs the settle probes several times within this ONE timer
            // tick once consecutive calls are each only producing an
            // imperceptibly small rotation -- see
            // SIMULATION_LEG_SETTLE_FAST_FORWARD_MAX_STEP_DEG's own comment
            // in config.h for the full reasoning. A real report showed a
            // perfectly legitimate, non-oscillating settle -- bestComDrop
            // alone, committing cleanly every single tick, nothing wrong
            // with any individual decision -- taking hundreds of ticks
            // (several real seconds at SIMULATION_AUTO_GRAVITY_INTERVAL_MS's
            // cadence) to finish, purely because each call only ever
            // advances by one already-tiny, already-safe step. Loosening
            // WHAT counts as safe (the straddle/stalemate floors) was
            // considered and rejected: the "ceiling" turned out to be a
            // small but genuinely real competing signal (a barely-dangling
            // point's own clearance improving in the opposite direction),
            // not measurement noise, and that pairing is exactly what a
            // real historical report already burned once (see
            // directionsStraddle's own comment above) -- relaxing it again
            // risks reopening that same class of bug. This fixes the
            // symptom the OTHER way instead: change how MANY of those
            // individually-imperceptible, already-correct calls happen
            // before the next frame is drawn, not what any one of them is
            // allowed to decide. Every call inside this loop is completely
            // unmodified -- same criteria, same floors, same straddle/
            // stalemate guards -- so nothing about WHAT gets committed
            // changes, only how fast an already-safe sequence of commits
            // plays out.
            //
            // Measures the ACTUAL kneeAngle/angle change each call
            // produces (rather than inferring from rockyKneeSettleStep/
            // rockyBodySettleStep directly), so this stays correct even
            // when one probe is structurally idle this tick (legHidden,
            // rockyKneeSettleSuppressed, or legRestingOnImmovableJoint) and
            // its OWN step size is just sitting at some frozen, larger,
            // irrelevant value left over from earlier in this same landing,
            // before it got guarded off -- an idle probe produces a true
            // zero delta regardless of its stale step size, so it can never
            // wrongly block fast-forwarding by itself. At a full-size step
            // (right after a fresh landing, or whenever a growth-streak
            // regrow -- rockyBodySettleGrowthStreak's own comment above --
            // has pushed a step back up), each call's own rotation is still
            // visually significant, so the very first call already breaks
            // out of this loop below and it falls back to exactly one call
            // per tick, unchanged -- preserving the smooth, gradual sink
            // SIMULATION_LEG_SETTLE_STEP_DEG's own comment describes.
            // [PERF] diagnostic, temporary -- times this whole batch of up
            // to SIMULATION_LEG_SETTLE_FAST_FORWARD_TICKS advanceRockySettle
            // calls, since a real report showed FPS occasionally dropping
            // to ~20 with no obvious cause yet identified. This loop is one
            // of the strongest suspects: each advanceRockySettle call does
            // real collision/distance searches against the WHOLE
            // environment (dropActiveRobotToRest's own binary search,
            // robotCollidesWithEnvironment, rockyToppleContactPoints, the
            // convergence sanity check's own scout probe), and it can run
            // up to 16 times back to back inside ONE WM_TIMER tick -- all
            // of that happens BEFORE this tick's own InvalidateRect, so a
            // slow batch here delays how soon the next real frame can even
            // be scheduled, which reads as a dropped frame rate exactly
            // like a slow render would, even though nothing in
            // renderCombinedFrame itself was slow. See renderCombinedFrame's
            // own [PERF] instrumentation for the render-side half of this
            // same investigation.
            double perfSettleStart = perfNowMs();
            int perfSettleCalls = 0;
            double perfSlowestCallMs = 0.0; // most expensive advanceRockySettle call so far this tick
            double perfSlowestSanityMs = 0.0, perfSlowestSeatMs = 0.0; // that call's convergence extras
            float comYDroppedThisTick = 0.0f; // total settle drop this tick -- see the drop cap below

            for (int ff = 0; ff < SIMULATION_LEG_SETTLE_FAST_FORWARD_TICKS; ff++)
            {
                // Real-time budget cap (SIMULATION_LEG_SETTLE_FAST_FORWARD_
                // BUDGET_MS -- see config.h's own comment for why this was
                // added): only checked from the second call onward, so the
                // very first call of every tick still always happens no
                // matter how starved this tick already is -- same
                // forward-progress guarantee SIMULATION_LEG_SETTLE_FAST_
                // FORWARD_TICKS itself relies on. Any ticks this skips are
                // simply picked back up on the NEXT WM_TIMER tick, since
                // this whole loop just runs again as long as
                // rockySettleConverged is still FALSE.
                //
                // Also stops BEFORE a call that would overshoot the budget,
                // not just after the budget is already gone: one call can
                // itself take longer than the whole budget, so "elapsed <
                // budget" alone let a tick run e.g. 8 ms + one more 15 ms
                // call. Predicts the next call's cost from the slowest call
                // seen so far this tick.
                if (ff > 0)
                {
                    double spentMs = perfNowMs() - perfSettleStart;
                    if (spentMs + perfSlowestCallMs > (double)SIMULATION_LEG_SETTLE_FAST_FORWARD_BUDGET_MS)
                        break; // next call would blow this tick's settle budget -- finish on a later tick
                }

                // Whichever robot is settling (Rocky or Semni) -- these used
                // to read Rocky's fields unconditionally, so for Semni they
                // never changed, this loop never saw "something moved", and
                // it batched up to SIMULATION_LEG_SETTLE_FAST_FORWARD_TICKS
                // settle calls (each allowed to drop the body) into every
                // tick: Semni sank many times faster than Rocky.
                float jointBefore[2] = { 0.0f, 0.0f };
                for (int j = 0; j < settleJointCount(); j++)
                    jointBefore[j] = *settleJointPtr(j);
                float bodyBefore = *settleBodyAnglePtr();
                float comYBefore = settleMassCenter().y;

                double perfCallStart = perfNowMs();
                advanceRockySettle();
                double perfCallMs = perfNowMs() - perfCallStart;
                if (perfCallMs > perfSlowestCallMs)
                {
                    perfSlowestCallMs = perfCallMs;
                    perfSlowestSanityMs = perfLastSettleSanityMs;
                    perfSlowestSeatMs = perfLastSettleSeatMs;
                }
                perfSettleCalls++;

                if (rockySettleConverged)
                    break; // nothing left to do -- stop early instead of spending the rest of the budget on no-ops

                float kneeDelta = 0.0f;
                for (int j = 0; j < settleJointCount(); j++)
                {
                    float d = fabsf(*settleJointPtr(j) - jointBefore[j]);
                    if (d > kneeDelta) kneeDelta = d;
                }
                float bodyDelta = fabsf(*settleBodyAnglePtr() - bodyBefore);

                if (kneeDelta > SIMULATION_LEG_SETTLE_FAST_FORWARD_MAX_STEP_DEG
                    || bodyDelta > SIMULATION_LEG_SETTLE_FAST_FORWARD_MAX_STEP_DEG)
                    break; // that call moved something by a visually real amount -- don't batch any further this tick

                // Also stop once the body has DROPPED a real amount this
                // tick: SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK caps a single
                // settle call's drop at one gravity step, and batching
                // several such calls would otherwise let a settling robot
                // sink faster than gravity itself moves it.
                comYDroppedThisTick += comYBefore - settleMassCenter().y;
                if (comYDroppedThisTick >= SIMULATION_LEG_SETTLE_MAX_DROP_PER_TICK)
                    break;
            }

            double perfSettleElapsed = perfNowMs() - perfSettleStart;
            if (perfSettleElapsed >= (double)SIMULATION_PERF_WARN_FRAME_MS)
            {
                SIM_FPS_LOG("[PERF] settle fast-forward took %.2fms across %d advanceRockySettle call(s) (avg %.2fms/call, slowest %.2fms [sanityCheck=%.2fms seat=%.2fms probes=%.2fms], budget %dms) -- this ran INSIDE the current WM_TIMER tick, before its own repaint was even scheduled\n",
                       perfSettleElapsed, perfSettleCalls,
                       perfSettleCalls > 0 ? perfSettleElapsed / (double)perfSettleCalls : 0.0,
                       perfSlowestCallMs, perfSlowestSanityMs, perfSlowestSeatMs,
                       perfSlowestCallMs - perfSlowestSanityMs - perfSlowestSeatMs,
                       SIMULATION_LEG_SETTLE_FAST_FORWARD_BUDGET_MS);
            }
        }
    }

    wasLanded = landed;
    InvalidateRect(hWnd, NULL, FALSE);
    return landed;
}

// Finds which segment's drawn arc strip is closest to a world-space point,
// within a small pick tolerance. Returns -1 if nothing is close enough.
static int findHoveredSegment(float wx, float wy)
{
    float tolerance = 0.05f * canvas.zoom; // pick radius, world units
    int best = -1;
    float bestDist = tolerance;

    for (int s = 0; s < canvas.segmentResultCount; s++)
    {
        int start = segmentStarts[s];
        int count = segmentCounts[s];
        if (count < 2) continue;

        for (int i = 0; i < count - 1; i++)
        {
            float ax = segmentPointsWorld[(start + i) * 2];
            float ay = segmentPointsWorld[(start + i) * 2 + 1];
            float bx = segmentPointsWorld[(start + i + 1) * 2];
            float by = segmentPointsWorld[(start + i + 1) * 2 + 1];

            float d = distPointToSegment(wx, wy, ax, ay, bx, by);
            if (d < bestDist) {
                bestDist = d;
                best = s;
            }
        }
    }

    return best;
}

// Finds the nearest stroke START or END point to a world-space point,
// within a small pick tolerance - used to let a new stroke snap onto
// where a previous one left off (chaining straight lines end-to-end).
// Only strokes belonging to the currently active design layer are
// considered, so this stays consistent with what's actually editable.
// Returns TRUE and fills outX/outY if something is close enough.
static BOOL findNearestStrokeEndpoint(float wx, float wy, float* outX, float* outY)
{
    float tolerance = 0.05f * canvas.zoom; // pick radius, world units - matches segment picking
    BOOL found = FALSE;
    float bestDist = tolerance;

    for (int s = 0; s < canvas.strokeCount; s++)
    {
        if (strokeLayer[s] != designLayer) continue;

        int start = strokeStarts[s];
        int end = (s == canvas.strokeCount - 1) ? canvas.pointCount : strokeStarts[s + 1];
        int count = (end - start) / 2;
        if (count < 1) continue;

        float candidates[2][2] = {
            { points[start],     points[start + 1] },     // stroke start
            { points[end - 2],   points[end - 1] },        // stroke end
        };

        for (int c = 0; c < 2; c++)
        {
            float dx = wx - candidates[c][0];
            float dy = wy - candidates[c][1];
            float d = sqrtf(dx * dx + dy * dy);
            if (d < bestDist)
            {
                bestDist = d;
                found = TRUE;
                *outX = candidates[c][0];
                *outY = candidates[c][1];
            }
        }
    }

    return found;
}

// In Simulation mode, the ArcSpline environment is driven by sim_camera's
// own independent zoom instead of canvas.zoom -- see sim_camera.h for why
// (keeps the environment and the robot zooming together as one scene,
// without disturbing canvas.zoom, which Design > Environment mode still
// owns and returns to exactly as it left it).
//
// NOTE on the conversion below: canvas.zoom follows a "bigger = zoomed
// OUT" convention (it's used directly as the ortho half-extent multiplier
// -- see the non-simulation branch), while sim_camera's zoom follows the
// opposite "bigger = zoomed IN" convention (same as graphics.c's g_zoom,
// so the robot's own applyProjection can share it via a plain
// ROBOT_VIEW_HALF_EXTENT/zoom -- see sim_camera.h). Inverting it here
// (1.0f / simCameraGetZoom(), 1.0
// being canvas's own base half-extent at zoom=1) is what lets a single
// simCameraZoom() call still zoom the environment and the robot in the
// same direction together, despite the two subsystems' projections having
// opposite native conventions.
void UpdateProjection(void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    float aspect = (float)glWindowWidth / (float)glWindowHeight;
    float zoom = (appMode == APP_MODE_SIMULATION) ? (1.0f / simCameraGetZoom()) : canvas.zoom;
    if (aspect >= 1.0f) {
        glOrtho(-aspect * zoom, aspect * zoom, -1.0f * zoom, 1.0f * zoom, -1.0f, 1.0f);
    } else {
        glOrtho(-1.0f * zoom, 1.0f * zoom, -(1.0f / aspect) * zoom, (1.0f / aspect) * zoom, -1.0f, 1.0f);
    }
    glMatrixMode(GL_MODELVIEW);
}

// NEW: periodic check for the "hover top-right corner to reveal UI panel" behavior
#define UI_HOTZONE_TIMER_ID 1001
#define UI_HOTZONE_INTERVAL_MS 16    // ~60Hz - also drives the fade animation smoothness
#define UI_HOTZONE_WIDTH  48
#define UI_HOTZONE_HEIGHT 48
#define UI_FADE_STEP 18              // alpha change per tick (~14 ticks, ~230ms, to fully fade)

// Simulation mode's "auto gravity" (Shift+G toggle -- see WM_KEYDOWN) --
// its own dedicated timer, separate from UI_HOTZONE_TIMER_ID above (that
// one's tied to the corner-reveal panel, an unrelated feature; sharing it
// here would couple the two for no reason). TRUE while a G press should
// keep repeating on its own, without the user having to hold the key down.
#define AUTO_GRAVITY_TIMER_ID 1002
static BOOL autoGravityActive = FALSE;

// TRUE for as long as a rotate-release topple (WM_KEYUP's VK_LEFT/RIGHT
// case below) still has real work left to do. Completely independent of
// autoGravityActive/Shift+G -- see advancePostRotateSettle's own comment
// for why this needed its own flag instead of just flipping that one on.
static BOOL postRotateSettleActive = FALSE;

// Rocky's knee (E/Q), while genuinely HELD: its own dedicated timer,
// completely independent of autoGravityActive/AUTO_GRAVITY_TIMER_ID --
// unlike auto-gravity, this needs to keep rotating the knee smoothly
// whether or not Auto Gravity happens to be on (E/Q already works with
// Auto Gravity off, it just doesn't also settle the rest of the body in
// that case -- see WM_KEYDOWN's own E/Q case). See
// advanceRockyKneeHold's own comment (further down) for the full
// reasoning on why this exists instead of just continuing to rely on
// Windows' own WM_KEYDOWN auto-repeat.
#define ROCKY_KNEE_HOLD_TIMER_ID 1004

// TRUE for as long as E, respectively Q, is physically held down -- set on
// that key's own WM_KEYDOWN (the first, non-auto-repeat press only; see
// isAutoRepeatEQ's own comment at that call site), cleared on its matching
// WM_KEYUP. Never both driven by the SAME variable: E and Q rotate in
// opposite directions, and a user can genuinely hold both at once (net
// rotation cancels to zero, same as it always has), so each needs its own
// independent held state. advanceRockyKneeHold reads both every tick to
// decide which way (if either) to actually rotate.
static BOOL rockyKneeHoldE = FALSE;
static BOOL rockyKneeHoldQ = FALSE;

// Real-time (GetTickCount) timestamp of the last advanceRockyKneeHold
// call -- same "scale by actual elapsed time, not an assumed fixed tick
// length" reasoning as autoGravityLastTickTime's own comment just above,
// applied to the knee-hold driver instead of the gravity-fall one.
static DWORD rockyKneeHoldLastTickTime = 0;

// simTimeScale/hSlowMotionBtn ("Slow Motion") are declared up near hRC/hDC
// instead of here -- applyGravityStep, defined earlier in this file, needs
// to read simTimeScale already. See that declaration's comment.

// Auto gravity's current fall speed, in world units PER MILLISECOND (real
// time, not "per tick" -- see advanceAutoGravity below for why). Ramps up
// from 0 by SIMULATION_AUTO_GRAVITY_ACCEL_PER_MS2 * elapsed-ms each time
// it's advanced, capped at SIMULATION_AUTO_GRAVITY_MAX_VELOCITY_PER_MS
// (config.h), so the fall actually accelerates instead of moving at one
// flat speed (see config.h's comment on why a flat speed kept reading as
// slow motion). Reset to 0 both when auto gravity is freshly toggled on
// (WM_KEYDOWN) and the instant applyGravityStep reports it landed
// (advanceAutoGravity) -- either way, the next fall should start from
// rest, not carry over speed from before.
static float autoGravityVelocity = 0.0f;


// Real-time (GetTickCount) timestamp of the last advanceAutoGravity call --
// lets it compute how much real time actually elapsed since last time,
// rather than assuming a fixed tick length. See advanceAutoGravity's own
// comment for why this matters.
static DWORD autoGravityLastTickTime = 0;

// Real-time (GetTickCount) timestamp of the last time E/Q's own settle
// probes got revived back to full step size -- either by a keyup, or by
// WM_KEYDOWN's own periodic re-arm while the key is held (see
// reviveRockyBodyProbeStepSizes and its call sites below). Reset to "now"
// on every fresh (non-auto-repeat) E/Q press so a long-overdue press
// doesn't immediately treat itself as already due for another revive one
// repeat later -- the interval should always be measured from when THIS
// hold actually started.
static DWORD rockyEQHoldLastReviveTick = 0;

// Advances auto gravity by however much real time has actually passed
// since the last call, instead of assuming a fixed SIMULATION_AUTO_GRAVITY_
// INTERVAL_MS worth of time. This is what it is because of a real bug:
// WM_TIMER is a LOW-PRIORITY Windows message -- the OS only synthesizes one
// once the thread's message queue would otherwise be empty -- so a steady
// stream of WM_MOUSEMOVE messages while the user is actively moving the
// cursor can starve AUTO_GRAVITY_TIMER_ID for as long as the mouse keeps
// moving, visibly pausing the fall. Fixing that means this can't assume
// "one call == one fixed-size step" anymore, since calls may now arrive
// far apart (WM_TIMER alone, mouse held still) or very close together
// (WM_MOUSEMOVE flooding in) -- so both the acceleration and the resulting
// step are scaled by the real elapsed milliseconds instead. Called from
// WM_TIMER's AUTO_GRAVITY_TIMER_ID case (the fallback, steady baseline) AND
// directly from WM_MOUSEMOVE (so mouse movement itself keeps driving the
// fall forward instead of blocking it) -- both funnel through here so the
// physics can never disagree no matter which message actually triggered it.
static void advanceAutoGravity(HWND hWnd)
{
    if (!autoGravityActive || appMode != APP_MODE_SIMULATION) return;

    // While the user is manually dragging the robot, let THEM be the one
    // moving it -- silently skip stepping instead of fighting the drag
    // (or, worse, applying a big catch-up step once the drag ends). This
    // deliberately leaves autoGravityActive/the toast untouched -- it's a
    // temporary pause, not a toggle-off, so nothing shows on screen and
    // Shift+G's own state doesn't change. WM_LBUTTONUP resets
    // autoGravityVelocity/autoGravityLastTickTime once the drag ends, so
    // the fall resumes fresh from rest rather than picking up wherever it
    // left off (the robot may have just been moved somewhere completely
    // different) or jumping by however long the drag itself lasted.
    if (app.draggingRobotSim) return;

    DWORD now = GetTickCount();
    DWORD elapsed = now - autoGravityLastTickTime;
    if (elapsed == 0) return; // already advanced this exact millisecond

    if (elapsed > SIMULATION_AUTO_GRAVITY_MAX_DT_MS)
        elapsed = SIMULATION_AUTO_GRAVITY_MAX_DT_MS; // avoid a big catch-up jump after a long stall

    autoGravityLastTickTime = now;

    // Cap against real elapsed time FIRST, then scale down for Slow Motion
    // -- capping the already-scaled value would let a real stall (elapsed
    // > MAX_DT_MS) sneak back under the cap purely because it got divided
    // down, defeating the whole point of the cap.
    float simElapsed = (float)elapsed * simTimeScale;

    // Real-world gravity (SIMULATION_GRAVITY_MPS2, 9.81 m/s^2), converted
    // into robot world units with the same mm-per-unit scale the "Size:
    // W x H mm" readout uses (MM_PER_WORLD_UNIT x the Robot Size slider) --
    // so the robot falls at its real physical speed for its displayed size.
    // Mass deliberately plays no part: without air resistance every object
    // falls the same way regardless of weight (weight still feeds the
    // exported masses and the mass-center position). 1 m/s^2 = 0.001
    // mm/ms^2, and 1 m/s = 1 mm/ms.
    float mmPerUnit = MM_PER_WORLD_UNIT * graphicsGetRobotScale();
    if (mmPerUnit <= 0.0f) mmPerUnit = MM_PER_WORLD_UNIT;
    float accelUnitsPerMs2 = (SIMULATION_GRAVITY_MPS2 * 0.001f) / mmPerUnit;
    float maxVelocity = SIMULATION_AUTO_GRAVITY_MAX_VELOCITY_MPS / mmPerUnit;

    autoGravityVelocity += accelUnitsPerMs2 * simElapsed;
    if (autoGravityVelocity > maxVelocity)
        autoGravityVelocity = maxVelocity;

    float step = autoGravityVelocity * simElapsed;

    // A single velocity-scaled step here can be MUCH bigger than the
    // plain G press's fixed SIMULATION_GRAVITY_STEP -- up to 100x, at the
    // velocity/elapsed-time caps just above (SIMULATION_AUTO_GRAVITY_MAX_
    // VELOCITY_PER_MS * SIMULATION_AUTO_GRAVITY_MAX_DT_MS) -- which is
    // exactly what a real stall produces (a burst of WM_MOUSEWHEEL zoom
    // events is a common real trigger: each one forces a synchronous
    // UpdateWindow that can starve AUTO_GRAVITY_TIMER_ID for a while, so
    // the next tick's catch-up elapsed time balloons toward its cap).
    // applyGravityStep's own GRAVITY_CONTACT_SEARCH_ITERATIONS binary
    // search only narrows the gap AFTER it already detected a collision
    // at the far end of a step -- it does nothing for a step that's
    // simply bigger than the ground line's own thickness, which can
    // carry the robot from cleanly above a thin line to cleanly below it
    // in one jump, with the end-of-step check reporting "not touching"
    // because it's already through to the other side. That's tunneling,
    // not a resting-precision problem, and no amount of searching WITHIN
    // one oversized step can catch it. Splitting into a sequence of
    // SIMULATION_GRAVITY_STEP-sized sub-steps -- the same size a plain G
    // press already uses without this problem -- guarantees the
    // environment gets tested at least once per that increment on the
    // way down, so a thin line can never be skipped over unnoticed no
    // matter how large the originally requested step was.
    float remaining = step;
    BOOL landedThisTick = FALSE;

    while (remaining > 0.0f)
    {
        float subStep = (remaining > SIMULATION_GRAVITY_STEP) ? SIMULATION_GRAVITY_STEP : remaining;
        remaining -= subStep;

        if (applyGravityStep(hWnd, subStep))
        {
            landedThisTick = TRUE;
            break;
        }
    }

    if (landedThisTick)
        autoGravityVelocity = 0.0f; // landed -- next fall starts from rest

    // Rocky's knee-to-foot pendulum used to run here (an automatic damped
    // swing while the foot wasn't resting) -- removed by explicit request
    // after it kept producing hard-to-diagnose "stuck"/embedded states on
    // top of the manual E/Q rotation. E/Q (WM_KEYDOWN below) is now the
    // only thing that moves Rocky's kneeAngle in Simulation mode; this
    // function only ever drives the whole-body drop above.
}

// After a manual Left/Right whole-body rotate (WM_KEYUP below) is
// released, the robot might now be resting on a corner/edge that's no
// longer actually stable (rotated past its own tipping point), or even
// lifted clean off the ground by the rotation itself. Auto Gravity
// (Shift+G) already knows how to resolve either case -- keep falling
// until landed, then let advanceRockySettle nudge the rest of the way --
// but the user shouldn't have to remember to turn that toggle on just to
// see a rotate-triggered topple finish playing out. This is a separate,
// self-terminating driver for exactly that: it never touches
// autoGravityActive or its toast, so the persistent Auto Gravity toggle
// stays exactly whatever the user last set it to, and it shuts its own
// timer back off once there's nothing left to do (rather than leaving a
// tiny "is anything still moving" check running forever).
static void advancePostRotateSettle(HWND hWnd)
{
    // Also bails while autoGravityActive is on -- both drivers ultimately
    // funnel through the SAME applyGravityStep, and every kickoff site
    // (VK_LEFT/RIGHT keyup, E/Q keyup, the Simulation-entry embed check,
    // WM_LBUTTONUP drag-release) now requires autoGravityActive to have
    // been on in the first place -- so without this, a still-active Auto
    // Gravity session and this pass both call applyGravityStep on the
    // SAME tick (WM_TIMER/WM_MOUSEMOVE call advanceAutoGravity then this,
    // back to back, unconditionally). applyGravityStep's own landed
    // branch also re-arms and fast-forwards advanceRockySettle every
    // single time it's called, so two calls a tick doesn't just repeat
    // idempotent work -- it runs the knee/body settle probes twice as
    // often as the step-size/growth-streak bookkeeping assumes, and this
    // function's own re-arm (rockySettleConverged = FALSE, step sizes
    // reset to full) on top of whatever Auto Gravity's own tick had
    // already refined them down to is exactly what a real report showed
    // as Rocky floating while playing with E/Q with Auto Gravity already
    // on and settled. Auto Gravity's own continuous driver already
    // re-checks and corrects every tick regardless of whether this ever
    // ran, so there's nothing this pass adds while it's on -- it only
    // ever has real work left to do in the (now theoretical, since
    // nothing can set postRotateSettleActive without autoGravityActive
    // already being on) case of Auto Gravity being switched off again
    // while this was still mid-pass.
    if (!postRotateSettleActive || appMode != APP_MODE_SIMULATION || autoGravityActive) return;

    // Same reasoning as advanceAutoGravity's own check just above -- don't
    // fight a manual drag in progress.
    if (app.draggingRobotSim) return;

    // Fixed SIMULATION_GRAVITY_STEP per tick (same size a plain G press
    // uses) rather than auto-gravity's own accelerating velocity ramp --
    // this is meant to read as "settling into place" after a rotate, not
    // "falling from height", and a topple is normally a short trip
    // either way.
    BOOL landed = applyGravityStep(hWnd, SIMULATION_GRAVITY_STEP); // weight no longer changes fall speed -- see advanceAutoGravity

    // Done once there's nothing left for gravity OR (for Rocky) the
    // settle probes to improve -- the same "fully at rest" condition the
    // rest of this file already tracks (rockySettleConverged), so this
    // can't spin forever on a shape that's genuinely settled. Semni/Stilo
    // have no equivalent settle system, so plain `landed` is already the
    // right stop condition for them.
    BOOL atRest = landed && (!settleSupportedKind() || rockySettleConverged);

    if (atRest)
    {
        postRotateSettleActive = FALSE;
        rockyKneeSettleSuppressed = FALSE; // this session (E/Q or rotate) is over either way

        // Don't rip the timer out from under a separately-active Auto
        // Gravity session -- only stop it if this was the only reason it
        // was still running.
        if (!autoGravityActive)
            KillTimer(hWnd, AUTO_GRAVITY_TIMER_ID);
    }
}

// Revives Probe 2/Probe 1's own step sizes (and the growth-streak/both-
// probes-committed bookkeeping tied to them) back to their full starting
// size, and re-arms rockySettleConverged/postRotateSettleActive/the timer
// so the settle loop actually starts probing again -- WITHOUT touching
// Probe 1's own direction/identity memory (rockyPivotSide,
// rockyBodyLastCommitDir, rockyToppleLastPivotCategory,
// rockyBodyReversalBlockedStreak). See E/Q's own WM_KEYUP case for the
// original reasoning on why this exact split (revive step size, preserve
// identity) is correct -- that reasoning is unchanged, this just factors
// the actual state change out into one shared place instead of a second,
// driftable copy. Also called periodically WHILE E/Q is held (WM_KEYDOWN's
// own auto-repeat case, throttled by rockyEQHoldLastReviveTick), not just
// once on release -- a real report showed a long hold visibly lagging
// behind a run of individual taps, traced to exactly this: a tap's own
// keyup already re-primes the settle probes at full strength after every
// single nudge, but a hold only ever got that same priming once, whenever
// it finally released, so the whole hold's worth of kneeAngle movement was
// chased by whatever step size had already shrunk down from BEFORE the
// hold began. Periodic re-arming during the hold gives it the same
// repeated fresh-attempt priming a run of taps already got for free.
static void reviveRockyBodyProbeStepSizes(HWND hWnd)
{
    rockySettleConverged = FALSE;
    rockyKneeSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
    semniHipSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
    rockyBodySettleStep = SIMULATION_BODY_SETTLE_STEP_DEG;
    rockyBothProbesCommittedStreak = 0;
    rockyKneeSettleGrowthStreak = 0;
    rockyBodySettleGrowthStreak = 0;

    postRotateSettleActive = TRUE;
    SetTimer(hWnd, AUTO_GRAVITY_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);
}

// ---- Scripted gait ("Walk" toggle, Shift+W -- see config.h's
// SIMULATION_GAIT_* comment block for the overall rationale) ----

#define AUTO_GAIT_TIMER_ID 1003
static BOOL gaitActive = FALSE;

// "WALK ON"/"WALK OFF" toast (Shift+W -- see ToggleGait below) -- same
// stateless-fade pattern as gravityToastOn/gravityToastStartTick further
// down this file, kept as its own separate pair (not reusing the gravity
// toast's variables) so auto-gravity and Walk can each show/fade their own
// toast independently without one stomping the other if both get toggled
// close together. Drawn one line above the gravity toast (canvasRenderFrame)
// so both can be visible at once without overlapping. Declared up here,
// ahead of gravityToastOn/gravityToastStartTick's own declaration, because
// ToggleGait -- defined right below -- already needs to write these.
static BOOL gaitToastOn = FALSE;
static DWORD gaitToastStartTick = 0;

// "ROTATION: NN" HUD, shown live while VK_LEFT/RIGHT is held in
// Simulation mode (see WM_KEYDOWN/WM_KEYUP's own VK_LEFT/RIGHT branches
// below), reading whichever robot is active via activeRobotAngleDegrees.
// Not quite the same shape as the two stateless-fade toasts above: while
// the key is actually held, this shows continuously at full opacity (no
// hold/fade timing at all) so it tracks the angle live, one substep at a
// time, for as long as the user keeps rotating; the SAME
// hold-then-fade pattern only kicks in once the key is released
// (rotateKeyHeld goes FALSE and rotateToastStartTick is stamped), so the
// last angle shown doesn't just vanish the instant the key comes up.
// Drawn one line above the Walk toast (canvasRenderFrame) so all three
// can be visible together without overlapping.
static BOOL rotateKeyHeld = FALSE;
static DWORD rotateToastStartTick = 0;

// The robot's exact pose the instant Walk was toggled on -- every gait
// tick restores this in full, then reapplies that tick's interpolated
// deltas on top (see advanceGait), rather than nudging the live pose
// incrementally tick after tick. Recomputing from this fixed source of
// truth every time means the cycle can never drift or accumulate
// floating-point error over a long walk, the same reasoning
// updateDrawingPoint's shift-line preview truncate-and-rebuild uses.
static Semni gaitBaseline;

// Continuously increasing (never wrapped/reset) -- one full unit is one
// complete crouch-push-swing-land cycle. advanceGait derives two different
// things from it: fmodf(gaitPhaseUnwrapped, 1.0f) for looking up where in
// the cycle the joints/hop-bob currently are (that part DOES need to
// repeat every cycle), and gaitPhaseUnwrapped directly (unwrapped) for how
// far forward the robot has walked (that part must NOT reset every cycle,
// or it would hop in place instead of advancing) -- see advanceGait's own
// comment for the derivation.
static float gaitPhaseUnwrapped = 0.0f;

// Real-time (GetTickCount) timestamp of the last advanceGait call -- same
// "measure actual elapsed time, don't assume a fixed tick length" reason
// autoGravityLastTickTime exists (see advanceAutoGravity's comment).
static DWORD gaitLastTickTime = 0;

// One keyframe in the gait cycle -- see config.h's SIMULATION_GAIT_*
// comment block for the overall design. Every field except `phase` is a
// DELTA from gaitBaseline, not an absolute value, so the cycle always
// swings around whatever pose the robot actually had when Walk was
// switched on instead of assuming a fixed geometry.
typedef struct {
    float phase;            // 0..1, strictly ascending; first entry MUST be 0.0, last MUST be 1.0
    float hipAngleDeltaDeg;
    float kneeAngleDeltaDeg;
    float bodyAngleDeltaDeg;
    float hopY;              // world units, relative to gaitBaseline.y
} GaitKeyframe;

// A single-leg hop/pivot cycle: crouch (load up), push off (extend and
// rise), swing the leg forward through the air (peak height), land back at
// neutral to close the loop. First-pass numbers (SIMULATION_GAIT_* in
// config.h) -- not visually tuned yet, see that block's comment. If a
// swing reads as going the wrong way once this is actually visible, the
// fix is almost certainly flipping one of these signs, not the structure.
static const GaitKeyframe gaitCycle[] = {
    // phase   hipDelta                          kneeDelta                          bodyDelta                          hopY
    { 0.00f,   0.0f,                              0.0f,                              0.0f,                              0.0f },
    { 0.20f,  -SIMULATION_GAIT_HIP_SWING_DEG*0.3f, SIMULATION_GAIT_KNEE_BEND_DEG,    -SIMULATION_GAIT_BODY_LEAN_DEG*0.5f, -SIMULATION_GAIT_HOP_HEIGHT*0.25f }, // crouch/load
    { 0.45f,   SIMULATION_GAIT_HIP_SWING_DEG*0.5f,-SIMULATION_GAIT_KNEE_BEND_DEG*0.7f, SIMULATION_GAIT_BODY_LEAN_DEG,      SIMULATION_GAIT_HOP_HEIGHT*0.6f  }, // push off
    { 0.70f,  -SIMULATION_GAIT_HIP_SWING_DEG,     SIMULATION_GAIT_KNEE_BEND_DEG*0.8f,  SIMULATION_GAIT_BODY_LEAN_DEG*0.3f, SIMULATION_GAIT_HOP_HEIGHT       }, // swing forward, peak height
    { 1.00f,   0.0f,                              0.0f,                              0.0f,                              0.0f },  // land -- same as phase 0.00, closes the loop
};
#define GAIT_KEYFRAME_COUNT (sizeof(gaitCycle) / sizeof(gaitCycle[0]))

// Linearly interpolates the gait cycle at the given phase (0..1, already
// wrapped -- see advanceGait). Walks the table for the bracketing pair of
// keyframes rather than assuming a fixed count/spacing, so gaitCycle's
// entries above can be freely added to/re-timed later without touching
// this function.
static void sampleGaitCycle(float phase, float* hipDeg, float* kneeDeg, float* bodyDeg, float* hopY)
{
    for (unsigned int i = 0; i + 1 < GAIT_KEYFRAME_COUNT; i++)
    {
        const GaitKeyframe* a = &gaitCycle[i];
        const GaitKeyframe* b = &gaitCycle[i + 1];

        if (phase >= a->phase && phase <= b->phase)
        {
            float span = b->phase - a->phase;
            float t = (span > 1e-6f) ? (phase - a->phase) / span : 0.0f;

            *hipDeg  = a->hipAngleDeltaDeg  + (b->hipAngleDeltaDeg  - a->hipAngleDeltaDeg)  * t;
            *kneeDeg = a->kneeAngleDeltaDeg + (b->kneeAngleDeltaDeg - a->kneeAngleDeltaDeg) * t;
            *bodyDeg = a->bodyAngleDeltaDeg + (b->bodyAngleDeltaDeg - a->bodyAngleDeltaDeg) * t;
            *hopY    = a->hopY              + (b->hopY              - a->hopY)              * t;
            return;
        }
    }

    // Shouldn't happen (phase is always in [0,1] and the table spans
    // [0,1]) -- fall back to the neutral pose rather than leaving these
    // uninitialized if it ever does.
    *hipDeg = 0.0f; *kneeDeg = 0.0f; *bodyDeg = 0.0f; *hopY = 0.0f;
}

// Advances the gait cycle by however much real time has actually passed
// since the last call -- same real-time-delta approach advanceAutoGravity
// uses, and for the same reason (WM_TIMER's low priority, see that
// function's comment); called from the same two places (WM_TIMER's
// AUTO_GAIT_TIMER_ID case and directly from WM_MOUSEMOVE) so mouse
// movement can't stall the walk either.
static void advanceGait(HWND hWnd)
{
    if (!gaitActive || appMode != APP_MODE_SIMULATION) return;

    // Same reasoning as advanceAutoGravity's own drag-pause: let the user's
    // drag win outright rather than fighting it or catching up afterward.
    if (app.draggingRobotSim) return;

    DWORD now = GetTickCount();
    DWORD elapsed = now - gaitLastTickTime;
    if (elapsed == 0) return;

    if (elapsed > SIMULATION_AUTO_GRAVITY_MAX_DT_MS)
        elapsed = SIMULATION_AUTO_GRAVITY_MAX_DT_MS; // same stall-guard auto-gravity uses

    gaitLastTickTime = now;

    float simElapsed = (float)elapsed * simTimeScale; // Slow Motion, same as advanceAutoGravity

    gaitPhaseUnwrapped += simElapsed / SIMULATION_GAIT_CYCLE_MS;

    float phase = fmodf(gaitPhaseUnwrapped, 1.0f);
    float hipDeg, kneeDeg, bodyDeg, hopY;
    sampleGaitCycle(phase, &hipDeg, &kneeDeg, &bodyDeg, &hopY);

    // Forward progress is the UNWRAPPED phase times the per-cycle step
    // length -- e.g. after 2.5 cycles, gaitPhaseUnwrapped is 2.5, so the
    // robot has moved 2.5 step-lengths forward, continuously and without
    // any special-casing at each loop boundary (unlike hipDeg/kneeDeg/
    // bodyDeg/hopY above, which DO reset every cycle via fmodf's wrap).
    float forwardX = gaitPhaseUnwrapped * SIMULATION_GAIT_STEP_LENGTH;

    app.robotScene.robot = gaitBaseline;
    app.robotScene.robot.hipAngle  += hipDeg;
    app.robotScene.robot.kneeAngle += kneeDeg;
    app.robotScene.robot.angle     += bodyDeg;
    translateRobot(&app.robotScene.robot, forwardX, hopY);

    InvalidateRect(hWnd, NULL, FALSE);
}

// Toggles the gait cycle on/off -- shared by Shift+W (WM_KEYDOWN) and a
// direct click on the "Walk" button (WM_COMMAND's ID_WALK_TOGGLE), so the
// two input paths can never drift apart. Captures gaitBaseline (the pose
// the cycle swings around) fresh every time it's switched ON, so
// re-toggling Walk after posing the robot differently restarts the cycle
// around the NEW pose rather than snapping back to whatever it was the
// first time Walk was turned on this session.
static void ToggleGait(HWND hWnd)
{
    gaitActive = !gaitActive;

    if (gaitActive)
    {
        gaitBaseline = app.robotScene.robot;
        gaitPhaseUnwrapped = 0.0f;
        gaitLastTickTime = GetTickCount();
        SetTimer(hWnd, AUTO_GAIT_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);
    }
    else
    {
        KillTimer(hWnd, AUTO_GAIT_TIMER_ID);
    }

    if (hWalkBtn)
        SendMessage(hWalkBtn, BM_SETCHECK, gaitActive ? BST_CHECKED : BST_UNCHECKED, 0);

    gaitToastOn = gaitActive;
    gaitToastStartTick = GetTickCount();
    InvalidateRect(hWnd, NULL, FALSE);
}

// Rotates Rocky's kneeAngle smoothly, by however much real time has
// actually passed since the last call, for as long as E and/or Q is
// genuinely held down -- same "scale by real elapsed time instead of
// assuming a fixed tick length" fix advanceAutoGravity already uses for
// the gravity fall (see its own comment), applied here to fix a different
// but related report: "holding E or Q feels jerky/inconsistent, not
// smooth like the fall does." Before this, a held E/Q relied entirely on
// Windows' own WM_KEYDOWN auto-repeat to keep nudging kneeAngle by a fixed
// SIMULATION_JOINT_ROTATE_STEP_DEG per repeated message -- auto-repeat has
// its own OS-level initial delay before it starts (read as a stutter/pause
// right at the start of a hold), then fires at a fixed rate set in the
// user's own keyboard Control Panel settings, unrelated to the screen's
// actual refresh rate -- so the rotation speed while held could feel
// noticeably chunky or uneven depending purely on that OS setting, instead
// of the smooth, consistent motion a real-time-driven rate gives
// regardless of it. Called every ROCKY_KNEE_HOLD_TIMER_ID tick (WM_TIMER
// below) for as long as either key is held; WM_KEYDOWN's own E/Q case
// still applies exactly one discrete SIMULATION_JOINT_ROTATE_STEP_DEG nudge
// on the initial (non-auto-repeat) press only, so a plain tap's feel is
// completely unchanged -- this only ever runs for a genuine hold.
static void advanceRockyKneeHold(HWND hWnd)
{
    if (appMode != APP_MODE_SIMULATION || app.robotScene.activeKind != ROBOT_KIND_ROCKY) return;
    if (app.robotScene.rocky.legHidden) return; // same no-op-on-legless-Rocky rule as WM_KEYDOWN's own E/Q case
    if (!rockyKneeHoldE && !rockyKneeHoldQ) return; // nothing actually held -- WM_TIMER's own dispatcher stops this timer shortly after this, see its comment

    DWORD now = GetTickCount();
    DWORD elapsed = now - rockyKneeHoldLastTickTime;
    if (elapsed == 0) { InvalidateRect(hWnd, NULL, FALSE); return; } // already advanced this exact millisecond

    if (elapsed > SIMULATION_JOINT_ROTATE_HOLD_MAX_DT_MS)
        elapsed = SIMULATION_JOINT_ROTATE_HOLD_MAX_DT_MS; // avoid a big catch-up jump after a stall

    rockyKneeHoldLastTickTime = now;

    // Same clockwise-is-negative convention WM_KEYDOWN's own single-tap
    // case uses (rotatePoint's CCW-for-positive-angle matrix) -- Q
    // (counter-clockwise) is positive, E (clockwise) is negative. Both
    // held at once cancels to zero, same net-nothing result a real report
    // never actually asked to be treated any differently.
    int dir = (rockyKneeHoldQ ? 1 : 0) + (rockyKneeHoldE ? -1 : 0);
    if (dir != 0)
    {
        Rocky* r = &app.robotScene.rocky;
        r->kneeAngle += (float)dir * SIMULATION_JOINT_ROTATE_RATE_DEG_PER_MS * (float)elapsed;

        resolveUpwardIfPenetrating(hWnd, SIMULATION_SLOPE_CORRECTION_MAX);
    }

    // Same periodic settle re-arm WM_KEYDOWN's own E/Q auto-repeat case
    // used to drive on its own -- now driven from here instead, once per
    // real ROCKY_KNEE_HOLD_TIMER_ID tick, which is actually a MORE
    // reliable cadence than however often Windows happened to re-deliver
    // an auto-repeated WM_KEYDOWN. See reviveRockyBodyProbeStepSizes' own
    // comment for the full reasoning on why this revive needs to happen
    // periodically during a hold at all, not just once on release.
    if (!app.robotScene.rocky.legHidden && autoGravityActive
        && (now - rockyEQHoldLastReviveTick) >= SIMULATION_ROCKY_EQ_HOLD_REVIVE_INTERVAL_MS)
    {
        rockyEQHoldLastReviveTick = now;
        SIM_LOG("[SETTLE] E/Q hold periodic re-arm -- reviving knee+body probe step sizes mid-hold, same as a keyup, so a long hold doesn't spend its whole duration chasing an increasingly stale settle attempt\n");
        reviveRockyBodyProbeStepSizes(hWnd);
    }

    // Same triplet WM_KEYDOWN's own E/Q auto-repeat case used to call --
    // keeps Auto Gravity (and, if separately on, Walk) advancing every
    // tick of the hold, not just once it's released. advancePostRotateSettle
    // is a no-op whenever autoGravityActive is on (its own guard), so
    // calling all three unconditionally here is exactly as safe as it was
    // at the old call site.
    advanceAutoGravity(hWnd);
    advancePostRotateSettle(hWnd);
    advanceGait(hWnd);

    InvalidateRect(hWnd, NULL, FALSE);

    // Same forced-synchronous-repaint fix WM_KEYDOWN's own E/Q case uses,
    // same reason -- WM_TIMER is exactly as low-priority as WM_PAINT, so
    // without this a run of back-to-back ROCKY_KNEE_HOLD_TIMER_ID ticks
    // could each move the robot without any of them actually being drawn
    // until the queue goes quiet.
    UpdateWindow(hWnd);
}

// ---- Semni joint control in Simulation (Q/E = hip, Shift+Q/E = knee) ----
//
// Same hold-to-rotate model as Rocky's E/Q knee (advanceRockyKneeHold
// above): the first press rotates one SIMULATION_JOINT_ROTATE_STEP_DEG step
// immediately, then its own timer keeps rotating at
// SIMULATION_JOINT_ROTATE_RATE_DEG_PER_MS for as long as the key is held
// (Windows' auto-repeat only re-arms the held flag). Q = +angle, E = -angle,
// matching Rocky. Shift is read LIVE on every tick, so pressing or
// releasing Shift mid-hold switches between hip and knee without having to
// let go of Q/E. Rotating a joint pushes the limb into the ground only
// upward (resolveUpwardIfPenetrating), and auto gravity (if on) keeps
// running during the hold, same as Rocky -- Semni has no rotational settle
// (toppling) of its own yet, so it only ever falls straight down.
#define SEMNI_JOINT_HOLD_TIMER_ID 1005

static BOOL semniJointHoldE = FALSE;
static BOOL semniJointHoldQ = FALSE;
static DWORD semniJointHoldLastTickTime = 0;

// Rotates Semni's hip (Shift up) or knee (Shift down) by deltaDeg, then
// lifts the robot out of the ground if that pushed a limb into it.
static void rotateSemniJoint(HWND hWnd, float deltaDeg)
{
    Semni* s = &app.robotScene.robot;
    if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
        s->kneeAngle += deltaDeg;
    else
        s->hipAngle += deltaDeg;

    resolveUpwardIfPenetrating(hWnd, SIMULATION_SLOPE_CORRECTION_MAX);
}

static void advanceSemniJointHold(HWND hWnd)
{
    if (appMode != APP_MODE_SIMULATION || app.robotScene.activeKind != ROBOT_KIND_SEMNI) return;
    if (!semniJointHoldE && !semniJointHoldQ) return;

    DWORD now = GetTickCount();
    DWORD elapsed = now - semniJointHoldLastTickTime;
    if (elapsed == 0) { InvalidateRect(hWnd, NULL, FALSE); return; }
    if (elapsed > SIMULATION_JOINT_ROTATE_HOLD_MAX_DT_MS)
        elapsed = SIMULATION_JOINT_ROTATE_HOLD_MAX_DT_MS; // avoid a big catch-up jump after a stall
    semniJointHoldLastTickTime = now;

    int dir = (semniJointHoldQ ? 1 : 0) + (semniJointHoldE ? -1 : 0); // both held cancel out
    if (dir != 0)
        rotateSemniJoint(hWnd, (float)dir * SIMULATION_JOINT_ROTATE_RATE_DEG_PER_MS * (float)elapsed);

    // Same periodic settle re-arm as Rocky's E/Q hold (advanceRockyKneeHold),
    // so Probe 2/2 keep reacting to the pose while a joint is being driven.
    if (autoGravityActive && (now - rockyEQHoldLastReviveTick) >= SIMULATION_ROCKY_EQ_HOLD_REVIVE_INTERVAL_MS)
    {
        rockyEQHoldLastReviveTick = now;
        reviveRockyBodyProbeStepSizes(hWnd);
    }

    advanceAutoGravity(hWnd);
    advancePostRotateSettle(hWnd);
    advanceGait(hWnd);

    InvalidateRect(hWnd, NULL, FALSE);
    UpdateWindow(hWnd);
}

// Bottom-left "AUTO GRAVITY ON"/"AUTO GRAVITY OFF" toast (canvasRenderFrame
// draws it, WM_KEYDOWN's Shift+G branch below sets these). Stateless fade:
// gravityToastStartTick is just a GetTickCount() snapshot from the moment
// of the toggle, and the render code recomputes the alpha fresh every
// frame from how long ago that was (SIMULATION_GRAVITY_TOAST_HOLD_MS/
// FADE_MS, config.h) rather than stepping some alpha variable on a timer
// tick -- simpler, and immune to any particular timer's cadence.
static BOOL gravityToastOn = FALSE;       // which message to show: ON vs OFF
static DWORD gravityToastStartTick = 0;   // 0 == no toast pending/visible

// Real-time FPS counter (View > Show FPS, ID_TOGGLE_SHOW_FPS) -- the
// number canvasRenderFrame draws, top-right, above the Probe 2 Settle
// button. fpsFrameCount is incremented once per call to canvasRenderFrame
// (which itself runs exactly once per renderCombinedFrame call -- see its
// own two call sites -- and every renderCombinedFrame ends in a real
// SwapBuffers, so this is a genuine "frames actually presented" count, not
// an assumed fixed rate). Averaged over a rolling real-time window
// (FPS_UPDATE_INTERVAL_MS) rather than recomputed every single frame -- an
// instantaneous per-frame value (1000 / this-frame's-own-elapsed-ms)
// bounces around far too fast to actually read, especially since this app
// only repaints on demand (a timer tick, a mouse move, a key press) rather
// than on a fixed render loop, so consecutive frames can be an arbitrary
// number of milliseconds apart. Updated (and drawn) unconditionally,
// regardless of showFpsOverlay -- this keeps measuring in the background
// even while the overlay is switched off, so the moment it's switched back
// on it already has a real, already-averaged number instead of starting
// over from a cold 0.
static int fpsFrameCount = 0;
static DWORD fpsWindowStartTick = 0;
static float fpsDisplayValue = 0.0f;

// Everything WM_PAINT used to do directly (clear excluded -- that's now
// renderCombinedFrame's job, done once per combined frame rather than once
// per subsystem) -- sets the ArcSpline canvas's own projection and draws
// the whole scene into whatever's currently in the color buffer. dimAmount
// scales every draw call's own alpha (opacity, below) when the ArcSpline
// canvas isn't the currently active editor mode, so it still reads as
// background context instead of vanishing while Semni is active. This is
// deliberately NOT a full-screen overlay drawn on top afterward -- that
// would also darken the shared white canvas background underneath it,
// making an empty canvas look grayed out everywhere instead of just this
// subsystem's own strokes/lines fading. Same "scale this alpha down"
// pattern the file already uses for dimming the non-edited Robot/
// Environment layer against each other (see strokeAlpha/ghostAlpha below).
void canvasRenderFrame(float dimAmount)
{
    float opacity = 1.0f - dimAmount;

    // FPS measurement -- see fpsDisplayValue's own comment above for the
    // full reasoning. Counted here, unconditionally, right at the top of
    // the one function that's guaranteed to run exactly once per actual
    // presented frame -- see that comment for why this specific spot.
    {
        DWORD fpsNow = GetTickCount();
        if (fpsWindowStartTick == 0)
            fpsWindowStartTick = fpsNow; // first frame ever -- start the window from here, not from tick 0

        fpsFrameCount++;

        DWORD fpsElapsed = fpsNow - fpsWindowStartTick;
        if (fpsElapsed >= FPS_UPDATE_INTERVAL_MS)
        {
            fpsDisplayValue = (float)fpsFrameCount * 1000.0f / (float)fpsElapsed;
            fpsFrameCount = 0;
            fpsWindowStartTick = fpsNow;

            // View > FPS Log (Simulation only) -- one line per measurement
            // window (FPS_UPDATE_INTERVAL_MS).
            SIM_FPS_LOG("[FPS] %.1f fps\n", (double)fpsDisplayValue);
        }
    }

    UpdateProjection();

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // In Simulation mode, pan through sim_camera instead of canvas.panX/
    // panY -- converted into THIS subsystem's own current half-extent (the
    // exact same aspect/zoom math UpdateProjection above just used) via
    // simCameraGetWorldPan, so it stays in exact pixel-lockstep with
    // however far the robot itself pans (see graphics.c's graphicsGetPan),
    // despite the two subsystems' projections not sharing a base unit or
    // formula.
    if (appMode == APP_MODE_SIMULATION)
    {
        float aspect = (float)glWindowWidth / (float)glWindowHeight;
        float zoom = 1.0f / simCameraGetZoom();
        float halfX, halfY;
        if (aspect >= 1.0f) { halfX = aspect * zoom; halfY = zoom; }
        else                { halfX = zoom; halfY = zoom / aspect; }

        float simPanX, simPanY;
        simCameraGetWorldPan(halfX, halfY, &simPanX, &simPanY);
        glTranslatef(-simPanX, -simPanY, 0.0f);
    }
    else
    {
        glTranslatef(-canvas.panX, -canvas.panY, 0.0f);   // NEW: apply camera pan to everything below
    }

    // Only show background image if NOT in active comparison mode.
    // Deliberately NOT gated on canvas.showSegments - Comparison Mode
    // has to work on its own whether or not "View Segments" is also
    // checked, as long as something has been traced.
    BOOL isComparisonActive = canvas.comparisonMode && canvas.segmentResultCount > 0;

    // Robot layer has no drawable content of its own yet (it's reserved
    // for a separate project to be embedded here later), so no new
    // strokes can be added while it's active (see WM_LBUTTONDOWN).
    // But the Environment layer still renders underneath as a dimmed
    // reference, same as when Environment is dimmed while Robot is
    // hypothetically active in the other direction — only the currently
    // edited layer is shown at full opacity.
    BOOL isRobotLayerActive = (appMode == APP_MODE_DESIGN && designLayer == LAYER_ROBOT);

    if (canvas.hasBackgroundImage && !isComparisonActive)
    {
        // FIXED bounds (computed once at upload time) — canvas.zoom now
        // actually affects this via the ortho projection, same as strokes
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glBindTexture(GL_TEXTURE_2D, canvasTexture);
        glColor4f(1.0f, 1.0f, 1.0f, (isRobotLayerActive ? 0.25f : 1.0f) * opacity);

        glBegin(GL_QUADS);
            glTexCoord2f(0.0f, 0.0f); glVertex2f(bgLeft,  bgBottom);
            glTexCoord2f(1.0f, 0.0f); glVertex2f(bgRight, bgBottom);
            glTexCoord2f(1.0f, 1.0f); glVertex2f(bgRight, bgTop);
            glTexCoord2f(0.0f, 1.0f); glVertex2f(bgLeft,  bgTop);
        glEnd();

        glDisable(GL_BLEND);
        glDisable(GL_TEXTURE_2D);
    }

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Only apply comparison mode (hide/fade strokes) if segments are actually being shown

    if (!isComparisonActive)
    {
        for (int s = 0; s < canvas.strokeCount; s++)
        {
            int start = strokeStarts[s];
            int end = (s == canvas.strokeCount - 1) ? canvas.pointCount : strokeStarts[s + 1];
            int count = (end - start) / 2;
            if (count < 2) continue;

            COLORREF c = strokeColor[s];

            // In Design mode, dim strokes belonging to the layer that
            // isn't currently being edited (Robot vs Environment) so
            // it stays visible as reference without competing with the
            // active layer. Simulation mode shows everything at full
            // opacity.
            float strokeAlpha = 1.0f;
            if (appMode == APP_MODE_DESIGN && strokeLayer[s] != designLayer)
                strokeAlpha = 0.25f;

            glColor4f(GetRValue(c)/255.0f, GetGValue(c)/255.0f, GetBValue(c)/255.0f, strokeAlpha * opacity);

            // Same sim_camera-vs-canvas.zoom fix as the Comparison Mode
            // ribbon below (see its own comment) -- this loop is normally
            // skipped during Simulation (isComparisonActive forces the
            // reconstructed ribbon instead), but Comparison Mode can be
            // unchecked manually while simulating, and canvas.zoom sits
            // frozen the whole time Simulation is active either way, so
            // this stayed wrong for the same reason if that ever happened.
            // Same reasoning as the Comparison Mode ribbon's baseHalfW
            // fix below: in Simulation mode, draw at the SAME half-width
            // collision actually uses (simEnvLineHalfWidthWorld, shared
            // with pointCollidesWithAnyEnvironmentStroke) instead of the
            // stroke's real measured thickness, so a manually-unchecked
            // Comparison Mode still shows contact as flush rather than
            // sinking/floating relative to what collision treats as the
            // surface.
            float effectiveZoomForStroke = (appMode == APP_MODE_SIMULATION) ? (1.0f / simCameraGetZoom()) : canvas.zoom;
            float halfW;
            if (appMode == APP_MODE_SIMULATION)
                halfW = simEnvLineHalfWidthWorld();
            else
                halfW = designStrokeHalfWidthWorld(strokeThickness[s], effectiveZoomForStroke);

            glBegin(GL_TRIANGLE_STRIP);
            for (int i = 0; i < count; i++)
            {
                float x = points[start + i * 2];
                float y = points[start + i * 2 + 1];
                float dx = 0.0f, dy = 0.0f;

                if (i == 0) {
                    dx = points[start + (i + 1) * 2] - x;
                    dy = points[start + (i + 1) * 2 + 1] - y;
                } else if (i == count - 1) {
                    dx = x - points[start + (i - 1) * 2];
                    dy = y - points[start + (i - 1) * 2 + 1];
                } else {
                    float dx1 = x - points[start + (i - 1) * 2];
                    float dy1 = y - points[start + (i - 1) * 2 + 1];
                    float dx2 = points[start + (i + 1) * 2] - x;
                    float dy2 = points[start + (i + 1) * 2 + 1] - y;
                    dx = dx1 + dx2;
                    dy = dy1 + dy2;
                }

                float len = sqrtf(dx * dx + dy * dy);
                if (len == 0.0f) len = 1.0f;
                float nx = -dy / len;
                float ny = dx / len;

                glVertex2f(x + nx * halfW, y + ny * halfW);
                glVertex2f(x - nx * halfW, y - ny * halfW);
            }
            glEnd();
        }
    }
    glDisable(GL_BLEND);

    // NEW: endpoint-snap highlight - a bright ring around the stroke
    // endpoint the cursor is currently hovering near, showing the user
    // that starting a new stroke here will snap onto it.
    if (snapEndpointAvailable)
    {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        const int ringSteps = 24;
        float ringRadius = 0.02f * canvas.zoom;

        glColor4f(1.0f, 0.55f, 0.0f, 0.9f * opacity);   // orange, matches nothing else on canvas
        glLineWidth(2.0f);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < ringSteps; i++)
        {
            float theta = (2.0f * 3.14159265f * i) / ringSteps;
            glVertex2f(snapEndpointX + ringRadius * cosf(theta),
                       snapEndpointY + ringRadius * sinf(theta));
        }
        glEnd();

        // Small filled center dot so the exact snap point is unambiguous
        glColor4f(1.0f, 0.55f, 0.0f, 0.9f * opacity);
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(snapEndpointX, snapEndpointY);
        for (int i = 0; i <= ringSteps; i++)
        {
            float theta = (2.0f * 3.14159265f * i) / ringSteps;
            glVertex2f(snapEndpointX + (ringRadius * 0.3f) * cosf(theta),
                       snapEndpointY + (ringRadius * 0.3f) * sinf(theta));
        }
        glEnd();

        glLineWidth(1.0f);
        glDisable(GL_BLEND);
    }


	// Rendered when EITHER "View Segments" is checked OR Comparison Mode
	// is active - the two controls are independent, so Comparison Mode
	// must be able to show the traced arcs on its own without also
	// requiring View Segments to be checked.
	if ((canvas.showSegments || isComparisonActive) && canvas.segmentResultCount > 0)
	{
	    glEnable(GL_BLEND);
	    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	    // Comparison Mode HIDES the original strokes entirely while it's on
	    // (see the "!isComparisonActive" guard around the real-stroke render
	    // loop above) -- so the user is judging width by memory/toggling,
	    // not a simultaneous overlay. Full opacity here (was 0.95) matches
	    // the original stroke's own strokeAlpha exactly, so a lower-contrast
	    // ghost line isn't ALSO reading as visually thinner/fainter on top
	    // of whatever the true geometric width difference is -- the actual
	    // width itself comes entirely from segmentAvgRadiusPx below, this
	    // is just making sure alpha doesn't quietly stack another
	    // "apples-to-apples" mismatch on top of it.
	    float ghostAlpha = isComparisonActive ? 1.0f : 0.35f;
	    if (isRobotLayerActive) ghostAlpha *= 0.3f;  // extra-dim: Environment reference while on Robot layer

	    for (int s = 0; s < canvas.segmentResultCount; s++)
	    {
	        int start = segmentStarts[s];
	        int count = segmentCounts[s];
	        if (count < 2) continue;

	        BOOL isHovered = (s == hoveredSegment) && !isRobotLayerActive;   // NEW

	        float r, g, b;
	        if (isComparisonActive) {
	            // Dark grey for comparison mode
	            r = 0.3f;
	            g = 0.3f;
	            b = 0.3f;
	        } else {
	            segmentGhostColor(s, &r, &g, &b);
	        }
	        glColor4f(r, g, b, (isHovered ? 1.0f : ghostAlpha) * opacity);

	        // Per-segment now (used to be one flat ghostHalfW for every
	        // segment) -- same *canvas.zoom/glWindowWidth constant-screen-
	        // pixel-width formula real strokes use just above, applied to
	        // THIS segment's own recovered original radius (segmentAvgRadiusPx,
	        // canvas_bridge.c), so the reconstruction respects each stroke's
	        // actual original thickness instead of rendering every segment
	        // at the same made-up width regardless of how thick it really was.
	        //
	        // The 2x bump is View-Segments-only: that ribbon (not the dashed
	        // ghost CIRCLE outline further below) is the actual colorful
	        // reconstructed line the user sees, and at its original 1x width
	        // the hovered segment's highlight color was hard to make out
	        // against its neighbors. Comparison Mode's whole point is an
	        // apples-to-apples look against the real original stroke, so it
	        // keeps the true 1x width (segmentAvgRadiusPx is already
	        // corrected to match strokeThickness's own units, same as the
	        // untouched original-stroke render above) -- doubling it there
	        // too made the reconstruction visibly thicker than the drawing
	        // it's supposed to be compared against.
	        // In Simulation mode this ribbon is driven by sim_camera's own
	        // independent zoom, not canvas.zoom (same reasoning as
	        // UpdateProjection's own "bigger = zoomed OUT" vs "bigger =
	        // zoomed IN" comment just above in this file) -- canvas.zoom is
	        // deliberately left untouched while simulating (WM_MOUSEWHEEL),
	        // so it just sits frozen at whatever Design > Environment last
	        // left it at. Using it here unconditionally meant this ribbon's
	        // drawn half-width never actually tracked sim_camera zooming in
	        // Simulation mode: scrolling to zoom moved the projection (and
	        // so the robot and the line's own CENTERLINE) correctly, but
	        // this ribbon's thickness stayed anchored to the stale
	        // canvas.zoom, making the line visibly thinner than its real
	        // (correct, zoom-independent) collision half-width the more you
	        // zoomed in -- exactly the "still a gap once I zoom in" symptom,
	        // even after the environment segment data itself was already
	        // correct and unaffected by zoom.
	        // In Simulation mode the ribbon's thickness must match what
	        // collision actually treats as the environment's half-width, or
	        // contact looks wrong even when it's mathematically exact:
	        // robotCollidesWithEnvironment() now pads every environment
	        // surface with a single fixed epsilon (robotLengthToEnvWorld(
	        // SIMULATION_ARC_COLLISION_THICKNESS), see eArcThickness/
	        // eEdgeThickness) instead of the stroke's real measured
	        // thickness (segmentAvgRadiusPx). If this ribbon kept drawing at
	        // the real (usually much larger) measured thickness, a robot
	        // settled flush at the collision centerline would visually sit
	        // inside/under the top of the still-thick-looking line -- the
	        // "went through the line" symptom. Drawing it at the same fixed
	        // epsilon collision uses makes contact look flush instead of
	        // floating or sinking, for any robot kind/size. Design mode is
	        // unaffected: it keeps the original real-thickness look, since
	        // nothing about the drawing there depends on this simulated
	        // collision constant.
	        float effectiveZoomForRender = (appMode == APP_MODE_SIMULATION) ? (1.0f / simCameraGetZoom()) : canvas.zoom;
	        float baseHalfW;
	        if (appMode == APP_MODE_SIMULATION)
	            baseHalfW = simEnvLineHalfWidthWorld();
	        else
	            baseHalfW = designStrokeHalfWidthWorld(segmentAvgRadiusPx[s], effectiveZoomForRender);
	        // (The View Segments 2x boost above was sized for the old,
	        // too-thin width -- see designStrokeHalfWidthWorld. Now that the
	        // base width is correct it's already about as wide as the old
	        // boosted ribbon, so no extra boost; hover still widens it.)
	        float ghostHalfW = baseHalfW;
	        float halfW = isHovered ? ghostHalfW * 1.5f : ghostHalfW;

	        glBegin(GL_TRIANGLE_STRIP);
	        for (int i = 0; i < count; i++)
	        {
	            float x = segmentPointsWorld[(start + i) * 2];
	            float y = segmentPointsWorld[(start + i) * 2 + 1];
	            float dx = 0.0f, dy = 0.0f;

	            if (i == 0) {
	                dx = segmentPointsWorld[(start + i + 1) * 2] - x;
	                dy = segmentPointsWorld[(start + i + 1) * 2 + 1] - y;
	            } else if (i == count - 1) {
	                dx = x - segmentPointsWorld[(start + i - 1) * 2];
	                dy = y - segmentPointsWorld[(start + i - 1) * 2 + 1];
	            } else {
	                dx = segmentPointsWorld[(start + i + 1) * 2] - segmentPointsWorld[(start + i - 1) * 2];
	                dy = segmentPointsWorld[(start + i + 1) * 2 + 1] - segmentPointsWorld[(start + i - 1) * 2 + 1];
	            }

	            float len = sqrtf(dx * dx + dy * dy);
	            if (len == 0.0f) len = 1.0f;
	            float nx = -dy / len;
	            float ny = dx / len;

	            glVertex2f(x + nx * halfW, y + ny * halfW);
	            glVertex2f(x - nx * halfW, y - ny * halfW);
	        }
	        glEnd();
	    }

	    glDisable(GL_BLEND);
	}

	// NEW: ghost circles - the FULL circle each arc segment was cut from
	if (canvas.showSegments && canvas.segmentResultCount > 0)
	{
	    glEnable(GL_BLEND);
	    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	    const int circleSteps = 64;

	    for (int s = 0; s < canvas.segmentResultCount; s++)
	    {
	        float rx = segmentCircleRadiusWorld[s];
	        float ry = segmentCircleRadiusWorldY[s];
	        if (rx <= 0.0f || ry <= 0.0f) continue; // straight/degenerate segment - no circle to show

	        float cx = segmentCircleCenterWorld[s * 2];
	        float cy = segmentCircleCenterWorld[s * 2 + 1];

	        BOOL isHovered = (s == hoveredSegment) && !isRobotLayerActive;   // NEW

	        float gr, gg, gb;
	        segmentGhostColor(s, &gr, &gg, &gb);

	        if (isHovered) {
	            glDisable(GL_LINE_STIPPLE);          // solid outline when hovered
	            glLineWidth(2.5f);
	            glColor4f(gr, gg, gb, 1.0f * opacity);
	        } else {
	            glEnable(GL_LINE_STIPPLE);
	            glLineStipple(1, 0x00FF);            // dotted outline otherwise
	            glLineWidth(1.0f);
	            glColor4f(gr, gg, gb, (isRobotLayerActive ? 0.18f : 0.6f) * opacity);
	        }

	        glBegin(GL_LINE_LOOP);
	        for (int i = 0; i < circleSteps; i++) {
	            float theta = (2.0f * 3.14159265f * i) / circleSteps;
	            glVertex2f(cx + rx * cosf(theta), cy + ry * sinf(theta));
	        }
	        glEnd();
	    }

	    glLineWidth(1.0f);
	    glDisable(GL_LINE_STIPPLE);
	    glDisable(GL_BLEND);
	}

    // Branch/junction points (a Y/T/X-shaped stroke splits into multiple
    // edges here) - green.
    if (branchMarkerCount > 0)
    {
        float branchMarkerRadius = 0.02f * canvas.zoom;
        for (int m = 0; m < branchMarkerCount; m++)
        {
            drawMarkerDisc(branchMarkersWorld[m * 2], branchMarkersWorld[m * 2 + 1],
                           branchMarkerRadius, 0.0f, 1.0f, 0.0f, opacity);
        }
    }

    // --- BLINK-FREE UI TEXT DRAWING ---
    // ArcSpline, Semni, and Simulation each have their own independent zoom
    // (canvas.zoom / graphicsGetZoom() / simCameraGetZoom()), but only ONE
    // readout should be on screen at a time -- whichever mode the user is
    // actually in -- rather than stacking all three, since the other two
    // are irrelevant to what you're doing.
    BOOL semniModeActive = (editorModeState.currentMode == EDITOR_MODE_SEMNI);

    char zoomStr[32];
    if (appMode == APP_MODE_SIMULATION)
    {
        // Same "bigger = zoomed in" convention as graphicsGetZoom below --
        // sim_camera's zoom was deliberately built to match it (see
        // sim_camera.h), so this readout uses the same "100 * zoom" formula
        // rather than canvas.zoom's inverted one.
        int simZoomPercent = (int)(100.0f * simCameraGetZoom());
        wsprintfA(zoomStr, "Zoom (Simulation): %d%%", simZoomPercent);
    }
    else if (semniModeActive)
    {
        // NOTE: opposite convention from canvas.zoom below -- graphics.c's
        // g_zoom is a direct multiplier on top of the base projection (see
        // graphicsZoom/applyProjection), so a BIGGER g_zoom means zoomed
        // IN (smaller frustum), unlike canvas.zoom where bigger means
        // zoomed OUT. Using the same "100 / zoom" formula here made this
        // readout count down while actually zooming in.
        int robotZoomPercent = (int)(100.0f * graphicsGetZoom());
        wsprintfA(zoomStr, "Zoom (Robot): %d%%", robotZoomPercent);
    }
    else
    {
        int zoomPercent = (int)(100.0f / canvas.zoom);
        wsprintfA(zoomStr, "Zoom (Sketch): %d%%", zoomPercent);
    }

    glMatrixMode(GL_PROJECTION);
    glPushMatrix(); glLoadIdentity();
    glOrtho(0, glWindowWidth, 0, glWindowHeight, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix(); glLoadIdentity();

    // Corner hover indicator - shows exactly where to hover to reveal the
    // UI panel, and brightens while you're hovering it. That panel is
    // Design > Environment-only tooling (see envDesignActive's comment,
    // WM_TIMER's UI_HOTZONE_TIMER_ID handling below), so this indicator
    // has no reason to exist outside that mode either -- left ungated
    // before, it kept drawing (and lighting up on hover) in the exact
    // same top-right corner Simulation's own Probe 2 toggle button now
    // lives in, which is exactly the "ui hover in simulation mode" this
    // fixes.
    if (appMode == APP_MODE_DESIGN && designLayer == LAYER_ENVIRONMENT)
    {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        float tabLeft   = (float)(glWindowWidth - UI_HOTZONE_WIDTH);
        float tabRight  = (float)glWindowWidth;
        float tabBottom = (float)(glWindowHeight - UI_HOTZONE_HEIGHT);
        float tabTop    = (float)glWindowHeight;

        float fillA = (hotZoneHighlighted ? 0.30f : 0.10f) * opacity;
        if (hotZoneHighlighted)
            glColor4f(0.25f, 0.55f, 0.95f, fillA);
        else
            glColor4f(0.4f, 0.4f, 0.4f, fillA);

        glBegin(GL_QUADS);
            glVertex2f(tabLeft,  tabBottom);
            glVertex2f(tabRight, tabBottom);
            glVertex2f(tabRight, tabTop);
            glVertex2f(tabLeft,  tabTop);
        glEnd();

        // Small drawer-handle icon: three short horizontal bars
        float shade = hotZoneHighlighted ? 0.95f : 0.55f;
        glColor4f(shade, shade, shade, 0.9f * opacity);
        float cx = (tabLeft + tabRight) * 0.5f;
        float cy = (tabBottom + tabTop) * 0.5f;
        float barHalfW = (float)UI_HOTZONE_WIDTH * 0.22f;
        for (int i = -1; i <= 1; i++)
        {
            float by = cy + i * 7.0f;
            glBegin(GL_QUADS);
                glVertex2f(cx - barHalfW, by - 1.5f);
                glVertex2f(cx + barHalfW, by - 1.5f);
                glVertex2f(cx + barHalfW, by + 1.5f);
                glVertex2f(cx - barHalfW, by + 1.5f);
            glEnd();
        }

        glDisable(GL_BLEND);
    }

    // Text/swatch drawing below relies on its glColor4f alpha actually
    // being respected (needed for opacity < 1 when this canvas is the
    // dimmed/inactive subsystem), which requires GL_BLEND enabled --
    // unlike the corner indicator above, this block doesn't toggle it
    // itself, so enable it here and leave it on through the mode indicator.
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // This zoom readout is global HUD, not ArcSpline-specific content, so
    // -- same reasoning as the mode indicator below -- it always draws at
    // full opacity instead of fading with `opacity` when this canvas
    // happens to be the dimmed/inactive subsystem.
    glColor4f(0.3f, 0.3f, 0.3f, 1.0f);
    glRasterPos2i(glWindowWidth - 160, 20);
    glPushAttrib(GL_LIST_BIT);
    glListBase(fontBase - 32);
    glCallLists((GLsizei)strlen(zoomStr), GL_UNSIGNED_BYTE, zoomStr);
    glPopAttrib();

    // Always-on exact client-area pixel position of the cursor, same
    // bottom-right column as the zoom readout just above, stacked directly
    // above it (y = 40 vs the zoom line's y = 20, one text row's worth of
    // clearance) so the two never overlap. Read fresh via GetCursorPos/
    // ScreenToClient every frame instead of threading it through
    // WM_MOUSEMOVE, since WM_MOUSEMOVE only ever reaches whichever
    // subsystem (WndProcGL here, or handleInput) is currently active (see
    // WndProcShared's mode-gated dispatch) -- reading the cursor position
    // directly here means one implementation works identically in both
    // Design > Robot and Design > Environment, with no mouse-move hook
    // needed in either one. Used to be gated behind a 'P' toggle -- removed
    // in favor of just always showing it. Same "always full opacity"
    // reasoning as the zoom readout above -- global HUD, not
    // ArcSpline-specific content.
    {
        POINT pt;
        GetCursorPos(&pt);
        ScreenToClient(hWndGL, &pt);

        char pixelStr[32];
        wsprintfA(pixelStr, "Pixel: (%d, %d)", (int)pt.x, (int)pt.y);

        glColor4f(0.3f, 0.3f, 0.3f, 1.0f);
        glRasterPos2i(glWindowWidth - 160, 40);
        glPushAttrib(GL_LIST_BIT);
        glListBase(fontBase - 32);
        glCallLists((GLsizei)strlen(pixelStr), GL_UNSIGNED_BYTE, pixelStr);
        glPopAttrib();
    }

    // NEW: View Segments hover readout -- tells you WHICH segment (by
    // position) the cursor is currently over, not just that it's
    // highlighted. Follows the cursor itself (drawn just up and to the
    // right of it, using the same client-pixel `pt` the Pixel readout just
    // above already fetched) rather than sitting in a fixed HUD corner, so
    // it always reads right next to whatever you're actually pointing at.
    // Colored to match the hovered circle/segment's own highlight color
    // (circleSegmentColor/bodyCircleColor/segmentGhostColor) instead of the
    // HUD's usual gray, so the label and the thing it's naming visually tie
    // together at a glance. Same "Segment N/M" format in both modes
    // (Design > Robot and Design > Environment). Only one of the two
    // branches can ever be true at once (Design > Robot forces
    // EDITOR_MODE_SEMNI, Design > Environment/Simulation don't), so there's
    // no need to pick between them beyond the existing semniModeActive
    // check both other HUD blocks in this function already use.
    //
    // Robot mode: input.c's WM_MOUSEMOVE hit-test (gated on
    // app.showCircleSegments the same way this is) already resolves the
    // hover down to at most ONE of a fillet (app.hoveredCircleSegment) or a
    // body circle (app.hoveredBodyCircle) -- see its own comment for why
    // they share one winner -- so at most one of these two branches fires.
    // The two are numbered as one combined N/M range (fillets 1..6, body
    // circles 7..11) rather than each restarting at 1/6 or 1/5, so this
    // reads as one consistent "N/M" position the same way Environment
    // mode's flat segment list already does, instead of silently meaning
    // two different scales depending on what's hovered.
    //
    // Environment mode: canvas.c's own hoveredSegment (WM_MOUSEMOVE above)
    // is an index into canvas.segmentResults, forced back to -1 outright
    // during Simulation (see that assignment's comment), so this can never
    // show a stale/wrong-mode readout there even though semniModeActive
    // alone wouldn't otherwise rule Simulation out.
    {
        char hoverSegStr[64];
        BOOL showHoverSeg = FALSE;
        float segR = 0.3f, segG = 0.3f, segB = 0.3f;

        if (semniModeActive)
        {
            // Rocky/Stilo have their own View Segments overlays now too
            // (renderer.c/h's computeRocky*/computeStilo*), each with a
            // different fillet/body-circle count than Semni's own 6/5 --
            // pick the matching pair for whichever kind is actually active
            // so the "N/M" total (and the fillet-vs-body-circle numbering
            // split just below) means the right thing for all three.
            //
            // The DISPLAY number is no longer just "fillets 1..N, then body
            // circles N+1..N+M" (the raw index order the underlying arrays
            // use for color/hit-test, which stays untouched) -- it now
            // follows the same Head/Butt/Seam/Hip/Knee/Feet/Thigh/Shin
            // priority order established for hover labels and click
            // priority (input.c), so a user reading "Segment 3/11" sees the
            // same position in that established order regardless of which
            // internal array (fillet vs body circle) actually backs it.
            // filletDisplayNum[i]/bodyDisplayNum[i] map a raw array index to
            // that display number; see each kind's compute* function
            // (renderer.c) for the raw index order these were derived from.
            int numCircleSegments, numBodyCircles, numRectSegments;
            const int* filletDisplayNum;
            const int* bodyDisplayNum;
            const int* rectDisplayNum;
            switch (app.robotScene.activeKind)
            {
                case ROBOT_KIND_ROCKY:
                {
                    // raw rect-edge order: top, right, bottom, left (see
                    // renderer.c's computeRockyRectSegments) -- raw fillet
                    // order: shin1, shin2 -- raw body order: knee, foot.
                    // The 4 rectangle edges still come first (1-4), then
                    // knee(5), foot(6), shin1(7), shin2(8) -- but the
                    // mapping among the 4 edges was cyclically shifted by
                    // one position per explicit user request (whatever
                    // showed "4" should show "1", "1"->"2", "2"->"3",
                    // "3"->"4"): raw index 0 (top, was 1) is now 2, raw 1
                    // (right, was 2) is now 3, raw 2 (bottom, was 3) is now
                    // 4, raw 3 (left, was 4) is now 1.
                    static const int rockyRectDisplayNum[NUM_ROCKY_RECT_SEGMENTS] = { 2, 3, 4, 1 };
                    static const int rockyFilletDisplayNum[NUM_ROCKY_CIRCLE_SEGMENTS] = { 7, 8 };
                    static const int rockyBodyDisplayNum[NUM_ROCKY_BODY_CIRCLES] = { 5, 6 };
                    numCircleSegments = NUM_ROCKY_CIRCLE_SEGMENTS;
                    numBodyCircles = NUM_ROCKY_BODY_CIRCLES;
                    numRectSegments = NUM_ROCKY_RECT_SEGMENTS;
                    filletDisplayNum = rockyFilletDisplayNum;
                    bodyDisplayNum = rockyBodyDisplayNum;
                    rectDisplayNum = rockyRectDisplayNum;
                    break;
                }
                case ROBOT_KIND_STILO:
                {
                    // raw fillet order: seam1, seam2, thigh1Arc1,
                    // thigh1Arc2, thigh2Arc1, thigh2Arc2 -- raw body order:
                    // out[0] is the physical headX-based circle, out[1] the
                    // physical buttX-based circle. Same display-name swap as
                    // input.c's hoverStiloHead/hoverStiloButt (see that
                    // comment): the physical headX circle (out[0]) is what
                    // the UI calls "Butt", and the physical buttX circle
                    // (out[1]) is what it calls "Head" -- so out[0] gets the
                    // "Butt" display number and out[1] gets "Head"'s, not
                    // the other way around. Desired: head=out[1](1),
                    // butt=out[0](2), seam1(3), seam2(4), hip1(5), feet1(6),
                    // thigh1Arc1(7), thigh1Arc2(8), hip2(9), feet2(10),
                    // thigh2Arc1(11), thigh2Arc2(12).
                    static const int stiloFilletDisplayNum[NUM_STILO_CIRCLE_SEGMENTS] = { 3, 4, 7, 8, 11, 12 };
                    static const int stiloBodyDisplayNum[NUM_STILO_BODY_CIRCLES] = { 2, 1, 5, 6, 9, 10 };
                    numCircleSegments = NUM_STILO_CIRCLE_SEGMENTS;
                    numBodyCircles = NUM_STILO_BODY_CIRCLES;
                    // Stilo has no rectangular body (see app.h's own
                    // comment on hoveredRectSegment) -- 0/NULL, never
                    // dereferenced since app.hoveredRectSegment is reset to
                    // -1 whenever Rocky isn't the active kind (input.c).
                    numRectSegments = 0;
                    filletDisplayNum = stiloFilletDisplayNum;
                    bodyDisplayNum = stiloBodyDisplayNum;
                    rectDisplayNum = NULL;
                    break;
                }
                case ROBOT_KIND_SEMNI:
                default:
                {
                    // raw fillet order: seam1, seam2, thigh1, thigh2, shin1,
                    // shin2 -- raw body order: out[0] is the physical
                    // headX-based circle, out[1] the physical buttX-based
                    // circle. Same display-name swap as input.c's
                    // hoverHead/hoverButt (see that comment): the physical
                    // headX circle (out[0]) is what the UI calls "Butt", and
                    // the physical buttX circle (out[1]) is what it calls
                    // "Head" -- so out[0] gets the "Butt" display number and
                    // out[1] gets "Head"'s, not the other way around.
                    // Desired: head=out[1](1), butt=out[0](2), seam1(3),
                    // seam2(4), hip(5), knee(6), foot(7), thigh1(8),
                    // thigh2(9), shin1(10), shin2(11).
                    static const int semniFilletDisplayNum[NUM_ROBOT_CIRCLE_SEGMENTS] = { 3, 4, 8, 9, 10, 11 };
                    static const int semniBodyDisplayNum[NUM_ROBOT_BODY_CIRCLES] = { 2, 1, 5, 6, 7 };
                    numCircleSegments = NUM_ROBOT_CIRCLE_SEGMENTS;
                    numBodyCircles = NUM_ROBOT_BODY_CIRCLES;
                    // Semni has no rectangular body either -- same 0/NULL,
                    // never-dereferenced reasoning as Stilo's own case above.
                    numRectSegments = 0;
                    filletDisplayNum = semniFilletDisplayNum;
                    bodyDisplayNum = semniBodyDisplayNum;
                    rectDisplayNum = NULL;
                    break;
                }
            }
            int totalRobotSegments = numCircleSegments + numBodyCircles + numRectSegments;

            if (app.showCircleSegments && app.hoveredCircleSegment != -1)
            {
                wsprintfA(hoverSegStr, "Segment %d/%d", filletDisplayNum[app.hoveredCircleSegment], totalRobotSegments);
                circleSegmentColor(app.hoveredCircleSegment, &segR, &segG, &segB);
                showHoverSeg = TRUE;
            }
            else if (app.showCircleSegments && app.hoveredBodyCircle != -1)
            {
                wsprintfA(hoverSegStr, "Segment %d/%d", bodyDisplayNum[app.hoveredBodyCircle], totalRobotSegments);
                bodyCircleColor(app.hoveredBodyCircle, &segR, &segG, &segB);
                showHoverSeg = TRUE;
            }
            else if (app.showCircleSegments && app.hoveredRectSegment != -1)
            {
                // Rocky only (see app.h's own hoveredRectSegment comment) --
                // rectDisplayNum is only ever non-NULL for
                // ROBOT_KIND_ROCKY, and app.hoveredRectSegment is only ever
                // set to something other than -1 while Rocky is active
                // (input.c), so this branch can't fire with a NULL
                // rectDisplayNum.
                wsprintfA(hoverSegStr, "Segment %d/%d", rectDisplayNum[app.hoveredRectSegment], totalRobotSegments);
                rectSegmentColor(app.hoveredRectSegment, &segR, &segG, &segB);
                showHoverSeg = TRUE;
            }
        }
        else if (canvas.showSegments && hoveredSegment != -1)
        {
            wsprintfA(hoverSegStr, "Segment %d/%d", hoveredSegment + 1, canvas.segmentResultCount);
            segmentGhostColor(hoveredSegment, &segR, &segG, &segB);
            showHoverSeg = TRUE;
        }

        if (showHoverSeg)
        {
            // Same GetCursorPos/ScreenToClient technique the Pixel readout
            // above uses (its own `pt` is scoped to that block, so this
            // fetches its own rather than reaching outside it) -- client
            // pixels, origin top-left, Y growing DOWNWARD. This block's
            // ortho (glOrtho(0, glWindowWidth, 0, glWindowHeight, ...), set
            // up before the Zoom readout earlier in this function) has
            // origin bottom-left, Y growing UPWARD instead, so Y has to
            // flip (glWindowHeight - pt.y) before adding the "up and to the
            // right" offset.
            POINT pt;
            GetCursorPos(&pt);
            ScreenToClient(hWndGL, &pt);

            int tooltipX = (int)pt.x + 16;
            int tooltipY = (glWindowHeight - (int)pt.y) + 16;

            glColor4f(segR, segG, segB, 1.0f);
            glRasterPos2i(tooltipX, tooltipY);
            glPushAttrib(GL_LIST_BIT);
            glListBase(fontBase - 32);
            glCallLists((GLsizei)strlen(hoverSegStr), GL_UNSIGNED_BYTE, hoverSegStr);
            glPopAttrib();
        }
    }

    // NEW: persistent top-left mode/layer indicator - otherwise the
    // only way to tell Design/Robot/Environment apart is to open the
    // Mode menu and see which item is checked.
    {
        char modeStr[64];
        float mr, mg, mb;

        if (appMode == APP_MODE_SIMULATION) {
            wsprintfA(modeStr, "Mode: Simulation");
            mr = 0.5f; mg = 0.3f; mb = 0.7f;   // purple
        } else if (designLayer == LAYER_ROBOT) {
            wsprintfA(modeStr, "Mode: Design - Robot");
            mr = 0.85f; mg = 0.45f; mb = 0.0f; // orange, matches the endpoint-snap highlight
        } else {
            wsprintfA(modeStr, "Mode: Design - Environment");
            mr = 0.1f; mg = 0.55f; mb = 0.15f; // green
        }

        // Small color swatch ahead of the text so the mode reads at a
        // glance without needing to read the label itself.
        //
        // This indicator reflects global app/mode state, not ArcSpline-
        // specific content, so it always draws at full opacity -- even
        // when this canvas is the dimmed/inactive subsystem (e.g. while
        // the Semni robot editor is on top). Using `opacity` here made
        // "Mode: Design - Robot" fade out precisely while you were IN
        // robot design mode, which read as a bug/dead control.
        glColor4f(mr, mg, mb, 1.0f);
        glBegin(GL_QUADS);
            glVertex2f(10.0f, (float)glWindowHeight - 24.0f);
            glVertex2f(20.0f, (float)glWindowHeight - 24.0f);
            glVertex2f(20.0f, (float)glWindowHeight - 14.0f);
            glVertex2f(10.0f, (float)glWindowHeight - 14.0f);
        glEnd();

        glColor4f(0.2f, 0.2f, 0.2f, 1.0f);
        glRasterPos2i(26, glWindowHeight - 22);
        glPushAttrib(GL_LIST_BIT);
        glListBase(fontBase - 32);
        glCallLists((GLsizei)strlen(modeStr), GL_UNSIGNED_BYTE, modeStr);
        glPopAttrib();
    }

    // FPS counter (View > Show FPS, ID_TOGGLE_SHOW_FPS) -- top-right,
    // directly above the Probe 2 Settle button (hProbe2ToggleBtn, WM_CREATE/
    // WM_SIZE below reserve FPS_OVERLAY_RESERVED_HEIGHT_PX of space above it
    // specifically for this). Left-aligned to that same button's own left
    // edge (glWindowWidth - PROBE2_TOGGLE_MARGIN_PX - PROBE2_TOGGLE_WIDTH_PX)
    // rather than right-aligned to the window edge -- this bitmap-font setup
    // has no cheap way to measure a string's rendered width up front to
    // right-align it, and lining up with the button underneath reads just
    // as tidy without needing that.
    //
    // Same "always full opacity" reasoning as the Mode indicator just
    // above -- this reflects real-time engine performance, not ArcSpline-
    // specific content, so it stays fully readable even while this canvas
    // is the dimmed/inactive subsystem.
    // Simulation only -- not shown in Design > Environment or Design > Robot.
    if (showFpsOverlay && appMode == APP_MODE_SIMULATION)
    {
        char fpsStr[32];
        int fpsRounded = (int)(fpsDisplayValue + 0.5f); // wsprintfA has no float specifier -- see ROTATION's own comment below for the same fix
        wsprintfA(fpsStr, "FPS: %d", fpsRounded);

        // Green/yellow/red at rough smoothness thresholds -- 50+ reads as
        // comfortably smooth, under 30 as visibly choppy, in between as
        // "keep an eye on it". Purely a visual aid, no other effect.
        float fr, fg, fb;
        if (fpsRounded >= 50)      { fr = 0.1f;  fg = 0.55f; fb = 0.15f; } // green
        else if (fpsRounded >= 30) { fr = 0.75f; fg = 0.55f; fb = 0.0f;  } // amber
        else                       { fr = 0.8f;  fg = 0.15f; fb = 0.1f;  } // red

        glColor4f(fr, fg, fb, 1.0f);
        glRasterPos2i(glWindowWidth - PROBE2_TOGGLE_MARGIN_PX - PROBE2_TOGGLE_WIDTH_PX, glWindowHeight - 24);
        glPushAttrib(GL_LIST_BIT);
        glListBase(fontBase - 32);
        glCallLists((GLsizei)strlen(fpsStr), GL_UNSIGNED_BYTE, fpsStr);
        glPopAttrib();
    }

    // Shift+G's "AUTO GRAVITY ON"/"AUTO GRAVITY OFF" toast -- bottom-left,
    // mirroring the top-left mode indicator above. Stateless fade: alpha is
    // recomputed fresh every frame from how long ago gravityToastStartTick
    // was stamped (WM_KEYDOWN's Shift+G branch), not stepped by a timer, so
    // it doesn't matter which timer happens to be driving repaints right
    // now (see WM_TIMER's UI_HOTZONE_TIMER_ID case, which nudges repaints
    // along during the fade once auto-gravity's own ticking has stopped).
    // gravityToastStartTick == 0 means no toast is pending/visible.
    if (gravityToastStartTick != 0)
    {
        DWORD elapsed = GetTickCount() - gravityToastStartTick;
        float toastAlpha = 0.0f;

        if (elapsed < SIMULATION_GRAVITY_TOAST_HOLD_MS)
        {
            toastAlpha = 1.0f;
        }
        else if (elapsed < (DWORD)(SIMULATION_GRAVITY_TOAST_HOLD_MS + SIMULATION_GRAVITY_TOAST_FADE_MS))
        {
            float fadeElapsed = (float)(elapsed - SIMULATION_GRAVITY_TOAST_HOLD_MS);
            toastAlpha = 1.0f - (fadeElapsed / (float)SIMULATION_GRAVITY_TOAST_FADE_MS);
        }

        if (toastAlpha > 0.0f)
        {
            const char* toastStr = gravityToastOn ? "AUTO GRAVITY ON" : "AUTO GRAVITY OFF";
            float tr = gravityToastOn ? 0.15f : 0.4f;
            float tg = gravityToastOn ? 0.55f : 0.4f;
            float tb = gravityToastOn ? 0.15f : 0.4f;

            glColor4f(tr, tg, tb, toastAlpha);
            glRasterPos2i(10, 20);
            glPushAttrib(GL_LIST_BIT);
            glListBase(fontBase - 32);
            glCallLists((GLsizei)strlen(toastStr), GL_UNSIGNED_BYTE, toastStr);
            glPopAttrib();
        }
    }

    // Shift+W's "WALK ON"/"WALK OFF" toast -- same stateless-fade pattern
    // as the gravity toast just above, one line higher (y=36 vs y=20) so
    // both can show at once without overlapping if auto-gravity and Walk
    // are toggled close together.
    if (gaitToastStartTick != 0)
    {
        DWORD elapsed = GetTickCount() - gaitToastStartTick;
        float toastAlpha = 0.0f;

        if (elapsed < SIMULATION_GRAVITY_TOAST_HOLD_MS)
        {
            toastAlpha = 1.0f;
        }
        else if (elapsed < (DWORD)(SIMULATION_GRAVITY_TOAST_HOLD_MS + SIMULATION_GRAVITY_TOAST_FADE_MS))
        {
            float fadeElapsed = (float)(elapsed - SIMULATION_GRAVITY_TOAST_HOLD_MS);
            toastAlpha = 1.0f - (fadeElapsed / (float)SIMULATION_GRAVITY_TOAST_FADE_MS);
        }

        if (toastAlpha > 0.0f)
        {
            const char* toastStr = gaitToastOn ? "WALK ON" : "WALK OFF";
            float tr = gaitToastOn ? 0.15f : 0.4f;
            float tg = gaitToastOn ? 0.55f : 0.4f;
            float tb = gaitToastOn ? 0.15f : 0.4f;

            glColor4f(tr, tg, tb, toastAlpha);
            glRasterPos2i(10, 36);
            glPushAttrib(GL_LIST_BIT);
            glListBase(fontBase - 32);
            glCallLists((GLsizei)strlen(toastStr), GL_UNSIGNED_BYTE, toastStr);
            glPopAttrib();
        }
    }

    // VK_LEFT/RIGHT's rotation HUD -- one line above the Walk toast (y=52
    // vs y=36), same 16px spacing. Not the same shape as the two
    // stateless-fade toasts just above: while rotateKeyHeld is TRUE the
    // key is actively down right now, so this shows continuously at full
    // opacity, live, every frame -- no hold/fade timing at all, otherwise
    // the readout would start fading out from under the user's own
    // fingers mid-hold. Only once the key comes up (WM_KEYUP clears
    // rotateToastStartTick) does the SAME
    // hold-then-fade pattern take over, so the last angle shown lingers
    // briefly instead of vanishing the instant the key is released. Shows
    // the real degree sign (0xB0) now that fontBase's own glyph range
    // covers it (see its own comment, WM_CREATE above) -- no longer
    // spelled out as "DEG".
    if (rotateKeyHeld || rotateToastStartTick != 0)
    {
        float toastAlpha = 1.0f;

        if (!rotateKeyHeld)
        {
            DWORD elapsed = GetTickCount() - rotateToastStartTick;
            toastAlpha = 0.0f;

            if (elapsed < SIMULATION_GRAVITY_TOAST_HOLD_MS)
            {
                toastAlpha = 1.0f;
            }
            else if (elapsed < (DWORD)(SIMULATION_GRAVITY_TOAST_HOLD_MS + SIMULATION_GRAVITY_TOAST_FADE_MS))
            {
                float fadeElapsed = (float)(elapsed - SIMULATION_GRAVITY_TOAST_HOLD_MS);
                toastAlpha = 1.0f - (fadeElapsed / (float)SIMULATION_GRAVITY_TOAST_FADE_MS);
            }
        }

        if (toastAlpha > 0.0f)
        {
            // wsprintfA (the convention every other on-screen label in this
            // file uses -- zoomStr/hoverSegStr/modeStr above) doesn't
            // support floating-point format specifiers at all, so round to
            // the nearest whole degree by hand first rather than handing
            // it a raw float.
            //
            // Negated here, display-only: rotatePoint (geometry.c) turns a
            // positive angle into a COUNTERclockwise turn on screen (the
            // standard math convention for this coordinate space), which
            // made VK_RIGHT (a clockwise turn -- it applies a NEGATIVE
            // step, see WM_KEYDOWN above) read as the number counting
            // DOWN, and VK_LEFT counting up -- backwards from how a
            // clockwise-increasing readout (like a compass heading) is
            // expected to behave. Flipping the sign right here, before
            // rounding, makes the DISPLAYED count increase 0->359 for a
            // clockwise turn (VK_RIGHT) and decrease for a counterclockwise
            // one (VK_LEFT), without touching the real angle field itself
            // or which key does which -- only which direction this readout
            // counts up in.
            float angle = -activeRobotAngleDegrees();
            int angleDeg = (int)(angle >= 0.0f ? (angle + 0.5f) : (angle - 0.5f));

            // activeRobotAngleDegrees() is the raw, unwrapped rotation --
            // it keeps climbing (or dropping negative) with every further
            // VK_LEFT/RIGHT press rather than resetting at a full turn, so
            // by itself it would show 360, 361, 720... instead of wrapping
            // back to 0. Wrap the ROUNDED int (not the float before
            // rounding) into [0, 359] here, display-only -- this never
            // touches the real angle field driving the robot's actual
            // pose, only what this readout prints. The C '%' operator can
            // return a negative result for a negative left operand (e.g.
            // -1 % 360 == -1, not 359), so the sign is corrected by hand
            // right after.
            angleDeg %= 360;
            if (angleDeg < 0) angleDeg += 360;

            char toastStr[32];
            wsprintfA(toastStr, "ROTATION: %d\xB0", angleDeg);

            glColor4f(0.2f, 0.4f, 0.85f, toastAlpha);
            glRasterPos2i(10, 52);
            glPushAttrib(GL_LIST_BIT);
            glListBase(fontBase - 32);
            glCallLists((GLsizei)strlen(toastStr), GL_UNSIGNED_BYTE, toastStr);
            glPopAttrib();
        }
    }

    glDisable(GL_BLEND);

    glMatrixMode(GL_PROJECTION); glPopMatrix();
    glMatrixMode(GL_MODELVIEW); glPopMatrix();
}

// Draws ONE combined frame: clears the color buffer once, then draws both
// editor subsystems, whichever is currently active (editorModeState.
// currentMode) at full opacity on top, the other dimmed underneath. See
// canvas.h for the full rationale.
//
// EXCEPT in Simulation mode: switchEditorMode always forces ArcSpline to
// be the "active" editor mode when Simulation is picked (see WM_COMMAND's
// ID_MODE_SIMULATION handling), which would otherwise leave the robot
// dimmed the whole time you're simulating -- backwards for a mode whose
// whole point is seeing the robot posed clearly within its environment,
// and dragging it into a starting position (WM_LBUTTONDOWN/WM_MOUSEMOVE
// above). So both subsystems draw at full opacity together here instead.
void renderCombinedFrame(void)
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    BOOL semniActive = (editorModeState.currentMode == EDITOR_MODE_SEMNI);
    BOOL simulationActive = (appMode == APP_MODE_SIMULATION);

    // hideInactiveLayer (View > Hide Inactive Layer, see its own comment)
    // swaps the inactive layer's dim amount from the normal partial fade
    // (INACTIVE_MODE_DIM_ALPHA) up to 1.0 -- renderRobotScene/
    // canvasRenderFrame both compute opacity = 1.0 - dimAmount, so 1.0
    // means fully invisible rather than just faded.
    float inactiveDimAmount = hideInactiveLayer ? 1.0f : INACTIVE_MODE_DIM_ALPHA;
    float robotDimAmount  = (semniActive || simulationActive) ? 0.0f : inactiveDimAmount;
    float canvasDimAmount = (!semniActive || simulationActive) ? 0.0f : inactiveDimAmount;

    // Simulation mode's mass-center drop line needs to know where a
    // straight drop from the mass center actually reaches the
    // environment -- computed once here (canvas.c owns the environment/
    // collision code this needs) and threaded into renderRobotScene,
    // which draws it (see drawSimulationMassCenterDropLine's own
    // comment). Only worth computing while actually in Simulation --
    // it's not drawn otherwise, and the search below does real per-frame
    // environment queries.
    float massCenterDropStopY = 0.0f;
    if (simulationActive)
    {
        PointF massCenterTip = computeSimulationMassCenterWorld(&app);
        massCenterDropStopY = simFindGroundBelowRobotPoint(massCenterTip);
    }

    // Semni's own projection/blend state has to be (re)asserted right
    // before it draws, and the ArcSpline canvas's projection right before
    // IT draws (canvasRenderFrame does this itself via UpdateProjection) --
    // same reasoning as the old per-mode render loop in main.c: the two
    // subsystems share one GL context, so whichever drew last left its own
    // projection matrix active.
    // [PERF] diagnostic, temporary -- see this function's own printf at the
    // bottom for the full reasoning (same investigation as applyGravityStep's
    // settle fast-forward timing). perfRobotMs/perfCanvasMs/perfDotsMs are
    // each just the elapsed time around that one call, summed across
    // whichever of the two branches below actually runs (only one does).
    double perfFrameStart = perfNowMs();
    double perfRobotMs = 0.0, perfCanvasMs = 0.0, perfDotsMs = 0.0;

    if (semniActive)
    {
        // ArcSpline underneath...
        double perfT0 = perfNowMs();
        canvasRenderFrame(canvasDimAmount);
        perfCanvasMs = perfNowMs() - perfT0;

        // ...Semni on top
        graphicsOnResize(glWindowWidth, glWindowHeight);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        perfT0 = perfNowMs();
        renderRobotScene(&app, robotDimAmount, massCenterDropStopY);
        perfRobotMs = perfNowMs() - perfT0;
    }
    else
    {
        // Semni underneath...
        graphicsOnResize(glWindowWidth, glWindowHeight);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        double perfT0 = perfNowMs();
        renderRobotScene(&app, robotDimAmount, massCenterDropStopY);
        perfRobotMs = perfNowMs() - perfT0;

        // ...ArcSpline on top
        perfT0 = perfNowMs();
        canvasRenderFrame(canvasDimAmount);
        perfCanvasMs = perfNowMs() - perfT0;

        // Contact dots (plain C toggle) -- drawn LAST, after BOTH the
        // robot and the environment, so nothing painted on top of
        // Simulation mode's own environment ribbon/strokes can cover them
        // (this used to run right after renderRobotScene, BEFORE
        // canvasRenderFrame -- if the environment's own drawing happened
        // to paint over a marker sitting right at ground contact, exactly
        // where most of these markers actually are, it would never be
        // visible despite genuinely being drawn). canvasRenderFrame just
        // rebound its OWN projection for its own draw, so the robot's has
        // to be reasserted here -- these points are in robot-local
        // coordinates, same convention drawRockyMassCenterTrack/
        // drawRockyReferencePoint already use, not whatever ArcSpline just
        // left bound. No-ops instantly unless both showContactDebug is on
        // and we're actually in Simulation mode. The old full-sample
        // diagnostic overlay this toggle used to gate is gone entirely --
        // by explicit request, plain-C now shows/hides
        // drawSimulationLiveContactDots instead, replacing it rather than
        // layering on top of it.
        graphicsOnResize(glWindowWidth, glWindowHeight);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        {
            // graphicsOnResize above only re-asserts the PROJECTION matrix
            // -- canvasRenderFrame's own MODELVIEW translate (the
            // ENVIRONMENT's pan, simPanX/simPanY) is still bound at this
            // point and has to be replaced with the ROBOT's own pan here,
            // the exact same way renderRobotScene/renderApp do it each
            // frame, or these robot-local points drift away from the
            // robot the moment either subsystem's pan differs from the
            // other's (which is most of the time -- they're unrelated
            // pan values that only coincide at (0,0)).
            float panX, panY;
            graphicsGetPan(&panX, &panY);
            glTranslatef(-panX, -panY, 0.0f);
        }
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        double perfT1 = perfNowMs();
        drawSimulationLiveContactDots();
        perfDotsMs = perfNowMs() - perfT1;
    }

    // SwapBuffers itself is timed separately from the draw calls above --
    // with vsync on, this is where the driver actually BLOCKS waiting for
    // the display's next refresh, which is a completely different kind of
    // cost (GPU/driver wait, not CPU work) from everything measured above
    // it. A [PERF] line dominated by this instead of robot/canvas/dots
    // would point at vsync/driver/GPU load rather than anything in this
    // app's own per-frame logic.
    double perfSwapStart = perfNowMs();
    SwapBuffers(hDC);
    double perfSwapMs = perfNowMs() - perfSwapStart;

    // [PERF] diagnostic, temporary (by explicit request, to chase down a
    // real report of FPS occasionally dropping to ~20 with no cause yet
    // identified) -- only prints once total frame time crosses
    // SIMULATION_PERF_WARN_FRAME_MS (config.h), so a normal fast frame
    // produces no output at all. Read alongside applyGravityStep's own
    // [PERF] settle fast-forward line: THAT one accounts for time spent
    // BEFORE this frame was even scheduled (inside a WM_TIMER tick's own
    // settle work), while this one accounts for time spent actually
    // drawing it -- together they cover both places a frame can go slow.
    // perfRobotMs/perfCanvasMs/perfDotsMs/perfSwapMs won't always sum to
    // exactly the total (glClear, graphicsOnResize, and the various GL
    // state calls between them aren't separately timed), but they cover
    // the expensive parts.
    double perfFrameElapsed = perfNowMs() - perfFrameStart;
    if (perfFrameElapsed >= (double)SIMULATION_PERF_WARN_FRAME_MS)
    {
        SIM_FPS_LOG("[PERF] slow frame: total=%.2fms robot=%.2fms canvas=%.2fms contactDots=%.2fms swapBuffers=%.2fms\n",
               perfFrameElapsed, perfRobotMs, perfCanvasMs, perfDotsMs, perfSwapMs);
    }
}

// Appends (or, while Shift is held, re-derives) the in-progress stroke's
// next point from a CLIENT-space pixel position -- the exact logic
// WM_MOUSEMOVE's drawing branch used to have inline. Factored out so
// WM_KEYDOWN's VK_SHIFT handling below can run the same "constrain to a
// straight line" computation using GetCursorPos, not just WM_MOUSEMOVE
// using lParam -- see that handler's comment for why that matters. mx/my
// are CLIENT window pixel coordinates in both cases (WM_MOUSEMOVE's
// LOWORD/HIWORD(lParam) already are; the caller is responsible for
// ScreenToClient-ing a GetCursorPos result first).
static void updateDrawingPoint(HWND hWnd, int mx, int my, BOOL shiftHeld, BOOL ctrlHeld)
{
    float x = (float)mx;
    float y = (float)my;
    float aspect = (float)glWindowWidth / (float)glWindowHeight;
    float nx, ny;
    if (aspect >= 1.0f) {
        nx = ((2.0f * x / glWindowWidth) - 1.0f) * aspect * canvas.zoom;
        ny = (1.0f - (2.0f * y / glWindowHeight)) * canvas.zoom;
    } else {
        nx = ((2.0f * x / glWindowWidth) - 1.0f) * canvas.zoom;
        ny = (1.0f - (2.0f * y / glWindowHeight)) * (1.0f / aspect) * canvas.zoom;
    }
    nx += canvas.panX;
    ny += canvas.panY;

    // Holding Shift constrains the stroke to a straight line from its
    // start point to the current cursor. Re-derived every call (truncate +
    // re-append) rather than appended to, so it tracks the cursor like a
    // rubber-band preview instead of accumulating a freehand trail
    // underneath it. Releasing Shift mid-drag restores the freehand path
    // exactly as it was before Shift was first pressed (see the backup
    // snapshot/restore below) -- Shift is a temporary preview, not a commit.
    //
    // Adding Ctrl on top of Shift instantly snaps that line's angle to the
    // nearest 45 degrees (horizontal / vertical / diagonal), same idea as
    // the axis-lock in most drawing tools.
    //
    // Holding the cursor still (no Ctrl needed) for SHIFT_HOLD_SNAP_MS near
    // one of those same angles snaps it too -- see the dwell check in
    // WM_TIMER, since a stationary cursor generates no WM_MOUSEMOVE
    // messages for that check to run inside. This function only tracks raw
    // cursor state and applies the lock once WM_TIMER has set
    // shiftHoldSnapped; it never decides to snap itself.
    // Cursor hidden while placing a Shift straight line (see WM_SETCURSOR),
    // back as soon as Shift is released mid-stroke.
    SetCursor(shiftHeld ? NULL : LoadCursor(NULL, IDC_ARROW));

    if (shiftHeld)
    {
        int curStrokeStart = strokeStarts[canvas.strokeCount - 1];

        if (!shiftHoldActive)
        {
            // Fresh activation for this drag (first Shift-held call since
            // the last release) -- snapshot the freehand points drawn so
            // far, BEFORE they get truncated away below, so releasing
            // Shift can restore them exactly instead of leaving whatever
            // the straight-line preview ended up at.
            shiftHoldFreehandBackupCount = canvas.pointCount;
            memcpy(shiftHoldFreehandBackup, points, sizeof(float) * (size_t)canvas.pointCount);
        }

        canvas.pointCount = curStrokeStart + 2; // keep only the stroke's first point

        int dxPix = mx - shiftHoldPixelX;
        int dyPix = my - shiftHoldPixelY;
        BOOL movedSignificantly = !shiftHoldActive ||
            (dxPix * dxPix + dyPix * dyPix) > (SHIFT_HOLD_JITTER_PX * SHIFT_HOLD_JITTER_PX);

        if (movedSignificantly)
        {
            shiftHoldActive       = TRUE;
            shiftHoldStrokeStart  = curStrokeStart;
            shiftHoldPixelX       = mx;
            shiftHoldPixelY       = my;
            shiftHoldLastMoveTick = GetTickCount();
            shiftHoldSnapped      = FALSE;   // moving again releases any dwell-lock
        }
        // Always track the latest raw position (even tiny sub-jitter
        // moves), so the WM_TIMER dwell check judges the angle against
        // where the cursor actually is right now.
        shiftHoldWorldX = nx;
        shiftHoldWorldY = ny;

        if (ctrlHeld)
        {
            // points[curStrokeStart]/[+1] is the stroke's untouched first
            // point - only pointCount was rewound above, the underlying
            // data is still there, so this is a safe anchor to snap from.
            float startX = points[curStrokeStart];
            float startY = points[curStrokeStart + 1];

            float dx = nx - startX;
            float dy = ny - startY;
            float len = sqrtf(dx * dx + dy * dy);

            if (len > 1e-6f)
            {
                const float step = 3.14159265f / 4.0f; // 45 degrees
                float angle = atan2f(dy, dx);
                float snapped = roundf(angle / step) * step;

                nx = startX + len * cosf(snapped);
                ny = startY + len * sinf(snapped);
            }
        }
        else if (shiftHoldSnapped)
        {
            // Dwell-locked (set in WM_TIMER): the ANGLE is fixed, but the
            // LENGTH stays live - project the raw cursor onto the locked
            // ray so the user can still drag the endpoint back and forth.
            float startX = points[curStrokeStart];
            float startY = points[curStrokeStart + 1];
            float dirX = cosf(shiftHoldSnapAngleRad);
            float dirY = sinf(shiftHoldSnapAngleRad);
            float relX = nx - startX;
            float relY = ny - startY;
            float proj = relX * dirX + relY * dirY;

            nx = startX + dirX * proj;
            ny = startY + dirY * proj;
        }
    }
    else
    {
        if (shiftHoldActive)
        {
            // Shift just released mid-drag -- restore the freehand points
            // from the snapshot taken when Shift was first pressed this
            // drag, discarding the straight-line preview entirely instead
            // of keeping it or continuing freehand from its endpoint.
            // Returns immediately after, so the restored path is exactly
            // what it was before Shift touched it -- no extra point tacked
            // on at wherever the cursor happens to be right now (ordinary
            // freehand drawing will naturally continue from here on the
            // next real mouse move, same as any other gap between moves).
            canvas.pointCount = shiftHoldFreehandBackupCount;
            memcpy(points, shiftHoldFreehandBackup, sizeof(float) * (size_t)shiftHoldFreehandBackupCount);

            shiftHoldActive  = FALSE;
            shiftHoldSnapped = FALSE;

            InvalidateRect(hWnd, NULL, FALSE);
            return;
        }

        shiftHoldActive  = FALSE;   // Shift released - drop any dwell tracking/lock
        shiftHoldSnapped = FALSE;
    }

    if (canvas.pointCount < MAX_POINTS - 1) {
        points[canvas.pointCount++] = nx;
        points[canvas.pointCount++] = ny;
        InvalidateRect(hWnd, NULL, FALSE);
    }
}
// ---- Debug log: original drawing vs reconstruction (Environment mode) ----
// Printed by View > Print Debug Log after the trace dump. Everything is in
// SCREEN pixels at the current view (x right, y down), so an offset reads
// directly as "how many pixels off on screen". Ends with the raw strokes in
// the exact Autosave\Environment.txt format, so the drawing can be
// reproduced from the log alone.
static float cmpDistToStroke(int st, float wx, float wy)
{
    int start = strokeStarts[st];
    int end = (st == canvas.strokeCount - 1) ? canvas.pointCount : strokeStarts[st + 1];
    int count = (end - start) / 2;
    if (count < 1) return 1e30f;
    if (count == 1) return hypotf(wx - points[start], wy - points[start + 1]);
    float best = 1e30f;
    for (int i = 0; i + 1 < count; i++)
    {
        float d = distPointToSegment(wx, wy, points[start + i * 2], points[start + i * 2 + 1],
                                     points[start + (i + 1) * 2], points[start + (i + 1) * 2 + 1]);
        if (d < best) best = d;
    }
    return best;
}

static void printEnvironmentComparison(void)
{
    float aspect = (float)glWindowWidth / (float)glWindowHeight;
    float zoom = canvas.zoom;
    float pxPerWorld = (float)glWindowWidth / (2.0f * zoom * ((aspect >= 1.0f) ? aspect : 1.0f));
    float halfW = glWindowWidth * 0.5f, halfH = glWindowHeight * 0.5f;
#define CMP_SX(wx) (((wx) - canvas.panX) * pxPerWorld + halfW)
#define CMP_SY(wy) (halfH - ((wy) - canvas.panY) * pxPerWorld)

    printf("\n---------- ORIGINAL vs RECONSTRUCTED ----------\n");
    printf("[CMP] window=%dx%d zoom=%.5f pan=(%.5f,%.5f) screenPx/world=%.3f traceRasterPx/world=%.3f\n",
           glWindowWidth, glWindowHeight, zoom, canvas.panX, canvas.panY, pxPerWorld, traceRasterPxPerWorld());
    printf("[CMP] fit slider=%.2f (0 arcs, 0.5 default, 1 lines only): line tolerance=%.2f px, arc tolerance=%.2f px (trace raster)\n",
           gArcLineBias, traceLineTolerance(), traceArcTolerance());
    printf("[CMP] positions = screen px (x right, y down); distances = screen px\n");

    // Original strokes
    printf("[ORIG] %d stroke(s)\n", canvas.strokeCount);
    for (int st = 0; st < canvas.strokeCount; st++)
    {
        int start = strokeStarts[st];
        int end = (st == canvas.strokeCount - 1) ? canvas.pointCount : strokeStarts[st + 1];
        int count = (end - start) / 2;
        if (count < 1) continue;
        printf("[ORIG] stroke=%d %s thickness=%.2f points=%d start=(%.2f,%.2f) end=(%.2f,%.2f)\n", st,
               strokeLayer[st] == LAYER_ENVIRONMENT ? "env" : "robot-layer", strokeThickness[st], count,
               CMP_SX(points[start]), CMP_SY(points[start + 1]),
               CMP_SX(points[end - 2]), CMP_SY(points[end - 1]));
    }

    // Reconstructed segments, each matched to the original stroke it lies on
    printf("[RECON] %d segment(s)\n", canvas.segmentResultCount);
    for (int s = 0; s < canvas.segmentResultCount; s++)
    {
        int start = segmentStarts[s];
        int count = segmentCounts[s];
        if (count < 2) continue;
        float ax = segmentPointsWorld[start * 2], ay = segmentPointsWorld[start * 2 + 1];
        float bx = segmentPointsWorld[(start + count - 1) * 2], by = segmentPointsWorld[(start + count - 1) * 2 + 1];
        BOOL isArc = segmentCircleRadiusWorld[s] > 0.0f;

        int bestStroke = -1;
        float bestMean = 1e30f, bestMax = 0.0f;
        for (int st = 0; st < canvas.strokeCount; st++)
        {
            if (strokeLayer[st] != LAYER_ENVIRONMENT) continue;
            float sum = 0.0f, mx = 0.0f;
            for (int i = 0; i < count; i++)
            {
                float d = cmpDistToStroke(st, segmentPointsWorld[(start + i) * 2], segmentPointsWorld[(start + i) * 2 + 1]);
                sum += d;
                if (d > mx) mx = d;
            }
            float mean = sum / (float)count;
            if (mean < bestMean) { bestMean = mean; bestMax = mx; bestStroke = st; }
        }

        printf("[RECON] seg=%d %s pts=%d start=(%.2f,%.2f) end=(%.2f,%.2f)", s, isArc ? "arc " : "line", count,
               CMP_SX(ax), CMP_SY(ay), CMP_SX(bx), CMP_SY(by));
        if (isArc)
            printf(" radius=%.2f", segmentCircleRadiusWorld[s] * pxPerWorld);
        printf(" width=%.2f inkShift(raster px)=(%.2f,%.2f,r%.2f)\n", segmentAvgRadiusPx[s],
               segmentInkShiftDebug[s * 3], segmentInkShiftDebug[s * 3 + 1], segmentInkShiftDebug[s * 3 + 2]);
        if (bestStroke >= 0)
            printf("[RECON]      -> on stroke %d: mean off %.2f px, max off %.2f px\n",
                   bestStroke, bestMean * pxPerWorld, bestMax * pxPerWorld);
    }

    // Every original stroke endpoint (corners and free ends) vs the nearest
    // reconstructed segment endpoint
    printf("[CORNER] original endpoint -> nearest reconstructed endpoint\n");
    for (int st = 0; st < canvas.strokeCount; st++)
    {
        if (strokeLayer[st] != LAYER_ENVIRONMENT) continue;
        int start = strokeStarts[st];
        int end = (st == canvas.strokeCount - 1) ? canvas.pointCount : strokeStarts[st + 1];
        if (end - start < 2) continue;
        for (int e = 0; e < 2; e++)
        {
            float ox = (e == 0) ? points[start] : points[end - 2];
            float oy = (e == 0) ? points[start + 1] : points[end - 1];
            float best = 1e30f, bx = 0.0f, by = 0.0f;
            int bestSeg = -1;
            for (int s = 0; s < canvas.segmentResultCount; s++)
            {
                int ss = segmentStarts[s], c = segmentCounts[s];
                if (c < 2) continue;
                for (int k = 0; k < 2; k++)
                {
                    int idx = (k == 0) ? ss : ss + c - 1;
                    float px = segmentPointsWorld[idx * 2], py = segmentPointsWorld[idx * 2 + 1];
                    float d = hypotf(px - ox, py - oy);
                    if (d < best) { best = d; bx = px; by = py; bestSeg = s; }
                }
            }
            if (bestSeg < 0) continue;
            printf("[CORNER] stroke=%d %s (%.2f,%.2f) -> seg=%d (%.2f,%.2f)  dx=%+.2f dy=%+.2f dist=%.2f px\n",
                   st, e == 0 ? "start" : "end  ", CMP_SX(ox), CMP_SY(oy), bestSeg, CMP_SX(bx), CMP_SY(by),
                   (bx - ox) * pxPerWorld, -(by - oy) * pxPerWorld, best * pxPerWorld);
        }
    }

    // Raw drawing, exact Autosave\Environment.txt format
    printf("[STROKES-BEGIN]\n");
    printf("%d\n", canvas.strokeCount);
    for (int st = 0; st < canvas.strokeCount; st++)
        printf("%d %.6f %lu %d\n", strokeStarts[st], strokeThickness[st],
               (unsigned long)strokeColor[st], (int)strokeLayer[st]);
    printf("%d\n", canvas.pointCount);
    for (int i = 0; i < canvas.pointCount; i += 2)
        printf("%.6f %.6f\n", points[i], points[i + 1]);
    printf("[STROKES-END]\n");
#undef CMP_SX
#undef CMP_SY
}

LRESULT CALLBACK WndProcGL(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
    case WM_CREATE:
    {
        hDC = GetDC(hWnd);
        PIXELFORMATDESCRIPTOR pfd = {0};
        pfd.nSize = sizeof(pfd);
        pfd.nVersion = 1;
        pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
        pfd.iPixelType = PFD_TYPE_RGBA;
        pfd.cColorBits = 24;
        pfd.cDepthBits = 16;

        int pf = ChoosePixelFormat(hDC, &pfd);
        SetPixelFormat(hDC, pf, &pfd);
        hRC = wglCreateContext(hDC);
        wglMakeCurrent(hDC, hRC);

        HFONT hFont = CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, 
                                 DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
                                 CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
        HFONT hOldFont = (HFONT)SelectObject(hDC, hFont);

        // Range widened from the original 32..127 (96 glyphs, plain ASCII
        // only) up through 176 (0xB0) -- the rotation HUD (canvasRenderFrame,
        // further down) wants the actual degree sign, which lives at 0xB0
        // in the Windows ANSI/Latin-1 codepage this DEFAULT_CHARSET font
        // resolves to, not anywhere in 32..127. glListBase(fontBase - 32)
        // (every call site already uses this same offset) still lines up
        // correctly for any byte in this new range since it's one
        // contiguous block starting at 32, same as before -- nothing else
        // needed to change. The handful of extra Latin-1 glyphs in between
        // (144 of them now instead of 96) go unused by anything else in
        // this file, which costs a bit more video memory for their display
        // lists but nothing else.
        fontBase = glGenLists(145);
        wglUseFontBitmaps(hDC, 32, 145, fontBase);
        SelectObject(hDC, hOldFont);
        DeleteObject(hFont);

        UpdateProjection();
        glLoadIdentity();

        SetTimer(hWnd, UI_HOTZONE_TIMER_ID, UI_HOTZONE_INTERVAL_MS, NULL); // NEW

        // "Reset" -- top of the panel. A plain BS_PUSHBUTTON, not
        // BS_AUTOCHECKBOX -- this is a one-shot action, not a persistent
        // on/off state, so it has nothing to stay "checked" as. Created
        // without WS_VISIBLE -- appMode starts in Design, not Simulation,
        // so it should start hidden; WM_COMMAND's ID_MODE_SIMULATION
        // handling shows/hides it from then on.
        hResetBtn = CreateWindowEx(0, L"BUTTON", L"Reset",
                            WS_CHILD | BS_PUSHBUTTON,
                            10, 10, 120, 28, hWnd, (HMENU)ID_RESET_ROBOT,
                            GetModuleHandle(NULL), NULL);

        // Slow Motion toggle -- directly below Reset (28px tall + 6px
        // gap). Same BS_AUTOCHECKBOX | BS_PUSHLIKE "checkbox that
        // looks/behaves like a toggle button" style ui.c's Trace/
        // Comparison Mode buttons use, same hidden-until-Simulation
        // treatment.
        hSlowMotionBtn = CreateWindowEx(0, L"BUTTON", L"Slow Motion",
                            WS_CHILD | BS_AUTOCHECKBOX | BS_PUSHLIKE,
                            10, 44, 120, 28, hWnd, (HMENU)ID_SLOW_MOTION,
                            GetModuleHandle(NULL), NULL);
        SendMessage(hSlowMotionBtn, BM_SETCHECK, BST_CHECKED, 0); // on by default, matching simTimeScale's initial value

        // "Probe 2 Settle" toggle button (top-right) removed by request --
        // same approach as the Walk button just below: hProbe2ToggleBtn is
        // left NULL (never created). Every other use of it in this file is
        // already guarded by "if (hProbe2ToggleBtn)", and without the
        // button ID_PROBE2_TOGGLE can never fire, so rockyProbe2Enabled
        // simply stays at its default TRUE -- Probe 2 (knee settle) keeps
        // running exactly as before, it just can't be switched off anymore.

        // "Walk" toggle (Shift+W) button removed for now -- hWalkBtn is
        // left NULL (its window is simply never created). All other
        // usages of hWalkBtn elsewhere in this file are already guarded
        // by "if (hWalkBtn)", so this is safe without touching them; the
        // underlying gaitActive/Shift+W machinery is untouched, only the
        // visible button is gone.

        // Environment autosave: restore whatever was last drawn before the
        // app was closed, so a fresh launch shows the last environment
        // instead of always starting blank. See loadEnvironmentAutosave's
        // own comment -- a no-op if nothing was ever autosaved yet.
        loadEnvironmentAutosave();
        return 0;
    }
    case WM_TIMER:
    {
        // Shift+G's "auto gravity" -- see WM_KEYDOWN's toggle above. This is
        // just the steady fallback driver (see SIMULATION_AUTO_GRAVITY_
        // INTERVAL_MS's comment, config.h, for why WM_MOUSEMOVE also calls
        // advanceAutoGravity directly) -- the real step/acceleration math
        // lives in advanceAutoGravity so both call sites can never disagree.
        // Also bails and turns itself off if Simulation mode was left some
        // other way (e.g. switching Design Mode from the menu) without going
        // through the mode-switch cleanup in WM_COMMAND -- defensive, since
        // it wouldn't make sense to keep running outside Simulation.
        if (wParam == AUTO_GRAVITY_TIMER_ID)
        {
            if (appMode == APP_MODE_SIMULATION)
            {
                advanceAutoGravity(hWnd);
                advancePostRotateSettle(hWnd);
            }
            else
            {
                autoGravityActive = FALSE;
                postRotateSettleActive = FALSE;
                KillTimer(hWnd, AUTO_GRAVITY_TIMER_ID);
            }
            return 0;
        }

        // Rocky's knee (E/Q) while genuinely held -- see
        // advanceRockyKneeHold's own comment for the full reasoning. Same
        // defensive shutoff as AUTO_GRAVITY_TIMER_ID just above (Simulation
        // left some other way while this was still running), PLUS its own
        // "nothing's actually held anymore" shutoff -- WM_KEYUP is the
        // normal way this timer gets killed, but if for any reason it's
        // still running with both rockyKneeHoldE/Q now FALSE (a missed or
        // out-of-order keyup, e.g. focus lost mid-hold -- the same
        // structural gap rotateKeyHeld already has, nothing new introduced
        // here), this notices and stops itself within one tick instead of
        // spinning forever on a no-op.
        // Semni's Q/E / Shift+Q/E joint hold -- see advanceSemniJointHold.
        // Stops itself if Simulation was left, the robot kind changed, or
        // both keys are somehow no longer held (e.g. a missed WM_KEYUP).
        if (wParam == SEMNI_JOINT_HOLD_TIMER_ID)
        {
            if (appMode == APP_MODE_SIMULATION && app.robotScene.activeKind == ROBOT_KIND_SEMNI
                && (semniJointHoldE || semniJointHoldQ))
            {
                advanceSemniJointHold(hWnd);
            }
            else
            {
                semniJointHoldE = FALSE;
                semniJointHoldQ = FALSE;
                KillTimer(hWnd, SEMNI_JOINT_HOLD_TIMER_ID);
            }
            return 0;
        }

        if (wParam == ROCKY_KNEE_HOLD_TIMER_ID)
        {
            if (appMode == APP_MODE_SIMULATION && (rockyKneeHoldE || rockyKneeHoldQ))
            {
                advanceRockyKneeHold(hWnd);
            }
            else
            {
                rockyKneeHoldE = FALSE;
                rockyKneeHoldQ = FALSE;
                KillTimer(hWnd, ROCKY_KNEE_HOLD_TIMER_ID);
            }
            return 0;
        }

        // Shift+W's "Walk" -- same fallback-driver/defensive-shutoff
        // structure as AUTO_GRAVITY_TIMER_ID just above, own timer ID so
        // gravity and the gait cycle can each be toggled independently.
        if (wParam == AUTO_GAIT_TIMER_ID)
        {
            if (appMode == APP_MODE_SIMULATION)
            {
                advanceGait(hWnd);
            }
            else
            {
                gaitActive = FALSE;
                KillTimer(hWnd, AUTO_GAIT_TIMER_ID);
            }
            return 0;
        }

        // Keeps the gravity toast's fade animating even after auto-gravity's
        // own timer has stopped ticking (e.g. the "AUTO GRAVITY OFF" toast,
        // or "ON" if the robot lands and applyGravityStep's per-tick
        // InvalidateRect calls happen to line up exactly with a paint
        // that's already up to date). Piggybacks on the always-running
        // hot-zone timer rather than starting a third one just for this.
        // Stops invalidating on its own once the fade duration has fully
        // elapsed (gravityToastStartTick reset to 0), so this doesn't
        // repaint forever.
        if (wParam == UI_HOTZONE_TIMER_ID && gravityToastStartTick != 0)
        {
            DWORD elapsed = GetTickCount() - gravityToastStartTick;
            if (elapsed >= (DWORD)(SIMULATION_GRAVITY_TOAST_HOLD_MS + SIMULATION_GRAVITY_TOAST_FADE_MS))
                gravityToastStartTick = 0;

            InvalidateRect(hWnd, NULL, FALSE);
        }

        // Same fade-keeping piggyback as the gravity toast just above, for
        // the "WALK ON"/"WALK OFF" toast.
        if (wParam == UI_HOTZONE_TIMER_ID && gaitToastStartTick != 0)
        {
            DWORD elapsed = GetTickCount() - gaitToastStartTick;
            if (elapsed >= (DWORD)(SIMULATION_GRAVITY_TOAST_HOLD_MS + SIMULATION_GRAVITY_TOAST_FADE_MS))
                gaitToastStartTick = 0;

            InvalidateRect(hWnd, NULL, FALSE);
        }

        // Same fade-keeping piggyback again, for the rotation HUD -- only
        // needed once the key's already up (rotateToastStartTick != 0);
        // while rotateKeyHeld is still TRUE, WM_KEYDOWN's own auto-repeat
        // and the settle timer's per-tick InvalidateRect already keep it
        // current every frame on their own.
        if (wParam == UI_HOTZONE_TIMER_ID && rotateToastStartTick != 0)
        {
            DWORD elapsed = GetTickCount() - rotateToastStartTick;
            if (elapsed >= (DWORD)(SIMULATION_GRAVITY_TOAST_HOLD_MS + SIMULATION_GRAVITY_TOAST_FADE_MS))
                rotateToastStartTick = 0;

            InvalidateRect(hWnd, NULL, FALSE);
        }

        // NEW: shift-line dwell-to-snap. If the cursor has been basically
        // stationary for SHIFT_HOLD_SNAP_MS while drawing a Shift-line, and
        // its raw angle from the line's start point is close to horizontal,
        // vertical, or a 45/135-degree diagonal, lock the line to that exact
        // angle. Has to live here (not WM_MOUSEMOVE) because a genuinely
        // still cursor produces no WM_MOUSEMOVE messages at all - this timer
        // tick, which already runs every 16ms for the UI hot-zone check
        // below, is what actually notices the elapsed time.
        //
        // NEW: once snapped, this block keeps RE-ASSERTING the locked
        // endpoint every tick (not just once) for as long as the hold is
        // still active - rather than writing it a single time and trusting
        // it to survive untouched. This makes it self-healing: if anything
        // else (a stray/no-op mouse message, etc.) leaves canvas.pointCount
        // truncated to just the start point, the very next 16ms tick puts
        // the endpoint straight back rather than leaving the line missing.
        if (wParam == UI_HOTZONE_TIMER_ID && drawing && shiftHoldActive &&
            (GetAsyncKeyState(VK_SHIFT) & 0x8000))
        {
            if (!shiftHoldSnapped &&
                (GetTickCount() - shiftHoldLastMoveTick) >= SHIFT_HOLD_SNAP_MS)
            {
                float startX = points[shiftHoldStrokeStart];
                float startY = points[shiftHoldStrokeStart + 1];
                float relX = shiftHoldWorldX - startX;
                float relY = shiftHoldWorldY - startY;
                float len = sqrtf(relX * relX + relY * relY);

                if (len > 1e-4f)
                {
                    float deg = atan2f(relY, relX) * (180.0f / 3.14159265f);
                    float nearest45 = roundf(deg / 45.0f) * 45.0f;
                    float diff = fabsf(deg - nearest45);

                    if (diff <= SHIFT_HOLD_TOLERANCE_DEG)
                    {
                        shiftHoldSnapped      = TRUE;
                        shiftHoldSnapAngleRad = nearest45 * (3.14159265f / 180.0f);
                    }
                }
            }

            if (shiftHoldSnapped)
            {
                float startX = points[shiftHoldStrokeStart];
                float startY = points[shiftHoldStrokeStart + 1];
                float dirX = cosf(shiftHoldSnapAngleRad);
                float dirY = sinf(shiftHoldSnapAngleRad);
                float relX = shiftHoldWorldX - startX;
                float relY = shiftHoldWorldY - startY;
                float proj = relX * dirX + relY * dirY;

                canvas.pointCount = shiftHoldStrokeStart + 4;
                points[shiftHoldStrokeStart + 2] = startX + dirX * proj;
                points[shiftHoldStrokeStart + 3] = startY + dirY * proj;

                if (hWndGL) InvalidateRect(hWndGL, NULL, FALSE);
            }
        }

        // NEW: reveal the UI panel when hovering the GL window's top-right
        // corner, or when the panel is already up and the cursor is over it
        // (so you don't lose it mid-click); hide it otherwise. Fades smoothly
        // instead of popping instantly.
        if (wParam == UI_HOTZONE_TIMER_ID && hWndUI)
        {
            POINT pt;
            GetCursorPos(&pt);

            // NEW: GetCursorPos/PtInRect only ever compare raw SCREEN
            // coordinates - they have no idea whether our window is
            // actually the one visible at that point, or buried behind
            // some other app (Discord, a browser, ...) that just happens
            // to overlap the same screen region as our hot zone. Without
            // this, moving the mouse over that other app's window while
            // ours sits behind it still read as "cursor is in the hot
            // zone" and popped the panel up on top of everything.
            // WindowFromPoint respects real Z-order/occlusion - it
            // returns whichever window would actually receive a click at
            // that exact screen point - so this only counts hovers that
            // are genuinely over one of OUR windows (the main GL window,
            // the panel itself, or one of the panel's own child controls).
            HWND wndAtPt = WindowFromPoint(pt);
            BOOL cursorOverOurWindows = wndAtPt != NULL &&
                                        ((wndAtPt == hWnd) ||
                                         (wndAtPt == hWndUI) ||
                                         IsChild(hWndUI, wndAtPt));

            // NEW: use the CLIENT area's top-right corner, not the full
            // window rect - GetWindowRect() includes the title bar, which
            // would (a) make the hot zone drift up into the title bar
            // instead of matching where the indicator is actually drawn,
            // and (b) place the panel over the title bar, covering the
            // close button.
            RECT glClientRect;
            GetClientRect(hWnd, &glClientRect);
            POINT clientTopRight = { glClientRect.right, glClientRect.top };
            ClientToScreen(hWnd, &clientTopRight);

            RECT hotZone;
            hotZone.right  = clientTopRight.x;
            hotZone.left   = clientTopRight.x - UI_HOTZONE_WIDTH;
            hotZone.top    = clientTopRight.y;
            hotZone.bottom = clientTopRight.y + UI_HOTZONE_HEIGHT;

            // This whole hot-zone/panel mechanism is Design > Environment-
            // only tooling (see the wantVisible gate a few lines down for
            // the panel itself) -- computed up here now, rather than only
            // further down, so it can gate hotZoneHighlighted (the corner
            // indicator's own highlighted look, drawn by canvasRenderFrame)
            // too. Without this, hovering that corner in Simulation mode
            // (where Probe 2's toggle button now happens to live) still
            // lit up a leftover Environment-mode indicator with nothing
            // behind it to reveal.
            BOOL envDesignActive = (appMode == APP_MODE_DESIGN && designLayer == LAYER_ENVIRONMENT);

            BOOL inHotZone = envDesignActive && cursorOverOurWindows && PtInRect(&hotZone, pt);

            if (inHotZone != hotZoneHighlighted)
            {
                hotZoneHighlighted = inHotZone;   // NEW: drives the corner indicator's look
                InvalidateRect(hWnd, NULL, FALSE);
            }

            BOOL inUIWindow = FALSE;
            if (uiShown && cursorOverOurWindows)
            {
                RECT uiRect;
                GetWindowRect(hWndUI, &uiRect);
                inUIWindow = PtInRect(&uiRect, pt);
            }

            BOOL wantVisible = inHotZone || inUIWindow;

            // This panel is Design > Environment-only tooling (Clear,
            // thickness, color, Trace, View Segments, Comparison Mode) --
            // none of it applies to Robot design mode or Simulation, so
            // only ever let the hot corner reveal it while Environment is
            // actually the active design layer, even if the cursor is
            // sitting in its hot corner in some other mode. (envDesignActive
            // itself is computed further up now, so it can also gate
            // inHotZone/hotZoneHighlighted -- reused here as-is.)
            if (!envDesignActive)
                wantVisible = FALSE;

            if (wantVisible && !uiShown)
            {
                // Just entered the hot zone: position it flush against the
                // client area's top-right corner (below the title bar) and
                // start fully transparent, then fade in below.
                RECT uiRectCur;
                GetWindowRect(hWndUI, &uiRectCur);
                int uiW = uiRectCur.right - uiRectCur.left;

                uiAlpha = 0;
                SetLayeredWindowAttributes(hWndUI, 0, (BYTE)uiAlpha, LWA_ALPHA);
                SetWindowPos(hWndUI, HWND_TOPMOST,
                             clientTopRight.x - uiW, clientTopRight.y,
                             0, 0, SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOACTIVATE);
                uiShown = TRUE;
            }

            if (uiShown)
            {
                int target = wantVisible ? 255 : 0;

                if (uiAlpha != target)
                {
                    if (uiAlpha < target) {
                        uiAlpha += UI_FADE_STEP;
                        if (uiAlpha > target) uiAlpha = target;
                    } else {
                        uiAlpha -= UI_FADE_STEP;
                        if (uiAlpha < target) uiAlpha = target;
                    }
                    SetLayeredWindowAttributes(hWndUI, 0, (BYTE)uiAlpha, LWA_ALPHA);
                }

                if (!wantVisible && uiAlpha <= 0)
                {
                    ShowWindow(hWndUI, SW_HIDE);
                    uiShown = FALSE;
                }
            }
        }
        return 0;
    }
    case WM_SIZE:
    {
        glWindowWidth = LOWORD(lParam);
        glWindowHeight = HIWORD(lParam);
        if (glWindowWidth == 0) glWindowWidth = 1;
        if (glWindowHeight == 0) glWindowHeight = 1;
        glViewport(0, 0, glWindowWidth, glWindowHeight);
        UpdateProjection();

        // Keep hProbe2ToggleBtn pinned to the top-right corner as the
        // window is resized -- unlike Reset/Slow Motion/Walk's fixed
        // top-left offset (never needs adjusting), a top-right anchor's
        // absolute X position depends on the current window width, so it
        // has to be recomputed and moved every resize. No-op if the
        // button hasn't been created yet (shouldn't happen -- WM_CREATE
        // always runs first -- but SetWindowPos on a NULL HWND would
        // otherwise be undefined, so guard it anyway).
        if (hProbe2ToggleBtn)
        {
            SetWindowPos(hProbe2ToggleBtn, NULL,
                         glWindowWidth - PROBE2_TOGGLE_MARGIN_PX - PROBE2_TOGGLE_WIDTH_PX,
                         PROBE2_TOGGLE_MARGIN_PX + FPS_OVERLAY_RESERVED_HEIGHT_PX,
                         0, 0, SWP_NOSIZE | SWP_NOZORDER);
        }

        // Simulation mode's ground-collision data (segmentPointsWorld/
        // segmentThicknessWorld) is traced from a raster sized to
        // glWindowWidth/glWindowHeight AT THE MOMENT Simulation was
        // entered (see canvasToImage/canvas_bridge.c) -- resizing the
        // window afterward (maximizing, going fullscreen, etc.) changes
        // that same pixel<->world mapping for everything rendered live
        // (including the environment stroke's own on-screen thickness),
        // but does nothing to the already-traced data, which just sits
        // there representing the OLD window size. The environment line
        // then visibly drifts out of sync with what collision is still
        // testing against -- exactly the "looks flush windowed, floats
        // once maximized/zoomed" symptom this fixes. Re-tracing here is
        // the other moment (besides ID_MODE_SIMULATION's own entry-point
        // trace, see its comment) where the trace goes stale through no
        // drawing action of the user's -- only through the window itself
        // changing size while Simulation is already active.
        //
        // wParam == SIZE_MINIMIZED is excluded deliberately: Windows
        // reports a minimized window's client area as 0x0, which the
        // glWindowWidth/Height == 0 guards just above clamp to 1x1 purely
        // so glViewport/UpdateProjection don't divide by zero -- tracing
        // against that degenerate 1x1 raster would collapse the whole
        // environment down to nothing, silently deleting every segment
        // collision tests against (robot then free-falls forever, since
        // nothing is left to land on). Minimizing never actually changes
        // the size the user will resume looking at, so there's nothing
        // real to re-trace here anyway -- the next genuine resize (e.g.
        // restoring the window) retraces correctly on its own.
        if (appMode == APP_MODE_SIMULATION && canvas.segmentResultCount > 0
            && wParam != SIZE_MINIMIZED)
            RunTracePipeline();

        InvalidateRect(hWnd, NULL, TRUE);
        return 0;
    }
    case WM_MOUSEWHEEL:
    {
        short zDelta = GET_WHEEL_DELTA_WPARAM(wParam);

        // Simulation mode, hovering the hip or knee body circle WHILE
        // HOLDING SHIFT: rotate that joint instead of zooming -- see
        // simHoveredJoint/findHoveredJointSim's comments. Gated behind
        // Shift for the same reason Design > Robot mode's own hip/knee
        // scroll-rotate is (input.c's WM_MOUSEWHEEL): a plain scroll while
        // the cursor happens to be over a joint should still zoom, same as
        // scrolling anywhere else, rather than surprise-rotating a limb.
        // WM_MOUSEWHEEL packs the modifier keys held during the scroll
        // into the low word of wParam (MK_SHIFT), same as WM_MOUSEMOVE --
        // no GetAsyncKeyState polling needed (same trick input.c's own
        // version already uses).
        if (appMode == APP_MODE_SIMULATION && simHoveredJoint != -1 && (LOWORD(wParam) & MK_SHIFT))
        {
            float step = (zDelta > 0) ? SIMULATION_JOINT_ROTATE_STEP_DEG : -SIMULATION_JOINT_ROTATE_STEP_DEG;

            if (simHoveredJoint == 2)      app.robotScene.robot.hipAngle  += step;
            else if (simHoveredJoint == 3) app.robotScene.robot.kneeAngle += step;

            // Rotating a joint can push the limb hanging off it into the
            // ground if the robot's already resting on something -- same
            // upward-only correction slope response uses after its own
            // rotation, so a joint tweak mid-rest can never visibly sink
            // through the terrain.
            resolveUpwardIfPenetrating(hWnd, SIMULATION_SLOPE_CORRECTION_MAX);

            InvalidateRect(hWnd, NULL, FALSE);
            return 0;
        }

        // Simulation mode: zoom through sim_camera (shared with the robot
        // -- see UpdateProjection/sim_camera.h) instead of canvas.zoom, so
        // Design > Environment's own zoom is left untouched by anything
        // that happens while simulating.
        //
        // Design > Robot's own camera zoom (graphics.c's g_zoom) is
        // deliberately advanced by the SAME factor right alongside
        // sim_camera's, even though applyProjection ignores g_zoom entirely
        // while Simulation is active (see its own comment) -- so it has no
        // effect on anything drawn THIS frame. The point is purely for
        // later: g_zoom and sim_camera's zoom start at the same default
        // (1.0) and share the exact same MIN_ZOOM/MAX_ZOOM clamp (config.h),
        // so stepping both by the same ZOOM_STEP factor here keeps them in
        // exact lockstep -- meaning leaving Simulation and going back into
        // Design > Robot lands on the same zoom level you were just looking
        // at, instead of snapping back to whatever g_zoom was last left at
        // before you ever entered Simulation.
        if (appMode == APP_MODE_SIMULATION)
        {
            float simZoomFactor = (zDelta > 0) ? ZOOM_STEP : (1.0f / ZOOM_STEP);
            simCameraZoom(simZoomFactor);
            graphicsZoom(simZoomFactor);
        }
        else
        {
            if (zDelta > 0) canvas.zoom *= 0.9f;
            else            canvas.zoom *= 1.1f;
            if (canvas.zoom < 0.1f)  canvas.zoom = 0.1f;
            if (canvas.zoom > 10.0f) canvas.zoom = 10.0f;
        }

        UpdateProjection();

        // Defensive safety net, Simulation mode only: zoom itself never
        // legitimately moves the robot relative to the environment (the
        // shared sim_camera conversion robotPointToEnvWorld uses is exact
        // and zoom-independent by construction), but a real report of the
        // robot slipping through the ground specifically while scrolling
        // to zoom -- worst on an unstable, narrow-footprint resting pose
        // (e.g. standing on a short edge) -- kept showing up regardless of
        // the tunneling fixes already made elsewhere (advanceAutoGravity's
        // sub-stepping, dropActiveRobotToRest's open-air check). Rapid
        // WM_MOUSEWHEEL scrolling forces a synchronous UpdateWindow on
        // every single notch, which is exactly the kind of message-queue
        // pressure that can cause an ordinary settle/gravity tick landing
        // in between those notches to end up very slightly embedded
        // instead of cleanly resting, same root cause as the auto-gravity
        // stall case. Rather than keep chasing the exact interleaving,
        // this re-validates right after every zoom step and pushes back
        // out (same bounded, collision-confirmed correction the joint-
        // rotate and Left/Right handlers already use elsewhere) if the
        // robot is currently colliding at all -- a complete no-op whenever
        // it genuinely isn't, which is the overwhelming majority of zoom
        // events.
        if (appMode == APP_MODE_SIMULATION)
            resolveUpwardIfPenetrating(hWnd, SIMULATION_SLOPE_CORRECTION_MAX);

        InvalidateRect(hWnd, NULL, FALSE);
        UpdateWindow(hWnd);
        return 0;
    }
    case WM_KEYDOWN:
        // Ctrl+Z = Undo last stroke (same as the Environment panel's Undo button).
        if (wParam == 'Z' && (GetKeyState(VK_CONTROL) & 0x8000)
            && appMode == APP_MODE_DESIGN && designLayer == LAYER_ENVIRONMENT)
        {
            UndoLastStroke();
            return 0;
        }
    {
        // Ctrl+Numpad0: reset the view (zoom to 100%, pan back to center --
        // i.e. canvas.panX/panY or sim_camera's pan back to exactly 0, not
        // just whatever this session's camera happened to start at) -- this
        // WndProc handles both Design > Environment and Simulation (see
        // editorModeState.currentMode's routing in main.c's
        // WndProcShared -- Simulation forces EDITOR_MODE_ARCSPLINE so it
        // ends up here too), so branch the same way WM_MOUSEWHEEL/panning
        // above do: Simulation resets sim_camera, Environment resets
        // canvas.zoom/panX/panY. Same shortcut as Design > Robot's own
        // Ctrl+Numpad0 (see input.c's WM_KEYDOWN). Deliberately VK_NUMPAD0,
        // not the top-row '0' -- top-row digits are VK_0..VK_9 (0x30-0x39,
        // same as their ASCII codes) while the numpad digits are their own
        // separate VK_NUMPAD0..VK_NUMPAD9 (0x60-0x69) range, so this only
        // fires for the numpad key specifically.
        if (wParam == VK_NUMPAD0 && (GetAsyncKeyState(VK_CONTROL) & 0x8000))
        {
            if (appMode == APP_MODE_SIMULATION)
            {
                simCameraReset();
            }
            else
            {
                canvas.zoom = 1.0f;
                canvas.panX = 0.0f;
                canvas.panY = 0.0f;
            }

            UpdateProjection();
            InvalidateRect(hWnd, NULL, FALSE);
            return 0;
        }

        // Shift (pressed while actively drawing, i.e. mid-drag): kicks off
        // the straight-line constraint immediately, using WHEREVER the
        // cursor already is, instead of waiting for it to also move.
        // updateDrawingPoint (used here and by WM_MOUSEMOVE) is only ever
        // driven by WM_MOUSEMOVE otherwise -- and Windows does NOT send
        // WM_MOUSEMOVE just because a modifier key's state changed, only
        // on actual cursor movement -- so pressing Shift mid-stroke used to
        // visibly do nothing at all until the user nudged the mouse
        // afterward, even though the key registered fine. Explicitly
        // pulling the current cursor position here (GetCursorPos, then
        // ScreenToClient to match lParam's coordinate space) and running
        // the exact same logic closes that gap: the line preview appears
        // the instant Shift goes down, full stop.
        //
        // Guarded by the lParam bit 30 auto-repeat check (same reasoning
        // as Shift+G below) so holding Shift down doesn't re-run this on
        // every OS key-repeat tick -- harmless if it did (idempotent), just
        // wasted work.
        if (wParam == VK_SHIFT && drawing && appMode != APP_MODE_SIMULATION)
        {
            BOOL isAutoRepeat = (lParam & 0x40000000) != 0;
            if (!isAutoRepeat)
            {
                POINT pt;
                GetCursorPos(&pt);
                ScreenToClient(hWnd, &pt);
                updateDrawingPoint(hWnd, pt.x, pt.y, TRUE, (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0);
            }
            return 0;
        }

        // Shift+G: toggles "auto gravity" on/off (Simulation mode only) --
        // starts/stops AUTO_GRAVITY_TIMER_ID, which calls applyGravityStep
        // on its own every SIMULATION_AUTO_GRAVITY_INTERVAL_MS (config.h)
        // without needing G held down. Checked BEFORE the plain-G branch
        // below, since Shift+G would otherwise also satisfy `wParam == 'G'`
        // (Shift is a separate modifier key, not part of wParam here).
        //
        // Unlike plain G (which WANTS Windows' auto-repeat -- see below),
        // a toggle has to ignore it: lParam bit 30 is set on every repeated
        // WM_KEYDOWN while a key is held, clear only on the very first one,
        // so holding Shift+G down would otherwise flip autoGravityActive
        // rapidly on/off/on/... instead of toggling once per actual press.
        if (wParam == 'G' && appMode == APP_MODE_SIMULATION && (GetAsyncKeyState(VK_SHIFT) & 0x8000))
        {
            BOOL isAutoRepeat = (lParam & 0x40000000) != 0;

            if (!isAutoRepeat)
            {
                autoGravityActive = !autoGravityActive;
                autoGravityVelocity = 0.0f; // (re)start every toggle from rest
                autoGravityLastTickTime = GetTickCount(); // avoid a huge first elapsed-time jump

                if (autoGravityActive)
                    SetTimer(hWnd, AUTO_GRAVITY_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);
                else
                {
                    KillTimer(hWnd, AUTO_GRAVITY_TIMER_ID);

                    // Also clear a still-active postRotateSettleActive here --
                    // it can only ever have been kicked off while
                    // autoGravityActive was on (every kickoff site requires
                    // it), and advancePostRotateSettle bails out for as long
                    // as autoGravityActive stays on too, so a session started
                    // by, say, an E/Q release earlier just sits there inert
                    // and TRUE, never reaching its own convergence check that
                    // would otherwise clear it. Turning gravity off right here
                    // removes the block on advancePostRotateSettle (its guard
                    // is "off unless autoGravityActive", not "off forever"),
                    // which un-inerts that leftover TRUE and lets it start
                    // actually driving applyGravityStep again on the very next
                    // WM_MOUSEMOVE -- exactly the "moving the cursor drifts
                    // Rocky down with Auto Gravity off" report this was all
                    // meant to stop. Explicitly zeroing it here, the moment
                    // gravity turns off, is what actually closes that gap.
                    postRotateSettleActive = FALSE;
                }

                // Kick off the bottom-left "AUTO GRAVITY ON/OFF" toast --
                // canvasRenderFrame reads these two each frame to compute
                // its fade. gravityToastOn mirrors the state we just
                // switched TO, not the one we switched from.
                gravityToastOn = autoGravityActive;
                gravityToastStartTick = GetTickCount();
                InvalidateRect(hWnd, NULL, FALSE);
            }

            return 0;
        }

        // G ("gravity"): Simulation mode only -- nudges the whole robot
        // straight down by SIMULATION_GRAVITY_STEP (config.h) via
        // applyGravityStep, same translateRobot the whole-robot drag uses,
        // so it's a pure rigid move that doesn't touch the pose. "Holding G
        // repeats it" is just Windows' own WM_KEYDOWN auto-repeat firing
        // this same branch again and again for as long as the key stays
        // down -- no separate timer or held-key tracking needed here
        // (unlike Shift+G's auto-gravity above, which has to keep going
        // even after the key is released).
        if (wParam == 'G' && appMode == APP_MODE_SIMULATION)
        {
            // Same notch for every weight -- mass doesn't change how fast
            // things fall (see advanceAutoGravity).
            applyGravityStep(hWnd, SIMULATION_GRAVITY_STEP);
            return 0;
        }

        // Shift+W: toggles the scripted gait cycle ("Walk") on/off --
        // same structure as Shift+G's auto-gravity toggle just above
        // (own timer, own auto-repeat guard, own toast), independent of
        // it -- gravity and Walk can each be on or off regardless of the
        // other. Captures gaitBaseline (the pose the cycle swings around)
        // fresh every time it's switched ON, so re-toggling Walk after
        // posing the robot differently restarts the cycle around the NEW
        // pose rather than snapping back to whatever it was the first
        // time Walk was turned on this session.
        if (wParam == 'W' && appMode == APP_MODE_SIMULATION && (GetAsyncKeyState(VK_SHIFT) & 0x8000))
        {
            BOOL isAutoRepeat = (lParam & 0x40000000) != 0;

            if (!isAutoRepeat)
                ToggleGait(hWnd);

            return 0;
        }

        // E / Q (no modifier): rotate Rocky's own knee joint (kneeAngle) in
        // Simulation mode, without needing to hover its body circle first
        // (unlike WM_MOUSEWHEEL's Shift+scroll-over-the-joint gesture
        // above -- simHoveredJoint/findHoveredJointSim only ever track
        // Semni's hip/knee circles, and Rocky has no separate hip stage to
        // hover anyway, just this one knee->foot joint hanging off the
        // rectangle). Deliberately plain (no Shift, unlike Shift+G/Shift+W
        // above) per explicit user request. Only acts while Rocky is the
        // active robot kind, same "harmlessly does nothing for the other
        // kinds" convention as Semni-only features elsewhere in this file.
        //
        // rotatePoint (geometry.c) is the standard CCW-for-positive-angle
        // matrix in this app's Y-up world space, so clockwise on screen is
        // the NEGATIVE direction: E (clockwise) subtracts the step, Q
        // (counter-clockwise) adds it -- same step size
        // (SIMULATION_JOINT_ROTATE_STEP_DEG) as the scroll-wheel joint
        // rotate, and same "let Windows' own auto-repeat handle holding
        // the key down" treatment as plain G above (a continuous rotate
        // needs no repeat/timer bookkeeping here).
        if ((wParam == 'E' || wParam == 'Q') && appMode == APP_MODE_SIMULATION && app.robotScene.activeKind == ROBOT_KIND_ROCKY)
        {
            // E/Q's entire job is bending the knee -- with the leg removed
            // (ID_ROCKY_TOGGLE_LEG_BUTTON) there's no visible/collidable
            // knee left to bend, so do nothing at all rather than letting
            // everything below still run on an invisible leg. It used to:
            // rotate kneeAngle (harmlessly, since nothing draws or collides
            // with it -- see advanceRockySettle's own !r->legHidden comment
            // on Probe 2), then unconditionally call dropActiveRobotToRest()
            // and kick off the postRotateSettleActive timer regardless --
            // dropActiveRobotToRest applies its FULL correction in one
            // synchronous jump (that's deliberate for a real knee rotation,
            // to avoid a two-frame "jump then land" -- see its own call
            // site's comment), so on a legless Rocky a single E/Q press
            // read as the whole rectangle instantly teleporting to the
            // ground, and the settle timer it started afterward then kept
            // running on top of that. Bailing out before any of it -- no
            // kneeAngle change, no drop, no settle kickoff -- makes E/Q a
            // true no-op for a legless Rocky, exactly like the button being
            // gone in the first place.
            if (app.robotScene.rocky.legHidden)
                return 0;

            // Used to ONLY rotate the knee joint with nothing else
            // touching the robot -- no push, no drop, no settle -- because
            // an earlier version ran dropActiveRobotToRest's full snap-to-
            // rest correction unconditionally after every press, which read
            // as the whole rectangle teleporting from a plain knee tap. By
            // explicit request this now interacts with the ground again,
            // but through the same small, bounded, collision-confirmed push
            // WM_MOUSEWHEEL's own Shift+scroll joint-rotate and the plain
            // Left/Right whole-body rotate both already use
            // (resolveUpwardIfPenetrating) -- not the old unconditional
            // snap, so bending the knee into the ground nudges the leg back
            // out just far enough to clear it instead of jumping the whole
            // robot.
            // Only the INITIAL press (not a Windows auto-repeat) applies a
            // discrete SIMULATION_JOINT_ROTATE_STEP_DEG nudge here -- a
            // plain tap's feel is completely unchanged from before. A
            // genuine hold's continuous rotation is now entirely
            // ROCKY_KNEE_HOLD_TIMER_ID/advanceRockyKneeHold's job instead
            // (started just below): that driver scales kneeAngle by real
            // elapsed time every tick, which is what actually fixed the
            // "holding feels jerky/chunky" report -- see its own comment
            // for the full reasoning on why relying on the OS's own
            // auto-repeat cadence for a smooth hold never worked well.
            // Auto-repeat events are otherwise ignored entirely here now
            // (no kneeAngle change, no advance* calls, no re-arm) since
            // the dedicated timer already owns all of that for as long as
            // the key stays down.
            BOOL isAutoRepeatEQ = (lParam & 0x40000000) != 0;
            if (isAutoRepeatEQ)
            {
                // Defensive only -- should already be TRUE from this key's
                // own initial press just below, but costs nothing to make
                // sure, in case an initial press was ever somehow missed
                // (e.g. focus changed mid-press) and only repeats arrived.
                if (wParam == 'E') rockyKneeHoldE = TRUE; else rockyKneeHoldQ = TRUE;
                return 0;
            }

            Rocky* r = &app.robotScene.rocky;
            float step = (wParam == 'E') ? -SIMULATION_JOINT_ROTATE_STEP_DEG : SIMULATION_JOINT_ROTATE_STEP_DEG;
            r->kneeAngle += step;

            resolveUpwardIfPenetrating(hWnd, SIMULATION_SLOPE_CORRECTION_MAX);

            // Starts (or, if somehow already running, just re-confirms)
            // the dedicated real-time-driven knee-hold timer -- see its
            // own declaration and advanceRockyKneeHold's comment. Both
            // this key's own held flag AND its hold-clock/revive-clock
            // timestamps are (re)initialized to right now on every fresh
            // press, not just the very first one ever -- otherwise a
            // second E press long after the first would see a huge
            // elapsed-time gap on its very first advanceRockyKneeHold tick
            // and try to fold all of that into one jump (clamped by
            // SIMULATION_JOINT_ROTATE_HOLD_MAX_DT_MS, but still not the
            // clean "start of a hold" it should read as).
            if (wParam == 'E') rockyKneeHoldE = TRUE; else rockyKneeHoldQ = TRUE;
            rockyKneeHoldLastTickTime = GetTickCount();
            rockyEQHoldLastReviveTick = rockyKneeHoldLastTickTime;
            SetTimer(hWnd, ROCKY_KNEE_HOLD_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);

            // Same "let the initial press react immediately rather than
            // waiting for the first timer tick" reasoning this block
            // always had -- a single tap should still feel instant.
            advanceAutoGravity(hWnd);
            advancePostRotateSettle(hWnd);
            advanceGait(hWnd);

            InvalidateRect(hWnd, NULL, FALSE);
            UpdateWindow(hWnd);
            return 0;
        }

        // Plain C (no modifier): toggles the pivot/non-pivot contact dot
        // overlay -- see drawSimulationLiveContactDots' own comment for
        // exactly what it draws and why. Not gated to any one robot kind
        // (unlike E/Q) since it's just as useful for Semni/Stilo.
        // Semni: Q/E rotates the hip, Shift+Q/Shift+E rotates the knee --
        // see advanceSemniJointHold. wParam is still 'Q'/'E' with Shift
        // held (Shift doesn't change the virtual-key code).
        if ((wParam == 'E' || wParam == 'Q') && appMode == APP_MODE_SIMULATION && app.robotScene.activeKind == ROBOT_KIND_SEMNI)
        {
            BOOL isAutoRepeat = (lParam & 0x40000000) != 0;
            if (wParam == 'E') semniJointHoldE = TRUE; else semniJointHoldQ = TRUE;
            if (isAutoRepeat)
                return 0; // the hold timer is already rotating -- just keep the flag armed

            float step = (wParam == 'E') ? -SIMULATION_JOINT_ROTATE_STEP_DEG : SIMULATION_JOINT_ROTATE_STEP_DEG;
            rotateSemniJoint(hWnd, step);

            semniJointHoldLastTickTime = GetTickCount();
            rockyEQHoldLastReviveTick = semniJointHoldLastTickTime;
            SetTimer(hWnd, SEMNI_JOINT_HOLD_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);

            advanceAutoGravity(hWnd);
            advancePostRotateSettle(hWnd);
            advanceGait(hWnd);

            InvalidateRect(hWnd, NULL, FALSE);
            UpdateWindow(hWnd);
            return 0;
        }

        if (wParam == 'C' && appMode == APP_MODE_SIMULATION)
        {
            showContactDebug = !showContactDebug;
            SIM_LOG("[CONTACT] overlay toggled %s (activeKind=%d)\n",
                   showContactDebug ? "ON" : "off", app.robotScene.activeKind);
            InvalidateRect(hWnd, NULL, FALSE);
            return 0;
        }

        // Plain Left/Right (no Shift): rotates the WHOLE robot, not any
        // one joint -- joints are a Shift+scroll-over-the-hovered-circle
        // action instead (WM_MOUSEWHEEL above), gated behind Shift
        // specifically so a plain scroll still zooms (see that branch's
        // own comment) -- unrelated to this. Same angle field and same
        // per-press step Design > Robot mode's own Left/Right already
        // nudges (input.c's WM_KEYDOWN, `angle += 2.0f` / `-= 2.0f`),
        // same Left = positive / Right = negative sign convention too,
        // so a press feels identical between the two editors. Windows'
        // own key-repeat re-fires this while held, same as plain G
        // above, so no repeat bookkeeping needed.
        //
        // Dispatches on activeKind now -- this used to unconditionally
        // write app.robotScene.robot.angle (Semni's own field) no matter
        // which kind was actually active, so a real report showed Left/
        // Right silently doing nothing visible while Rocky or Stilo was
        // selected: it WAS rotating something, just the invisible,
        // inactive Semni sitting behind it, not the robot actually on
        // screen. Every other kind-specific action in this file (E/Q,
        // robotCollidesWithEnvironment, applyGravityStep's settle, etc.)
        // already reads app.robotScene.activeKind for exactly this
        // reason -- this was the one plain-rotate branch that never got
        // the same treatment.
        if ((wParam == VK_LEFT || wParam == VK_RIGHT) && appMode == APP_MODE_SIMULATION)
        {
            // Rotation HUD: show it (at full opacity, no fade) for as long
            // as the key stays down -- Windows auto-repeat re-fires
            // WM_KEYDOWN every press-and-hold, so this just re-stamps TRUE
            // each time rather than needing any "first press" detection.
            // See rotateKeyHeld's own comment for the rest of the mechanics.
            rotateKeyHeld = TRUE;

            float step = (wParam == VK_LEFT) ? SIMULATION_WHOLE_BODY_ROTATE_STEP_DEG : -SIMULATION_WHOLE_BODY_ROTATE_STEP_DEG;

            // Sub-stepped (see SIMULATION_WHOLE_BODY_ROTATE_SUBSTEP_DEG's
            // own comment for why a single big jump can tunnel a far
            // corner clean through the ground line when resting on a
            // narrow edge): walk the full press's rotation in several
            // smaller pieces, re-checking/correcting after each one
            // instead of only once at the very end.
            float remaining = step;
            while (remaining != 0.0f)
            {
                float sub = SIMULATION_WHOLE_BODY_ROTATE_SUBSTEP_DEG;
                if (sub > fabsf(remaining)) sub = fabsf(remaining);
                if (remaining < 0.0f) sub = -sub;

                switch (app.robotScene.activeKind)
                {
                    case ROBOT_KIND_ROCKY:
                        app.robotScene.rocky.angle += sub;
                        break;
                    case ROBOT_KIND_STILO:
                        app.robotScene.stilo.angle += sub;
                        break;
                    case ROBOT_KIND_SEMNI:
                    default:
                        app.robotScene.robot.angle += sub;
                        break;
                }

                // Same re-settle WM_MOUSEWHEEL's joint-rotate branch and
                // slope response both use -- keeps a rotate from visibly
                // sinking the robot into ground it's already resting on.
                // Already reads activeKind internally
                // (robotCollidesWithEnvironment's own switch), so no
                // change needed here to act on the right kind. Called
                // after EVERY sub-step (not just once at the end) so a
                // corner sweeping toward the ground is caught and pushed
                // back up as soon as it first touches, rather than only
                // after the whole press has already been applied.
                //
                // Skipped for a legless Rocky specifically: with no leg
                // holding the rectangle up off the ground, its own edge is
                // what's normally resting flush against it, so this
                // center-spin rotation routinely embeds one corner every
                // single press -- pushing that corner back up here, only
                // for WM_KEYUP's own settle pass to immediately pull the
                // whole body back down again to find the new resting
                // angle, is what actually produced the visible "one tap
                // and the rectangle drops" a real report described (see
                // WM_KEYUP's own comment on that settle pass, unconditional
                // by explicit request). A legged Rocky doesn't have this
                // problem -- it's normally resting on the foot/knee, well
                // clear of the rectangle's own corners, so this almost
                // never fires for it anyway. Leaving the corner embedded
                // here instead just lets applyGravityStep's own contact
                // search (inside that same settle pass) resolve it in one
                // direction -- back up to the true contact point -- rather
                // than pushing up and then immediately dropping back down.
                //
                // Also skipped for a leg-only Rocky (bodyHidden, leg still
                // visible): same reported symptom ("rotating it with
                // arrows, steps the gravity"), same fix as the legless
                // case, by explicit request -- arrow-key rotation for this
                // configuration should just rotate, nothing else.
                if (!(app.robotScene.activeKind == ROBOT_KIND_ROCKY
                      && (app.robotScene.rocky.legHidden || app.robotScene.rocky.bodyHidden)))
                    resolveUpwardIfPenetrating(hWnd, SIMULATION_SLOPE_CORRECTION_MAX);

                remaining -= sub;
            }

            InvalidateRect(hWnd, NULL, FALSE);
            return 0;
        }

        return 0;
    }
    case WM_KEYUP:
    {
        if (wParam == VK_SHIFT && drawing)
            SetCursor(LoadCursor(NULL, IDC_ARROW)); // Shift released mid-stroke: cursor back
        // Kick off a topple the instant a manual whole-body rotate is
        // released, in case it left the robot resting somewhere no
        // longer actually stable (or lifted clean off the ground) --
        // see advancePostRotateSettle's own comment for the full
        // reasoning. Re-arms rockySettleConverged/both step sizes first,
        // same fix E/Q's own knee-push re-arm above uses and for the
        // same reason: without it, a robot that had already fully
        // settled before this rotate would leave rockySettleConverged
        // still TRUE, and advanceRockySettle would just no-op forever --
        // the topple would never actually move anything.
        if ((wParam == VK_LEFT || wParam == VK_RIGHT) && appMode == APP_MODE_SIMULATION)
        {
            // Rotation HUD: the key's up, so stop showing it live and start
            // the same hold-then-fade countdown the gravity/Walk toasts use
            // (see rotateKeyHeld's own comment) -- InvalidateRect right here
            // rather than waiting for the settle timer's own next tick, so
            // the fade visibly starts on this exact frame instead of
            // whatever the first AUTO_GRAVITY_TIMER_ID tick happens to be.
            rotateKeyHeld = FALSE;
            rotateToastStartTick = GetTickCount();
            InvalidateRect(hWnd, NULL, FALSE);

            // Skipped entirely for a legless Rocky: this settle pass is
            // exactly what a real report showed as "pressing left/right
            // once moves the robot down" -- postRotateSettleActive's own
            // driver (advancePostRotateSettle) calls applyGravityStep --
            // a REAL gravity step, translating the robot down first and
            // only correcting back if that step happened to land -- every
            // single tick for as long as it takes to reconverge, and with
            // no leg (Probe 2 skipped, Probe 1 alone driving convergence,
            // no push-up left to undo now that WM_KEYDOWN's own corner-fix
            // is skipped too -- see its own comment just above) that takes
            // long enough to read as a real, visible fall rather than an
            // imperceptible snap. A legged Rocky keeps this exactly as
            // before -- it's normally resting on the foot/knee already,
            // so this pass is nearly always a no-op for it, and removing
            // it there was never what was reported as broken.
            //
            // Also skipped for a leg-only Rocky (bodyHidden): same real
            // gravity step, same visible "rotating it steps the gravity"
            // symptom, same fix, by explicit request -- arrow-key rotation
            // here should just rotate, no automatic settle/drop tacked on.
            // Also now requires autoGravityActive, same reasoning and
            // same explicit request as the Simulation-entry embed
            // correction above (see its own comment): resolving
            // whatever interpenetration a rotate just caused is a
            // gravity-style settle exactly like that one (same
            // applyGravityStep-per-tick driver), so it should be just
            // as silent with Auto Gravity off -- a rotate that leaves
            // the robot clipping the ground just stays clipping until
            // gravity is turned on, same as any other overlap now.
            if (!(app.robotScene.activeKind == ROBOT_KIND_ROCKY
                  && (app.robotScene.rocky.legHidden || app.robotScene.rocky.bodyHidden))
                && autoGravityActive)
            {
                SIM_LOG("[SETTLE] VK_LEFT/RIGHT keyup reset fired -- resetting probe step sizes and anti-oscillation state\n");
                rockySettleConverged = FALSE;
                rockyKneeSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
                semniHipSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
                rockyBodySettleStep = SIMULATION_BODY_SETTLE_STEP_DEG;
                rockyBothProbesCommittedStreak = 0;
                rockyKneeSettleGrowthStreak = 0;
                rockyBodySettleGrowthStreak = 0;
                rockyPivotSide = 0;
                rockyBodyLastCommitDir = 0;
                rockyToppleLastPivotCategory = 0;
                rockyBodyReversalBlockedStreak = 0;
                rockyKneeSettleSuppressed = FALSE; // whole-body rotate: nothing else drives kneeAngle, Probe 2 is safe here

                postRotateSettleActive = TRUE;
                SetTimer(hWnd, AUTO_GRAVITY_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);
            }
        }

        // A single E/Q tap (or a held one, via Windows auto-repeat
        // re-arming rockyKneeSettleSuppressed on every WM_KEYDOWN) leaves
        // Probe 2 (knee-bending) suppressed for the whole settle session
        // that follows it -- see rockyKneeSettleSuppressed's own comment.
        // Nothing else ever clears it back to FALSE for Rocky: the
        // "normal" path (advancePostRotateSettle's atRest branch, right
        // above) can only fire once BOTH rockyKneeSettleStep and
        // rockyBodySettleStep have shrunk below
        // SIMULATION_LEG_SETTLE_MIN_STEP_DEG, but Probe 2's own step-
        // shrinking code lives entirely inside the block this suppression
        // skips -- so while suppressed, rockyKneeSettleStep never moves,
        // convergence can never happen, and un-suppression (which only
        // happens inside that same atRest branch) can't either. That's a
        // permanent deadlock: after just one E/Q tap, Probe 2 stays dead
        // for the rest of the session, and if closing some residual gap
        // genuinely needed knee bending (not just the body rotate Probe 1
        // still runs) rather than a plain vertical drop, the robot is
        // left visibly floating with nothing left able to fix it. This is
        // what a real report described as "i only pressed e once and the
        // robot is already floating". Releasing the key is the real
        // signal that the user is done driving kneeAngle by hand, so
        // mirror VK_LEFT/VK_RIGHT's own keyup handling just above and
        // clear the suppression here.
        //
        // By explicit request (same as WM_KEYDOWN's own
        // resolveUpwardIfPenetrating above): actually kick off the settle
        // pass here too now, same re-arm/postRotateSettleActive/SetTimer
        // as VK_LEFT/VK_RIGHT's own keyup just above, gated the same way
        // on autoGravityActive -- so releasing E/Q, like releasing a
        // whole-body rotate, lets the leg settle the rest of the way onto
        // whatever it's now resting against, but stays a true no-op with
        // Auto Gravity off. Skipped for a legless Rocky same as
        // WM_KEYDOWN's own early-out (there's nothing left to settle), but
        // NOT skipped for a leg-only Rocky (bodyHidden) -- unlike the
        // whole-body Left/Right rotate, bending just the knee never moves
        // the (invisible) rectangle's corners, so the corner-embedding
        // problem that skip exists for doesn't apply here.
        if ((wParam == 'E' || wParam == 'Q') && appMode == APP_MODE_SIMULATION && app.robotScene.activeKind == ROBOT_KIND_ROCKY)
        {
            // This key is no longer held -- stop advanceRockyKneeHold from
            // continuing to rotate on its behalf. Only kill the dedicated
            // timer once NEITHER key is held anymore (the other one may
            // still be down, e.g. releasing E while Q is still held should
            // keep Q's own rotation going uninterrupted).
            if (wParam == 'E') rockyKneeHoldE = FALSE; else rockyKneeHoldQ = FALSE;
            if (!rockyKneeHoldE && !rockyKneeHoldQ)
                KillTimer(hWnd, ROCKY_KNEE_HOLD_TIMER_ID);

            rockyKneeSettleSuppressed = FALSE;

            if (!app.robotScene.rocky.legHidden && autoGravityActive)
            {
                // Narrowed by explicit diagnosis: this used to reset ALL
                // settle state on every E/Q release, including Probe 1's
                // (body pivot) own DIRECTION/IDENTITY memory --
                // rockyPivotSide, rockyBodyLastCommitDir,
                // rockyToppleLastPivotCategory -- even though E/Q only
                // ever drives the KNEE (Probe 2). A real report showed
                // bodyAngle visibly oscillating during a run of ordinary
                // knee taps, traced via the printf below to exactly
                // this: every E/Q release was wiping Probe 1's reversal
                // guard, so the very next tick's body-pivot commit
                // sailed right through a guard that had just blocked
                // the same reversal four ticks in a row.
                //
                // Tried dropping the rockyBodySettleStep reset too, not
                // just the three identity/direction variables above --
                // that broke a DIFFERENT thing: rockyBodySettleStep only
                // ever grows back via SIMULATION_LEG_SETTLE_GROWTH_STREAK
                // consecutive CLEAN commits (see that check above), which
                // a run of reversal-guard blocks can never accumulate --
                // each block only shrinks it, never grows it. Once it
                // shrinks below SIMULATION_LEG_SETTLE_MIN_STEP_DEG, Probe
                // 2's entire block (further up) stops being entered at
                // all, so nothing can ever revive it again on its own,
                // and the very next convergence check (right below this
                // function) then falsely declares the settle DONE while
                // the body is visibly still floating -- exactly the "now
                // the rectangle doesn't fall down" a real report showed
                // once this reset was dropped. So rockyBodySettleStep
                // (and its own growth streak) IS still revived here, same
                // as before -- it's the three IDENTITY variables that
                // stay untouched, since those are what caused the
                // guard-bypass, not the step size being large again (a
                // large step with the guard still intact just gets
                // reblocked and reshrunk correctly, no bypass).
                SIM_LOG("[SETTLE] E/Q keyup reset fired -- reviving knee+body probe step sizes, leaving body pivot direction/identity memory untouched\n");
                reviveRockyBodyProbeStepSizes(hWnd);
            }
        }
        if ((wParam == 'E' || wParam == 'Q') && appMode == APP_MODE_SIMULATION && app.robotScene.activeKind == ROBOT_KIND_SEMNI)
        {
            if (wParam == 'E') semniJointHoldE = FALSE; else semniJointHoldQ = FALSE;
            if (!semniJointHoldE && !semniJointHoldQ)
                KillTimer(hWnd, SEMNI_JOINT_HOLD_TIMER_ID);

            // Same as Rocky's E/Q keyup: let Probe 2/2 settle the new pose
            // (only with Auto Gravity on, like Rocky).
            if (autoGravityActive)
            {
                SIM_LOG("[SETTLE] Semni Q/E keyup reset fired -- reviving knee/hip + body probe step sizes\n");
                reviveRockyBodyProbeStepSizes(hWnd);
            }
        }
        return 0;
    }
    case WM_CAPTURECHANGED:
        // Mouse capture taken away mid-pan (Alt+Tab, a dialog...): stop
        // panning, otherwise the view keeps following the mouse with no
        // button held.
        if ((HWND)lParam != hWnd) panning = FALSE;
        break;

    case WM_SETCURSOR:
    {
        // Hide the cursor while drawing a Shift straight line, so it
        // doesn't sit on top of the line being placed.
        if (drawing && LOWORD(lParam) == HTCLIENT && (GetKeyState(VK_SHIFT) & 0x8000))
        {
            SetCursor(NULL);
            return TRUE;
        }
        // Middle-mouse pan (WM_MBUTTONDOWN/UP, further down) works
        // identically in both Design and Simulation mode -- `panning` is
        // set the instant the middle button goes down and cleared the
        // instant it comes back up, so it's an exact mirror of "is the
        // middle button currently held" with nothing mode-specific about
        // it. Show the hand cursor for as long as that's true, in every
        // mode, checked first so it always wins over whatever cursor the
        // mode-specific logic below would otherwise pick (e.g. hovering
        // the robot in Simulation mode while panning shouldn't still show
        // the move-robot cursor).
        if (panning && LOWORD(lParam) == HTCLIENT)
        {
            SetCursor(LoadCursor(NULL, IDC_HAND));
            return TRUE;
        }

        // Simulation mode: dragging the robot's own body moves it (see
        // WM_LBUTTONDOWN/WM_MOUSEMOVE below) -- a 4-way move cursor
        // signals that specifically while hovering over the robot
        // (app.hoveringRobotSim, kept up to date every WM_MOUSEMOVE),
        // rather than implying anywhere on the canvas is draggable.
        // Outside Simulation mode, off the robot, or over the window's
        // border/caption/etc (hit-test isn't HTCLIENT), fall through to
        // the default arrow.
        if (appMode == APP_MODE_SIMULATION && LOWORD(lParam) == HTCLIENT && app.hoveringRobotSim)
        {
            SetCursor(LoadCursor(NULL, IDC_SIZEALL));
            return TRUE;
        }
        break;
    }
    case WM_LBUTTONDOWN:
    {
        // Simulation mode: no new environment strokes -- a left-click
        // drag started INSIDE the robot's own body instead grabs and
        // moves it, so the user can set its starting position within the
        // scene. A click elsewhere on the canvas (off the robot) does
        // nothing, rather than falling through to stroke-drawing.
        if (appMode == APP_MODE_SIMULATION)
        {
            float wx, wy;
            screenToGL(hWnd, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam), &wx, &wy);
            if (isPointInsideActiveRobotBody(wx, wy))
            {
                app.draggingRobotSim = TRUE;
                dragRobotLastWX = wx;
                dragRobotLastWY = wy;
                SetCapture(hWnd);
            }
            return 0;
        }

        // Robot layer is a blank placeholder for now (a separate project
        // will live here later) - no drawing while it's active.
        if (appMode == APP_MODE_DESIGN && designLayer == LAYER_ROBOT) return 0;
        if (canvas.strokeCount >= MAX_STROKES) return 0;
        drawing = TRUE;
        strokeStarts[canvas.strokeCount] = canvas.pointCount;
        strokeColor[canvas.strokeCount] = brushColor;
        strokeThickness[canvas.strokeCount] = thickness;
        strokeLayer[canvas.strokeCount] = designLayer;
        canvas.strokeCount++;

        float x = (float)GET_X_LPARAM(lParam);
        float y = (float)GET_Y_LPARAM(lParam);
        float aspect = (float)glWindowWidth / (float)glWindowHeight;
        float nx, ny;
        if (aspect >= 1.0f) {
		    nx = ((2.0f * x / glWindowWidth) - 1.0f) * aspect * canvas.zoom;
		    ny = (1.0f - (2.0f * y / glWindowHeight)) * canvas.zoom;
		} else {
		    nx = ((2.0f * x / glWindowWidth) - 1.0f) * canvas.zoom;
		    ny = (1.0f - (2.0f * y / glWindowHeight)) * (1.0f / aspect) * canvas.zoom;
		}
		nx += canvas.panX;   // NEW
		ny += canvas.panY;   // NEW

		// NEW: if the cursor was hovering near an existing stroke's
		// endpoint, snap this new stroke's first point exactly onto it
		// instead of the raw cursor position - lets straight lines be
		// chained end-to-end into a connected polyline.
		if (snapEndpointAvailable)
		{
		    nx = snapEndpointX;
		    ny = snapEndpointY;
		    snapEndpointAvailable = FALSE;
		}

		if (canvas.pointCount < MAX_POINTS - 1) {
		    points[canvas.pointCount++] = nx;
		    points[canvas.pointCount++] = ny;
		}
        return 0;
    }
    case WM_LBUTTONUP:
        // Environment autosave: a stroke was just finished drawing (see
        // WM_LBUTTONDOWN -- `drawing` can only ever be TRUE here for an
        // Environment-layer stroke, since Simulation mode and the Robot
        // layer both return early there before it's ever set). Persist the
        // drawing right away so it's never more than one stroke stale if
        // the app is closed unexpectedly. Checked BEFORE `drawing` is
        // reset below, since that's what this check is testing.
        if (drawing)
        {
            saveEnvironmentAutosave();
            SetCursor(LoadCursor(NULL, IDC_ARROW)); // show it again after a Shift line
        }
        drawing = FALSE;
        shiftHoldActive  = FALSE;   // NEW: end any in-progress dwell-snap tracking
        shiftHoldSnapped = FALSE;   // NEW
        if (app.draggingRobotSim)
        {
            app.draggingRobotSim = FALSE;

            // Auto gravity was silently paused for the duration of the drag
            // (see advanceAutoGravity's app.draggingRobotSim check) -- pick
            // back up from rest now that the robot's been let go, same as a
            // fresh Shift+G toggle-on or a landing, rather than resuming
            // with whatever velocity had built up before the drag started
            // (the robot may now be somewhere completely different) or
            // jumping by however long the drag itself lasted.
            if (autoGravityActive)
            {
                autoGravityVelocity = 0.0f;
                autoGravityLastTickTime = GetTickCount();
            }

            // Kick off a settle pass on release -- but ONLY if the robot is
            // already touching/overlapping the ground exactly where it was
            // just dropped, same mechanism as VK_LEFT/RIGHT's own WM_KEYUP
            // kickoff below (see advancePostRotateSettle's own comment for
            // the full reasoning). Without this at all, a plain drag-and-
            // drop with Auto Gravity OFF called applyGravityStep exactly
            // zero times, which meant advanceRockySettle (Probe 2/Probe 1,
            // Rocky's knee-bend and body-pivot) never ran even once -- the
            // robot just stayed wherever the mouse let go of it, floating
            // parts and all, with nothing left able to fix it short of
            // manually turning Auto Gravity on or pressing G. That's what a
            // real report showed: Rocky dropped in its home pose, resting
            // on the knee circle alone with the foot circle visibly hanging
            // in mid-air and not a single [SETTLE] line ever printed --
            // not a bug in either probe's own search, just neither one ever
            // getting a chance to run.
            //
            // The robotCollidesWithEnvironment() guard matters just as much
            // as the kickoff itself: this timer runs the EXACT same driver
            // Auto Gravity's own timer does (applyGravityStep every tick,
            // which falls the robot however far it takes to land) -- an
            // earlier version of this fix started it unconditionally on
            // every release, which meant releasing the robot ANYWHERE, even
            // high up in the air, made it fall all the way down on its own,
            // Auto Gravity OFF or not. That defeats the whole point of the
            // toggle. Only a pose that's ALREADY touching something needs
            // Probe 2/Probe 1 at all -- that's the entire "home position,
            // knee down but foot floating" scenario this was meant to fix
            // -- a robot released genuinely airborne is supposed to just
            // hang there until the user turns gravity on or presses G,
            // same as it always has.
            // Also now requires autoGravityActive -- same explicit
            // request as the other two postRotateSettleActive kickoffs
            // (Simulation-entry embed correction, VK_LEFT/RIGHT rotate,
            // both above): a hand-released robot left overlapping the
            // ground now just stays overlapping until gravity is turned
            // on, instead of quietly correcting itself (visibly, since
            // this same driver is also nudged forward by every
            // WM_MOUSEMOVE) with Auto Gravity off.
            if (robotCollidesWithEnvironment() && autoGravityActive)
            {
                // Re-arms the convergence flag and both step sizes first,
                // same reason the other two kickoffs do it: a robot that
                // had already fully settled before this drag would
                // otherwise leave rockySettleConverged still TRUE and the
                // driver would just no-op forever. rockyKneeSettleSuppressed
                // is cleared too -- nothing else is driving kneeAngle right
                // now, so Probe 2 is safe to run, same as VK_LEFT/RIGHT.
                // Harmless to start even when nothing actually needs to
                // move beyond this -- advancePostRotateSettle notices
                // there's nothing left to do and shuts its own timer back
                // off within a tick or two.
                SIM_LOG("[SETTLE] WM_LBUTTONUP drag-release reset fired -- resetting probe step sizes and anti-oscillation state\n");
                rockySettleConverged = FALSE;
                rockyKneeSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
                semniHipSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
                rockyBodySettleStep = SIMULATION_BODY_SETTLE_STEP_DEG;
                rockyBothProbesCommittedStreak = 0;
                rockyKneeSettleGrowthStreak = 0;
                rockyBodySettleGrowthStreak = 0;
                rockyPivotSide = 0;
                rockyBodyLastCommitDir = 0;
                rockyToppleLastPivotCategory = 0;
                rockyBodyReversalBlockedStreak = 0;
                rockyKneeSettleSuppressed = FALSE;

                postRotateSettleActive = TRUE;
                SetTimer(hWnd, AUTO_GRAVITY_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);
            }

            ReleaseCapture();
        }
        return 0;
	case WM_MBUTTONDOWN:
	{
	    panning = TRUE;
	    panLastX = GET_X_LPARAM(lParam);
	    panLastY = GET_Y_LPARAM(lParam);
	    SetCapture(hWnd);

	    // Set the hand cursor immediately on the down-click rather than
	    // only relying on WM_SETCURSOR's own panning check (further up
	    // this switch) -- WM_SETCURSOR for THIS same button-down event is
	    // actually dispatched by Windows BEFORE this handler runs (cursor
	    // messages precede the button message that triggers them), so at
	    // that point `panning` was still FALSE and it fell through to
	    // whatever cursor was already showing. Setting it here, right
	    // after panning actually becomes TRUE, means the cursor changes
	    // the instant the button goes down instead of only catching up
	    // once the mouse happens to move again.
	    SetCursor(LoadCursor(NULL, IDC_HAND));
	    return 0;
	}
	case WM_MBUTTONUP:
	{
	    panning = FALSE;
	    ReleaseCapture();
	    return 0;
	}
    case WM_MOUSEMOVE:
	{
	    // See advanceAutoGravity's comment: WM_TIMER is low-priority and
	    // gets starved by a steady stream of WM_MOUSEMOVE, which otherwise
	    // visibly pauses the fall for as long as the mouse keeps moving.
	    // Calling it here too means mouse movement itself keeps the fall
	    // going instead of blocking it -- no-ops instantly if auto gravity
	    // isn't currently on.
	    advanceAutoGravity(hWnd);

	    // Same starvation concern, for a rotate-release topple still in
	    // progress -- no-ops instantly once postRotateSettleActive is off.
	    advancePostRotateSettle(hWnd);

	    // Same reasoning, for the gait cycle -- no-ops instantly if Walk
	    // isn't currently on.
	    advanceGait(hWnd);

	    if (app.draggingRobotSim)
	    {
	        float wx, wy;
	        screenToGL(hWnd, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam), &wx, &wy);

	        translateActiveRobot(wx - dragRobotLastWX, wy - dragRobotLastWY);

	        dragRobotLastWX = wx;
	        dragRobotLastWY = wy;

	        InvalidateRect(hWnd, NULL, FALSE);
	        return 0;
	    }

	    // Simulation mode, not currently dragging: keep app.hoveringRobotSim
	    // (used by WM_SETCURSOR/WM_LBUTTONDOWN above, and by renderRobot for
	    // the yellow hover highlight) up to date so the move cursor -- and
	    // the ability to start a drag -- only ever appears while genuinely
	    // over the robot's body.
	    if (appMode == APP_MODE_SIMULATION)
	    {
	        float wx, wy;
	        screenToGL(hWnd, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam), &wx, &wy);
	        app.hoveringRobotSim = isPointInsideActiveRobotBody(wx, wy);

	        // Keep simHoveredJoint current too -- see its own comment and
	        // findHoveredJointSim's, used by WM_MOUSEWHEEL below to decide
	        // whether a Shift+scroll rotates the hovered joint instead of
	        // zooming. (WM_KEYDOWN's plain Left/Right is unrelated -- that
	        // rotates the WHOLE robot, not a specific joint, so it doesn't
	        // read simHoveredJoint at all.)
	        simHoveredJoint = findHoveredJointSim(app.robotScene.robot, wx, wy);

	        // Mirror it into the SAME hover fields Design > Robot mode's own
	        // hip/knee handles use (app.hoverHip/hoverKnee) -- renderer.c's
	        // drawSemniBody/drawThigh/drawShin already color the thigh/shin
	        // from these whenever Shift is ALSO held (RenderState.shiftHeld,
	        // sampled live every frame in renderRobot -- same field, same
	        // gating Design mode itself uses), so this is all that's needed
	        // to get the exact same "which limb is about to rotate"
	        // highlight Design mode shows, for free.
	        app.hoverHip  = (simHoveredJoint == 2);
	        app.hoverKnee = (simHoveredJoint == 3);

	        InvalidateRect(hWnd, NULL, FALSE);
	    }

	    if (panning)
	    {
	        // Same reasoning as WM_MBUTTONDOWN's own SetCursor call --
	        // don't rely solely on WM_SETCURSOR to keep the hand cursor
	        // showing for the rest of the drag (a captured middle-button
	        // drag doesn't reliably keep re-triggering WM_SETCURSOR on
	        // this window the way an uncaptured hover does), just
	        // explicitly re-assert it on every move that's actually
	        // panning. Cheap enough to call unconditionally here (Windows
	        // no-ops a SetCursor call for the cursor that's already
	        // active) rather than trying to track whether it's already
	        // been set this drag.
	        SetCursor(LoadCursor(NULL, IDC_HAND));

	        int mx = GET_X_LPARAM(lParam);
	        int my = GET_Y_LPARAM(lParam);
	        int dx = mx - panLastX;
	        int dy = my - panLastY;

	        // Simulation mode: pan through sim_camera (shared with the
	        // robot) instead of canvas.panX/panY -- same reasoning as
	        // WM_MOUSEWHEEL above.
	        if (appMode == APP_MODE_SIMULATION)
	        {
	            simCameraPan(dx, dy);
	        }
	        else
	        {
	            float aspect = (float)glWindowWidth / (float)glWindowHeight;
	            float worldPerPixelX, worldPerPixelY;

	            if (aspect >= 1.0f) {
	                worldPerPixelX = (2.0f * aspect * canvas.zoom) / glWindowWidth;
	                worldPerPixelY = (2.0f * canvas.zoom) / glWindowHeight;
	            } else {
	                worldPerPixelX = (2.0f * canvas.zoom) / glWindowWidth;
	                worldPerPixelY = (2.0f * (canvas.zoom / aspect)) / glWindowHeight;
	            }

	            canvas.panX -= dx * worldPerPixelX;
	            canvas.panY += dy * worldPerPixelY;
	        }

	        panLastX = mx;
	        panLastY = my;

	        InvalidateRect(hWnd, NULL, FALSE);
	        return 0;
	    }

	    // Simulation mode never draws new strokes (WM_LBUTTONDOWN above
	    // returns early for it unconditionally), so the segment-hover/
	    // endpoint-snap preview below has nothing to actually feed into --
	    // and it computes world coords from canvas.zoom/panX/panY directly,
	    // which no longer match what's on screen once sim_camera is driving
	    // the view (see UpdateProjection). Skip it outright rather than let
	    // it show a highlight in the wrong place.
	    if (appMode == APP_MODE_SIMULATION)
	    {
	        if (hoveredSegment != -1 || snapEndpointAvailable)
	        {
	            hoveredSegment = -1;
	            snapEndpointAvailable = FALSE;
	            InvalidateRect(hWnd, NULL, FALSE);
	        }
	        // Must return here, not fall through -- the stroke-continuation
	        // code below this whole if/else-if assumes drawing == TRUE
	        // (indexes strokeStarts[canvas.strokeCount - 1] unconditionally),
	        // which is never true in Simulation mode but would still be
	        // unsafe to reach with strokeCount == 0.
	        return 0;
	    }
	    else if (!drawing || !(wParam & MK_LBUTTON))
	    {
	        // NEW: hover detection (segment overlay + stroke endpoint
	        // snapping) when not actively drawing or panning. World coords
	        // computed once here so both checks below can share them.
	        float hx = (float)GET_X_LPARAM(lParam);
	        float hy = (float)GET_Y_LPARAM(lParam);
	        float hAspect = (float)glWindowWidth / (float)glWindowHeight;
	        float hwx, hwy;
	        if (hAspect >= 1.0f) {
	            hwx = ((2.0f * hx / glWindowWidth) - 1.0f) * hAspect * canvas.zoom;
	            hwy = (1.0f - (2.0f * hy / glWindowHeight)) * canvas.zoom;
	        } else {
	            hwx = ((2.0f * hx / glWindowWidth) - 1.0f) * canvas.zoom;
	            hwy = (1.0f - (2.0f * hy / glWindowHeight)) * (1.0f / hAspect) * canvas.zoom;
	        }
	        hwx += canvas.panX;
	        hwy += canvas.panY;

	        // NEW: does hovering land near an existing stroke's start/end
	        // point? If so, the next stroke drawn will snap to it (chains
	        // straight lines into a connected polyline).
	        float newSnapX, newSnapY;
	        BOOL newSnapAvailable = findNearestStrokeEndpoint(hwx, hwy, &newSnapX, &newSnapY);
	        if (newSnapAvailable != snapEndpointAvailable ||
	            (newSnapAvailable && (newSnapX != snapEndpointX || newSnapY != snapEndpointY)))
	        {
	            snapEndpointAvailable = newSnapAvailable;
	            snapEndpointX = newSnapX;
	            snapEndpointY = newSnapY;
	            InvalidateRect(hWnd, NULL, FALSE);
	        }

	        // Needed to actually receive WM_MOUSELEAVE below (used to clear
	        // both the segment hover and the endpoint-snap highlight) -
	        // registered unconditionally now since endpoint snapping isn't
	        // gated on canvas.showSegments the way segment hover is.
	        TRACKMOUSEEVENT tme = {0};
	        tme.cbSize = sizeof(tme);
	        tme.dwFlags = TME_LEAVE;
	        tme.hwndTrack = hWnd;
	        TrackMouseEvent(&tme);

	        if (canvas.showSegments && canvas.segmentResultCount > 0)
	        {
	            int newHover = findHoveredSegment(hwx, hwy);
	            if (newHover != hoveredSegment)
	            {
	                hoveredSegment = newHover;
	                InvalidateRect(hWnd, NULL, FALSE);
	            }
	        }
	        else if (hoveredSegment != -1)
	        {
	            hoveredSegment = -1;
	            InvalidateRect(hWnd, NULL, FALSE);
	        }

	        return 0;
	    }

	    // Shared with WM_KEYDOWN's VK_SHIFT handling below (see its comment)
	    // -- both funnel through updateDrawingPoint so a fresh point/preview
	    // can never disagree about how it was computed depending on which
	    // message happened to trigger it.
	    updateDrawingPoint(hWnd, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam),
	                       (wParam & MK_SHIFT) != 0, (wParam & MK_CONTROL) != 0);
	    return 0;
	}
	case WM_MOUSELEAVE:
	{
	    if (app.hoveringRobotSim)
	    {
	        app.hoveringRobotSim = FALSE;
	        InvalidateRect(hWnd, NULL, FALSE);
	    }
	    if (hoveredSegment != -1)
	    {
	        hoveredSegment = -1;
	        InvalidateRect(hWnd, NULL, FALSE);
	    }
	    if (snapEndpointAvailable)
	    {
	        snapEndpointAvailable = FALSE;
	        InvalidateRect(hWnd, NULL, FALSE);
	    }
	    if (simHoveredJoint != -1)
	    {
	        simHoveredJoint = -1;
	        app.hoverHip = FALSE;
	        app.hoverKnee = FALSE;
	        InvalidateRect(hWnd, NULL, FALSE);
	    }
	    return 0;
	}
	case WM_COMMAND:
	{
	    if (LOWORD(wParam) == ID_UPLOAD)
	    {
	        RunUploadPipeline();
	        SendMessage(hWndUI, WM_COMMAND, MAKEWPARAM(ID_VIEW_SEGMENTS, BN_CLICKED), 0);
	        if (hWndGL) InvalidateRect(hWndGL, NULL, FALSE);
	    }
	    else if (LOWORD(wParam) == ID_SLOW_MOTION)
	    {
	        // BS_AUTOCHECKBOX already flipped its own check state before this
	        // notification fires, so read it back rather than tracking a
	        // separate bool -- the button IS the toggle state (same pattern
	        // ui.c's Trace/Comparison Mode buttons use).
	        BOOL nowChecked = (SendMessage(hSlowMotionBtn, BM_GETCHECK, 0, 0) == BST_CHECKED);
	        simTimeScale = nowChecked ? SIMULATION_SLOW_MOTION_SCALE : 1.0f;

	        // Clicking a button gives IT keyboard focus by default -- left
	        // there, G/Shift+G/Ctrl+Numpad0 (all handled in this window's own
	        // WM_KEYDOWN) would stop working after the first Slow Motion
	        // click, since WM_KEYDOWN would go to the button instead of here.
	        // Hand focus straight back to the main window so keyboard control
	        // keeps working immediately, with no extra click needed.
	        SetFocus(hWnd);
	    }
	    else if (LOWORD(wParam) == ID_PROBE2_TOGGLE)
	    {
	        // Same BS_AUTOCHECKBOX pattern as ID_SLOW_MOTION just above --
	        // the button already flipped its own check state before this
	        // notification fires, so read it back into rockyProbe2Enabled
	        // rather than tracking a separate bool. advanceRockySettle reads
	        // this flag directly on its next tick -- unchecking it here takes
	        // effect immediately, no other state to reset (Probe 2 has no
	        // ongoing timer/animation of its own the way Slow Motion/Walk do).
	        rockyProbe2Enabled = (SendMessage(hProbe2ToggleBtn, BM_GETCHECK, 0, 0) == BST_CHECKED);

	        // Same reasoning as ID_SLOW_MOTION's SetFocus above -- hand
	        // keyboard focus back so G/Shift+G/E/Q/arrow keys etc. keep
	        // working immediately after the click.
	        SetFocus(hWnd);
	    }
	    else if (LOWORD(wParam) == ID_WALK_TOGGLE)
	    {
	        // ToggleGait maintains its own authoritative gaitActive bool
	        // (needed since Shift+W, WM_KEYDOWN, drives this same toggle
	        // without ever touching the button) and re-syncs hWalkBtn's
	        // checkbox to match every time -- BS_AUTOCHECKBOX already
	        // flipped it once on this real click, but ToggleGait's own
	        // BM_SETCHECK just re-affirms the same state, so this is safe
	        // to call unconditionally rather than reading BM_GETCHECK back.
	        ToggleGait(hWnd);

	        // Same reasoning as ID_SLOW_MOTION's SetFocus just above --
	        // hand keyboard focus back so G/Shift+G/Shift+W/arrow keys etc.
	        // keep working immediately after the click.
	        SetFocus(hWnd);
	    }
	    else if (LOWORD(wParam) == ID_RESET_ROBOT)
	    {
	        // Wipe the console FIRST, unconditionally -- even if there's no
	        // snapshot to restore yet, Reset is the one button whose whole
	        // point is "start over", and a debug log still full of whatever
	        // the PREVIOUS run printed makes it hard to tell that anything
	        // just happened, or to find this run's own prints among the
	        // last one's leftovers.
	        ClearConsoleLog();

	        if (haveSimulationStartSnapshot)
	        {
	            app.robotScene = simulationStartSnapshot;

	            // Leftover motion state belongs to whatever pose the robot
	            // was just IN, not the one it's being reset back to --
	            // without clearing this, a robot reset mid-fall would snap
	            // back to its starting pose and then immediately keep
	            // falling at its old speed, which reads as the reset not
	            // having really happened.
	            autoGravityVelocity = 0.0f;

	            SIM_LOG("[RESET] robot restored to its Simulation-start pose (kind=%d)\n", app.robotScene.activeKind);
	        }

	        // Reset also resets the VIEW: 100% zoom, centered on the robot
	        // (its center of mass, the same point the green mass-center line
	        // is drawn from). The camera stores pan as a fraction of the
	        // current half-extent (sim_camera.c), shared by both the robot
	        // and environment projections, so centering the robot means
	        // panFrac = robotPoint / robotHalfExtent at the new (1.0) zoom --
	        // same half-extent math robotPointToEnvWorld uses.
	        simCameraReset();
	        if (glWindowWidth > 0 && glWindowHeight > 0)
	        {
	            float aspect = (float)glWindowWidth / (float)glWindowHeight;
	            float robotHalfY = ROBOT_VIEW_HALF_EXTENT / (simCameraGetZoom() * graphicsGetRobotScale());
	            float robotHalfX = robotHalfY * aspect;
	            PointF robotCenter = computeSimulationMassCenterWorld(&app);
	            if (robotHalfX > 0.0f && robotHalfY > 0.0f)
	                simCameraSetPanFraction(robotCenter.x / robotHalfX, robotCenter.y / robotHalfY);
	        }
	        InvalidateRect(hWnd, NULL, FALSE);

	        // Same reasoning as ID_SLOW_MOTION's SetFocus just above.
	        SetFocus(hWnd);
	    }
	    else if (LOWORD(wParam) == ID_LAYER_ROBOT || LOWORD(wParam) == ID_LAYER_ENVIRONMENT || LOWORD(wParam) == ID_MODE_SIMULATION)
	    {
	        // "Mode" is the second top-level popup (index 1, after "File");
	        // "Design Mode" is the first item within it (index 0) and is
	        // itself a submenu holding the two layer choices.
	        HMENU hMenuBar = GetMenu(hWnd);
	        HMENU hModeMenu = GetSubMenu(hMenuBar, 1);
	        HMENU hDesignMenu = GetSubMenu(hModeMenu, 0);

	        if (LOWORD(wParam) == ID_MODE_SIMULATION)
	        {
	            if (!envViewStateSaved)
	            {
	                envSavedShowSegments = canvas.showSegments;
	                envSavedComparisonMode = canvas.comparisonMode;
	                envViewStateSaved = TRUE;
	            }
	            canvas.showSegments = FALSE; // View Segments overlay is Environment-only

	            appMode = APP_MODE_SIMULATION;

	            // Snapshot whichever pose the robot is in RIGHT NOW, before
	            // anything below or afterward (gravity, E/Q, dragging...)
	            // gets a chance to move it -- this is what ID_RESET_ROBOT's
	            // "Reset" button below restores. Re-captured every time
	            // Simulation is (re-)entered, so leaving and coming back
	            // with the robot posed differently updates what "starting
	            // position" means for the NEXT reset, rather than forever
	            // remembering only the very first entry this session.
	            simulationStartSnapshot = app.robotScene;
	            haveSimulationStartSnapshot = TRUE;

	            // Design > Robot mode's own hover flags (app.hoverHead/
	            // hoverButt/hoverFoot/hoverHip/hoverKnee) are only ever
	            // updated by input.c's WM_MOUSEMOVE, which stops receiving
	            // messages the moment editor mode leaves EDITOR_MODE_SEMNI --
	            // so if the user was hovering a handle there right before
	            // switching to Simulation, a stale TRUE would otherwise keep
	            // that part highlighted blue here even with the cursor
	            // nowhere near it (drawSemniBody/drawThigh/drawShin read
	            // these fields unconditionally, regardless of editor mode).
	            // Clearing them here guarantees Simulation always starts
	            // with a clean, accurate hover state; WM_MOUSEMOVE/
	            // WM_MOUSELEAVE below keep hoverHip/hoverKnee current for
	            // the rest of the session (simHoveredJoint's own comment).
	            app.hoverHead = FALSE;
	            app.hoverButt = FALSE;
	            app.hoverFoot = FALSE;
	            app.hoverHip = FALSE;
	            app.hoverKnee = FALSE;
	            simHoveredJoint = -1;

	            // Design > Environment's own hover state (segment highlight +
	            // endpoint-snap ring) is just as stale here as the Robot-mode
	            // flags above -- switching straight from Design > Environment
	            // to Simulation via the Mode menu (no intervening mouse move)
	            // otherwise leaves hoveredSegment/snapEndpointAvailable pointing
	            // at whatever was last hovered, and the paint code that draws
	            // them (segment highlight color, snap-endpoint ring) has no
	            // appMode gate of its own -- so it would keep drawing on top of
	            // the Simulation view until the next WM_MOUSEMOVE/WM_MOUSELEAVE.
	            hoveredSegment = -1;
	            snapEndpointAvailable = FALSE;

	            // Belt-and-suspenders alongside the hover reset above: these
	            // normally always get cleared on WM_LBUTTONUP (input.c), but
	            // reset them here too on the off chance a drag ever got left
	            // stuck active (e.g. the button-up landed somewhere that
	            // didn't reach input.c) -- setColor's `active` parameter now
	            // takes priority over hoveringWhole's yellow (see its own
	            // comment), so a stale TRUE here would otherwise paint a
	            // spurious blue highlight throughout Simulation instead of
	            // being silently masked the way it used to be.
	            app.draggingSeamArc1 = 0;
	            app.draggingSeamArc2 = 0;
	            app.draggingInner = 0;
	            app.draggingKnee = 0;
	            app.draggingThigh1 = 0;
	            app.draggingThigh2 = 0;
	            app.draggingFoot = 0;
	            app.draggingShin1 = 0;
	            app.draggingShin2 = 0;
	            app.activeHandle = 0;
	            app.draggingSemniMassCenter = 0;

	            // Same belt-and-suspenders, extended to Rocky's and Stilo's own
	            // per-handle drag flags (app.h) -- these were missing from this
	            // reset even though input.c's handleInput never calls
	            // SetCapture for any of them either, so they're exactly as
	            // exposed to a button-up landing on some other window (e.g. the
	            // Robot editor's own Remove Leg/Remove Body checkboxes sitting
	            // right next to the canvas, input.c's
	            // ID_ROCKY_TOGGLE_LEG_BUTTON/ID_ROCKY_TOGGLE_BODY_BUTTON) as the
	            // Semni fields above were. Left uncleared, a stuck TRUE here
	            // survives a full round trip through Simulation and back: the
	            // next WM_MOUSEMOVE the Robot editor receives drags that part
	            // (e.g. the knee, dragging the whole leg with it) straight from
	            // wherever the cursor happens to be, with no mouse button held
	            // down at all -- which is exactly what a stuck
	            // draggingRockyKnee/draggingRockyBody looks like from the
	            // outside.
	            app.draggingRockyBody = 0;
	            app.draggingRockyEdge = ROCKY_EDGE_NONE;
	            app.draggingRockyKnee = 0;
	            app.draggingRockyFoot = 0;
	            app.draggingRockyMassCenter = 0;
	            app.draggingRockyShin1 = 0;
	            app.draggingRockyShin2 = 0;
	            app.draggingStiloMassCenter = 0;
	            app.draggingStiloSeamArc1 = 0;
	            app.draggingStiloSeamArc2 = 0;
	            app.draggingStiloHip1 = 0;
	            app.draggingStiloFeet1 = 0;
	            app.draggingStiloThigh1Arc1 = 0;
	            app.draggingStiloThigh1Arc2 = 0;
	            app.draggingStiloHip2 = 0;
	            app.draggingStiloFeet2 = 0;
	            app.draggingStiloThigh2Arc1 = 0;
	            app.draggingStiloThigh2Arc2 = 0;

	            // Ground collision (robotCollidesWithEnvironment ->
	            // pointCollidesWithAnyEnvironmentStroke) tests against the
	            // arc-fitted RECONSTRUCTION (segmentPointsWorld) now, not the
	            // raw hand-drawn strokes -- see that function's comment for
	            // why. That data is only produced by tracing (View Segments/
	            // Comparison Mode both trigger it on demand, see ui.c), which
	            // goes stale the moment the user draws or edits another
	            // stroke afterward. Re-tracing right here, every
	            // time Simulation is entered, closes both gaps for free: it's
	            // always present and always current, without the user having
	            // to think about it. Cheap to do unconditionally -- environment
	            // strokes can't be added or edited while Simulation is active
	            // (WM_LBUTTONDOWN only grabs the robot in this mode), so this
	            // is the one moment per Simulation session where re-tracing
	            // actually needs to happen at all.
	            //
	            // Console noise, not useful noise: this automatic re-trace
	            // is never something the user asked for (unlike View
	            // Segments/Comparison Mode/Save, which stay verbose), so
	            // suppress its [DEBUG] Path Analysis/Arc Segmentation dumps
	            // specifically -- see gSuppressTraceDebugPrints' own comment.
	            {
	                BOOL savedSuppress = gSuppressTraceDebugPrints;
	                gSuppressTraceDebugPrints = TRUE;
	                RunTracePipeline();
	                gSuppressTraceDebugPrints = savedSuppress;
	            }

	            // Kick off a settle pass -- but ONLY if the robot is already
	            // touching/overlapping the freshly-traced environment right
	            // now, exactly where it was left in Design mode. This has to
	            // come AFTER RunTracePipeline just above: robotCollidesWithEnvironment
	            // reads segmentPointsWorld, which tracing is what produces,
	            // so checking any earlier would be testing against stale (or
	            // entirely absent) ground data. Gating on actual contact
	            // matters just as much as the placement: this timer runs the
	            // exact same driver Auto Gravity's own timer does
	            // (applyGravityStep every tick), so starting it unconditionally
	            // here -- as an earlier version of this fix did -- made ANY
	            // entry into Simulation mode fall all the way to the ground on
	            // its own, even with Auto Gravity OFF, which defeats the whole
	            // point of that toggle. Only touching-right-now poses need
	            // Probe 2/Probe 1 at all (that's the entire "home position,
	            // knee down but foot floating" scenario this was meant to
	            // fix) -- a robot starting out genuinely airborne is supposed
	            // to just sit there until the user turns gravity on or
	            // presses G, same as it always has.
	            //
	            // Also now requires autoGravityActive itself (by explicit
	            // request): without this, a robot that had already settled
	            // onto the ground once (e.g. from an earlier Auto Gravity
	            // drop) re-triggered this SAME correction pass every single
	            // time Simulation was re-entered afterward -- e.g. a trip out
	            // to Design > Robot to toggle Remove Leg/Remove Body and back
	            // -- since it was still touching right where it landed. With
	            // Auto Gravity off that read as the robot (or, with the body
	            // hidden, just the visible leg) quietly drifting on its own
	            // driven by mouse movement (advancePostRotateSettle's own
	            // WM_MOUSEMOVE fallback-driver call) even though nothing
	            // gravity-related was ever turned on -- exactly the "moving the
	            // cursor moves the robot with Auto Gravity off" behavior this
	            // was reported to do. Gravity off should mean nothing settles
	            // on its own, full stop; the "knee down, foot floating" home-
	            // position correction above only ever mattered for a freshly-
	            // posed robot anyway, and a user relying on that nudge can
	            // just turn Auto Gravity on for it now.
	            if (robotCollidesWithEnvironment() && autoGravityActive)
	            {
	                SIM_LOG("[SETTLE] Simulation-mode-entry reset fired -- resetting probe step sizes and anti-oscillation state\n");
	                rockySettleConverged = FALSE;
	                rockyKneeSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
	                semniHipSettleStep = SIMULATION_LEG_SETTLE_STEP_DEG;
	                rockyBodySettleStep = SIMULATION_BODY_SETTLE_STEP_DEG;
	                rockyBothProbesCommittedStreak = 0;
	                rockyKneeSettleGrowthStreak = 0;
	                rockyBodySettleGrowthStreak = 0;
	                rockyPivotSide = 0;
	                rockyBodyLastCommitDir = 0;
	                rockyToppleLastPivotCategory = 0;
	                rockyBodyReversalBlockedStreak = 0;
	                rockyKneeSettleSuppressed = FALSE;
	                postRotateSettleActive = TRUE;
	                SetTimer(hWnd, AUTO_GRAVITY_TIMER_ID, SIMULATION_AUTO_GRAVITY_INTERVAL_MS, NULL);
	            }

	            SIM_LOG("[ENV] %d segment(s) traced:\n", canvas.segmentResultCount);
	            for (int s = 0; s < canvas.segmentResultCount; s++)
	            {
	                int start = segmentStarts[s];
	                int count = segmentCounts[s];
	                if (count < 2) continue;
	                float sax = segmentPointsWorld[start * 2];
	                float say = segmentPointsWorld[start * 2 + 1];
	                float sbx = segmentPointsWorld[(start + count - 1) * 2];
	                float sby = segmentPointsWorld[(start + count - 1) * 2 + 1];
	                SIM_LOG("[ENV]   seg=%d start=(%.5f,%.5f) end=(%.5f,%.5f) thickness=%.5f\n",
	                       s, sax, say, sbx, sby, segmentThicknessWorld[s]);
	            }

	            // Since the environment strokes shown on screen aren't what
	            // collision actually tests against anymore, show the user
	            // what physics sees instead of what they drew -- switches
	            // the Environment view from the original strokes over to
	            // the reconstructed/arc-fitted drawing (same as manually
	            // checking "Comparison Mode"), so it's obvious what the
	            // robot is really going to land on.
	            SetComparisonModeUI(TRUE);

	            // Simulation is driven from the ArcSpline canvas's own
	            // WndProc (this file), not the Semni editor's -- make sure
	            // picking it also backs out of the Semni robot editor if
	            // that's currently active. renderCombinedFrame special-cases
	            // APP_MODE_SIMULATION to draw the environment AND the robot
	            // both at full opacity together (rather than dimming
	            // whichever side isn't "active"), and WM_LBUTTONDOWN/
	            // WM_MOUSEMOVE above switch left-drag from drawing new
	            // strokes to dragging the whole robot into a starting pose.
	            switchEditorMode(EDITOR_MODE_ARCSPLINE, &editorModeState);

	            // Only ONE of Robot (Semni) / Environment / Simulation
	            // should ever show as checked at a time. designLayer itself
	            // is left alone here on purpose -- switching back to Design
	            // Mode later should return to whichever layer was last
	            // active -- but the CHECKMARKS have to be cleared now, or
	            // whichever layer was checked before would still show
	            // checked alongside Simulation, making it look like two
	            // modes are active at once.
	            CheckMenuItem(hDesignMenu, ID_LAYER_ROBOT, MF_BYCOMMAND | MF_UNCHECKED);
	            CheckMenuItem(hDesignMenu, ID_LAYER_ENVIRONMENT, MF_BYCOMMAND | MF_UNCHECKED);
	        }
	        else
	        {
	            // Picking either layer both enters Design mode and selects
	            // which layer new strokes/edits go to.
	            appMode = APP_MODE_DESIGN;
	            designLayer = (LOWORD(wParam) == ID_LAYER_ROBOT) ? LAYER_ROBOT : LAYER_ENVIRONMENT;

	            // Coming back from Simulation: restore exactly the View
	            // Segments / Comparison Mode state Environment had before
	            // (Simulation forced Comparison Mode on and the overlay off).
	            if (envViewStateSaved)
	            {
	                canvas.showSegments = envSavedShowSegments;
	                SetComparisonModeUI(envSavedComparisonMode); // also re-syncs the button's checkmark
	                envViewStateSaved = FALSE;
	            }
	            CheckMenuItem(hDesignMenu, ID_LAYER_ROBOT, MF_BYCOMMAND | (designLayer == LAYER_ROBOT ? MF_CHECKED : MF_UNCHECKED));
	            CheckMenuItem(hDesignMenu, ID_LAYER_ENVIRONMENT, MF_BYCOMMAND | (designLayer == LAYER_ENVIRONMENT ? MF_CHECKED : MF_UNCHECKED));

	            // "Robot (Semni)" used to be a blank placeholder layer -- it's
	            // now the real entry point into the separate Semni robot
	            // editor, which takes over this same window. Picking
	            // Environment (back) returns to the ArcSpline canvas.
	            switchEditorMode(designLayer == LAYER_ROBOT ? EDITOR_MODE_SEMNI : EDITOR_MODE_ARCSPLINE, &editorModeState);
	        }

	        CheckMenuItem(hModeMenu, ID_MODE_SIMULATION, MF_BYCOMMAND | (appMode == APP_MODE_SIMULATION ? MF_CHECKED : MF_UNCHECKED));

	        // View > Simulation Log / FPS Log only exist in Simulation --
	        // enabled here on entry, greyed out again on leaving. Their
	        // checkmarks/flags are left as they were, so logging resumes
	        // automatically the next time Simulation is entered.
	        {
	            HMENU hViewMenuForLogs = GetSubMenu(hMenuBar, 2);
	            UINT logItemState = MF_BYCOMMAND | (appMode == APP_MODE_SIMULATION ? MF_ENABLED : MF_GRAYED);
	            EnableMenuItem(hViewMenuForLogs, ID_TOGGLE_SIM_LOG, logItemState);
	            EnableMenuItem(hViewMenuForLogs, ID_TOGGLE_FPS_LOG, logItemState);
	            EnableMenuItem(hViewMenuForLogs, ID_TOGGLE_SHOW_FPS, logItemState); // Show FPS: Simulation only too
	        }

	        logModeIfChanged(); // "[Mode] Switched to: Robot / Environment / Simulation"

	        // Slow Motion button: only makes sense in Simulation, so it
	        // shows/hides right alongside it. Slow Motion is ON by default
	        // (by request), so leaving Simulation resets it back to that
	        // default -- checked, SIMULATION_SLOW_MOTION_SCALE -- and every
	        // Simulation session starts in slow motion.
	        if (hSlowMotionBtn)
	        {
	            if (appMode == APP_MODE_SIMULATION)
	            {
	                ShowWindow(hSlowMotionBtn, SW_SHOW);
	            }
	            else
	            {
	                ShowWindow(hSlowMotionBtn, SW_HIDE);
	                SendMessage(hSlowMotionBtn, BM_SETCHECK, BST_CHECKED, 0);
	                simTimeScale = SIMULATION_SLOW_MOTION_SCALE;
	            }
	        }

	        // Same show/hide-on-mode-switch treatment for "Walk" -- also
	        // stops the gait cycle and kills its timer on the way out (same
	        // reasoning as autoGravityActive's own reset just below: doesn't
	        // make sense to keep animating once Simulation isn't active,
	        // and leaving it "on" would restart mid-cycle, at whatever pose
	        // gaitBaseline still holds from before, the next time Simulation
	        // is entered -- confusing rather than a useful persisted state).
	        if (hWalkBtn)
	        {
	            if (appMode == APP_MODE_SIMULATION)
	            {
	                ShowWindow(hWalkBtn, SW_SHOW);
	            }
	            else
	            {
	                ShowWindow(hWalkBtn, SW_HIDE);
	                SendMessage(hWalkBtn, BM_SETCHECK, BST_UNCHECKED, 0);
	                if (gaitActive)
	                {
	                    gaitActive = FALSE;
	                    KillTimer(hWnd, AUTO_GAIT_TIMER_ID);
	                }
	            }
	        }

	        // "Reset" -- same show/hide-on-mode-switch treatment. Nothing
	        // to un-check (it's a push button, not a toggle) and nothing to
	        // stop on the way out -- it doesn't drive a timer or any
	        // ongoing state of its own, it just acts once when clicked.
	        if (hResetBtn)
	        {
	            ShowWindow(hResetBtn, appMode == APP_MODE_SIMULATION ? SW_SHOW : SW_HIDE);
	        }

	        // Probe 2 toggle -- same show/hide-on-mode-switch treatment as
	        // Slow Motion above. Leaving Simulation also resets it back to
	        // checked/enabled (rockyProbe2Enabled = TRUE) rather than leaving
	        // it silently disabled the next time Simulation is entered --
	        // same "temporary aid, not a persisted setting" reasoning Slow
	        // Motion's own reset uses.
	        if (hProbe2ToggleBtn)
	        {
	            if (appMode == APP_MODE_SIMULATION)
	            {
	                ShowWindow(hProbe2ToggleBtn, SW_SHOW);
	            }
	            else
	            {
	                ShowWindow(hProbe2ToggleBtn, SW_HIDE);
	                SendMessage(hProbe2ToggleBtn, BM_SETCHECK, BST_CHECKED, 0);
	                rockyProbe2Enabled = TRUE;
	            }
	        }

	        // The Environment-only panel (hWndUI) can't rely on WM_TIMER to
	        // fade itself out here -- see HideUIPanelImmediately's comment --
	        // so force it closed immediately whenever the mode we just
	        // switched TO isn't Design > Environment, in case it was left
	        // showing from before this switch.
	        if (!(appMode == APP_MODE_DESIGN && designLayer == LAYER_ENVIRONMENT))
	            HideUIPanelImmediately();

	        // Same reasoning as the panel hide above: Shift+G's auto-gravity
	        // (see WM_KEYDOWN/WM_TIMER) shouldn't keep running once
	        // Simulation isn't the active mode anymore -- WM_TIMER's own
	        // defensive check would eventually catch this too, but turning
	        // it off immediately here avoids even one extra stray tick.
	        if (appMode != APP_MODE_SIMULATION && autoGravityActive)
	        {
	            autoGravityActive = FALSE;
	            autoGravityVelocity = 0.0f;
	            KillTimer(hWnd, AUTO_GRAVITY_TIMER_ID);

	            // Same reasoning as Shift+G's own turn-off (WM_KEYDOWN above):
	            // a postRotateSettleActive session that was inert (blocked by
	            // autoGravityActive being on) while we were still in
	            // Simulation would otherwise survive the mode switch and wake
	            // back up -- advancePostRotateSettle's guard only blocks it
	            // while autoGravityActive is CURRENTLY on, not permanently --
	            // the moment this same block just turned autoGravityActive
	            // off, a leftover TRUE here would start driving
	            // applyGravityStep off of WM_MOUSEMOVE again the next time
	            // Simulation is re-entered, with Auto Gravity showing off the
	            // whole time.
	            postRotateSettleActive = FALSE;
	        }

	        // Same reasoning again, for the knee-hold timer -- a switch away
	        // from Simulation mid-hold (e.g. the menu, not a keyup) would
	        // otherwise leave ROCKY_KNEE_HOLD_TIMER_ID running and
	        // rockyKneeHoldE/Q still TRUE, ready to start rotating a knee
	        // that isn't even on screen anymore the moment Simulation is
	        // re-entered and E/Q happens to still be physically held down.
	        if (appMode != APP_MODE_SIMULATION && (semniJointHoldE || semniJointHoldQ))
	        {
	            semniJointHoldE = FALSE;
	            semniJointHoldQ = FALSE;
	            KillTimer(hWnd, SEMNI_JOINT_HOLD_TIMER_ID);
	        }
	        if (appMode != APP_MODE_SIMULATION && (rockyKneeHoldE || rockyKneeHoldQ))
	        {
	            rockyKneeHoldE = FALSE;
	            rockyKneeHoldQ = FALSE;
	            KillTimer(hWnd, ROCKY_KNEE_HOLD_TIMER_ID);
	        }

	        // Don't let the toast linger into whatever mode we just switched
	        // to -- it only makes sense as feedback for a Shift+G press made
	        // while actually in Simulation.
	        if (appMode != APP_MODE_SIMULATION)
	            gravityToastStartTick = 0;

	        // Same reasoning, for Shift+W's "WALK ON/OFF" toast.
	        if (appMode != APP_MODE_SIMULATION)
	            gaitToastStartTick = 0;

	        if (hWndGL) InvalidateRect(hWndGL, NULL, FALSE);
	    }
	    else if (LOWORD(wParam) == ID_SAVE)
	    {
	        // Single File > Save entry point for the whole app -- folded in
	        // from what used to be two separate things: this dialog-based
	        // ArcSpline-only save, and the Robot editor's own "Save" button
	        // (input.c's now-removed ID_SAVE_BUTTON). Used to only save
	        // whichever HALF of the app was currently showing (Robot editor
	        // vs Environment canvas), picked via editorModeState.currentMode
	        // -- but that meant Save while posing a robot silently skipped
	        // the environment (and vice versa), even though both are
	        // independent, already-drawn/posed things sitting in memory
	        // regardless of which one you're currently looking at. Now
	        // always does BOTH, every time, so one Save reliably captures
	        // the whole scene: the Environment canvas AND whichever robot
	        // kind is currently active (app.robotScene.activeKind) -- not
	        // "every robot kind", just the one actually being worked on,
	        // same as before.

	        // --- Environment: EnvExport\Env.bmp + Env.txt ---
	        //
	        // Env.txt's segments come from canvas.segmentResultCount,
	        // which is only produced by tracing (View Segments/Comparison
	        // Mode trigger it on demand, see ui.c) -- stale the moment
	        // another stroke is drawn afterward. Re-tracing right here
	        // closes both gaps for free -- same reasoning (and same
	        // RunTracePipeline call) the ID_MODE_SIMULATION handler above
	        // already uses so ground-collision data is always current on
	        // entry. Gated on CanvasHasTraceableContent() (pipeline.c) now,
	        // not unconditional any more -- a robot-only Save (nothing ever
	        // drawn on the Environment canvas) has nothing to trace, so
	        // skip the call entirely instead of running it just to print
	        // "Canvas is empty" to the console every single time.
	        if (CanvasHasTraceableContent())
	            RunTracePipeline();

	        CreateDirectoryA("EnvExport", NULL);

	        // If comparison mode is on and segments exist, save reconstructed drawing
	        if (canvas.comparisonMode && canvas.segmentResultCount > 0)
	        {
	            Image* img = (Image*)malloc(sizeof(Image));
	            if (img)
	            {
	                img->width = glWindowWidth;
	                img->height = glWindowHeight;
	                img->data = (uint8_t*)malloc((size_t)img->width * img->height * 3);
	                img->bin = NULL;

	                if (img->data)
	                {
	                    renderSegmentsToImage(img, segmentPointsWorld, segmentStarts, segmentCounts,
	                                         segmentAvgRadiusPx, canvas.segmentResultCount,
	                                         img->width, img->height);
	                    saveBMP_UI("EnvExport\\Env.bmp", img, NULL, BMP_RGB);
	                }

	                free(img->data);
	                free(img);
	            }
	        }
	        else
	        {
	            // Save original drawing. Guarded on the exact same
	            // pointCount/strokeCount check canvasToImage() itself uses
	            // (not CanvasHasTraceableContent() above -- a pending,
	            // not-yet-traced uploaded BMP still has no actual canvas
	            // stroke, so canvasToImage() would return NULL and print
	            // "Canvas is empty" anyway in that case). Save still always
	            // runs this branch even when the user only came here to
	            // save a robot and never drew an environment at all (a
	            // perfectly normal case, not an error), it just no longer
	            // calls into canvasToImage() at all in that case, so
	            // there's no "Canvas is empty" console print and no dialog.
	            Image* img = (canvas.pointCount >= 1 && canvas.strokeCount >= 1) ? canvasToImage() : NULL;
	            if (img)
	            {
	                saveBMP_UI("EnvExport\\Env.bmp", img, img->bin, BMP_RGB);
	                free(img->data);
	                free(img->bin);
	                free(img->radius); // canvasToImage's own exact-radius raster -- see bmp.h
	                free(img);
	            }
	        }

	        saveEnvironmentSegmentsAsTxt("EnvExport\\Env.txt");

	        // --- Robot: whichever kind is currently active ---
	        //
	        // Each kind saves into its own export folder so posing one
	        // robot never overwrites another's saved files. Exact same
	        // per-kind logic the old Robot editor Save button used.
	        // Confirm a Weight value that's typed but not yet confirmed
	        // (Enter / click-away) so Save always writes what's in the box --
	        // for every robot kind, not just Rocky.
	        commitWeightEdit(&app);

	        switch (app.robotScene.activeKind)
	        {
	            case ROBOT_KIND_ROCKY:
	            {
	                CreateDirectoryA("RockyExport", NULL);

	                saveCanvasAsBMP("RockyExport\\rocky.bmp", app.hwndMain, &app);
	                // rocky.txt (saveRockyAsEquations) is no longer written
	                // here on every File > Save -- rocky.bmp alone is
	                // enough for this export, per explicit user request.
	                // saveRockyAsEquations itself is untouched and still
	                // used elsewhere (input.c's Standing/Home pose buttons,
	                // Poses\rocky_standing.txt / Poses\rocky_home.txt).

	                // Rob.txt/Arm.txt export (see save.c's
	                // saveRockyAsRobArm) -- bodyWeight/legWeight (the
	                // mass-center ratio) are already live in the struct
	                // (the ratio slider and on-canvas drag both write
	                // straight into it, no edit box to re-read anymore --
	                // see ID_WEIGHT_RATIO_SLIDER's own comment), so only
	                // the separate Weight edit box (the real mass actually
	                // written as Rob.txt's own weight value) needs a
	                // GetWindowText here, same as Stilo/Semni's own cases
	                // below already just trust the live struct for the
	                // ratio.
	                saveRockyAsRobArm(&app);
	                break;
	            }

	            case ROBOT_KIND_STILO:
	                CreateDirectoryA("StiloExport", NULL);
	                saveCanvasAsBMP("StiloExport\\stilo.bmp", app.hwndMain, &app);

	                // Rob.txt (torso, both hip joints) + Leg1.txt/Leg2.txt
	                // (see save.c's saveStiloAsRobLeg) -- same Rocky-style
	                // convention as saveRockyAsRobArm above, generalized to
	                // Stilo's arc-based torso and two independent legs.
	                // Supersedes the old stilo.txt KEY=value equations dump
	                // (saveStiloAsEquations), no longer written here.
	                saveStiloAsRobLeg(&app);
	                break;

	            case ROBOT_KIND_SEMNI:
	            default:
	                CreateDirectoryA("SemniExport", NULL);
	                saveCanvasAsBMP("SemniExport\\semni.bmp", app.hwndMain, &app);

	                // Rob.txt (torso) + Leg.txt (hip/knee/foot leg) -- see
	                // save.c's saveSemniAsRobLeg, same Rocky-style
	                // convention as saveRockyAsRobArm above, generalized to
	                // Semni's arc-based torso and two-stage leg. Supersedes
	                // the old semni.txt KEY=value equations dump
	                // (saveRobotAsEquations), no longer written here.
	                saveSemniAsRobLeg(&app);
	                break;
	        }

	        // Robot editor's own controls (e.g. the Body/Leg Weight edit
	        // boxes just read above) can be left with keyboard focus after
	        // this -- only relevant while that editor is actually showing.
	        if (editorModeState.currentMode == EDITOR_MODE_SEMNI)
	            SetFocus(app.hwndMain);
	    }
	    else if (LOWORD(wParam) == ID_DEBUG_LOG_MENU)
	    {
	        // View > Print Debug Log -- one on-demand dump for the mode the
	        // user is in (replaces the robot panel's Debug Log button and the
	        // trace dumps that used to print on every View Segments /
	        // Comparison Mode click).
	        const char* modeName = currentModeName();
	        printf("\n========== DEBUG LOG: %s ==========\n", modeName);

	        if (appMode == APP_MODE_SIMULATION || editorModeState.currentMode == EDITOR_MODE_SEMNI)
	        {
	            // Robot pose as app_init.c-style assignments (copy-pasteable
	            // as a new starting pose) -- what the old button printed.
	            switch (app.robotScene.activeKind)
	            {
	                case ROBOT_KIND_ROCKY: printRockyAsInit(app.robotScene.rocky); break;
	                case ROBOT_KIND_STILO: printStiloAsInit(app.robotScene.stilo); break;
	                case ROBOT_KIND_SEMNI:
	                default:               printRobotAsInit(app.robotScene.robot); break;
	            }
	        }

	        if (appMode == APP_MODE_SIMULATION)
	        {
	            // The environment exactly as collision sees it (traced on
	            // entering Simulation).
	            printf("[ENV] %d segment(s) traced:\n", canvas.segmentResultCount);
	            for (int s = 0; s < canvas.segmentResultCount; s++)
	            {
	                int start = segmentStarts[s];
	                int count = segmentCounts[s];
	                if (count < 2) continue;
	                printf("[ENV]   seg=%d start=(%.5f,%.5f) end=(%.5f,%.5f) %s thickness=%.5f\n", s,
	                       segmentPointsWorld[start * 2], segmentPointsWorld[start * 2 + 1],
	                       segmentPointsWorld[(start + count - 1) * 2], segmentPointsWorld[(start + count - 1) * 2 + 1],
	                       segmentCircleRadiusWorld[s] > 0.0f ? "arc " : "line", segmentThicknessWorld[s]);
	            }
	        }
	        else if (editorModeState.currentMode != EDITOR_MODE_SEMNI)
	        {
	            // Environment: re-trace with the full pipeline dump (path
	            // analysis, endpoints, arc segmentation).
	            BOOL savedSuppress = gSuppressTraceDebugPrints;
	            gSuppressTraceDebugPrints = FALSE;
	            RunTracePipeline();
	            gSuppressTraceDebugPrints = savedSuppress;
	            printEnvironmentComparison();
	        }

	        printf("========== END DEBUG LOG ==========\n\n");
	        if (hWnd) InvalidateRect(hWnd, NULL, FALSE);
	    }
	    else if (LOWORD(wParam) == ID_ABOUT)
	    {
	        // Help > About RoboBuilder -- author credit.
	        MessageBox(hWnd,
	                   L"RoboBuilder\n\n"
	                   L"Robot design, environment tracing and simulation tool.\n\n"
	                   L"Created by " APP_AUTHOR_NAME L"\n"
	                   L"Berlin University of Applied Sciences (BHT)",
	                   L"About RoboBuilder", MB_OK | MB_ICONINFORMATION);
	    }
	    else if (LOWORD(wParam) == ID_HELP)
	    {
	        // Reference list of every keyboard/mouse control for posing and
	        // simulating the robot -- File > Controls Help... (main.c's
	        // buildMainMenu). A proper modal reference window (see
	        // help_dialog.c) instead of a single-string MessageBox: section
	        // headers, a two-column key/description layout, and an OK
	        // button, reads far more like a real "Keyboard Shortcuts" page.
	        // Replaces an earlier, now-removed floating on-screen hint that
	        // only ever showed one gesture (Shift + Scroll rotate) at a
	        // time; this covers all of them at once, reachable whenever
	        // needed instead of only while hovering the right joint. Scoped
	        // to Robot Editing + Simulation (posing/moving the ROBOT
	        // itself), not the Environment canvas's own drawing controls,
	        // since that's what was actually asked for.
	        showControlsHelpDialog(hWnd);
	    }
	    else if (LOWORD(wParam) == ID_TOGGLE_HIDE_INACTIVE)
	    {
	        // View > Hide Inactive Layer -- independent on/off toggle, not
	        // part of the Design/Simulation mode-switching group above, so
	        // it gets its own small handler rather than folding into that
	        // one. The menu item IS the toggle state (flipped here, then
	        // the checkmark re-synced to match) same as the mode radio
	        // group's own CheckMenuItem calls just do it for one item
	        // instead of a group.
	        hideInactiveLayer = !hideInactiveLayer;

	        HMENU hMenuBar = GetMenu(hWnd);
	        HMENU hViewMenu = GetSubMenu(hMenuBar, 2);
	        CheckMenuItem(hViewMenu, ID_TOGGLE_HIDE_INACTIVE, MF_BYCOMMAND | (hideInactiveLayer ? MF_CHECKED : MF_UNCHECKED));

	        InvalidateRect(hWnd, NULL, FALSE);
	    }
	    else if (LOWORD(wParam) == ID_TOGGLE_SHOW_FPS)
	    {
	        // View > Show FPS -- same independent on/off toggle pattern as
	        // Hide Inactive Layer just above (own small handler, menu item
	        // IS the state, checkmark re-synced after flipping). Doesn't
	        // reset fpsFrameCount/fpsWindowStartTick -- canvasRenderFrame's
	        // own FPS measurement keeps running in the background
	        // unconditionally regardless of this flag (see fpsDisplayValue's
	        // own comment), so switching the overlay back on shows an
	        // already-averaged number immediately instead of starting over.
	        showFpsOverlay = !showFpsOverlay;

	        HMENU hMenuBar = GetMenu(hWnd);
	        HMENU hViewMenu = GetSubMenu(hMenuBar, 2);
	        CheckMenuItem(hViewMenu, ID_TOGGLE_SHOW_FPS, MF_BYCOMMAND | (showFpsOverlay ? MF_CHECKED : MF_UNCHECKED));

	        InvalidateRect(hWnd, NULL, FALSE);
	    }
	    else if (LOWORD(wParam) == ID_TOGGLE_SIM_LOG || LOWORD(wParam) == ID_TOGGLE_FPS_LOG)
	    {
	        // View > Simulation Log / FPS Log -- same independent toggle
	        // pattern as Show FPS above. Only reachable in Simulation (the
	        // items are greyed out otherwise -- see the mode-switch handler),
	        // but guarded here too in case of a stray WM_COMMAND.
	        if (appMode == APP_MODE_SIMULATION)
	        {
	            BOOL isSimLog = (LOWORD(wParam) == ID_TOGGLE_SIM_LOG);
	            BOOL* flag = isSimLog ? &simPhysicsLogEnabled : &simFpsLogEnabled;
	            *flag = !*flag;

	            HMENU hMenuBar = GetMenu(hWnd);
	            HMENU hViewMenu = GetSubMenu(hMenuBar, 2);
	            CheckMenuItem(hViewMenu, LOWORD(wParam), MF_BYCOMMAND | (*flag ? MF_CHECKED : MF_UNCHECKED));

	            // Plain printf, not SIM_LOG -- the OFF message has to show
	            // even though the flag was just cleared.
	            printf("[LOG] %s %s\n", isSimLog ? "Simulation log" : "FPS log", *flag ? "ON" : "OFF");
	        }
	    }
	    return 0;
	}
	case WM_PAINT:
	{
	    // The actual drawing now lives in renderCombinedFrame (both
	    // subsystems, one dimmed) so it can also be driven directly by
	    // main.c's per-frame loop instead of only through Invalidate/
	    // UpdateWindow -- WM_PAINT just needs BeginPaint/EndPaint around it
	    // so an OS-triggered repaint (e.g. window restore) still clears the
	    // invalid region and shows the correct combined frame.
	    PAINTSTRUCT ps;
	    BeginPaint(hWnd, &ps);
	    renderCombinedFrame();
	    EndPaint(hWnd, &ps);
	    return 0;
	}
    case WM_ERASEBKGND: return 1;
    case WM_DESTROY: KillTimer(hWnd, UI_HOTZONE_TIMER_ID); KillTimer(hWnd, AUTO_GRAVITY_TIMER_ID); KillTimer(hWnd, ROCKY_KNEE_HOLD_TIMER_ID); KillTimer(hWnd, SEMNI_JOINT_HOLD_TIMER_ID); PostQuitMessage(0); return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}
