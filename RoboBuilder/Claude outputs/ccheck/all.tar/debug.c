﻿// 1. Tell the compiler we want secure standard functions (like freopen_s)
#define __STDC_WANT_LIB_EXT1__ 1

#include <stdio.h>
#include <stdlib.h>

// 2. Ensure the core Windows API header is present for AllocConsole and SetConsoleTitleA
#include <windows.h> 

#include "debug.h"

#include <windows.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>

void OpenConsole() {
    // 1. Create the console window
    AllocConsole();
    
    // 2. Redirect standard streams to the new console
    // "CONOUT$" is the system device for the console output
    // "CONIN$" is the system device for console input
    
    // Redirect stdout to console
    (void)freopen("CONOUT$", "w", stdout);
    
    // Redirect stderr to console
    (void)freopen("CONOUT$", "w", stderr);
    
    // Redirect stdin to console
    (void)freopen("CONIN$", "r", stdin);

    // 3. Disable buffering for immediate output
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    SetConsoleTitle(L"Debug Console");
}

// Wipes the AllocConsole window OpenConsole created, same way "cls" does,
// but through the Console API directly rather than spawning a shell
// process to run the real cls.exe (system("cls") works too, but launching
// a whole extra process just to clear a window we already own is
// unnecessary overhead, and briefly steals focus/flashes a window on some
// setups). Fills the entire current screen buffer with blank spaces (the
// console's own default background attribute), then homes the cursor back
// to (0,0) -- printf's own internal position tracking doesn't need any
// reset, it just keeps writing from wherever the cursor physically is.
void ClearConsoleLog(void)
{
    // Deliberately NOT GetStdHandle(STD_OUTPUT_HANDLE) here: OpenConsole
    // above already re-pointed the CRT's own `stdout` FILE* at CONOUT$ via
    // freopen AFTER AllocConsole handed the process its std handles --
    // freopen opens its OWN new low-level handle for that (it doesn't
    // call SetStdHandle to keep the two in sync), so STD_OUTPUT_HANDLE can
    // end up stale/still referring to whatever (usually nothing, for a
    // GUI-subsystem app) the process had before AllocConsole ran, even
    // though printf's own output clearly still reaches the visible
    // window through the separate freopen'd handle. Opening "CONOUT$"
    // directly, the same special filename freopen itself uses, always
    // resolves to THIS process's current active console screen buffer
    // regardless of which handle anything else is holding, so this can't
    // silently no-op the way GetStdHandle did.
    HANDLE hConsole = CreateFileA("CONOUT$", GENERIC_READ | GENERIC_WRITE,
                                   FILE_SHARE_READ | FILE_SHARE_WRITE,
                                   NULL, OPEN_EXISTING, 0, NULL);
    if (hConsole == INVALID_HANDLE_VALUE) return;

    CONSOLE_SCREEN_BUFFER_INFO csbi;
    if (GetConsoleScreenBufferInfo(hConsole, &csbi))
    {
        DWORD cellCount = (DWORD)csbi.dwSize.X * (DWORD)csbi.dwSize.Y;
        COORD homeCoords = { 0, 0 };
        DWORD count;

        FillConsoleOutputCharacter(hConsole, ' ', cellCount, homeCoords, &count);
        FillConsoleOutputAttribute(hConsole, csbi.wAttributes, cellCount, homeCoords, &count);
        SetConsoleCursorPosition(hConsole, homeCoords);
    }

    // Opened fresh above (unlike GetStdHandle's handle, which belongs to
    // the system) -- ours to close.
    CloseHandle(hConsole);
}

void debugPrintPath(Point* path, int numPoints) {
    printf("\n[DEBUG] Path Analysis: %d points identified.\n", numPoints);

    if (numPoints <= 0 || path == NULL) {
        printf("  -> Error: Path data invalid or empty.\n\n");
        return;
    }

    // Using field width specifiers:
    // %5d: Pad to 5 spaces (index)
    // %6d: Pad to 6 spaces (x coord)
    // %6d: Pad to 6 spaces (y coord)
    printf("  Index |     X |     Y\n");
    printf("-------------------------\n");

    for (int i = 0; i < numPoints; i++) {
        // Logic check: only print start, end, or increments of 100
        if (i == 0 || (i % 100 == 0) || (i == numPoints - 1)) {
            printf("  %5d | %5d | %5d\n", i, path[i].x, path[i].y);
        }
    }

    printf("-------------------------\n");
    printf("[DEBUG] End of trace.\n\n");
}

void debugPrintSegments(ArcSegment* segments, int count)
{
    printf("\n[DEBUG] Arc Segmentation: %d segment(s) found.\n", count);

    if (count <= 0 || segments == NULL) {
        printf("  -> No segments to display.\n\n");
        return;
    }

    printf("  Seg |  Points |    Center (x, y)    | Radius  | Avg Curvature\n");
    printf("----------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        ArcSegment s = segments[i];
        printf("  %3d | %7d | (%7.2f, %7.2f) | %7.2f | %13.5f\n",
               i, s.count, s.circle.cx, s.circle.cy, s.circle.r, s.avgCurvature);
    }

    printf("----------------------------------------------------------------\n");
    printf("[DEBUG] End of segmentation.\n\n");
}
