﻿#include "canvas_bridge.h"
#include "ui_state.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define ARC_PI 3.14159265358979323846

// world<->pixel mapping used by canvasToImage's rasterization below (and,
// through it, everything View Segments/Comparison Mode/ground-collision
// tracing produces) -- FIXED per trace, from the drawing's OWN bounding
// box, deliberately NOT the live camera's canvas.zoom/panX/panY the way
// this used to work. The old version reprojected strokes through
// whatever the on-screen view happened to be at trace time: zoom out and
// the raster (still just w x h pixels) had to cover more world space per
// pixel, losing precision; zoom in past the point where part of a stroke
// scrolled off screen and that part fell outside [0,w)x[0,h) entirely --
// stampDisc/stampSegment's own bounds check (setBinPixel) silently
// dropped it, so View Segments' ghost overlay was missing whatever
// wasn't currently in view. Tracing off a fixed bounding box instead
// means the WHOLE drawing is always captured at one consistent
// resolution, independent of wherever the camera happens to be pointed.
// computeTraceBounds (below) sets g_traceOriginX/Y/g_tracePxPerWorld once
// per canvasToImage call; pixelToWorldExact (the inverse, used when
// converting traced points back to world space) reads the same three.
static float g_traceOriginX = 0.0f;
static float g_traceOriginY = 0.0f;
static float g_tracePxPerWorld = 1.0f; // pixels per world unit -- ONE value for both axes (isotropic), so a drawn circle traces back out as a circle, not an ellipse

// Smallest world-unit span computeTraceBounds will ever fit the raster
// to, so a degenerate drawing (a single dot, or every point on one exact
// horizontal/vertical line) can't collapse a span to 0 and blow up
// g_tracePxPerWorld into infinity/NaN.
#define TRACE_MIN_WORLD_SPAN 0.05f

// Scans every point in every stroke (points[]/canvas.pointCount, already
// flat across strokes) for its world-space bounding box, then derives the
// fixed mapping worldToPixel/pixelToWorldExact use to fit that box into a
// w x h raster -- letterboxed (whichever axis is tighter wins the shared
// scale) and centered, with a margin wide enough that a stroke's own
// rendered THICKNESS (stamped as a disc/ribbon around each point, not
// just the bare point itself) never gets clipped by sitting right at the
// raster's edge. Called once per canvasToImage, before any stamping.
static void computeTraceBounds(int w, int h)
{
    if (canvas.pointCount < 2) {
        // Nothing (or a single point) to bound -- values here don't
        // matter, canvasToImage's own stroke loop has nothing to stamp.
        g_traceOriginX = 0.0f;
        g_traceOriginY = 0.0f;
        g_tracePxPerWorld = 1.0f;
        return;
    }

    float minX = points[0], maxX = points[0];
    float minY = points[1], maxY = points[1];

    // canvas.pointCount is a FLOAT index (2 floats per point, see
    // canvas.c's WM_LBUTTONDOWN/WM_MOUSEMOVE -- it's incremented twice per
    // point, once for x and once for y, same convention strokeStarts[]
    // uses), so it's already the right bound for a straight for-loop here.
    for (int i = 0; i < canvas.pointCount; i += 2) {
        float x = points[i], y = points[i + 1];
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
    }

    // Margin, in WORLD units, sized off the thickest stroke currently on
    // the canvas -- strokeThickness[] is the same raw slider-pixel value
    // canvas.c's real-stroke render divides by glWindowWidth (at zoom==1)
    // to get a world-unit half-width, so this approximates that same
    // conversion; doubled since this only needs to be generous enough to
    // avoid clipping, not exact.
    float maxThicknessPx = 1.0f;
    for (int s = 0; s < canvas.strokeCount; s++)
        if (strokeThickness[s] > maxThicknessPx) maxThicknessPx = strokeThickness[s];

    float margin = (maxThicknessPx / (float)w) * 2.0f;

    minX -= margin; maxX += margin;
    minY -= margin; maxY += margin;

    float spanX = maxX - minX;
    float spanY = maxY - minY;
    if (spanX < TRACE_MIN_WORLD_SPAN) spanX = TRACE_MIN_WORLD_SPAN;
    if (spanY < TRACE_MIN_WORLD_SPAN) spanY = TRACE_MIN_WORLD_SPAN;

    // Isotropic scale: fit whichever axis is tighter against the raster,
    // same letterboxing idea the live camera's own aspect handling uses
    // elsewhere, just computed against the DRAWING's box instead of the
    // window's.
    float scaleX = (float)w / spanX;
    float scaleY = (float)h / spanY;
    g_tracePxPerWorld = (scaleX < scaleY) ? scaleX : scaleY;

    // Origin = the bounding box's own center -- the world point that
    // lands at pixel (w/2, h/2), so the drawing sits centered in the
    // raster with equal letterbox margin on whichever axis has slack.
    g_traceOriginX = (minX + maxX) * 0.5f;
    g_traceOriginY = (minY + maxY) * 0.5f;
}

static void worldToPixel(float wx, float wy, int w, int h, float* px, float* py)
{
    *px = (w / 2.0f) + (wx - g_traceOriginX) * g_tracePxPerWorld;
    // Y flipped: screen pixels grow downward, world Y grows upward.
    *py = (h / 2.0f) - (wy - g_traceOriginY) * g_tracePxPerWorld;
}

// px/py are PIXEL-INDEX-space coordinates (an integer i means "pixel i",
// spanning the continuous range [i, i+1)) -- the convention every caller
// in this file actually uses: raw traced path points (integer pixel
// indices from the skeletonized stroke), a fitted circle's cx/cy (fit
// against those same raw indices, so it inherits the same convention),
// and arc points sampled off that circle all live in this space. Adding
// 0.5 here converts an index to that pixel's CENTER -- the actual
// continuous position it represents -- matching canvasToImage's own
// rasterization convention (stampDisc/stampSegment test each candidate
// pixel's CENTER, (x+0.5, y+0.5), against the stroke). Without this, every
// reconstructed point comes out exactly half a pixel short in each axis:
// since Y is flipped (screen grows down, world grows up), that shows up
// as the reconstructed line sitting visibly ABOVE a horizontal stroke and
// LEFT of a vertical one -- never below/right -- which is exactly the
// direction the missing offset predicts.
static void pixelToWorldExact(float px, float py, int w, int h, float* wx, float* wy)
{
    px += 0.5f;
    py += 0.5f;

    // Exact inverse of worldToPixel above -- same fixed, drawing-bounding-
    // box-derived g_traceOriginX/Y/g_tracePxPerWorld (set once per trace
    // by computeTraceBounds), not the live camera. w/h still matter here
    // (pixel (w/2, h/2) is where g_traceOrigin lands, same as
    // worldToPixel), they just no longer feed an aspect/zoom calculation
    // directly -- computeTraceBounds already baked this same w/h into
    // g_tracePxPerWorld, so this only has to undo the half-width/height
    // offset and the shared scale.
    *wx = g_traceOriginX + (px - w / 2.0f) / g_tracePxPerWorld;
    *wy = g_traceOriginY - (py - h / 2.0f) / g_tracePxPerWorld;
}

// Uses the FIXED bg bounds, so no canvas.zoom/pan math needed here —
// pan/canvas.zoom are applied uniformly later by the shared render pipeline
//
// Same pixel-index-to-pixel-center +0.5 correction as pixelToWorldExact
// above, for the same reason (this is the "uploaded BMP" counterpart --
// every call site picks one or the other via the same `stretched` flag,
// feeding both the exact same px/py, so both need the same fix).
static void pixelToWorldStretched(float px, float py, int imgW, int imgH, float* wx, float* wy)
{
    px += 0.5f;
    py += 0.5f;

    float u = px / (float)imgW;
    float v = 1.0f - (py / (float)imgH);

    *wx = bgLeft + u * (bgRight - bgLeft);
    *wy = bgBottom + v * (bgTop - bgBottom);
}

void addBranchMarker(int imgW, int imgH, int px, int py, BOOL stretched)
{
    if (branchMarkerCount >= MAX_BRANCH_MARKERS) return;

    float wx, wy;
    if (stretched) {
        pixelToWorldStretched((float)px, (float)py, imgW, imgH, &wx, &wy);
    } else {
        pixelToWorldExact((float)px, (float)py, imgW, imgH, &wx, &wy);
    }

    branchMarkersWorld[branchMarkerCount * 2]     = wx;
    branchMarkersWorld[branchMarkerCount * 2 + 1] = wy;
    branchMarkerCount++;

    if (hWndGL) InvalidateRect(hWndGL, NULL, FALSE);
}

static void setBinPixel(Image* img, int x, int y, float r)
{
    if (x < 0 || y < 0 || x >= img->width || y >= img->height) return;

    int idx = y * img->width + x;
    img->bin[idx] = 1;

    // Record the EXACT half-thickness this pixel was stamped with (see
    // bmp.h's own comment on Image.radius) -- only when the caller
    // actually has one (canvasToImage's hand-drawn strokes; NULL for an
    // uploaded BMP raster, which never calls stampDisc/stampSegment at
    // all, so this is purely defensive).
    if (img->radius) img->radius[idx] = r;

    if (img->data)   // NULL for canvasInkMask's mask-only image
    {
        img->data[idx * 3 + 0] = 0; // B
        img->data[idx * 3 + 1] = 0; // G
        img->data[idx * 3 + 2] = 0; // R
    }
}

static void stampDisc(Image* img, float cx, float cy, float r)
{
    int minX = (int)floorf(cx - r);
    int maxX = (int)ceilf(cx + r);
    int minY = (int)floorf(cy - r);
    int maxY = (int)ceilf(cy + r);

    for (int y = minY; y <= maxY; y++) {
        for (int x = minX; x <= maxX; x++) {
            float dx = (x + 0.5f) - cx;
            float dy = (y + 0.5f) - cy;
            if (dx * dx + dy * dy <= r * r) {
                setBinPixel(img, x, y, r);
            }
        }
    }
}

// Every pixel whose CENTER is within r of the segment (a capsule), not a
// row of discs stamped every half pixel along it. The disc version's width
// depended on how the stamps happened to line up with the pixel rows, and
// that drifted along the line (the step is len/ceil(len/0.5), not exactly
// 0.5): a real report's short vertical riser came out 2 px wide near the
// floor and 1 px wide further up, so the traced line tilted toward the
// wide part. A capsule is the exact shape of a stroke and has the same
// width everywhere.
static void stampSegment(Image* img, float x0, float y0, float x1, float y1, float r)
{
    float dx = x1 - x0;
    float dy = y1 - y0;
    float len2 = dx * dx + dy * dy;

    if (len2 < 1e-6f) {
        stampDisc(img, x0, y0, r);
        return;
    }

    int minY = (int)floorf(((y0 < y1) ? y0 : y1) - r);
    int maxY = (int)ceilf(((y0 > y1) ? y0 : y1) + r);
    if (minY < 0) minY = 0;
    if (maxY > img->height - 1) maxY = img->height - 1;
    double len = sqrt((double)len2);
    double ux = dx / len, uy = dy / len;       // along the segment
    double nx = -uy, ny = ux;                   // across it
    double rr = r;

    // The capsule is convex, so each pixel row's centre line (y + 0.5)
    // crosses it in ONE interval of x: the union of where it crosses the
    // two end discs and the straight band between them. Only that interval
    // is filled, so the cost is the stroke's own area, not its bounding
    // box (which is huge for a long diagonal, and this also renders the
    // finer canvasInkMask).
    for (int y = minY; y <= maxY; y++) {
        double py = y + 0.5;
        double lo = 1e30, hi = -1e30;

        // End discs.
        for (int e = 0; e < 2; e++) {
            double cx = e ? x1 : x0, cy = e ? y1 : y0;
            double h2 = rr * rr - (py - cy) * (py - cy);
            if (h2 < 0.0) continue;
            double hw = sqrt(h2);
            if (cx - hw < lo) lo = cx - hw;
            if (cx + hw > hi) hi = cx + hw;
        }

        // Band: |(p - p0).n| <= r and 0 <= (p - p0).u <= len, solved for px
        // on this row (each is a linear inequality in px).
        {
            double bLo = -1e30, bHi = 1e30;
            BOOL empty = FALSE;
            // (px - x0) * k + c with k = nx or ux
            double k1 = nx, c1 = (py - y0) * ny;        // -r <= k1*(px-x0) + c1 <= r
            double k2 = ux, c2 = (py - y0) * uy;        //  0 <= k2*(px-x0) + c2 <= len
            double lims[2][3] = { { k1, c1 - rr, c1 + rr }, { k2, c2 - len, c2 } };
            for (int q = 0; q < 2 && !empty; q++) {
                double k = lims[q][0];
                // need  -(c+..) : lower <= k*X <= upper with X = px - x0,
                // lower = -(c + r) ... written as: -c - r <= k X <= -c + r
                double lower = -lims[q][2], upper = -lims[q][1];
                if (fabs(k) < 1e-12) {
                    if (lower > 0.0 || upper < 0.0) empty = TRUE;   // row entirely outside
                } else {
                    double a = lower / k, b = upper / k;
                    if (a > b) { double t = a; a = b; b = t; }
                    if (a + x0 > bLo) bLo = a + x0;
                    if (b + x0 < bHi) bHi = b + x0;
                }
            }
            if (!empty && bLo <= bHi) {
                if (bLo < lo) lo = bLo;
                if (bHi > hi) hi = bHi;
            }
        }

        if (lo > hi) continue;
        // Pixel centres x + 0.5 inside [lo, hi].
        int xa = (int)ceil(lo - 0.5 - 1e-9), xb = (int)floor(hi - 0.5 + 1e-9);
        if (xa < 0) xa = 0;
        if (xb > img->width - 1) xb = img->width - 1;
        for (int x = xa; x <= xb; x++)
            setBinPixel(img, x, y, r);
    }
}

// Sub-pixel arc sample point - deliberately NOT the int-based Point type used
// for traced pixel paths. See note below.
// Named SampleF rather than PointF to avoid colliding with geometry.h's
// PointF (the unrelated robot-joint float point type, now merged into
// geometry.h alongside this pixel-domain code).
typedef struct { float x, y; } SampleF;

// s0x/s0y and s1x/s1y are the ink re-centering shifts (see ArcSegment's
// inkShift fields) to apply at the first and last point -- computed by
// computeEndShifts so neighbouring segments get the same shift at the
// pixel they share and still meet exactly.
static void sampleArcPoints(ArcSegment* seg, SampleF* outPts, int* outCount, int maxOut,
                            float s0x, float s0y, float s1x, float s1y)
{
    Circle c = seg->circle;
    c.r += seg->inkShiftR;   // ink re-centering (0 for straight segments)

    if (c.r < 1e-3f) {
        // degenerate/near-straight segment - no meaningful circle to sample
        // from, so fit a straight line instead: interpolate evenly between
        // the segment's two raw endpoint pixels (p0/p1), the same way the
        // circle branch below samples evenly by ANGLE around its fitted
        // circle rather than using raw traced pixels directly.
        //
        // This used to copy raw seg->pts[idx] pixels straight through.
        // Those are the THINNED SKELETON's actual integer pixel positions,
        // which -- for anything but a perfectly axis-aligned line -- zigzag
        // in a staircase pattern (a 1px-wide raster line can only ever move
        // in whole-pixel steps). canvas.c's ribbon renderer derives each
        // vertex's extrusion NORMAL from the direction to its neighboring
        // vertex; on a short/steep segment (few raw points, so little
        // averaging-out of the zigzag between consecutive sampled points)
        // that per-step direction is often purely horizontal or purely
        // vertical instead of the line's true diagonal direction. Extruding
        // by halfW along that wrong-angle normal is never WIDER than the
        // correct perpendicular extrusion (off by a cos(theta) <= 1
        // factor), so the ribbon reads as visibly thinner than the
        // original stroke -- exactly the "still thinner, but only for
        // straight lines" symptom, since width MEASUREMENT (avgRadiusPx,
        // pipeline.c) is unbiased and the circle branch below already
        // samples smooth analytic positions instead of raw pixels.
        Point p0 = seg->pts[0];
        Point p1 = seg->pts[seg->count - 1];
        int sampleCount = (maxOut < 24) ? maxOut : 24;
        if (sampleCount < 2) sampleCount = 2;

        float ax = (float)p0.x + s0x, ay = (float)p0.y + s0y;
        float bx = (float)p1.x + s1x, by = (float)p1.y + s1y;
        for (int i = 0; i < sampleCount; i++) {
            float t = (float)i / (float)(sampleCount - 1);
            outPts[i].x = ax + (bx - ax) * t;
            outPts[i].y = ay + (by - ay) * t;
        }
        *outCount = sampleCount;
        return;
    }

    Point p0 = seg->pts[0];
    Point p1 = seg->pts[seg->count - 1];

    // Sweep between the ends as they'll actually be drawn (pixel + shift;
    // a line-arc corner can move them a few pixels, see
    // refineStraightSegmentEnds), so the arc doesn't double back.
    double a0 = atan2(p0.y + s0y - c.cy, p0.x + s0x - c.cx);
    double a1 = atan2(p1.y + s1y - c.cy, p1.x + s1x - c.cx);

    double diff = a1 - a0;
    while (diff > ARC_PI)  diff -= 2.0 * ARC_PI;
    while (diff < -ARC_PI) diff += 2.0 * ARC_PI;

    // The shortest way from a0 to a1 is only right for arcs under 180 deg.
    // For a (near-)semicircle or a bigger arc it can pick the OTHER side of
    // the circle, drawing the curve mirrored across its chord (seen on an
    // S-curve's half-circles at some window sizes). The traced pixels know
    // which side the stroke actually went: if the middle traced pixel isn't
    // inside the short sweep, take the long way round instead.
    if (seg->count >= 3)
    {
        Point pm = seg->pts[seg->count / 2];
        double am = atan2(pm.y - c.cy, pm.x - c.cx);
        double rel = am - a0;                      // angle of the midpoint, measured from a0 in diff's direction
        if (diff < 0.0) rel = -rel;
        while (rel < 0.0)            rel += 2.0 * ARC_PI;
        while (rel >= 2.0 * ARC_PI)  rel -= 2.0 * ARC_PI;
        if (rel > fabs(diff))                      // midpoint lies outside the short sweep
            diff = (diff > 0.0) ? diff - 2.0 * ARC_PI : diff + 2.0 * ARC_PI;
    }

    int steps = (maxOut < 24) ? maxOut : 24;

    for (int i = 0; i < steps; i++) {
        double t = (double)i / (double)(steps - 1);
        double a = a0 + diff * t;
        // NEW: keep sub-pixel precision here - these come from an analytic
        // circle fit (float cx/cy/r), not from the traced pixel grid, so
        // there's no reason to snap them to whole source-image pixels.
        // Doing so used to be invisible for hand-drawn strokes (traced at
        // full window resolution, so 1px error is negligible) but very
        // visible for uploaded BMPs, where the curve can occupy only a
        // few dozen source pixels before being stretched to fill the
        // window - the same 1px snap becomes a visible staircase.
        outPts[i].x = (float)(c.cx + c.r * cos(a));
        outPts[i].y = (float)(c.cy + c.r * sin(a));
    }

    // NEW: force the two ends of this sampled arc to be the EXACT raw path
    // pixel (p0/p1), not their circle-projected position. p0/p1 are
    // themselves ordinary pixels from the single shared path buffer, and
    // buildSegments's recursive split always hands the two halves of a run
    // a literal shared boundary point (out[i].pts/out[i+1].pts overlap by
    // exactly that one Point) -- so the neighboring segment on either side
    // of this one has that exact same raw pixel as ITS p1/p0. But each
    // segment fits its OWN circle independently, and that fit is rarely
    // perfect (residual up to ARC_FIT_TOLERANCE), so projecting the shared
    // point onto two different circles yields two slightly different
    // world positions - a visible gap in the reconstructed ribbon
    // (segmentPointsWorld), since canvas.c draws each segment's ribbon
    // separately. Snapping both ends back to the one raw pixel they
    // actually share makes adjacent segments meet at a bit-identical
    // world coordinate; only the interior of the arc still follows the
    // fitted circle.
    outPts[0].x        = (float)p0.x + s0x;
    outPts[0].y        = (float)p0.y + s0y;
    outPts[steps - 1].x = (float)p1.x + s1x;
    outPts[steps - 1].y = (float)p1.y + s1y;

    *outCount = steps;
}

// ---- Straight-segment refinement (exact corners) ----
//
// A straight segment used to be drawn from its first traced pixel to its
// last one. At a corner those two pixels are wherever the corner split
// happened to land -- on a 2 px stroke easily 1-2 px along the neighbouring
// line -- so a short vertical riser between two floors came out visibly
// tilted. Instead, each straight segment gets a least-squares line fitted to
// its traced pixels (ignoring a few pixels at each end, which are the ones
// bent by the corner), and two straight neighbours meet exactly where their
// fitted lines intersect. Free ends are projected onto the fitted line;
// ends shared with an arc stay on the shared pixel so nothing disconnects.

#define LINE_REFINE_TRIM_PX       4     // traced pixels ignored at each end for the fit
#define LINE_REFINE_MIN_ANGLE_DEG 10.0  // below this two lines are ~collinear: keep the shared pixel
#define LINE_REFINE_MAX_SHIFT_PX  6.0   // never move a corner further than this from its traced pixel

typedef struct { int valid; double cx, cy, dx, dy; } FittedLine;

static FittedLine fitLineToPixels(const Point* pts, int n)
{
    FittedLine L = { 0 };
    int trim = LINE_REFINE_TRIM_PX;
    if (n - 2 * trim < 3) trim = (n - 3) / 2;
    if (trim < 0) trim = 0;
    int a = trim, b = n - 1 - trim;
    if (b - a + 1 < 2) return L;

    double mx = 0, my = 0;
    for (int i = a; i <= b; i++) { mx += pts[i].x; my += pts[i].y; }
    int m = b - a + 1;
    mx /= m; my /= m;
    double sxx = 0, syy = 0, sxy = 0;
    for (int i = a; i <= b; i++)
    {
        double ux = pts[i].x - mx, uy = pts[i].y - my;
        sxx += ux * ux; syy += uy * uy; sxy += ux * uy;
    }
    // Principal direction of the pixel cloud (total least squares).
    double ang = 0.5 * atan2(2.0 * sxy, sxx - syy);
    L.valid = 1; L.cx = mx; L.cy = my; L.dx = cos(ang); L.dy = sin(ang);
    return L;
}

static void projectOntoLine(const FittedLine* L, double px, double py, float* ox, float* oy)
{
    double t = (px - L->cx) * L->dx + (py - L->cy) * L->dy;
    *ox = (float)(L->cx + L->dx * t);
    *oy = (float)(L->cy + L->dy * t);
}

// Ink re-centering shift (pixels) to apply at each segment's first and
// last point. A straight segment moves by its inkShiftX/Y everywhere; an
// arc's radius grows by inkShiftR, which moves each end along its own
// radial direction. Where two segments of the same traced path share a
// pixel, both get the AVERAGE of their two shifts there, so they still
// meet at one identical point after re-centering.
static void computeEndShifts(const ArcSegment* segs, int count,
                             float* s0x, float* s0y, float* s1x, float* s1y)
{
    for (int s = 0; s < count; s++)
    {
        s0x[s] = s0y[s] = s1x[s] = s1y[s] = 0.0f;
        if (segs[s].count < 1) continue;
        if (segs[s].circle.r > 1e-3f)
        {
            Point p0 = segs[s].pts[0], p1 = segs[s].pts[segs[s].count - 1];
            float dr = segs[s].inkShiftR;
            float ax = p0.x - segs[s].circle.cx, ay = p0.y - segs[s].circle.cy;
            float bx = p1.x - segs[s].circle.cx, by = p1.y - segs[s].circle.cy;
            float al = sqrtf(ax * ax + ay * ay), bl = sqrtf(bx * bx + by * by);
            if (al > 1e-3f) { s0x[s] = dr * ax / al; s0y[s] = dr * ay / al; }
            if (bl > 1e-3f) { s1x[s] = dr * bx / bl; s1y[s] = dr * by / bl; }
        }
        else
        {
            s0x[s] = s1x[s] = segs[s].inkShiftX;
            s0y[s] = s1y[s] = segs[s].inkShiftY;
        }
    }
    for (int s = 0; s + 1 < count; s++)
    {
        if (segs[s].pts + (segs[s].count - 1) != segs[s + 1].pts) continue;
        float jx = 0.5f * (s1x[s] + s0x[s + 1]);
        float jy = 0.5f * (s1y[s] + s0y[s + 1]);
        s1x[s] = s0x[s + 1] = jx;
        s1y[s] = s0y[s + 1] = jy;
    }
}

// Line-to-arc corners: the traced pixel where a line hands over to an arc
// is wherever the segment split landed, which on a sharp corner is often
// 2-3 px along the curve (a real report: 2.5 px at the join between a
// Shift-line and a hand-drawn curve). The actual bend is where the traced
// path turns hardest, so look a few pixels either side of the split for
// the sharpest turn (angle between the directions 3 px back and 3 px
// ahead) and put the corner there, projected onto the fitted line. A
// smooth, near-tangent join has no such turn, so it keeps the split pixel.
#define LINE_ARC_CORNER_SEARCH_PX 6
#define LINE_ARC_CORNER_ARM_PX    3
#define LINE_ARC_CORNER_MIN_DEG   20.0

// joint points at the shared pixel inside the path buffer; lo/hi (<= 0,
// >= 0) are how far the buffer extends behind/ahead of it.
static int sharpestTurnNear(const Point* joint, int lo, int hi, int* outK)
{
    double bestTurn = 0.0;
    int bestK = 0;
    const int arm = LINE_ARC_CORNER_ARM_PX;
    for (int k = -LINE_ARC_CORNER_SEARCH_PX; k <= LINE_ARC_CORNER_SEARCH_PX; k++)
    {
        if (k - arm < lo || k + arm > hi) continue;
        double v1x = joint[k].x - joint[k - arm].x, v1y = joint[k].y - joint[k - arm].y;
        double v2x = joint[k + arm].x - joint[k].x, v2y = joint[k + arm].y - joint[k].y;
        double l1 = hypot(v1x, v1y), l2 = hypot(v2x, v2y);
        if (l1 < 1e-9 || l2 < 1e-9) continue;
        double cosA = (v1x * v2x + v1y * v2y) / (l1 * l2);
        if (cosA > 1.0) cosA = 1.0;
        if (cosA < -1.0) cosA = -1.0;
        double turn = acos(cosA);
        if (turn > bestTurn) { bestTurn = turn; bestK = k; }
    }
    if (bestTurn * 180.0 / ARC_PI < LINE_ARC_CORNER_MIN_DEG) return 0;
    *outK = bestK;
    return 1;
}

// Fills startX/Y, endX/Y (source-image pixel coordinates) for every STRAIGHT
// segment; refined[s] = 1 when segment s got refined endpoints. Fitted lines
// are moved by the segment's ink re-centering shift. Joints:
//  - line + line: where the two fitted lines intersect;
//  - line + arc: the sharpest turn of the traced path near the split,
//    projected onto the fitted line (see sharpestTurnNear); the arc's own
//    end shift (s0x/s1x) is rewritten so it starts/ends there too;
//  - otherwise the joint pixel plus its shared shift (computeEndShifts).
static void refineStraightSegmentEnds(ArcSegment* segs, int count,
                                      float* startX, float* startY, float* endX, float* endY, int* refined,
                                      float* s0x, float* s0y, float* s1x, float* s1y)
{
    static FittedLine fl[MAX_ARC_SEGMENTS];
    for (int s = 0; s < count; s++)
    {
        refined[s] = 0;
        fl[s].valid = 0;
        if (segs[s].circle.r > 1e-3f || segs[s].count < 2) continue;
        if (segs[s].lineFitValid)
        {
            // Line through the middle of the ink band (pipeline.c's
            // measureInkCenterShift) -- already re-centered, and not
            // tilted by a skeleton that hops between the two middle
            // columns of an even-width stroke.
            fl[s].valid = 1;
            fl[s].cx = segs[s].lineFitCx; fl[s].cy = segs[s].lineFitCy;
            fl[s].dx = segs[s].lineFitDx; fl[s].dy = segs[s].lineFitDy;
        }
        else
        {
            fl[s] = fitLineToPixels(segs[s].pts, segs[s].count);
            if (!fl[s].valid) continue;
            fl[s].cx += segs[s].inkShiftX;   // ink re-centering
            fl[s].cy += segs[s].inkShiftY;
        }
        refined[s] = 1;
        Point p0 = segs[s].pts[0], p1 = segs[s].pts[segs[s].count - 1];
        projectOntoLine(&fl[s], p0.x, p0.y, &startX[s], &startY[s]);
        projectOntoLine(&fl[s], p1.x, p1.y, &endX[s], &endY[s]);
    }

    for (int s = 0; s + 1 < count; s++)
    {
        // Only neighbours on the same traced path, sharing their joint pixel.
        if (segs[s].pts + (segs[s].count - 1) != segs[s + 1].pts) continue;
        Point jointPx = segs[s + 1].pts[0];
        // The shared pixel, moved by the joint's shared re-centering shift.
        struct { double x, y; } joint = { jointPx.x + s1x[s], jointPx.y + s1y[s] };

        if (refined[s] && refined[s + 1])
        {
            double cr = fl[s].dx * fl[s + 1].dy - fl[s].dy * fl[s + 1].dx;   // sin of the angle between them
            double ix = joint.x, iy = joint.y;
            if (fabs(cr) > sin(LINE_REFINE_MIN_ANGLE_DEG * ARC_PI / 180.0))
            {
                double qx = fl[s + 1].cx - fl[s].cx, qy = fl[s + 1].cy - fl[s].cy;
                double t = (qx * fl[s + 1].dy - qy * fl[s + 1].dx) / cr;
                double cx = fl[s].cx + fl[s].dx * t, cy = fl[s].cy + fl[s].dy * t;
                if (hypot(cx - joint.x, cy - joint.y) <= LINE_REFINE_MAX_SHIFT_PX) { ix = cx; iy = cy; }
            }
            endX[s] = startX[s + 1] = (float)ix;
            endY[s] = startY[s + 1] = (float)iy;
        }
        else
        {
            double ix = joint.x, iy = joint.y;

            int lineIdx = -1;
            if (refined[s] && segs[s + 1].circle.r > 1e-3f)      lineIdx = s;
            else if (refined[s + 1] && segs[s].circle.r > 1e-3f) lineIdx = s + 1;
            if (lineIdx >= 0)
            {
                // Line next to an arc: corner at the path's sharpest turn.
                const Point* jp = segs[s + 1].pts;
                int k;
                if (sharpestTurnNear(jp, -(segs[s].count - 1), segs[s + 1].count - 1, &k))
                {
                    float px, py;
                    projectOntoLine(&fl[lineIdx], jp[k].x, jp[k].y, &px, &py);
                    if (hypot(px - jointPx.x, py - jointPx.y) <= LINE_REFINE_MAX_SHIFT_PX) { ix = px; iy = py; }
                }
            }

            if (refined[s])     { endX[s] = (float)ix;       endY[s] = (float)iy; }
            if (refined[s + 1]) { startX[s + 1] = (float)ix; startY[s + 1] = (float)iy; }
            // An arc's end is drawn at pixel + shift (sampleArcPoints), so
            // store the joint as that shift.
            s1x[s] = s0x[s + 1] = (float)(ix - jointPx.x);
            s1y[s] = s0y[s + 1] = (float)(iy - jointPx.y);
        }
    }
}

float segmentInkShiftDebug[MAX_ARC_SEGMENTS * 3];
float traceRasterPxPerWorld(void) { return g_tracePxPerWorld; }

void setSegmentOverlay(ArcSegment* segments, int count, int imgW, int imgH, BOOL stretched)
{
    int total = 0;
    int usedSegments = 0;

    static float lineStartX[MAX_ARC_SEGMENTS], lineStartY[MAX_ARC_SEGMENTS];
    static float lineEndX[MAX_ARC_SEGMENTS], lineEndY[MAX_ARC_SEGMENTS];
    static int lineRefined[MAX_ARC_SEGMENTS];
    static float shiftS0X[MAX_ARC_SEGMENTS], shiftS0Y[MAX_ARC_SEGMENTS];
    static float shiftS1X[MAX_ARC_SEGMENTS], shiftS1Y[MAX_ARC_SEGMENTS];
    int refineCount = (count < MAX_ARC_SEGMENTS) ? count : MAX_ARC_SEGMENTS;
    computeEndShifts(segments, refineCount, shiftS0X, shiftS0Y, shiftS1X, shiftS1Y);
    refineStraightSegmentEnds(segments, refineCount, lineStartX, lineStartY, lineEndX, lineEndY, lineRefined,
                              shiftS0X, shiftS0Y, shiftS1X, shiftS1Y);

    for (int s = 0; s < count && s < MAX_ARC_SEGMENTS; s++)
    {
        SampleF arcPts[24];
        int arcCount = 0;
        sampleArcPoints(&segments[s], arcPts, &arcCount, 24,
                        shiftS0X[s], shiftS0Y[s], shiftS1X[s], shiftS1Y[s]);

        // Straight segment: redraw it between its refined endpoints (fitted
        // line, exact corners -- see refineStraightSegmentEnds).
        if (lineRefined[s] && arcCount >= 2)
        {
            for (int i = 0; i < arcCount; i++)
            {
                float t = (float)i / (float)(arcCount - 1);
                arcPts[i].x = lineStartX[s] + (lineEndX[s] - lineStartX[s]) * t;
                arcPts[i].y = lineStartY[s] + (lineEndY[s] - lineStartY[s]) * t;
            }
        }

        if (arcCount < 2) continue;
        if (total + arcCount > MAX_SEGMENT_POINTS) break;

        segmentStarts[usedSegments] = total;
        segmentCounts[usedSegments] = arcCount;
        segmentInkShiftDebug[usedSegments * 3]     = segments[s].inkShiftX;
        segmentInkShiftDebug[usedSegments * 3 + 1] = segments[s].inkShiftY;
        segmentInkShiftDebug[usedSegments * 3 + 2] = segments[s].inkShiftR;

        // NEW: ghost circle in world space - the FULL circle this arc was cut
        // from, not just the sampled arc points. Same pixel->world helpers
        // used for the arc points above, so it lines up exactly with them.
        //
        // NOTE: in "stretched" mode the background image is scaled by
        // different factors along x and y to fill the window (see
        // pixelToWorldStretched), so a pixel-space circle maps to an
        // ELLIPSE in world space, not a circle. Sample an offset point
        // along each axis separately and keep two radii - using a single
        // radius for both axes (the old behavior) made the ghost circle
        // drift away from the actual arc except where it happened to touch
        // the x-offset sample point.
        Circle c = segments[s].circle;
        if (c.r > 1e-3f) c.r += segments[s].inkShiftR;   // same re-centered radius the arc is drawn with
        if (c.r > 1e-3f) {
            float wcx, wcy, wrx, wry, wrxY, wryY;
            if (stretched) {
                pixelToWorldStretched(c.cx, c.cy, imgW, imgH, &wcx, &wcy);
                pixelToWorldStretched(c.cx + c.r, c.cy, imgW, imgH, &wrx, &wry);
                pixelToWorldStretched(c.cx, c.cy + c.r, imgW, imgH, &wrxY, &wryY);
            } else {
                pixelToWorldExact(c.cx, c.cy, imgW, imgH, &wcx, &wcy);
                pixelToWorldExact(c.cx + c.r, c.cy, imgW, imgH, &wrx, &wry);
                pixelToWorldExact(c.cx, c.cy + c.r, imgW, imgH, &wrxY, &wryY);
            }
            float rdx = wrx - wcx;
            float rdy = wry - wcy;
            float rdxY = wrxY - wcx;
            float rdyY = wryY - wcy;
            segmentCircleCenterWorld[usedSegments * 2]     = wcx;
            segmentCircleCenterWorld[usedSegments * 2 + 1] = wcy;
            segmentCircleRadiusWorld[usedSegments]         = sqrtf(rdx * rdx + rdy * rdy);
            segmentCircleRadiusWorldY[usedSegments]        = sqrtf(rdxY * rdxY + rdyY * rdyY);
        } else {
            segmentCircleRadiusWorld[usedSegments]  = 0.0f; // straight/degenerate - no ghost circle
            segmentCircleRadiusWorldY[usedSegments] = 0.0f;
        }

        // This segment's original stroke thickness, converted to the SAME
        // unit strokeThickness[] (canvas.c) is in -- NOT the same as
        // avgRadiusPx itself. canvasToImage stamps the raster this was
        // measured from using strokeThickness[s]/2 as the RADIUS, so
        // avgRadiusPx (measured directly off that raster) comes back as
        // roughly HALF of strokeThickness[s] -- but canvas.c's real strokes
        // render on screen using strokeThickness[s] directly, un-halved, as
        // the half-width (halfW = strokeThickness[s] * canvas.zoom /
        // glWindowWidth -- see canvas.c's stroke render loop). Plugging
        // avgRadiusPx straight into that same formula (which is what the
        // segment ghost overlay/BMP export both do) would render every
        // reconstructed line at HALF its true on-screen weight -- doubling
        // it here is what actually corrects that, not just carries the
        // measurement through.
        float srcRadiusPx = (segments[s].avgRadiusPx > 0.0f) ? segments[s].avgRadiusPx : 1.0f;
        segmentAvgRadiusPx[usedSegments] = srcRadiusPx * 2.0f;

        // Same VISUAL half-width segmentAvgRadiusPx just stored (note: the
        // DOUBLED value, not srcRadiusPx alone -- using srcRadiusPx here
        // would only convert HALF of the line's actual rendered thickness
        // into world units, leaving collision under-compensated by exactly
        // half of what's needed and the robot stopping visibly short of
        // the real surface), but converted into an actual WORLD-SPACE (EWS)
        // length instead of kept as a raw pixel count -- for Simulation's
        // ground collision (canvas.c's pointCollidesWithAnyEnvironmentStroke),
        // which works entirely in EWS units (segmentPointsWorld's own
        // space), not screen pixels. Without this, collision tests the
        // robot against this segment's bare mathematical CENTERLINE while
        // the reconstructed line is actually RENDERED with real thickness
        // around that centerline -- meaning the robot's contact point
        // tracks an invisible line instead of the visible surface it's
        // approaching. Same "offset a point by the pixel amount, see how
        // far it moved in world space" technique as the ghost circle
        // radius above.
        {
            float renderedRadiusPx = segmentAvgRadiusPx[usedSegments]; // == srcRadiusPx * 2.0f
            float refX = arcPts[0].x, refY = arcPts[0].y;
            float wpx, wpy, wrx, wry, wrxY, wryY;
            if (stretched) {
                pixelToWorldStretched(refX, refY, imgW, imgH, &wpx, &wpy);
                pixelToWorldStretched(refX + renderedRadiusPx, refY, imgW, imgH, &wrx, &wry);
                pixelToWorldStretched(refX, refY + renderedRadiusPx, imgW, imgH, &wrxY, &wryY);
            } else {
                pixelToWorldExact(refX, refY, imgW, imgH, &wpx, &wpy);
                pixelToWorldExact(refX + renderedRadiusPx, refY, imgW, imgH, &wrx, &wry);
                pixelToWorldExact(refX, refY + renderedRadiusPx, imgW, imgH, &wrxY, &wryY);
            }
            float tdx = wrx - wpx, tdy = wry - wpy;
            float tdxY = wrxY - wpx, tdyY = wryY - wpy;
            float radiusWorldX = sqrtf(tdx * tdx + tdy * tdy);
            float radiusWorldY = sqrtf(tdxY * tdxY + tdyY * tdyY);
            segmentThicknessWorld[usedSegments] = (radiusWorldX + radiusWorldY) * 0.5f;
        }

        for (int i = 0; i < arcCount; i++)
        {
            float wx, wy;
            if (stretched)
                pixelToWorldStretched((float)arcPts[i].x, (float)arcPts[i].y, imgW, imgH, &wx, &wy);
            else
                pixelToWorldExact((float)arcPts[i].x, (float)arcPts[i].y, imgW, imgH, &wx, &wy);

            segmentPointsWorld[total * 2]     = wx;
            segmentPointsWorld[total * 2 + 1] = wy;
            total++;

            // Bounding box for Simulation's collision broad phase (see
            // segmentBoundsWorld in ui_state.h).
            float* b = &segmentBoundsWorld[usedSegments * 4];
            if (i == 0) { b[0] = b[2] = wx; b[1] = b[3] = wy; }
            else {
                if (wx < b[0]) b[0] = wx;
                if (wy < b[1]) b[1] = wy;
                if (wx > b[2]) b[2] = wx;
                if (wy > b[3]) b[3] = wy;
            }
        }

        usedSegments++;
    }

    canvas.segmentResultCount = usedSegments;
    if (hWndGL) InvalidateRect(hWndGL, NULL, FALSE);
}

uint8_t* canvasInkMask(int scale, int* outW, int* outH)
{
    if (canvas.pointCount < 1 || canvas.strokeCount < 1 || scale < 1) return NULL;

    int baseW = glWindowWidth, baseH = glWindowHeight;
    Image img = { 0 };
    img.width  = baseW * scale;
    img.height = baseH * scale;
    img.bin = (uint8_t*)calloc((size_t)img.width * img.height, sizeof(uint8_t));
    if (!img.bin) return NULL;

    computeTraceBounds(baseW, baseH);   // same mapping as canvasToImage, just scaled below

    for (int s = 0; s < canvas.strokeCount; s++)
    {
        int start = strokeStarts[s];
        int end   = (s == canvas.strokeCount - 1) ? canvas.pointCount : strokeStarts[s + 1];
        int count = (end - start) / 2;
        if (count < 1) continue;

        float r = strokeThickness[s] / 2.0f * (float)scale;

        float px0, py0;
        worldToPixel(points[start], points[start + 1], baseW, baseH, &px0, &py0);
        px0 *= scale; py0 *= scale;

        if (count == 1) { stampDisc(&img, px0, py0, r); continue; }

        for (int i = 1; i < count; i++)
        {
            float px1, py1;
            worldToPixel(points[start + i * 2], points[start + i * 2 + 1], baseW, baseH, &px1, &py1);
            px1 *= scale; py1 *= scale;
            stampSegment(&img, px0, py0, px1, py1, r);
            px0 = px1;
            py0 = py1;
        }
    }

    *outW = img.width;
    *outH = img.height;
    return img.bin;
}

Image* canvasToImage(void)
{
    if (canvas.pointCount < 1 || canvas.strokeCount < 1) {
        printf("Canvas is empty - draw a curve first\n");
        return NULL;
    }

    int w = glWindowWidth;
    int h = glWindowHeight;

    Image* img = (Image*)malloc(sizeof(Image));
    if (!img) return NULL;

    img->width  = w;
    img->height = h;
    img->data = (uint8_t*)malloc((size_t)w * h * 3);
    img->bin  = (uint8_t*)calloc((size_t)w * h, sizeof(uint8_t));

    // Parallel EXACT-radius raster (see bmp.h's Image.radius) -- calloc'd
    // to 0 so an unstamped pixel reads as "no known radius" rather than
    // garbage; every pixel setBinPixel actually touches below overwrites
    // its 0 with the real stamped r, which is always > 0.
    img->radius = (float*)calloc((size_t)w * h, sizeof(float));

    if (!img->data || !img->bin || !img->radius) {
        free(img->data);
        free(img->bin);
        free(img->radius);
        free(img);
        return NULL;
    }

    memset(img->data, 255, (size_t)w * h * 3); // white background

    // Fixed, zoom/pan-independent mapping for this trace -- see its own
    // comment. Must run before the stroke loop below (worldToPixel reads
    // the globals it sets) and after canvas.pointCount's own empty check
    // above (it assumes at least one point exists).
    computeTraceBounds(w, h);

    for (int s = 0; s < canvas.strokeCount; s++)
    {
        int start = strokeStarts[s];
        int end   = (s == canvas.strokeCount - 1) ? canvas.pointCount : strokeStarts[s + 1];
        int count = (end - start) / 2;
        if (count < 1) continue;

        // No floor on r here (there used to be one, clamping up to 1.0px)
        // -- stampDisc/stampSegment's own pixel-CENTER test ((x+0.5)-cx,
        // not a bare integer compare) reliably rasterizes a genuine 0.5px
        // disc to at least one real "on" pixel regardless of sub-pixel
        // alignment (verified numerically: 0 empty rasters across a full
        // sweep of offsets), so the floor wasn't actually needed to avoid
        // an invisible stroke. What it WAS doing: at thickness == 1 (the
        // slider's minimum, the only value where this floor ever
        // triggered), it silently inflated the raster's true radius from
        // 0.5 to 1.0 -- pipeline.c's width measurement then faithfully
        // measured that INFLATED 1.0, and canvas_bridge.c's own *2
        // conversion back below took it from there, so the reconstructed
        // line rendered at fully double the actual thickness=1 stroke's
        // width. Letting r go down to its true 0.5 here is what the
        // measurement needs to recover the CORRECT width instead.
        float r = strokeThickness[s] / 2.0f;

        float px0, py0;
        worldToPixel(points[start], points[start + 1], w, h, &px0, &py0);

        if (count == 1) {
            stampDisc(img, px0, py0, r);
            continue;
        }

        for (int i = 1; i < count; i++)
        {
            float px1, py1;
            worldToPixel(points[start + i * 2], points[start + i * 2 + 1], w, h, &px1, &py1);
            stampSegment(img, px0, py0, px1, py1, r);
            px0 = px1;
            py0 = py1;
        }
    }

    return img;
}

void displayImageOnCanvas(Image* img)
{
    int w = img->width;
    int h = img->height;

    uint8_t* rgb = (uint8_t*)malloc((size_t)w * h * 3);
    if (!rgb) return;

    for (int y = 0; y < h; y++) {
        int srcY = h - 1 - y;
        for (int x = 0; x < w; x++) {
            int srcIdx = (srcY * w + x) * 3;
            int dstIdx = (y * w + x) * 3;
            rgb[dstIdx + 0] = img->data[srcIdx + 2];
            rgb[dstIdx + 1] = img->data[srcIdx + 1];
            rgb[dstIdx + 2] = img->data[srcIdx + 0];
        }
    }

    if (canvasTexture == 0) glGenTextures(1, &canvasTexture);
    glBindTexture(GL_TEXTURE_2D, canvasTexture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, rgb);
    free(rgb);

    // NEW: fixed reference bounds (canvas.zoom = 1), computed once here —
    // WM_PAINT must NOT recompute these using the live canvas.zoom value
    float aspect = (float)glWindowWidth / (float)glWindowHeight;
    if (aspect >= 1.0f) {
        bgRight = aspect;  bgLeft = -bgRight;
        bgTop   = 1.0f;    bgBottom = -bgTop;
    } else {
        bgRight = 1.0f;    bgLeft = -bgRight;
        bgTop   = 1.0f / aspect; bgBottom = -bgTop;
    }

    canvas.hasBackgroundImage = TRUE;
    if (hWndGL) InvalidateRect(hWndGL, NULL, TRUE);
}
